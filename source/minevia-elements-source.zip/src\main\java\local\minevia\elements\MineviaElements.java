package local.minevia.elements;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import local.minevia.elements.net.CastPayload;
import local.minevia.elements.net.MenuPayload;
import local.minevia.elements.net.PlayerSkinPayload;
import local.minevia.elements.net.UploadSkinPayload;
import local.minevia.elements.net.StatePayload;
import local.minevia.elements.temple.TemplePiece;
import local.minevia.elements.temple.TempleStructure;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.command.argument.EntityArgumentType;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructurePieceType;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureType;

public class MineviaElements implements ModInitializer {
    public static final String MOD_ID = "minevia_elements";
    public static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger(MOD_ID);
    /** Боссом считается любой враг с таким запасом здоровья, в том числе из других модов. */
    private static final float BOSS_HEALTH = 150.0F;

    public static final Item ELEMENT_CORE = Registry.register(
            Registries.ITEM,
            Identifier.of(MOD_ID, "element_core"),
            new ElementCoreItem(new Item.Settings().maxCount(16).rarity(Rarity.EPIC)));

    public static final EntityType<SpellEntity> SPELL = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(MOD_ID, "spell"),
            EntityType.Builder.<SpellEntity>create(SpellEntity::new, SpawnGroup.MISC)
                    .dimensions(0.5F, 0.5F).maxTrackingRange(8).trackingTickInterval(1)
                    .makeFireImmune().disableSummon().disableSaving().build("spell"));

    public static final Item[] SEALS = {seal("fire"), seal("water"), seal("earth"), seal("air")};

    public static final Block ALTAR = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "altar"),
            new AltarBlock(AbstractBlock.Settings.create().strength(-1.0F, 3600000.0F).nonOpaque().dropsNothing().luminance(state -> 11)));

    public static final Block TRAP = Registry.register(Registries.BLOCK, Identifier.of(MOD_ID, "trap"),
            new TrapBlock(AbstractBlock.Settings.create().strength(4.0F, 6.0F).dropsNothing().luminance(state -> 3)));

    public static final BlockEntityType<AltarBlockEntity> ALTAR_ENTITY = Registry.register(Registries.BLOCK_ENTITY_TYPE,
            Identifier.of(MOD_ID, "altar"), BlockEntityType.Builder.create(AltarBlockEntity::new, ALTAR).build(null));

    public static final EntityType<ElementBoss> BOSS = Registry.register(
            Registries.ENTITY_TYPE,
            Identifier.of(MOD_ID, "element_boss"),
            EntityType.Builder.create(ElementBoss::new, SpawnGroup.MONSTER)
                    .dimensions(2.4F, 3.6F).maxTrackingRange(12).makeFireImmune().build("element_boss"));

    public static final StructureType<TempleStructure> TEMPLE = Registry.register(Registries.STRUCTURE_TYPE,
            Identifier.of(MOD_ID, "temple"), () -> TempleStructure.CODEC);

    public static final StructurePieceType TEMPLE_PIECE = Registry.register(Registries.STRUCTURE_PIECE,
            Identifier.of(MOD_ID, "temple"), (StructurePieceType.Simple) TemplePiece::new);

    private static final int FIND_COOLDOWN = 100;
    private static final Map<UUID, Long> FOUND_AT = new HashMap<>();

    private static Item seal(String element) {
        return Registry.register(Registries.ITEM, Identifier.of(MOD_ID, "seal_" + element),
                new SealItem(new Item.Settings().maxCount(16).rarity(Rarity.RARE)));
    }

    @Override
    public void onInitialize() {
        Sounds.init();
        FabricDefaultAttributeRegistry.register(BOSS, ElementBoss.attributes());
        PayloadTypeRegistry.playC2S().register(CastPayload.ID, CastPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(MenuPayload.ID, MenuPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(UploadSkinPayload.ID, UploadSkinPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(StatePayload.ID, StatePayload.CODEC);
        PayloadTypeRegistry.playS2C().register(PlayerSkinPayload.ID, PlayerSkinPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(CastPayload.ID,
                (payload, context) -> Abilities.cast(context.player(), payload.slot()));
        ServerPlayNetworking.registerGlobalReceiver(MenuPayload.ID,
                (payload, context) -> onMenu(context.player(), payload));
        ServerPlayNetworking.registerGlobalReceiver(UploadSkinPayload.ID,
                (payload, context) -> Skins.upload(context.player(), payload.png()));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS).register(entries -> {
            entries.add(ELEMENT_CORE);
            for (Item seal : SEALS) {
                entries.add(seal);
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            onJoin(handler.getPlayer(), server);
            Skins.sendAll(handler.getPlayer());
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            Abilities.forget(handler.getPlayer().getUuid());
            Skins.forget(handler.getPlayer(), server);
        });
        ServerLivingEntityEvents.AFTER_DEATH.register(MineviaElements::onDeath);
        ServerTickEvents.END_SERVER_TICK.register(Effects::tick);
        ServerTickEvents.END_SERVER_TICK.register(Combos::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> Effects.removeTemporaryBlocks());
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            Effects.clear();
            Combos.clear();
        });
        CommandRegistrationCallback.EVENT.register((dispatcher, registries, environment) -> dispatcher.register(
                CommandManager.literal("elements")
                        .executes(context -> list(context.getSource()))
                        .then(CommandManager.literal("reset")
                                .requires(source -> source.hasPermissionLevel(2))
                                .then(CommandManager.argument("player", EntityArgumentType.player())
                                        .executes(context -> reset(context.getSource(),
                                                EntityArgumentType.getPlayer(context, "player")))))
                        .then(CommandManager.literal("altar")
                                .requires(source -> source.hasPermissionLevel(2))
                                .executes(context -> toAltar(context.getSource().getPlayerOrThrow())))
                        .then(CommandManager.literal("set")
                                .requires(source -> source.hasPermissionLevel(2))
                                .then(CommandManager.argument("player", EntityArgumentType.player())
                                        .then(CommandManager.argument("element", StringArgumentType.word())
                                                .then(CommandManager.argument("level", IntegerArgumentType.integer(1, ElementState.MAX_LEVEL))
                                                        .then(CommandManager.argument("path", IntegerArgumentType.integer(0, 2))
                                                                .executes(context -> set(EntityArgumentType.getPlayer(context, "player"),
                                                                        StringArgumentType.getString(context, "element"),
                                                                        IntegerArgumentType.getInteger(context, "level"),
                                                                        IntegerArgumentType.getInteger(context, "path"))))))))));
    }

    /** Для администратора: перенести к ближайшему алтарю и повернуть лицом к нему. */
    private static int toAltar(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        ChunkPos center = player.getChunkPos();
        for (int dx = -8; dx <= 8; dx++) {
            for (int dz = -8; dz <= 8; dz++) {
                // Только загруженные чанки: чтение остальных заставило бы сервер генерировать мир и зависнуть.
                if (!world.isChunkLoaded(center.x + dx, center.z + dz)) {
                    continue;
                }
                for (BlockEntity entity : world.getChunk(center.x + dx, center.z + dz).getBlockEntities().values()) {
                    if (entity instanceof AltarBlockEntity) {
                        BlockPos at = entity.getPos();
                        player.teleport(world, at.getX() + 3.0, at.getY(), at.getZ() + 0.5, 90.0F, 24.0F);
                        return Command.SINGLE_SUCCESS;
                    }
                }
            }
        }
        return 0;
    }

    /** Выдать игроку стихию, уровень и путь вручную: для администратора мира. */
    private static int set(ServerPlayerEntity player, String element, int level, int path) {
        ElementState state = ElementState.get(player.getServer());
        ElementState.Data data = state.getOrAssign(player.getUuid());
        data.element = Element.valueOf(element.toUpperCase(Locale.ROOT));
        data.level = level;
        data.path = path;
        state.markDirty();
        Abilities.forget(player.getUuid());
        sync(player);
        return Command.SINGLE_SUCCESS;
    }

    private static void onMenu(ServerPlayerEntity player, MenuPayload payload) {
        if (payload.action() == MenuPayload.CHOOSE_PATH) {
            choosePath(player, payload.value());
        } else if (payload.action() == MenuPayload.FIND_TEMPLE) {
            findTemple(player, payload.value());
        }
    }

    private static void choosePath(ServerPlayerEntity player, int path) {
        ElementState state = ElementState.get(player.getServer());
        ElementState.Data data = state.getOrAssign(player.getUuid());
        if (data.level < ElementState.MAX_LEVEL || data.path != 0 || path < 1 || path > 2) {
            return;
        }
        data.path = path;
        state.markDirty();
        player.sendMessage(Text.translatable("message.minevia_elements.path_chosen", Text.translatable(data.element.pathKey(path))), false);
        sync(player);
    }

    /** Подсказка из меню: где ближайший храм и в какую сторону идти. Поиск не дешёвый, поэтому не чаще раза в пять секунд. */
    private static void findTemple(ServerPlayerEntity player, int element) {
        ServerWorld world = player.getServerWorld();
        long now = player.getServer().getTicks();
        if (element < 0 || element >= Element.values().length || FOUND_AT.getOrDefault(player.getUuid(), 0L) > now) {
            return;
        }
        FOUND_AT.put(player.getUuid(), now + FIND_COOLDOWN);
        Element wanted = Element.values()[element];
        if (world.getRegistryKey() != World.OVERWORLD) {
            player.sendMessage(Text.translatable("message.minevia_elements.temple_overworld"), false);
            return;
        }
        TagKey<Structure> tag = TagKey.of(RegistryKeys.STRUCTURE, Identifier.of(MOD_ID, "temple_" + wanted.id()));
        BlockPos found = world.locateStructure(tag, player.getBlockPos(), 120, false);
        if (found == null) {
            player.sendMessage(Text.translatable("message.minevia_elements.temple_none"), false);
            return;
        }
        int dx = found.getX() - player.getBlockX();
        int dz = found.getZ() - player.getBlockZ();
        int distance = (int) Math.hypot(dx, dz);
        int side = Math.floorMod((int) Math.round(Math.toDegrees(Math.atan2(dx, -dz)) / 45), 8);
        player.sendMessage(Text.translatable("message.minevia_elements.temple_found", name(wanted), found.getX(), found.getZ(), distance,
                Text.translatable("direction.minevia_elements." + side)), false);
    }

    private static void onJoin(ServerPlayerEntity player, MinecraftServer server) {
        ElementState state = ElementState.get(server);
        boolean isNew = state.find(player.getUuid()) == null;
        ElementState.Data data = state.getOrAssign(player.getUuid());
        if (isNew) {
            player.sendMessage(Text.translatable("message.minevia_elements.assigned", name(data.element)), false);
        }
        sync(player);
    }

    private static void onDeath(LivingEntity entity, DamageSource source) {
        if (entity instanceof PlayerEntity) {
            return;
        }
        if (entity.getMaxHealth() >= BOSS_HEALTH) {
            entity.dropStack(new ItemStack(ELEMENT_CORE));
        }
        if (entity instanceof Monster && source.getAttacker() instanceof ServerPlayerEntity player) {
            addXp(player);
        }
    }

    private static void addXp(ServerPlayerEntity player) {
        ElementState state = ElementState.get(player.getServer());
        ElementState.Data data = state.getOrAssign(player.getUuid());
        if (data.level != 1) {
            return;
        }
        data.xp++;
        if (data.xp >= ElementState.XP_FOR_LEVEL_TWO) {
            data.level = 2;
            player.sendMessage(Text.translatable("message.minevia_elements.level_up", data.level), true);
        }
        state.markDirty();
        sync(player);
    }

    private static int list(ServerCommandSource source) {
        MinecraftServer server = source.getServer();
        for (Map.Entry<UUID, ElementState.Data> entry : ElementState.get(server).all().entrySet()) {
            ServerPlayerEntity online = server.getPlayerManager().getPlayer(entry.getKey());
            String who = online != null ? online.getName().getString() : entry.getKey().toString().substring(0, 8);
            ElementState.Data data = entry.getValue();
            source.sendFeedback(() -> Text.literal(who + ": ").append(name(data.element)).append(" " + data.level), false);
        }
        return Command.SINGLE_SUCCESS;
    }

    private static int reset(ServerCommandSource source, ServerPlayerEntity player) {
        ElementState state = ElementState.get(source.getServer());
        state.remove(player.getUuid());
        ElementState.Data data = state.getOrAssign(player.getUuid());
        Abilities.forget(player.getUuid());
        player.sendMessage(Text.translatable("message.minevia_elements.assigned", name(data.element)), false);
        sync(player);
        return Command.SINGLE_SUCCESS;
    }

    private static MutableText name(Element element) {
        return Text.translatable(element.key()).withColor(element.color);
    }

    public static void sync(ServerPlayerEntity player) {
        ElementState.Data data = ElementState.get(player.getServer()).getOrAssign(player.getUuid());
        int[] left = Abilities.remaining(player);
        if (ServerPlayNetworking.canSend(player, StatePayload.ID)) {
            ServerPlayNetworking.send(player,
                    new StatePayload(data.element.ordinal(), data.level, data.xp, data.path, Arrays.stream(left).boxed().toList()));
        }
    }
}
