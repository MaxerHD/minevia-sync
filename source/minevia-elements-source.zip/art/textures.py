# Рисует текстуры блоков и предметов храмов: каменные плиты с резьбой и печати. Запуск: python textures.py
import os
import struct
import zlib

import numpy as np

ROOT = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements\textures"
COLORS = {"fire": (255, 138, 61), "water": (92, 200, 255), "earth": (168, 212, 104), "air": (228, 240, 246)}
BASES = {"fire": (46, 40, 44), "water": (34, 74, 80), "earth": (86, 90, 74), "air": (214, 214, 208)}


def png(path, rgba):
    h, w, _ = rgba.shape
    raw = b"".join(b"\0" + rgba[y].astype(np.uint8).tobytes() for y in range(h))

    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as out:
        out.write(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
                  + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


def stone(base, seed):
    """Плита: шершавый камень с тёмной рамкой по краю."""
    rng = np.random.default_rng(seed)
    grain = rng.normal(size=(16, 16, 1)) * 7
    img = np.array(base, dtype=float)[None, None, :] + grain
    img[0, :] *= 0.72
    img[15, :] *= 0.72
    img[:, 0] *= 0.72
    img[:, 15] *= 0.72
    return img


def rune(img, color, kind):
    """Вырезанный знак стихии: по нему игрок заранее видит, какая ловушка под ногами."""
    mark = np.zeros((16, 16), dtype=bool)
    y, x = np.mgrid[0:16, 0:16] - 7.5
    if kind == "fire":
        mark = (np.abs(x) + np.abs(y + 1) * 0.6 < 5) & (np.abs(x) + np.abs(y + 1) * 0.6 > 3.2)
    elif kind == "water":
        mark = (np.abs(np.sin(x * 0.75) * 2.2 - y + 2.5) < 0.9) | (np.abs(np.sin(x * 0.75) * 2.2 - y - 2.5) < 0.9)
        mark &= np.abs(x) < 6
    elif kind == "earth":
        mark = (np.maximum(np.abs(x), np.abs(y)) < 5) & (np.maximum(np.abs(x), np.abs(y)) > 3.4)
    else:
        r = np.hypot(x, y)
        mark = (np.abs(r - 4.6) < 0.9) & (np.sin(np.arctan2(y, x) * 3 + r) > -0.3)
    img = img.copy()
    img[mark] = np.array(color, dtype=float) * 0.95
    return img


def with_alpha(img):
    return np.concatenate([np.clip(img, 0, 255), np.full((16, 16, 1), 255.0)], axis=2)


def seal(color, kind):
    """Печать: круглая каменная пластина со знаком стихии."""
    y, x = np.mgrid[0:16, 0:16] - 7.5
    r = np.hypot(x, y)
    img = np.zeros((16, 16, 4))
    disc = r <= 7.2
    edge = disc & (r > 5.9)
    img[disc, :3] = (44, 40, 52)
    img[edge, :3] = np.array(color) * 0.75
    img[disc, 3] = 255
    marked = rune(np.zeros((16, 16, 3)), color, kind)
    glow = (marked.sum(axis=2) > 0) & (r < 5.8)
    img[glow, :3] = color
    return img


for name, color in COLORS.items():
    png(os.path.join(ROOT, "block", f"trap_{name}.png"), with_alpha(rune(stone(BASES[name], 7), color, name)))
    png(os.path.join(ROOT, "item", f"seal_{name}.png"), seal(color, name))
top = stone((58, 56, 66), 11)
y, x = np.mgrid[0:16, 0:16] - 7.5
top[np.abs(np.hypot(x, y) - 5) < 0.9] = (150, 130, 190)
png(os.path.join(ROOT, "block", "altar_top.png"), with_alpha(top))
side = stone((48, 46, 56), 12)
side[6:8, 1:15] = (120, 104, 160)
png(os.path.join(ROOT, "block", "altar_side.png"), with_alpha(side))
print("Текстуры готовы")
