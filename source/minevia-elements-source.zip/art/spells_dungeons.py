# Дополнительные модели. Исполняется из spells.py, существующие модели не меняет.

D_IRON = np.array([0.20, 0.22, 0.25])
D_BRONZE = np.array([0.55, 0.28, 0.10])
D_SHELL = np.array([0.42, 0.55, 0.50])
D_VOID = np.array([0.15, 0.10, 0.25])


def dungeon_skin(pos, quads, color, t=0, glow=None):
    grain = Flow(1801, freq=5, octaves=2, speed=0)(pos, 0)
    seams = Flow(1803, freq=3.3, octaves=3, speed=0)(pos, 0)
    crust = np.clip(1 - np.abs(seams) * 15, 0, 1)[:, None]
    rgb = baked(pos, quads, color * (0.75 + 0.55 * grain[:, None])) * (1 - crust * 0.8)
    pits = Flow(1804, freq=13, octaves=2, speed=0)(pos, 0)
    rgb *= (0.65 + 0.35 * np.clip(pits[:, None] + 0.5, 0, 1))
    if glow is not None:
        vein = Flow(1802, freq=2.6, octaves=2, speed=0)(pos, 0)
        crack = np.clip(1 - np.abs(vein) * 22, 0, 1)[:, None] * (0.7 + 0.3 * math.sin(TAU * t) ** 2)
        rgb = rgb * (1 - crack) + np.array(glow) * crack
    return rgba(rgb, np.ones(len(pos)))


def dungeon_place(shape, at, color, t=0, glow=None, turn=None):
    p, q = shape[:2]
    p = p @ turn.T if turn is not None else p.copy()
    p += np.array(at)
    return p, q, dungeon_skin(p, q, color, t, glow)


def dungeon_rock(seed, scale, cuts=3):
    # Кованые грани со срезанными углами, без округлого шарообразного объёма.
    p, q = cube_sphere(max(cuts, 5))
    p /= np.maximum(np.abs(p).max(axis=1, keepdims=True), 1e-6)
    for axis in range(3):
        for a in (-1, 1):
            for b in (-1, 1):
                n = np.zeros(3)
                n[axis], n[(axis + 1) % 3] = a, b
                n /= np.linalg.norm(n)
                p -= np.maximum(p @ n - 1.2, 0)[:, None] * n
    grain = Flow(seed, freq=8, octaves=2, speed=0)(p, 0)
    p *= (1 + 0.012 * grain[:, None])
    p *= np.array(scale)
    return p, q, np.ones((len(p), 4))


def dungeon_tube(points, radius, color, sides=8):
    points = np.asarray(points)
    p = tube(points, np.broadcast_to(radius, len(points)), sides)
    q = grid(sides, len(points))
    rgb = np.broadcast_to(np.array(color), (len(p), 3))
    return p, q, rgba(baked(p, q, rgb), np.ones(len(p)))


def dungeon_ring(radius, height, width, color, t=0, tilt=None, at=(0, 0, 0)):
    a = np.linspace(0, TAU, 65)
    points = np.stack([radius * np.cos(a), np.full(len(a), height), radius * np.sin(a)], axis=1)
    if tilt is not None:
        points = points @ tilt.T
    return dungeon_tube(points + np.array(at), width, color)


def dungeon_save(name, frames):
    result = []
    topology = None
    for parts in frames:
        p, q, c = merged(parts)
        if topology is None:
            topology = q
        assert np.array_equal(topology, q), name + ": topology changed"
        assert np.isfinite(p).all() and np.isfinite(c).all(), name + ": invalid geometry"
        assert len(p) < 65536, name + ": too many vertices"
        result.append((p, c))
    save(name, result, topology)


def boss_smith():
    """Пустой обожжённый доспех: перекрывающиеся пластины, заклёпки и молот с раскалённым швом."""
    chest = dungeon_rock(1810, (0.66, 0.62, 0.4), 6)
    shoulder = dungeon_rock(1811, (0.49, 0.27, 0.46), 4)
    limb = dungeon_rock(1812, (0.24, 0.37, 0.25))
    boot = dungeon_rock(1813, (0.29, 0.17, 0.4))
    plate = dungeon_rock(1814, (0.29, 0.17, 0.09))
    helmet = lathe([(0.32, 2.42), (0.42, 2.53), (0.4, 2.94), (0.28, 3.17), (0.06, 3.25)], 16)
    rivet, rivet_q, *_ = sphere(6, 5, axis=1)
    head = dungeon_rock(1815, (0.76, 0.4, 0.4), 5)
    frames = []
    for f in range(24):
        t = f / 24
        swing = math.sin(TAU * t)
        bob = 0.025 * abs(swing)
        parts = [dungeon_place(chest, (0, 1.98 + bob, 0), D_IRON, t, (1, 0.29, 0.025)),
                 dungeon_place(helmet, (0, bob, 0), D_IRON * 1.2, t, (0.7, 0.13, 0.01))]
        for row in range(4):
            for side in (-1, 1):
                parts.append(dungeon_place(plate, (side * 0.3, 1.6 + row * 0.23 + bob, 0.4 - row * 0.01), D_IRON * (1.3 + row * 0.06), t))
                parts.append(dungeon_place((rivet * 0.042, rivet_q), (side * 0.49, 1.6 + row * 0.23 + bob, 0.49), D_BRONZE))
        # Прорезь забрала утоплена под тяжёлым надбровьем.
        parts.append(dungeon_tube([(-0.27, 2.82, 0.35), (0, 2.8, 0.4), (0.27, 2.82, 0.35)], 0.025, (1, 0.5, 0.07)))
        for side in (-1, 1):
            # Зазубренные наплечники и прорези вместо гладких округлых плеч.
            for spike in range(3):
                cp, cq = crystal(0.32 + spike * 0.06, 0.065, 4)
                parts.append(dungeon_place((cp, cq), (side * (0.72 + spike * 0.2), 2.58 - spike * 0.03, -0.08), D_IRON * 1.7, t, turn=rotation((0, 0, 1), -side * 0.7)))
            for vent in range(4):
                parts.append(dungeon_tube([(side * 0.1, 2.56 + vent * 0.045, 0.385), (side * 0.28, 2.56 + vent * 0.045, 0.34)], 0.012, (0.012, 0.009, 0.008)))
        parts.append(dungeon_tube([(-0.4, 2.89, 0.34), (0, 2.91, 0.44), (0.4, 2.89, 0.34)], 0.065, D_IRON * 1.8))
        for side in (-1, 1):
            for layer in range(3):
                parts.append(dungeon_place(shoulder, (side * (0.79 + layer * 0.08), 2.47 - layer * 0.13 + bob, 0), D_IRON * (1.25 - layer * 0.1), t))
            for y in (1.92, 1.48):
                parts.append(dungeon_place(limb, (side * 1.0, y + bob + side * swing * 0.08, 0.08), D_IRON, t, (0.75, 0.15, 0.01)))
            for y in (0.93, 0.43):
                parts.append(dungeon_place(limb, (side * 0.36, y, side * swing * 0.12), D_IRON * 1.1, t))
            parts.append(dungeon_place(boot, (side * 0.36, 0.17, 0.17 + side * swing * 0.12), D_IRON))
            # Стальные полосы передника, отдельные края обиты медью.
            for strip in range(3):
                parts.append(dungeon_place(plate, (side * (0.12 + strip * 0.17), 1.28 - strip * 0.06, 0.4), D_BRONZE * 0.55, t, (0.55, 0.11, 0.01), rotation((1, 0, 0), 0.25)))
        hand = np.array([1.0, 1.46 + swing * 0.08, 0.15])
        hammer_turn = rotation((1, 0, 0), 0.35 + 0.15 * swing)
        top = hand + np.array([0, 1.22, 0]) @ hammer_turn.T
        parts.append(dungeon_tube([hand - np.array([0, 0.5, 0]), hand, top], 0.09, (0.22, 0.14, 0.075)))
        parts.append(dungeon_place(head, top, D_IRON * 1.1, t, (1, 0.32, 0.025), hammer_turn))
        for side in (-1, 1):
            parts.append(dungeon_ring(0.3, 0, 0.045, D_BRONZE, tilt=rotation((0, 0, 1), math.pi / 2), at=top + np.array([side * 0.55, 0, 0])))
        frames.append(parts)
    dungeon_save("boss_smith", frames)


def boss_keeper():
    """Водяной торс под слоями древних раковин, рёбра брони и корона из ледяных игл."""
    dirs, ball, *_ = sphere(28, 22, axis=1)
    # Раковина с радиальными рёбрами и сколотой кромкой.
    shell_p, shell_q, *_ = sphere(42, 30, axis=1)
    theta = np.arctan2(shell_p[:, 0], shell_p[:, 1])
    ridges = 1 + 0.08 * np.cos(theta * 17)
    shell_p *= ridges[:, None] * np.array([0.42, 0.5, 0.14])
    shell = (shell_p, shell_q)
    arm = dungeon_rock(1841, (0.19, 0.32, 0.19), 4)
    crystal_p, crystal_q = crystal(0.55, 0.08, 5)
    profile = [(0.06, 0), (0.42, 0.3), (0.25, 0.7), (0.46, 1.2), (0.65, 1.8), (0.45, 2.3)]
    body, body_q = lathe(profile, 48)
    ripple = Flow(1842, freq=3.3, octaves=3, speed=2)
    frames = []
    for f in range(28):
        t = f / 28
        n = ripple(body, t)
        water = body * (1 + 0.065 * n[:, None])
        parts = [(water, body_q, rgba(ramp(np.clip(0.5 + 0.4 * n, 0, 1), WATER), np.full(len(body), 0.85)))]
        for side in (-1, 1):
            for layer in range(3):
                turn = rotation((0, 0, 1), side * (0.28 + 0.06 * layer))
                parts.append(dungeon_place(shell, (side * (0.32 + layer * 0.06), 1.82 - layer * 0.11, 0.37 + layer * 0.045), D_SHELL * (0.8 + layer * 0.13), t, turn=turn))
            for rib in range(8):
                x = side * (0.09 + rib * 0.08)
                parts.append(dungeon_tube([(x * 0.8, 2.23, 0.5), (x, 1.93, 0.62), (x * 0.7, 1.55, 0.57)], 0.012, D_SHELL * 1.35))
            for segment in range(3):
                parts.append(dungeon_place(arm, (side * (0.77 + segment * 0.1), 2.03 - segment * 0.32 + 0.06 * math.sin(TAU * t + side), 0.05 + segment * 0.1), D_SHELL * 0.8, t))
        skull = dirs * np.array([0.3, 0.44, 0.23]) + np.array([0, 2.62, 0])
        parts.append((skull, ball, dungeon_skin(skull, ball, D_SHELL, t)))
        for side in (-1, 1):
            parts.append(dungeon_tube([(side * 0.08, 2.66, 0.31), (side * 0.26, 2.7, 0.26)], 0.026, (0.47, 1, 0.94)))
        for i in range(7):
            a = i / 7 * TAU
            parts.append(dungeon_place((crystal_p, crystal_q), (math.cos(a) * 0.28, 2.86, math.sin(a) * 0.22), D_SHELL * 1.5, t, turn=rotation((math.sin(a), 0, -math.cos(a)), 0.35)))
        for layer in range(3):
            a = np.linspace(0, TAU * 1.8, 56)
            radius = 0.4 + np.linspace(0, 0.6, len(a))
            points = np.stack([radius * np.cos(a + TAU * t + layer), np.linspace(0.1, 1.2, len(a)), radius * np.sin(a + TAU * t + layer)], axis=1)
            parts.append(dungeon_tube(points, np.linspace(0.02, 0.08, len(a)), (0.025, 0.23, 0.3)))
        frames.append(parts)
    dungeon_save("boss_keeper", frames)


def boss_astronomer():
    """Тёмная фигура в рваном звёздном облачении, медная астролябия и острые парящие пластины."""
    nu, nv = 48, 26
    angle = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    robe_q = grid(nu, nv)
    hood = dungeon_rock(1860, (0.31, 0.5, 0.31), 5)
    blade = (lambda p, q: (p - np.array([0, 0.6, 0]), q))(*crystal(1.2, 0.13, 4))
    hand = dungeon_rock(1862, (0.14, 0.2, 0.12), 3)
    frames = []
    for f in range(28):
        t = f / 28
        radius = 0.34 + 0.48 * (1 - s) ** 2 + 0.035 * np.sin(angle * 12)
        hem = (1 - s) ** 4 * (0.24 + 0.22 * np.cos(angle * 9))
        robe = np.stack([radius * np.cos(angle), 0.2 + s * 2.0 + hem + 0.03 * np.sin(angle * 4 + TAU * t), radius * np.sin(angle)], axis=1)
        tone = (0.85 + 0.22 * np.sin(angle * 12))[:, None]
        rgb = baked(robe, robe_q, D_VOID * tone)
        trim = (np.abs(np.sin(angle * 6)) < 0.13) | (s > 0.95) | (s < 0.05)
        rgb[trim] = np.array([0.12, 0.055, 0.025])
        parts = [(robe, robe_q, rgba(rgb, np.ones(len(robe)))), dungeon_place(hood, (0, 2.52, 0), D_VOID * 1.3, t)]
        # Лицо скрыто в щели, свет виден только из глубоких глазниц.
        parts.append(dungeon_tube([(-0.16, 2.55, 0.33), (-0.08, 2.57, 0.37)], 0.019, (0.8, 0.67, 1)))
        parts.append(dungeon_tube([(0.16, 2.55, 0.33), (0.08, 2.57, 0.37)], 0.019, (0.8, 0.67, 1)))
        for side in (-1, 1):
            points = [(side * 0.4, 2.0, 0), (side * 0.7, 1.67, 0.05), (side * 0.9, 1.85 + 0.06 * math.sin(TAU * t), 0.42)]
            parts.append(dungeon_tube(points, np.array([0.14, 0.09, 0.045]), D_VOID * 1.6))
            parts.append(dungeon_place(hand, points[-1], D_BRONZE * 0.5, t))
            for finger in range(3):
                x, y, z = points[-1]
                parts.append(dungeon_tube([(x + side * finger * 0.05, y, z), (x + side * finger * 0.05, y - 0.22, z + 0.12)], 0.022, D_BRONZE))
        for i in range(8):
            a = i / 8 * TAU + TAU * t
            parts.append(dungeon_place(blade, (math.cos(a) * 1.25, 1.4 + math.sin(a * 2) * 0.15, math.sin(a) * 1.25), D_BRONZE * 0.9, t, turn=rotation((0, 1, 0), -a)))
        # Тяжёлые бронзовые ламели на воротнике и знаки созвездий на ткани.
        for i in range(10):
            a = i / 10 * TAU
            cp, cq = crystal(0.45, 0.09, 4)
            parts.append(dungeon_place((cp, cq), (math.cos(a) * 0.42, 1.95, math.sin(a) * 0.42), D_BRONZE, t, turn=rotation((math.sin(a), 0, -math.cos(a)), 0.7)))
        for i in range(7):
            y = 0.7 + i * 0.17
            x = math.sin(i * 2.5) * 0.17
            parts.append(dungeon_tube([(x - 0.025, y, 0.5), (x + 0.025, y + 0.03, 0.5)], 0.009, (0.4, 0.3, 0.65), 4))
        at = (0.9, 2.35, 0.6)
        for axis, turn in [((1, 0, 0), 0.5), ((0, 0, 1), 1.1), ((1, 0, 0), math.pi / 2)]:
            parts.append(dungeon_ring(0.47, 0, 0.027, D_BRONZE * 1.5, tilt=rotation(axis, turn + TAU * t), at=at))
        parts.append(dungeon_ring(0.57, 2.84, 0.025, D_BRONZE))
        frames.append(parts)
    dungeon_save("boss_astronomer", frames)


def forge_wave():
    frames = []
    nu, nv = 72, 7
    a = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    r = np.repeat(np.linspace(0.83, 1.08, nv), nu)
    q = grid(nu, nv)
    for f in range(20):
        t = f / 20
        height = (0.09 + 0.12 * np.sin(a * 17 + t * TAU)) * np.sin((r - 0.83) / 0.25 * math.pi)
        p = np.stack([r * np.cos(a), height + 0.04, r * np.sin(a)], axis=1)
        h = np.clip(0.35 + 0.4 * np.sin(a * 13 + t * TAU) + height, 0, 1)
        frames.append([(p, q, rgba(ramp(h, FIRE), np.ones(len(p))))])
    dungeon_save("forge_wave", frames)


def hot_billet():
    shape = dungeon_rock(1880, (0.3, 0.27, 0.75), 5)
    frames = []
    for f in range(16):
        parts = [dungeon_place(shape, (0, 0, 0), D_IRON, f / 16, (1, 0.42, 0.035))]
        for side in (-1, 1):
            parts.append(dungeon_tube([(side * 0.18, -0.1, -0.65), (side * 0.21, 0.14, 0), (side * 0.16, 0, 0.68)], 0.018, (1, 0.7, 0.14)))
        frames.append(parts)
    dungeon_save("hot_billet", frames)


def heat_burst():
    # Объёмная корона жара: трубки с замкнутым сечением, без спрайтов.
    frames = []
    for f in range(20):
        t = f / 19
        parts = []
        for i in range(12):
            a = i / 12 * TAU
            k = np.linspace(0, 1, 22)
            radius = (0.08 + 0.88 * t) * k
            points = np.stack([radius * np.cos(a + k * 0.3), 0.06 + np.sin(k * math.pi) * 0.5 * (1 - t * 0.5), radius * np.sin(a + k * 0.3)], axis=1)
            parts.append(dungeon_tube(points, (0.01 + 0.035 * np.sin(k * math.pi)) * (1 - t * 0.8), (1, 0.28 + t * 0.2, 0.035)))
        frames.append(parts)
    dungeon_save("heat_burst", frames)


def depth_vortex():
    frames = []
    for f in range(24):
        t = f / 24
        parts = []
        for i in range(5):
            k = np.linspace(0, 1, 72)
            a = k * TAU * 2 + i * TAU / 5 - TAU * t
            r = 0.12 + k * 1.5
            points = np.stack([r * np.cos(a), k * 1.1, r * np.sin(a)], axis=1)
            parts.append(dungeon_tube(points, 0.035 + 0.045 * k, (0.12 + i * 0.03, 0.46 + i * 0.05, 0.65 + i * 0.05)))
        frames.append(parts)
    dungeon_save("depth_vortex", frames)


def depth_spear():
    p, q = crystal(1.6, 0.12, 6)
    p = p @ rotation((1, 0, 0), math.pi / 2).T
    frames = []
    for f in range(16):
        t = f / 16
        parts = [(p, q, dungeon_skin(p, q, np.array([0.4, 0.74, 0.91]) * (0.9 + 0.1 * math.sin(TAU * t))))]
        for side in (-1, 1):
            parts.append(dungeon_tube([(0, 0, 0.1), (side * 0.16, 0, 0.45), (0, 0, 0.7)], 0.018, (0.8, 0.97, 1)))
        frames.append(parts)
    dungeon_save("depth_spear", frames)


def depth_heal():
    frames = []
    for f in range(24):
        t = f / 24
        parts = []
        for i in range(3):
            k = np.linspace(0, 1, 52)
            a = k * TAU * 1.2 + TAU * (i / 3 + t)
            r = 0.5 + 0.1 * np.sin(k * 8 - TAU * t)
            points = np.stack([r * np.cos(a), k * 1.7, r * np.sin(a)], axis=1)
            parts.append(dungeon_tube(points, 0.022 + 0.02 * np.sin(k * math.pi), (0.23, 0.87, 0.72)))
        frames.append(parts)
    dungeon_save("depth_heal", frames)


def falling_star():
    core = dungeon_rock(1890, (0.33, 0.33, 0.52), 4)
    frames = []
    for f in range(16):
        t = f / 16
        parts = [dungeon_place(core, (0, 0, 0), np.array([0.43, 0.28, 0.62]), t, (0.9, 0.8, 1))]
        for i in range(6):
            a = i / 6 * TAU
            k = np.linspace(0, 1, 25)
            r = (0.05 + k * 0.2) * (1 - k)
            points = np.stack([r * np.cos(a + k * 7 + TAU * t), r * np.sin(a + k * 7 + TAU * t), -k * 2.8], axis=1)
            parts.append(dungeon_tube(points, (0.035 * (1 - k) + 0.003), (0.74, 0.57, 1)))
        frames.append(parts)
    dungeon_save("falling_star", frames)


def star_field():
    frames = []
    for f in range(24):
        t = f / 24
        parts = []
        for i in range(3):
            parts.append(dungeon_ring(0.38 + i * 0.3, 0.07 + 0.025 * math.sin(TAU * t + i), 0.009, (0.51, 0.35, 0.78)))
        for i in range(12):
            a = i / 12 * TAU + TAU * t * 0.08
            p, q = crystal(0.08 + (i % 3) * 0.025, 0.025, 4)
            parts.append(dungeon_place((p, q), (math.cos(a) * 0.8, 0.08, math.sin(a) * 0.8), np.array([0.8, 0.7, 1]), t))
            if i % 2 == 0:
                b = a + TAU * 5 / 12
                parts.append(dungeon_tube([(math.cos(a) * 0.8, 0.08, math.sin(a) * 0.8), (math.cos(b) * 0.8, 0.08, math.sin(b) * 0.8)], 0.005, (0.4, 0.26, 0.65), 4))
        frames.append(parts)
    dungeon_save("star_field", frames)


def dungeon_arc(name, palette):
    frames = []
    for f in range(16):
        t = f / 16
        parts = []
        for layer in range(4):
            k = np.linspace(-1.2, 1.2, 64)
            r = 0.8 + layer * 0.06
            points = np.stack([r * np.sin(k), 0.1 * np.sin(k * 7 + TAU * t), r * np.cos(k)], axis=1)
            rgb = ramp(np.array([0.3 + layer * 0.22]), palette)[0]
            parts.append(dungeon_tube(points, (0.025 + layer * 0.008) * np.maximum(0.05, np.cos(k)), rgb))
        frames.append(parts)
    dungeon_save(name, frames)


def cinder_arc():
    dungeon_arc("cinder_arc", FIRE)


def soul_cleave():
    dungeon_arc("soul_cleave", WATER)


def tidal_dash():
    frames = []
    for f in range(16):
        t = f / 16
        parts = []
        for i in range(5):
            a = i / 5 * TAU
            k = np.linspace(0, 1, 42)
            r = 0.12 + k * 0.64
            points = np.stack([r * np.cos(a + k * 2 + t * TAU), r * np.sin(a + k * 2 + t * TAU), 0.8 - k * 1.8], axis=1)
            parts.append(dungeon_tube(points, (0.015 + 0.045 * k) * np.sin(k * math.pi) + 0.003, (0.16, 0.62 + i * 0.06, 0.84)))
        frames.append(parts)
    dungeon_save("tidal_dash", frames)


def gravity_knot():
    core = dungeon_rock(1895, (0.13, 0.13, 0.13))
    frames = []
    for f in range(24):
        t = f / 24
        parts = [dungeon_place(core, (0, 0, 0), D_VOID, t, (0.72, 0.42, 1))]
        for i in range(3):
            parts.append(dungeon_ring(0.45 + i * 0.07, 0, 0.025, (0.65, 0.46, 0.89), tilt=rotation((1, i * 0.6, 0), TAU * t + i)))
        frames.append(parts)
    dungeon_save("gravity_knot", frames)
