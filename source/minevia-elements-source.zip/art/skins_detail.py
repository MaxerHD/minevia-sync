"""Детали HD-скинов поверх общей обработки: джинсы, обувь, волосы прядями, капюшоны и аксессуары.

Координаты здесь в пикселях HD-скина 128x128. Развёртка частей тела та же, что у обычного скина,
только вдвое крупнее. Внешний слой у всех четырёх персонажей был пустым: аксессуары кладутся туда
и поэтому чуть выступают над телом, как настоящие часы или браслет.
"""
import math

K = 2


def rgb(h):
    return tuple(bytes.fromhex(h[1:])) + (255,)


# Что у кого: обувь (верх, подошва, вид), капюшон, ребристые манжеты и аксессуары.
# Аксессуары подобраны так, чтобы персонажа узнавали сразу, но рисунок одежды остался прежним.
CHARACTERS = {
    "Alither": {"shoes": ("#202024", "#e6e3dd", "sneaker"), "hood": False, "rib": True,
                "extras": ["chain", ("watch", "left", "#1b1b1e", "#c9ccd2")]},
    "Master of slaves": {"shoes": None, "hood": True, "rib": True,
                         "extras": [("band", "right", "#16161a")]},
    "Niga": {"shoes": ("#3b261b", "#22160f", "leather"), "hood": False, "rib": False,
             "extras": ["shirt_back", ("watch", "left", "#5a3a24", "#e2bc62")]},
    "Zlauka": {"shoes": ("#e9e7e2", "#bdb7ae", "sneaker"), "hood": True, "rib": False,
               "extras": [("beads", "right")]},
}


def face_rect(uv, size, side):
    w, h, d = size
    u, v = uv
    rect = {
        "top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h), "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h), "back": (u + d + w + d, v + d, w, h),
    }[side]
    return tuple(c * K for c in rect)


def mul(p, f, add=0):
    return tuple(max(0, min(255, int(round(c * f + add)))) for c in p[:3]) + (255,)


def luma(p):
    return 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]


def base_color(src, rect64):
    """Средний цвет ткани в исходнике: от него строится новая фактура без грязного шума."""
    x, y, w, h = rect64
    px = [src.getpixel((x + i, y + j)) for j in range(h) for i in range(w)]
    px = [p for p in px if p[3]]
    return tuple(sum(p[c] for p in px) // len(px) for c in range(3)) + (255,)


# ---------- джинсы и обувь ----------

LEGS = [  # развёртка основы, внешний бок, внутренняя сторона на виде спереди
    ((0, 16), "right", "inner_right"),
    ((16, 48), "left", "inner_left"),
]


def pants(dst, src, info):
    shoes = info["shoes"]
    for uv, outer, inner in LEGS:
        c = base_color(src, (uv[0] + 4, uv[1] + 4, 4, 8))
        stop = 20 if shoes else own_shoes(src, uv)
        for side in ("front", "back", "right", "left"):
            x0, y0, w, h = face_rect(uv, (4, 12, 4), side)
            for y in range(stop):
                for x in range(w):
                    X, Y = x0 + x, y0 + y
                    if src.getpixel((X // K, Y // K))[3] == 0:
                        continue
                    f = 1.05 - 0.12 * (y / 24)
                    # Диагональное переплетение джинсовой ткани.
                    f *= 1.05 if (X - Y) % 4 == 0 else 0.97 if (X - Y) % 4 == 2 else 1.0
                    if x in (0, w - 1):
                        f *= 0.9
                    dst.putpixel((X, Y), mul(c, f))
            if side in ("front", "back"):
                # Ноги разделены: внутренний край темнее.
                edge = w - 1 if (outer == "right") == (side == "front") else 0
                for y in range(stop):
                    dst.putpixel((x0 + edge, y0 + y), mul(c, 0.68))
            if side == outer:
                for y in range(stop):
                    dst.putpixel((x0 + w // 2, y0 + y), mul(c, 0.8 if y % 3 else 1.25))
            if side == "front":
                # Передний карман: косой вырез от пояса к боковому шву.
                pts = [(5, 0), (4, 1), (3, 2), (2, 3), (1, 4), (0, 5)]
                for px, py in pts:
                    xx = px if outer == "right" else w - 1 - px
                    dst.putpixel((x0 + xx, y0 + py), mul(c, 0.62))
                    if 0 <= xx + (1 if outer == "right" else -1) < w:
                        dst.putpixel((x0 + xx + (1 if outer == "right" else -1), y0 + py), mul(c, 1.18))
                # Складки на колене.
                for px, py in ((2, 12), (3, 12), (4, 11), (5, 11), (3, 14), (4, 14)):
                    xx = px if outer == "right" else w - 1 - px
                    dst.putpixel((x0 + xx, y0 + py), mul(c, 1.22))
            if side == "back":
                # Накладной карман: чуть темнее ткани, светлая строчка только по верхнему краю, бока в тени.
                for x in range(1, 7):
                    for y in range(3, 9):
                        if y == 3:
                            p = mul(c, 1.3, 6)
                        elif x in (1, 6) or y == 8:
                            p = mul(c, 0.8)
                        else:
                            p = mul(dst.getpixel((x0 + x, y0 + y)), 0.94)
                        dst.putpixel((x0 + x, y0 + y), p)
            if shoes:
                # Подворот над обувью.
                for x in range(w):
                    dst.putpixel((x0 + x, y0 + 19), mul(c, 1.25))
                    dst.putpixel((x0 + x, y0 + 18), mul(c, 0.8))
        if shoes:
            shoe(dst, uv, shoes)


def own_shoes(src, uv):
    """Если обувь уже нарисована в исходнике (светлые нижние строки ноги), джинсы заканчиваются над ней."""
    x, y, w, h = face_rect(uv, (4, 12, 4), "front")
    for row in range(6, 12):
        if any(luma(src.getpixel((x // K + i, y // K + row))) > 140 for i in range(4)):
            return row * K
    return 24


def shoe(dst, uv, spec):
    upper, sole, kind = rgb(spec[0]), rgb(spec[1]), spec[2]
    for side in ("front", "back", "right", "left"):
        x0, y0, w, h = face_rect(uv, (4, 12, 4), side)
        for x in range(w):
            for y in range(20, 24):
                if y == 23:
                    p = sole
                elif y == 22:
                    p = mul(sole, 0.85) if kind == "sneaker" else mul(upper, 0.7)
                else:
                    p = mul(upper, 1.08 if y == 20 else 1.0)
                if x in (0, w - 1):
                    p = mul(p, 0.88)
                dst.putpixel((x0 + x, y0 + y), p)
        if side == "front":
            if kind == "sneaker":
                lace = mul(sole, 1.0) if luma(upper) < 120 else mul(upper, 0.6)
                for x in (2, 4, 3, 5):
                    dst.putpixel((x0 + x, y0 + 20 + (x % 2)), lace)
            else:
                # Блик на носке кожаного ботинка.
                for x in (2, 3, 4, 5):
                    dst.putpixel((x0 + x, y0 + 21), mul(upper, 1.55, 10))
    x0, y0, w, h = face_rect(uv, (4, 12, 4), "bottom")
    for x in range(w):
        for y in range(h):
            dst.putpixel((x0 + x, y0 + y), mul(sole, 0.8 if (x + y) % 3 == 0 else 0.9))


# ---------- волосы ----------

def is_hair_px(src, x, y):
    p = src.getpixel((x, y))
    if p[3] == 0 or luma(p) >= 80:
        return False
    r, g, b = p[:3]
    skinlike = r > g > b and r - b > 30 and luma(p) > 90
    return not skinlike


def hair_mean(src, uv, side):
    x0, y0, w, h = face_rect(uv, (8, 8, 8), side)
    px = [src.getpixel((x0 // K + i, y0 // K + j)) for j in range(h // K) for i in range(w // K)]
    px = [p for p in px if p[3] and luma(p) < 80]
    if not px:
        return (40, 40, 40)
    return tuple(sum(p[c] for p in px) // len(px) for c in range(3))


def hair(dst, src):
    """Пряди вместо шума: на макушке расходятся от вихра, на затылке и висках идут сверху вниз."""
    means = {}
    for uv in ((0, 0), (32, 0)):
        for side in ("top", "back", "right", "left", "front"):
            x0, y0, w, h = face_rect(uv, (8, 8, 8), side)
            for y in range(h):
                for x in range(w):
                    X, Y = x0 + x, y0 + y
                    if side == "front" and y >= 6:
                        continue
                    if not is_hair_px(src, X // K, Y // K):
                        continue
                    p = src.getpixel((X // K, Y // K))
                    # Пёстрый исходник сглаживается к среднему цвету волос этой грани, иначе пряди тонут в шуме.
                    m = means.setdefault((uv, side), hair_mean(src, uv, side))
                    p = tuple(int(m[i] * 0.6 + p[i] * 0.4) for i in range(3)) + (255,)
                    if side == "top":
                        ang = math.atan2(y - 11, x - 9)
                        band = math.sin(ang * 9 + math.hypot(x - 9, y - 11) * 0.35)
                    else:
                        band = math.sin(x * 1.9 + math.sin(y * 0.4) * 1.6)
                    f = 1.0 + 0.11 * band
                    add = 10 if band > 0.88 else 0
                    if side != "top" and y >= h - 2:
                        add += 4
                    dst.putpixel((X, Y), mul(p, f, add))


# ---------- спина, капюшон, манжеты ----------

def hood(dst, src):
    x0, y0, w, h = face_rect((16, 16), (8, 12, 4), "back")
    c = base_color(src, (32, 20, 8, 12))
    for x in range(w):
        bottom = 2 + int(round(7 * (1 - ((x - 7.5) / 7.5) ** 2)))
        for y in range(0, bottom + 1):
            if y == bottom or x in (0, w - 1):
                p = mul(c, 0.66)
            elif y <= 1:
                p = mul(c, 0.82)
            else:
                p = mul(c, 1.1 - 0.03 * y)
            dst.putpixel((x0 + x, y0 + y), p)
        dst.putpixel((x0 + x, y0 + min(h - 1, bottom + 1)), mul(c, 0.85))


def shirt_back(dst, src):
    x0, y0, w, h = face_rect((16, 16), (8, 12, 4), "back")
    for x in range(w):
        dst.putpixel((x0 + x, y0 + 6), mul(dst.getpixel((x0 + x, y0 + 6)), 0.88))
    for y in range(7, h):
        dst.putpixel((x0 + 7, y0 + y), mul(dst.getpixel((x0 + 7, y0 + y)), 0.92))
        dst.putpixel((x0 + 8, y0 + y), mul(dst.getpixel((x0 + 8, y0 + y)), 1.04))


def ribbing(dst):
    """Ребристый низ кофты: чередование столбцов на двух нижних строках тела спереди и сзади."""
    for side in ("front", "back"):
        x0, y0, w, h = face_rect((16, 16), (8, 12, 4), side)
        for y in (h - 3, h - 2):
            for x in range(w):
                dst.putpixel((x0 + x, y0 + y), mul(dst.getpixel((x0 + x, y0 + y)), 0.86 if x % 2 else 1.06))


# ---------- аксессуары на внешнем слое ----------

ARM_LAYER = {"right": (40, 32), "left": (48, 48)}
ARM_BASE = {"right": (40, 16), "left": (32, 48)}


def wrist_row(src, arm, slim):
    """Строка над кистью: самая верхняя строка, ниже которой рука идёт кожей до конца."""
    a = 3 if slim else 4
    x, y, w, h = face_rect(ARM_BASE[arm], (a, 12, 4), "front")
    rows64 = [y // K + j for j in range(12)]
    skin = [all(src.getpixel((x // K + i, r))[0] > src.getpixel((x // K + i, r))[2] + 25 for i in range(a)) for r in rows64]
    first = 11
    while first > 0 and skin[first - 1]:
        first -= 1
    return max(4, first - 1) * K


def band_on_arm(dst, arm, slim, row, colors, face=None):
    a = 3 if slim else 4
    for side in ("front", "back", "right", "left"):
        x0, y0, w, h = face_rect(ARM_LAYER[arm], (a, 12, 4), side)
        for x in range(w):
            for dy in range(2):
                dst.putpixel((x0 + x, y0 + row + dy), colors[(x + dy) % len(colors)])
        if face and side == "front":
            cx = w // 2 - 1
            for dx in range(2):
                for dy in range(2):
                    dst.putpixel((x0 + cx + dx, y0 + row + dy), face if (dx, dy) != (1, 1) else mul(face, 0.8))


def chain(dst):
    x0, y0, w, h = face_rect((16, 16), (8, 12, 4), "front")
    pts = [(4, 0), (5, 1), (6, 2), (7, 3), (8, 3), (9, 2), (10, 1), (11, 0)]
    for i, (x, y) in enumerate(pts):
        dst.putpixel((x0 + x, y0 + y), (214, 216, 222, 255) if i % 2 == 0 else (150, 152, 160, 255))


def decorate(dst, src, name, slim):
    info = CHARACTERS.get(name)
    if not info:
        return
    pants(dst, src, info)
    hair(dst, src)
    if info["rib"]:
        ribbing(dst)
    if info["hood"]:
        hood(dst, src)
    for extra in info["extras"]:
        if extra == "chain":
            chain(dst)
        elif extra == "shirt_back":
            shirt_back(dst, src)
        elif extra[0] == "watch":
            _, arm, strap, dial = extra
            band_on_arm(dst, arm, slim, wrist_row(src, arm, slim), [rgb(strap)], face=rgb(dial))
        elif extra[0] == "band":
            _, arm, color = extra
            band_on_arm(dst, arm, slim, wrist_row(src, arm, slim), [rgb(color), mul(rgb(color), 1.4, 6)])
        elif extra[0] == "beads":
            band_on_arm(dst, extra[1], slim, wrist_row(src, extra[1], slim), [rgb("#6b4a33"), rgb("#2b2522"), rgb("#9a7451")])
