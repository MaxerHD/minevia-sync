# Вторая часть моделей: комбо, вторая ступень стихий, храмы и стражи.
# Запускается из spells.py и пользуется его помощниками.

LIGHT = np.array([0.35, 0.85, 0.4]) / np.linalg.norm([0.35, 0.85, 0.4])
DUST = [(0.0, (0.26, 0.20, 0.14)), (0.55, (0.52, 0.42, 0.30)), (1.0, (0.82, 0.72, 0.56))]
MAGMA = [(0.0, (0.05, 0.03, 0.03)), (0.35, (0.16, 0.06, 0.04)), (0.55, (0.72, 0.14, 0.02)), (0.8, (1.0, 0.46, 0.05)), (1.0, (1.0, 0.82, 0.32))]


def baked(pos, quads, rgb):
    """Свет запечён в цвет: стражи рисуются ярко, и объём им дают только тени в самой модели."""
    shade = 0.45 + 0.65 * np.clip(normals(pos, quads) @ LIGHT, 0, 1)
    return np.clip(rgb * shade[:, None], 0, 1)


def stack(parts):
    """Склеивает части кадра: каждая часть это (позиции, цвет)."""
    return np.concatenate([p for p, _ in parts]), np.concatenate([c for _, c in parts])


def faces(shapes):
    """Общий список граней для частей с заданным числом вершин: (вершин, грани)."""
    out, offset = [], 0
    for count, quads in shapes:
        out.append(quads + offset)
        offset += count
    return np.concatenate(out)


def tube(path, radius, nu):
    """Трубка вдоль ломаной path (N точек) с радиусом radius (N значений)."""
    tangent = np.gradient(path, axis=0)
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1, keepdims=True), 1e-6)
    side = np.cross(tangent, np.array([0.31, 0.77, 0.55]))
    side /= np.maximum(np.linalg.norm(side, axis=1, keepdims=True), 1e-6)
    up = np.cross(tangent, side)
    angle = np.linspace(0, TAU, nu, endpoint=False)
    ring = np.cos(angle)[None, :, None] * side[:, None, :] + np.sin(angle)[None, :, None] * up[:, None, :]
    return (path[:, None, :] + ring * radius[:, None, None]).reshape(-1, 3)


# ---------------------------------------------------------------- огнемёт

def flame_jet():
    """Струя огнемёта: отдельные острые языки вылетают из сопла, извиваются, остывают и тают."""
    frames, nu, nv = 24, 7, 13
    s = np.linspace(0, 1, nv)
    one = grid(nu, nv)
    for name, count, width, heat, power, seed, reach in (("flame_jet_core", 8, 0.09, 0.84, 0.8, 71, 5.4),
                                                        ("flame_jet_outer", 18, 0.17, 0.68, 0.66, 75, 7.4)):
        rng = np.random.default_rng(seed)
        tongues = [{"phase": rng.uniform(), "angle": rng.uniform(0, TAU), "spread": rng.uniform(0.25, 1.0),
                    "wave": rng.uniform(0, TAU), "speed": rng.uniform(4.5, 8.0), "fat": rng.uniform(0.7, 1.25)} for _ in range(count)]
        quads = faces([(nu * nv, one)] * count)
        result = []
        for f in range(frames):
            t = f / frames
            pos, col = [], []
            for g in tongues:
                age = (t + g["phase"]) % 1.0
                head = reach * age ** 0.78
                length = 0.9 + 2.3 * age
                z = np.maximum(head - length * (1 - s), 0)
                spread = g["spread"] * (0.05 + 1.25 * (z / 7.4) ** 1.2)
                sway = 0.34 * (z / 7.4) * np.sin(s * g["speed"] + g["wave"] + TAU * t * 2)
                path = np.stack([np.cos(g["angle"]) * spread + sway, np.sin(g["angle"]) * spread + 0.5 * (z / 7.4) ** 2 + sway * 0.6, z], axis=1)
                radius = width * g["fat"] * (0.35 + 1.5 * age) * np.sin(np.clip(s, 0, 1) ** 0.55 * math.pi) ** 0.9 + 0.004
                pos.append(tube(path, radius, nu))
                h = np.repeat(heat - age * 0.72 - (1 - s) * 0.1 + 0.18 * s, nu)
                a = np.repeat(power * math.sin(age * math.pi) ** 0.55 * (1 - s ** 4), nu)
                col.append(rgba(ramp(np.clip(h, 0, 1), FIRE), a))
            result.append((np.concatenate(pos), np.concatenate(col)))
        save(name, result, quads)


# ---------------------------------------------------------------- комбо

def funnel(name, palette, seed, hot=False):
    """Смерч другого вещества: та же закрученная воронка, но с рваными краями и своей палитрой."""
    frames, nu, nv = 24, 58, 30
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    one = grid(nu, nv)
    count = nu * nv
    quads = np.concatenate([one, one + count])
    licks = Flow(seed, freq=2.6, octaves=3, gain=0.6, speed=2)
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for layer, width, power, arms in ((0, 1.0, 0.95, 6), (1, 0.62, 0.9, 5)):
            sway = 0.22 * s * np.sin(s * 4.2 - TAU * t)
            sway2 = 0.22 * s * np.cos(s * 3.4 - TAU * t)
            spot = np.stack([np.cos(theta) * 1.4, s * 5, np.sin(theta) * 1.4], axis=1)
            n = licks(spot, t)
            radius = (0.22 + 2.1 * s ** 1.5) * width * (1 + 0.16 * n)
            pos.append(np.stack([radius * np.cos(theta) + sway, s * 5.0, radius * np.sin(theta) + sway2], axis=1))
            lines = streak(theta, s, t, arms, 11, 3, 3 + layer)
            a = power * (0.34 + 0.66 * lines) * np.clip(s * 9, 0, 1) * np.clip((1 - s) * 5, 0, 1) * np.clip(0.75 + 1.6 * n, 0, 1)
            if hot:
                # Яркий верх палитры под шейдером уходит в белый, поэтому смерч держится в насыщенном оранжевом.
                h = 0.74 - 0.26 * s + 0.2 * n + 0.1 * lines
                a = power * (0.6 + 0.4 * lines) * np.clip(s * 9, 0, 1) * np.clip((1 - s) * 5, 0, 1) * np.clip(0.85 + 1.6 * n, 0, 1)
            else:
                h = 0.3 + 0.7 * lines + 0.2 * n
            col.append(rgba(ramp(np.clip(h, 0, 1), palette), a))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save(name, result, quads)


def fire_tornado():
    funnel("fire_tornado", FIRE, 401, hot=True)


def rock_tornado():
    funnel("rock_tornado", DUST, 405)
    # Камни кружат по спирали вокруг воронки: за круг анимации они делают ровно один оборот.
    frames = 24
    rng = np.random.default_rng(407)
    stones = [rock(410 + i, cuts=2, planes=6, depth=0.5) for i in range(10)]
    plan = [{"height": rng.uniform(0.8, 4.6), "phase": rng.uniform(0, TAU), "size": rng.uniform(0.14, 0.34),
             "axis": rng.normal(size=3), "turns": int(rng.integers(1, 3))} for _ in stones]
    quads = faces([(len(p), q) for p, q, _ in stones])
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for (p, q, c), g in zip(stones, plan):
            orbit = 0.35 + 2.1 * (g["height"] / 5) ** 1.5 + 0.35
            angle = g["phase"] + TAU * t
            center = np.array([math.cos(angle) * orbit, g["height"] + 0.2 * math.sin(TAU * t + g["phase"]), math.sin(angle) * orbit])
            pos.append(p * g["size"] @ rotation(g["axis"], TAU * t * g["turns"]).T + center)
            col.append(c * np.array([0.78, 0.68, 0.56, 1.0]))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("rock_orbit", result, quads)


def puffs(name, seed, count, spread, flat, palette, alpha, nu=22, nv=14, ring=0.0):
    """Облако из нескольких мягких клубов, которые медленно перекатываются по кругу."""
    frames = 24
    rng = np.random.default_rng(seed)
    dirs, one, *_ = sphere(nu, nv, axis=1)
    quads = faces([(len(dirs), one)] * count)
    plan = [{"at": (np.array([math.cos(i / count * TAU) * ring, 0.16, math.sin(i / count * TAU) * ring]) if ring else np.zeros(3))
             + np.array([rng.normal() * spread, rng.normal() * spread * 0.22, rng.normal() * spread]),
             "size": rng.uniform(0.45, 0.8) * (0.5 if ring else 1), "phase": rng.uniform(0, TAU), "noise": Flow(seed + 10 + i, freq=1.8, octaves=3, speed=1)} for i in range(count)]
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for g in plan:
            n = g["noise"](dirs, t)
            drift = np.array([math.cos(TAU * t + g["phase"]), 0.4 * math.sin(TAU * t + g["phase"]), math.sin(TAU * t + g["phase"])]) * 0.09
            shape = dirs * (g["size"] * (1 + 0.3 * n))[:, None]
            shape[:, 1] *= flat
            pos.append(shape + g["at"] + drift)
            h = 0.5 + 0.42 * dirs[:, 1] + 0.32 * n
            col.append(rgba(ramp(np.clip(h, 0, 1), palette), np.full(len(dirs), alpha)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save(name, result, quads)


def steam_cloud():
    puffs("steam_cloud", 421, 8, 0.52, 0.72, [(0.0, (0.26, 0.28, 0.30)), (0.6, (0.40, 0.42, 0.44)), (1.0, (0.56, 0.58, 0.60))], 0.5)


def mist_ring():
    """Туман вокруг игрока: кольцо клубов, чтобы изнутри не смотреть сквозь модель."""
    puffs("mist_ring", 425, 13, 0.1, 0.8, [(0.0, (0.26, 0.30, 0.33)), (0.6, (0.36, 0.41, 0.44)), (1.0, (0.48, 0.53, 0.56))], 0.46, ring=0.92)


def storm_cloud():
    puffs("storm_cloud", 431, 10, 0.62, 0.42, [(0.0, (0.24, 0.25, 0.31)), (0.6, (0.42, 0.44, 0.52)), (1.0, (0.72, 0.75, 0.82))], 0.9)


def magma_boulder():
    """Раскалённая глыба: тёмная корка, а по трещинам бежит жар."""
    frames = 16
    pos, quads, _ = rock(441, cuts=14, planes=15, scale=(0.86, 0.74, 0.92))
    veins = Flow(442, freq=2.6, octaves=3, gain=0.6, speed=0)
    crack = np.clip(1 - np.abs(veins(pos, 0.0)) * 5.5, 0, 1)
    pulse = Flow(443, freq=2.0, octaves=2, speed=1)
    result = []
    for f in range(frames):
        t = f / frames
        h = 0.18 + crack * (0.8 + 0.22 * pulse(pos, t))
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), MAGMA), np.ones(len(pos)))))
    save("magma_boulder", result, quads)


def pool(name, seed, frames, colour, swell=0.03):
    """Лужа на земле: неровный край, поверхность волнуется, а цвет считает функция colour."""
    nu, nv = 64, 15
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    r = np.repeat(np.linspace(0.02, 1, nv), nu)
    quads = grid(nu, nv)
    edge_noise = Flow(seed, freq=1.7, octaves=3, speed=0)
    ring = np.stack([np.cos(theta), theta * 0, np.sin(theta)], axis=1)
    edge = 0.84 + 0.2 * edge_noise(ring, 0.0)
    wave = Flow(seed + 1, freq=2.8, octaves=3, speed=1)
    flow = Flow(seed + 2, freq=3.6, octaves=3, gain=0.6, speed=1)
    result = []
    for f in range(frames):
        t = f / frames
        flat = np.stack([r * edge * np.cos(theta), r * 0, r * edge * np.sin(theta)], axis=1)
        y = 0.07 + swell * wave(flat, t) * (1 - r ** 4) * 3 - 0.05 * r ** 6
        pos = flat + np.stack([r * 0, y, r * 0], axis=1)
        result.append((pos, colour(flow(flat, t), r)))
    save(name, result, quads[:, ::-1])


def magma_pool():
    pool("magma_pool", 451, 24, lambda n, r: rgba(ramp(np.clip(0.62 - 1.05 * np.abs(n) + 0.42 * (1 - r), 0, 1), MAGMA), np.clip((1 - r) * 8, 0, 1)))


def mud_pool():
    mud = [(0.0, (0.13, 0.09, 0.06)), (0.6, (0.28, 0.20, 0.13)), (1.0, (0.46, 0.36, 0.25))]
    pool("mud_pool", 461, 24, lambda n, r: rgba(ramp(np.clip(0.42 + 0.6 * n, 0, 1), mud), np.clip((1 - r) * 7, 0, 0.94)), swell=0.045)


def element_mark():
    """Метка стихии над головой: кристалл в кольце. Белая, цвет задаёт игра."""
    frames, nu = 16, 40
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), 2)
    side = np.repeat(np.array([-1.0, 1.0]), nu)
    ring_q = grid(nu, 2)
    gem, gem_q = crystal(0.62, 0.2, sides=4)
    lower = gem * np.array([1, -1, 1])
    quads = faces([(len(theta), ring_q), (len(gem), gem_q), (len(gem), gem_q[:, ::-1])])
    result = []
    for f in range(frames):
        t = f / frames
        r = 0.62 + side * 0.05
        tilt = rotation((1, 0, 0), 0.3 * math.sin(TAU * t))
        ring = np.stack([r * np.cos(theta), side * 0, r * np.sin(theta)], axis=1) @ tilt.T
        glow = 0.75 + 0.25 * math.sin(TAU * t)
        pos = np.concatenate([ring, gem, lower])
        col = rgba(np.ones((len(pos), 3)), np.full(len(pos), 0.55 + 0.4 * glow))
        result.append((pos, col))
    save("element_mark", result, quads)


# ---------------------------------------------------------------- вторая ступень

def ice_bolt():
    """Ледяное копьё: длинный кристалл вдоль полёта и три осколка у хвоста."""
    rng = np.random.default_rng(471)
    parts = []
    turn = rotation((1, 0, 0), math.pi / 2)
    for i, (length, width) in enumerate(((2.2, 0.17), (1.1, 0.1), (1.0, 0.09), (0.9, 0.08))):
        pos, quads = crystal(length, width)
        placed = pos @ turn.T + np.array([0, 0, -1.1])
        if i:
            angle = i / 3 * TAU
            placed = placed @ rotation((math.cos(angle), math.sin(angle), 0), rng.uniform(0.08, 0.16)).T
        h = np.clip((placed[:, 2] + 1.1) / 2.2, 0, 1)
        rgb = np.array([0.14, 0.46, 0.82]) * (1 - h[:, None]) + np.array([0.72, 0.92, 1.0]) * h[:, None]
        parts.append((placed, quads, rgba(rgb, np.full(len(pos), 0.8))))
    pos, quads, col = merged(parts)
    save("ice_bolt", [(pos, col)], quads)


def lightning():
    """Молния длиной в единицу: ломаный канал и две ветки, форма меняется каждый кадр."""
    frames, nv = 8, 22
    rng = np.random.default_rng(481)
    across = np.array([-1.0, 1.0])
    s = np.linspace(0, 1, nv)

    def ribbon(path, width):
        """Две скрещённые ленты: молнию видно с любой стороны."""
        wide = width[:, None, None]
        first = path[:, None, :] + across[None, :, None] * wide * np.array([1.0, 0, 0])
        second = path[:, None, :] + across[None, :, None] * wide * np.array([0, 1.0, 0])
        return np.concatenate([first.reshape(-1, 3), second.reshape(-1, 3)])

    strip = grid(2, nv, wrap=False)
    count = 2 * nv
    branches = 2
    quads = faces([(count, strip)] * (2 * (1 + branches)))
    result = []
    for f in range(frames):
        jag = np.cumsum(rng.normal(size=(nv, 2)) * 0.2, axis=0)
        jag -= np.outer(s, jag[-1])
        main = np.stack([jag[:, 0], jag[:, 1], s], axis=1)
        pos = [ribbon(main, 0.09 + 0.07 * np.sin(s * math.pi))]
        col = [rgba(np.ones((2 * count, 3)), np.ones(2 * count))]
        for b in range(branches):
            start = main[rng.integers(4, nv // 2)]
            walk = np.cumsum(rng.normal(size=(nv, 2)) * 0.12, axis=0) + rng.normal(size=2) * 0.2 * s[:, None] * 3
            branch = np.stack([start[0] + walk[:, 0], start[1] + walk[:, 1], start[2] + s * 0.3], axis=1)
            pos.append(ribbon(branch, 0.05 * (1 - s) + 0.004))
            col.append(rgba(np.ones((2 * count, 3)), np.repeat(np.tile(1 - s, 2), 2) * 0.8))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("lightning", result, quads)


def magma_geyser():
    """Столб магмы: бьёт вверх, разваливается и падает каплями."""
    frames, nu, nv = 20, 26, 20
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    column = grid(nu, nv)
    blobs = bits(18, 491, 2.6, 7.0, 16.0, 0.26)
    blob_pos, blob_q = cube_sphere(2)
    quads = faces([(len(theta), column)] + [(len(blob_pos), blob_q)] * len(blobs))
    churn = Flow(492, freq=2.0, octaves=3, speed=2)
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        rise = 1 - (1 - min(1.0, t * 2.6)) ** 2
        fall = max(0.0, (t - 0.45) / 0.55)
        height = 6.2 * rise * (1 - fall ** 2)
        spot = np.stack([np.cos(theta), s * 6, np.sin(theta)], axis=1)
        n = churn(spot, t)
        radius = (0.72 - 0.42 * s + 0.1 * s ** 3) * (1 + 0.32 * n) * (1 - 0.6 * fall)
        pos = [np.stack([radius * np.cos(theta), s * height, radius * np.sin(theta)], axis=1)]
        h = 1.05 - 0.55 * s - 0.5 * fall + 0.25 * n
        col = [rgba(ramp(np.clip(h, 0, 1), MAGMA), np.clip((1.3 - fall * 1.4) * (1 - s ** 6), 0, 1))]
        for d in blobs:
            k = max(0.0, t - 0.12) / 0.88
            center = d["v"] * k * 0.8 - np.array([0, d["gravity"] * k * k * 0.5 * 0.8, 0])
            center[1] = max(center[1], 0.1)
            pos.append(blob_pos * d["size"] * (1 - k ** 3) + center)
            col.append(rgba(ramp(np.full(len(blob_pos), 0.85 - 0.5 * k), MAGMA), np.full(len(blob_pos), 1.0 if k > 0 else 0.0)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("magma_geyser", result, quads)


def sand_pit():
    """Воронка зыбучего песка: воронка уходит вниз, а по ней бегут спиральные гребни."""
    frames, nu, nv = 24, 72, 20
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    r = np.repeat(np.linspace(0.04, 1, nv), nu)
    quads = grid(nu, nv)
    grain = Flow(501, freq=7.0, octaves=2, speed=0)
    sand = [(0.0, (0.46, 0.36, 0.22)), (0.6, (0.74, 0.62, 0.40)), (1.0, (0.93, 0.84, 0.62))]
    result = []
    for f in range(frames):
        t = f / frames
        ridge = np.sin(theta * 5 + r * 13 + TAU * t * 2)
        # Земля под воронкой настоящая, поэтому песок лежит чашей поверх неё, а не уходит вниз.
        y = (0.014 + 0.075 * r ** 1.7 + 0.009 * ridge * (1 - r ** 3)) * np.clip((1.0 - r) / 0.07, 0, 1) ** 0.5
        pos = np.stack([r * np.cos(theta), y, r * np.sin(theta)], axis=1)
        h = 0.5 + 0.34 * ridge + 0.16 * grain(pos, 0.0) + 0.24 * r
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), sand), np.ones(len(pos)))))
    save("sand_pit", result, quads)


def metal_blade():
    """Клинок из железа: ромб с острой кромкой вдоль полёта."""
    section = [(0.0, 0.0), (0.2, 0.05), (0.0, 0.0), (0.2, -0.05)]
    stations = [(-0.8, 0.02), (-0.55, 0.55), (0.1, 1.0), (0.75, 0.42), (1.05, 0.015)]
    pos, quads = [], []
    for i, (z, width) in enumerate(stations):
        pos += [(0.0, 0.05 * width, z), (0.22 * width, 0.0, z), (0.0, -0.05 * width, z), (-0.22 * width, 0.0, z)]
    for i in range(len(stations) - 1):
        for j in range(4):
            a = i * 4 + j
            b = i * 4 + (j + 1) % 4
            quads.append((a, b, b + 4, a + 4))
    pos = np.array(pos, dtype=float)
    quads = np.array(quads, dtype=np.int32)
    edge = np.clip(np.abs(pos[:, 0]) / 0.22, 0, 1)
    grey = 0.5 + 0.42 * edge
    save("metal_blade", [(pos, rgba(np.stack([grey, grey * 1.02, grey * 1.07], axis=1), np.ones(len(pos))))], quads)


def vacuum():
    """Схлопывание воздуха: оболочка с закрученными струями сжимается в точку."""
    frames = 22
    dirs, quads, theta, phi = sphere(48, 24, axis=1)
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        radius = 1.0 - 0.94 * t ** 2.2
        s = phi / math.pi
        lines = streak(theta + t * 4, s, t, 6, 7, 3, 3)
        a = (0.08 + 0.72 * lines) * (0.35 + 0.65 * t)
        result.append((dirs * radius, rgba(ramp(0.3 + 0.7 * lines, WIND), a)))
    save("vacuum", result, quads)


def danger_ring():
    """Предупреждение на земле: пульсирующее кольцо и слабая заливка. Белое, цвет задаёт игра."""
    frames, nu, nv = 12, 72, 8
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    r = np.repeat(np.linspace(0.0, 1.0, nv), nu)
    quads = grid(nu, nv)[:, ::-1]
    pos = np.stack([r * np.cos(theta), r * 0, r * np.sin(theta)], axis=1)
    result = []
    for f in range(frames):
        t = f / frames
        band = np.clip(1 - np.abs(r - 0.96) * 14, 0, 1)
        sweep = np.clip(1 - np.abs(r - t) * 7, 0, 1) * 0.3
        result.append((pos, rgba(np.ones((len(pos), 3)), 0.14 + 0.78 * band + sweep)))
    save("danger_ring", result, quads)


# ---------------------------------------------------------------- храмы и стражи

def altar_core():
    """Ядро над алтарём: двойной кристалл в двух кольцах. Белое, цвет задаёт игра."""
    frames, nu = 24, 48
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), 2)
    side = np.repeat(np.array([-1.0, 1.0]), nu)
    ring_q = grid(nu, 2)
    gem, gem_q = crystal(1.0, 0.36, sides=6)
    lower = gem * np.array([1, -1, 1])
    quads = faces([(len(gem), gem_q), (len(gem), gem_q[:, ::-1]), (len(theta), ring_q), (len(theta), ring_q)])
    result = []
    for f in range(frames):
        t = f / frames
        r = 1.0 + side * 0.05
        flat = np.stack([r * np.cos(theta), side * 0, r * np.sin(theta)], axis=1)
        one = flat @ rotation((1, 0, 0), TAU * t).T
        two = flat @ rotation((0, 0, 1), -TAU * t).T * 1.18
        pos = np.concatenate([gem, lower, one, two])
        glow = np.concatenate([np.full(2 * len(gem), 0.95), np.full(2 * len(theta), 0.6)])
        result.append((pos, rgba(np.ones((len(pos), 3)), glow)))
    save("altar_core", result, quads)


def seal_orb():
    """Печать Истока: светящийся шар с тёмным поясом. Белая, цвет задаёт игра."""
    frames = 16
    dirs, quads, theta, phi = sphere(22, 14, axis=1)
    result = []
    for f in range(frames):
        t = f / frames
        band = np.clip(1 - np.abs(np.sin(phi * 2 + TAU * t)) * 1.5, 0, 1)
        grey = 0.65 + 0.35 * band
        result.append((dirs * 0.5, rgba(np.stack([grey] * 3, axis=1), np.full(len(dirs), 0.95))))
    save("seal_orb", result, quads)


def plates_around(seed, count, size, radius, height, t, cycles=1, tilt=0.35):
    """Кольцо камней вокруг стража: кадр t даёт поворот, за круг анимации ровно целое число оборотов."""
    parts = []
    for i in range(count):
        p, q, c = seed[i]
        angle = i / count * TAU + TAU * t * cycles
        out = np.array([math.cos(angle), 0, math.sin(angle)])
        turn = rotation((0, 1, 0), -angle + math.pi / 2) @ rotation((1, 0, 0), tilt)
        bob = 0.22 * math.sin(TAU * t + i * 1.3)
        parts.append((p * size @ turn.T + out * radius + np.array([0, height + bob, 0]), q, c))
    return parts


def boss_fire():
    """Страж огня: сердце из магмы, вокруг него плиты базальта, сверху корона из языков пламени."""
    frames = 24
    dirs, core_q, *_ = sphere(34, 22, axis=1)
    hot = Flow(601, freq=2.4, octaves=3, speed=1)
    plates = [rock(610 + i, cuts=4, planes=8, scale=(0.72, 1.0, 0.3), depth=0.55) for i in range(7)]
    nu, nv = 6, 12
    one = grid(nu, nv)
    count = 11
    rng = np.random.default_rng(603)
    flames = [{"angle": rng.uniform(0, TAU), "phase": rng.uniform(), "spread": rng.uniform(0.2, 0.85), "tall": rng.uniform(1.0, 1.9)} for _ in range(count)]
    quads = faces([(len(dirs), core_q)] + [(len(p), q) for p, q, _ in plates] + [(nu * nv, one)] * count)
    s = np.linspace(0, 1, nv)
    result = []
    for f in range(frames):
        t = f / frames
        n = hot(dirs, t)
        core = dirs * (1.05 * (1 + 0.1 * n))[:, None]
        parts = [(core, rgba(ramp(np.clip(0.72 + 0.42 * n, 0, 1), MAGMA), np.ones(len(dirs))))]
        for p, q, c in plates_around(plates, 7, 1.0, 1.75, 0.0, t):
            parts.append((p, rgba(baked(p, q, c[:, :3] * np.array([0.3, 0.26, 0.26])), np.ones(len(p)))))
        for g in flames:
            age = (t + g["phase"]) % 1.0
            top = g["tall"] * (0.5 + 0.5 * math.sin(age * math.pi))
            path = np.stack([math.cos(g["angle"]) * g["spread"] * (1 - 0.5 * s) + 0.1 * np.sin(s * 6 + TAU * t),
                             0.85 + s * top, math.sin(g["angle"]) * g["spread"] * (1 - 0.5 * s)], axis=1)
            radius = 0.24 * (1 - s) ** 0.8 + 0.005
            h = np.repeat(1.0 - 0.75 * s, nu)
            parts.append((tube(path, radius, nu), rgba(ramp(np.clip(h, 0, 1), FIRE), np.repeat(1 - s ** 3, nu))))
        result.append(stack(parts))
    save("boss_fire", result, quads)


def boss_water():
    """Страж воды: волнующаяся водяная фигура и кольцо ледяных копий."""
    frames = 24
    dirs, core_q, *_ = sphere(36, 26, axis=1)
    wobble = Flow(621, freq=1.5, octaves=3, gain=0.5, speed=1)
    ripple = Flow(622, freq=3.4, octaves=2, speed=2)
    spear, spear_q = crystal(1.7, 0.16)
    count = 8
    quads = faces([(len(dirs), core_q)] + [(len(spear), spear_q)] * count)
    result = []
    for f in range(frames):
        t = f / frames
        n = wobble(dirs, t)
        m = ripple(dirs, t)
        body = dirs * (1 + 0.2 * n + 0.05 * m)[:, None] * np.array([1.05, 1.65, 1.05])
        body[:, 0:3:2] *= (1 + 0.3 * np.clip(-dirs[:, 1], 0, 1))[:, None]
        h = 0.45 + 0.5 * m + 0.3 * dirs[:, 1]
        parts = [(body, rgba(baked(body, core_q, ramp(np.clip(h, 0, 1), WATER)), np.full(len(dirs), 0.86)))]
        for i in range(count):
            angle = i / count * TAU - TAU * t
            out = np.array([math.cos(angle), 0, math.sin(angle)])
            turn = rotation((-out[2], 0, out[0]), 1.15)
            placed = spear @ turn.T + out * 1.9 + np.array([0, 0.5 + 0.2 * math.sin(TAU * t + i), 0])
            hh = np.clip(spear[:, 1] / 1.7, 0, 1)
            parts.append((placed, rgba(np.array([0.2, 0.55, 0.86]) * (1 - hh[:, None]) + np.array([0.82, 0.96, 1.0]) * hh[:, None], np.full(len(spear), 0.9))))
        result.append(stack(parts))
    save("boss_water", result, quads)


def boss_earth():
    """Страж земли: каменная грудь и голова с горящими глазами, два кулака и замшелые плечи."""
    frames = 24
    chest = rock(641, cuts=10, planes=13, scale=(1.3, 1.25, 1.0))
    head = rock(643, cuts=6, planes=10, scale=(0.62, 0.55, 0.6))
    fist = rock(645, cuts=6, planes=10, scale=(0.62, 0.62, 0.62))
    shoulder = rock(647, cuts=5, planes=8, scale=(0.72, 0.42, 0.6))
    eye_dirs, eye_q, *_ = sphere(10, 7, axis=1)
    quads = faces([(len(chest[0]), chest[1]), (len(head[0]), head[1]), (len(fist[0]), fist[1]), (len(fist[0]), fist[1]),
                   (len(shoulder[0]), shoulder[1]), (len(shoulder[0]), shoulder[1]), (len(eye_dirs), eye_q), (len(eye_dirs), eye_q)])
    stone = np.array([0.62, 0.58, 0.52])
    moss = np.array([0.30, 0.42, 0.18])
    result = []
    for f in range(frames):
        t = f / frames
        sway = math.sin(TAU * t)
        parts = []
        body = chest[0] + np.array([0, -0.2, 0])
        parts.append((body, chest[1], chest[2][:, :3] * stone))
        top = head[0] + np.array([0, 1.32 + 0.05 * sway, 0.1])
        parts.append((top, head[1], head[2][:, :3] * stone))
        for side in (-1, 1):
            hand = fist[0] @ rotation((1, 0, 0), TAU * t * side).T + np.array([side * 2.1, -0.75 + 0.32 * math.sin(TAU * t + side), 0.65 + 0.25 * sway * side])
            parts.append((hand, fist[1], fist[2][:, :3] * stone))
        for side in (-1, 1):
            cap = shoulder[0] + np.array([side * 1.42, 0.88 + 0.05 * sway, 0])
            tone = np.clip((cap[:, 1] - 0.9) * 4, 0, 1)[:, None]
            parts.append((cap, shoulder[1], shoulder[2][:, :3] * (stone * (1 - tone) + moss * tone)))
        frame_pos, frame_col = [], []
        for p, q, c in parts:
            frame_pos.append(p)
            frame_col.append(rgba(baked(p, q, c), np.ones(len(p))))
        for side in (-1, 1):
            frame_pos.append(eye_dirs * 0.1 + np.array([side * 0.24, 1.42 + 0.05 * sway, 0.62]))
            frame_col.append(rgba(np.tile(np.array([1.0, 0.82, 0.3]), (len(eye_dirs), 1)), np.ones(len(eye_dirs))))
        result.append((np.concatenate(frame_pos), np.concatenate(frame_col)))
    save("boss_earth", result, quads)


def boss_air():
    """Страж воздуха: глаз бури в воронке и кольцо лезвий."""
    frames, nu, nv = 24, 46, 24
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    cone = grid(nu, nv)
    dirs, core_q, *_ = sphere(22, 14, axis=1)
    blade_pos = np.array([(-0.1, 0, -0.1), (0.1, 0, -0.1), (0.14, 0, 0.7), (0.0, 0, 1.3),
                          (-0.1, 0.02, -0.1), (-0.14, 0.02, 0.7), (0.0, 0.02, 1.3), (0.1, 0.02, -0.1)], dtype=float)
    blade_q = np.array([(0, 1, 2, 3), (4, 5, 6, 7)], dtype=np.int32)
    count = 6
    quads = faces([(len(theta), cone), (len(dirs), core_q)] + [(len(blade_pos), blade_q)] * count)
    result = []
    for f in range(frames):
        t = f / frames
        radius = (0.2 + 1.5 * s ** 1.4) * (1 + 0.06 * np.sin(s * 17 - TAU * t * 3))
        funnel_pos = np.stack([radius * np.cos(theta), s * 3.4 - 1.9, radius * np.sin(theta)], axis=1)
        lines = streak(theta, s, t, 5, 9, 3, 3)
        a = (0.28 + 0.72 * lines) * np.clip(s * 8, 0, 1) * np.clip((1 - s) * 6, 0, 1)
        parts = [(funnel_pos, rgba(ramp(0.3 + 0.7 * lines, WIND), a))]
        eye = dirs * (0.5 + 0.05 * math.sin(TAU * t * 2))
        iris = np.clip(dirs[:, 2] * 1.6, 0, 1)[:, None]
        parts.append((eye, rgba(np.array([0.92, 0.97, 1.0]) * (1 - iris) + np.array([0.18, 0.5, 0.78]) * iris, np.ones(len(dirs)))))
        for i in range(count):
            angle = i / count * TAU + TAU * t * 2
            turn = rotation((0, 1, 0), -angle + math.pi / 2)
            out = np.array([math.cos(angle), 0, math.sin(angle)])
            placed = blade_pos @ turn.T + out * 1.1 + np.array([0, 0.3, 0])
            parts.append((placed, rgba(ramp(np.linspace(0.4, 1, len(blade_pos)), WIND), np.full(len(blade_pos), 0.92))))
        result.append(stack(parts))
    save("boss_air", result, quads)


def boss_primal():
    """Исток: чёрное ядро и четыре пояса стихий, вращающиеся в разные стороны."""
    frames = 24
    dirs, core_q, *_ = sphere(38, 26, axis=1)
    churn = Flow(661, freq=2.0, octaves=3, speed=1)
    nu, nv = 60, 5
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    across = np.repeat(np.linspace(-1, 1, nv), nu)
    band = grid(nu, nv)
    colours = [(1.0, 0.45, 0.12), (0.26, 0.68, 1.0), (0.56, 0.74, 0.3), (0.9, 0.96, 1.0)]
    tilts = [(1, 0, 0.2), (0.2, 0, 1), (1, 0, -0.8), (-0.7, 0, 1)]
    spike, spike_q = crystal(1.6, 0.2)
    spikes = 10
    rng = np.random.default_rng(663)
    aims = rng.normal(size=(spikes, 3))
    aims /= np.linalg.norm(aims, axis=1, keepdims=True)
    quads = faces([(len(dirs), core_q)] + [(len(theta), band)] * 4 + [(len(spike), spike_q)] * spikes)
    result = []
    for f in range(frames):
        t = f / frames
        n = churn(dirs, t)
        core = dirs * (1.3 * (1 + 0.12 * n))[:, None]
        void = np.clip(0.12 + 0.3 * n, 0.02, 0.5)
        parts = [(core, rgba(np.stack([void * 0.8, void * 0.5, void * 1.3], axis=1), np.ones(len(dirs))))]
        for i in range(4):
            r = 2.05 + 0.12 * i + across * 0.16
            ring = np.stack([r * np.cos(theta), across * 0.04, r * np.sin(theta)], axis=1)
            turn = rotation(tilts[i], TAU * t * (1 if i % 2 else -1))
            lines = 0.55 + 0.45 * np.sin(theta * 6 + TAU * t * 2 + i)
            parts.append((ring @ turn.T, rgba(np.array(colours[i]) * lines[:, None], (1 - np.abs(across) ** 3) * 0.95)))
        for i in range(spikes):
            up = aims[i]
            axis = np.cross((0, 1, 0), up)
            turn = rotation(axis if np.linalg.norm(axis) > 1e-3 else (1, 0, 0), math.acos(np.clip(up[1], -1, 1)))
            spin = rotation((0, 1, 0), TAU * t)
            placed = (spike * (1 + 0.1 * math.sin(TAU * t + i)) @ turn.T + up * 1.1) @ spin.T
            hh = np.clip(spike[:, 1] / 1.6, 0, 1)[:, None]
            parts.append((placed, rgba(np.array([0.1, 0.06, 0.16]) * (1 - hh) + np.array([0.66, 0.42, 1.0]) * hh, np.ones(len(spike)))))
        result.append(stack(parts))
    save("boss_primal", result, quads)


# ---------------------------------------------------------------- управляемые и супер-навыки

GALE = [(0.0, (0.16, 0.20, 0.26)), (0.5, (0.44, 0.52, 0.60)), (0.8, (0.76, 0.84, 0.90)), (1.0, (0.96, 0.99, 1.0))]


def wind_orb():
    """Вихрь: три вложенные оболочки из спиральных струй крутятся в разные стороны."""
    frames = 16
    dirs, shell, theta, phi = sphere(44, 26, axis=1)
    count = len(dirs)
    quads = np.concatenate([shell, shell + count, shell + 2 * count])
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for layer, (radius, arms, turn) in enumerate(((1.0, 5, 1), (0.72, 4, -1), (0.46, 3, 2))):
            lines = np.maximum(np.sin(arms * theta + 3.4 * np.cos(phi) - TAU * turn * t), 0) ** 3
            wobble = 1 + 0.05 * np.sin(5 * phi + TAU * t * 2 + layer * 2)
            pos.append(dirs * (radius * wobble)[:, None])
            a = (0.16 + 0.84 * lines) * (0.9 - 0.15 * layer) * np.clip(np.sin(phi) * 3, 0, 1)
            col.append(rgba(ramp(0.25 + 0.75 * lines, WIND), a))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("wind_orb", result, quads)


def ball_lightning():
    """Шаровая молния: кипящее ядро, от которого во все стороны бьют короткие дуги."""
    frames, arcs, nodes, nu = 12, 6, 10, 5
    dirs, core, *_ = sphere(28, 18, axis=1)
    arc = grid(nu, nodes)
    quads = faces([(len(dirs), core)] + [(nodes * nu, arc)] * arcs)
    churn = Flow(711, freq=2.4, octaves=3, speed=2)
    along = np.linspace(0, 1, nodes)
    result = []
    for f in range(frames):
        t = f / frames
        n = churn(dirs, t)
        body = dirs * (0.6 + 0.1 * n)[:, None]
        shade = np.clip(0.72 + 0.34 * n, 0, 1)
        parts = [(body, rgba(np.repeat(shade[:, None], 3, axis=1), np.full(len(dirs), 0.95)))]
        for a in range(arcs):
            rng = np.random.default_rng(7100 + a * 97 + f)
            way = rng.normal(size=3)
            way /= np.linalg.norm(way)
            path = way * (0.5 + along[:, None] * 1.05) + rng.normal(size=(nodes, 3)) * 0.17 * along[:, None]
            strand = tube(path, 0.06 - 0.045 * along, nu)
            parts.append((strand, rgba(np.ones((len(strand), 3)), np.ones(len(strand)))))
        result.append(stack(parts))
    save("ball_lightning", result, quads)


def meteor():
    """Метеорит: тёмная глыба с горящими трещинами, жар пульсирует и бежит по разломам."""
    frames = 16
    pos, quads, _ = rock(721, cuts=16, planes=22, scale=(1.0, 0.92, 1.1), depth=0.72)
    veins = Flow(722, freq=2.2, octaves=3, gain=0.6, speed=0)
    crack = np.clip(1 - np.abs(veins(pos, 0.0)) * 4.2, 0, 1)
    pulse = Flow(723, freq=1.8, octaves=2, speed=1)
    front = np.clip(pos[:, 2], 0, 1)
    result = []
    for f in range(frames):
        t = f / frames
        h = 0.16 + 0.34 * front + crack * (0.72 + 0.24 * pulse(pos, t))
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), MAGMA), np.ones(len(pos)))))
    save("meteor", result, quads)


def meteor_tail():
    """Хвост метеорита: два слоя рваного пламени тянутся назад от глыбы."""
    frames, nu, nv = 12, 30, 26
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    one = grid(nu, nv)
    count = nu * nv
    quads = np.concatenate([one, one + count])
    licks = Flow(731, freq=2.2, octaves=3, gain=0.6, speed=2)
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for width, power in ((1.25, 0.85), (0.8, 1.0)):
            spot = np.stack([np.cos(theta) * 1.2, np.sin(theta) * 1.2, s * 4], axis=1)
            n = licks(spot, t)
            radius = (0.05 + 0.98 * (1 - s) ** 0.8) * width * (1 + 0.42 * n * s)
            pos.append(np.stack([radius * np.cos(theta), radius * np.sin(theta), 0.5 - s * 6.5], axis=1))
            h = 0.92 - 0.72 * s + 0.22 * n
            a = power * (1 - s) ** 1.2 * np.clip(0.7 + 1.5 * n, 0, 1)
            col.append(rgba(ramp(np.clip(h, 0, 1), FIRE), a))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("meteor_tail", result, quads)


def water_geyser():
    """Гейзер: столб воды бьёт вверх, распадается и падает каплями."""
    frames, nu, nv = 20, 26, 20
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    column = grid(nu, nv)
    blobs = bits(18, 741, 2.8, 7.2, 16.0, 0.24)
    blob_pos, blob_q = cube_sphere(2)
    quads = faces([(len(theta), column)] + [(len(blob_pos), blob_q)] * len(blobs))
    churn = Flow(742, freq=2.2, octaves=3, speed=2)
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        rise = 1 - (1 - min(1.0, t * 3.0)) ** 2
        fall = max(0.0, (t - 0.45) / 0.55)
        height = 6.4 * rise * (1 - fall ** 2)
        spot = np.stack([np.cos(theta), s * 6, np.sin(theta)], axis=1)
        n = churn(spot, t)
        radius = (0.66 - 0.4 * s + 0.2 * s ** 4) * (1 + 0.26 * n) * (1 - 0.6 * fall)
        pos = [np.stack([radius * np.cos(theta), s * height, radius * np.sin(theta)], axis=1)]
        h = 0.5 + 0.4 * s + 0.3 * n
        col = [rgba(ramp(np.clip(h, 0, 1), WATER), np.clip((1.2 - fall * 1.3) * (1 - s ** 7), 0, 1) * 0.92)]
        for d in blobs:
            k = max(0.0, t - 0.14) / 0.86
            center = d["v"] * k * 0.8 - np.array([0, d["gravity"] * k * k * 0.5 * 0.8, 0])
            center[1] = max(center[1], 0.1)
            pos.append(blob_pos * d["size"] * (1 - k ** 3) + center)
            col.append(rgba(ramp(np.full(len(blob_pos), 0.8), WATER), np.full(len(blob_pos), 0.9 if k > 0 else 0.0)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("water_geyser", result, quads)


def water_guardian():
    """Страж воды: великан из воды с ледяными наплечниками, вместо ног у него водоворот, руки бьют по очереди."""
    frames = 24
    dirs, ball, *_ = sphere(30, 20, axis=1)
    nu, nv = 26, 16
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    column = grid(nu, nv)
    arm_nodes, arm_nu = 12, 12
    arm = grid(arm_nu, arm_nodes)
    eye, eye_q = cube_sphere(2)
    spike, spike_q = crystal(0.95, 0.15)
    spikes = [(-1.02, 1.0, -0.05, 0.6), (-0.78, 1.14, -0.2, 0.28), (1.02, 1.0, -0.05, -0.6), (0.78, 1.14, -0.2, -0.28),
              (-0.14, 1.94, 0.0, 0.3), (0.14, 1.94, 0.0, -0.3)]
    quads = faces([(len(dirs), ball), (len(dirs), ball), (len(theta), column), (arm_nodes * arm_nu, arm), (arm_nodes * arm_nu, arm),
                   (len(dirs), ball), (len(dirs), ball), (len(eye), eye_q), (len(eye), eye_q)] + [(len(spike), spike_q)] * len(spikes))
    swell = Flow(751, freq=1.6, octaves=3, gain=0.5, speed=1)
    ripple = Flow(752, freq=3.6, octaves=2, speed=2)
    swirl = Flow(753, freq=2.4, octaves=3, speed=2)

    def water(points, t, lift=0.0):
        m = ripple(points, t)
        return rgba(ramp(np.clip(0.32 + 0.46 * m + lift, 0, 1), WATER), np.full(len(points), 0.9))

    def arm_path(side, swing):
        """Плечо, локоть и кулак: swing от 0 до 1 заносит руку и бьёт ей вперёд."""
        k = np.linspace(0, 1, arm_nodes)[:, None]
        shoulder = np.array([side * 0.86, 0.92, 0.0])
        rest = np.array([side * 1.28, -0.2, 0.28])
        hit = np.array([side * 0.5, 0.5, 1.75])
        hand = rest * (1 - swing) + hit * swing
        elbow = (shoulder + hand) / 2 + np.array([side * 0.45, -0.1 + 0.3 * swing, -0.32])
        return (1 - k) ** 2 * shoulder + 2 * k * (1 - k) * elbow + k ** 2 * hand, hand

    result = []
    for f in range(frames):
        t = f / frames
        breathe = 0.04 * math.sin(TAU * t)
        n = swell(dirs, t)
        # Широкие плечи и узкая талия: фигура читается как воин, а не как капля.
        taper = 0.62 + 0.46 * np.clip(dirs[:, 1] + 0.25, -1, 1)
        torso = dirs * (1 + 0.12 * n)[:, None] * np.array([0.98, 1.02, 0.6])
        torso[:, 0] *= taper
        torso[:, 2] *= 0.8 + 0.3 * taper
        torso += np.array([0, 0.52 + breathe, 0])
        head = dirs * (1 + 0.06 * n)[:, None] * np.array([0.27, 0.4, 0.31]) + np.array([0, 1.66 + breathe, 0.08])
        spot = np.stack([np.cos(theta) * 1.2, s * 3, np.sin(theta) * 1.2], axis=1)
        m = swirl(spot, t)
        turned = theta + 2.2 * (1 - s) - TAU * t
        radius = (0.5 + 0.92 * (1 - s) ** 2.1) * (1 + 0.2 * m)
        base = np.stack([radius * np.cos(turned), -1.62 + s * 1.9, radius * np.sin(turned)], axis=1)
        left = max(0.0, math.sin(TAU * t)) ** 2
        right = max(0.0, -math.sin(TAU * t)) ** 2
        left_path, left_hand = arm_path(-1, left)
        right_path, right_hand = arm_path(1, right)
        thick = 0.3 - 0.1 * np.linspace(0, 1, arm_nodes)
        left_arm = tube(left_path, thick, arm_nu)
        right_arm = tube(right_path, thick, arm_nu)
        left_fist = dirs * (1 + 0.1 * n)[:, None] * 0.36 + left_hand
        right_fist = dirs * (1 + 0.1 * n)[:, None] * 0.36 + right_hand
        parts = [(torso, water(torso, t)), (head, water(head, t, 0.15)),
                 (base, rgba(ramp(np.clip(0.4 + 0.46 * m + 0.3 * (1 - s), 0, 1), WATER), np.full(len(theta), 0.88))),
                 (left_arm, water(left_arm, t)), (right_arm, water(right_arm, t)),
                 (left_fist, water(left_fist, t, 0.08)), (right_fist, water(right_fist, t, 0.08))]
        for side in (-1, 1):
            spark = eye * np.array([0.1, 0.03, 0.05]) @ rotation((0, 0, 1), side * 0.32).T + np.array([side * 0.13, 1.72 + breathe, 0.36])
            parts.append((spark, rgba(np.ones((len(eye), 3)), np.ones(len(eye)))))
        for x, y, z, lean in spikes:
            placed = spike @ rotation((0, 0, 1), lean).T + np.array([x, y + breathe, z])
            height = np.clip(spike[:, 1] / 0.95, 0, 1)[:, None]
            parts.append((placed, rgba(np.array([0.24, 0.6, 0.9]) * (1 - height) + np.array([0.86, 0.97, 1.0]) * height, np.full(len(spike), 0.95))))
        result.append(stack(parts))
    save("water_guardian", result, quads)


def rock_fist():
    """Каменный кулак: предплечье с костяшками вырывается из земли, замирает и уходит обратно."""
    frames = 20
    bones = [(751, (0.72, 1.5, 0.72), (0, 0.9, 0)), (752, (0.9, 0.66, 0.74), (0, 2.5, 0)),
             (753, (0.26, 0.3, 0.3), (-0.6, 3.05, 0.34)), (754, (0.26, 0.32, 0.3), (-0.2, 3.12, 0.38)),
             (755, (0.26, 0.32, 0.3), (0.2, 3.12, 0.38)), (756, (0.26, 0.3, 0.3), (0.6, 3.05, 0.34)),
             (757, (0.3, 0.42, 0.3), (0.86, 2.5, 0.34))]
    shapes = [rock(seed, cuts=5, planes=10, scale=scale, depth=0.6) for seed, scale, _ in bones]
    quads = faces([(len(p), q) for p, q, _ in shapes])
    whole = np.concatenate([p + np.array(at) for (p, _, _), (_, _, at) in zip(shapes, bones)])
    colour = np.concatenate([c for _, _, c in shapes])
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        up = 1 - (1 - min(1.0, t * 5)) ** 3
        over = 0.35 * math.sin(min(1.0, t * 5) * math.pi)
        down = max(0.0, (t - 0.72) / 0.28) ** 2
        lean = rotation((1, 0, 0.4), 0.2 * math.sin(t * 5))
        result.append((whole @ lean.T + np.array([0, -4.2 * (1 - up) + over - 4.4 * down, 0]), colour))
    save("rock_fist", result, quads)


def great_tornado():
    funnel("great_tornado", GALE, 761)


def rain_column():
    """Дождь: струи падают ровным кругом и гаснут у земли, поэтому петля незаметна."""
    frames, strands, height = 10, 150, 2.4
    rng = np.random.default_rng(771)
    angle = rng.uniform(0, TAU, strands)
    distance = np.sqrt(rng.uniform(0, 1, strands)) * 3.0
    phase = rng.uniform(0, 1, strands)
    side = np.stack([np.cos(angle + 1.3), np.zeros(strands), np.sin(angle + 1.3)], axis=1) * 0.012
    center = np.stack([np.cos(angle) * distance, np.zeros(strands), np.sin(angle) * distance], axis=1)
    quads = np.array([(i * 4, i * 4 + 1, i * 4 + 2, i * 4 + 3) for i in range(strands)], dtype=np.int32)
    result = []
    for f in range(frames):
        t = f / frames
        fall = (phase + t) % 1.0
        top = height * (1 - fall)
        bottom = np.maximum(top - 0.34, 0.0)
        low = center + np.stack([np.zeros(strands), bottom, np.zeros(strands)], axis=1)
        high = center + np.stack([np.zeros(strands), top, np.zeros(strands)], axis=1)
        pos = np.stack([low - side, low + side, high + side, high - side], axis=1).reshape(-1, 3)
        fade = np.clip(fall * 7, 0, 1) * np.clip((1 - fall) * 7, 0, 1)
        col = rgba(ramp(np.full(len(pos), 0.72), WATER), np.repeat(fade * 0.8, 4))
        result.append((pos, col))
    save("rain_column", result, quads)


# ---------------------------------------------------------------- духи стихий

def slit(ball, side, x, y, z, length=0.1, height=0.022, slant=0.34):
    """Узкий злой глаз: вытянутая точка, наклонённая к переносице."""
    return (ball * np.array([length, height, 0.03])) @ rotation((0, 0, 1), side * slant).T + np.array([side * x, y, z])


def mob_fire():
    """Искрень: обугленная маска с горящими щелями, за ней корона языков пламени, снизу тело сходит на нет."""
    frames, nu, nv = 24, 40, 24
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    flame = grid(nu, nv)
    count = nu * nv
    small, small_q, *_ = sphere(10, 7, axis=1)
    mask = rock(801, cuts=6, planes=11, scale=(0.2, 0.26, 0.13))
    horn, horn_q = crystal(0.34, 0.05, sides=4)
    shard, shard_q = crystal(0.34, 0.09, sides=4)
    quads = faces([(count, flame), (count, flame), (len(mask[0]), mask[1]), (len(small), small_q), (len(small), small_q),
                   (len(horn), horn_q), (len(horn), horn_q)] + [(len(shard), shard_q)] * 4)
    licks = Flow(806, freq=2.2, octaves=3, gain=0.6, speed=2)
    result = []
    for f in range(frames):
        t = f / frames
        spot = np.stack([np.cos(theta) * 1.3, s * 3.2, np.sin(theta) * 1.3], axis=1)
        n = licks(spot, t)
        parts = []
        for width, heat, tongues in ((1.0, 0.0, 5), (0.62, 0.3, 4)):
            profile = (0.03 + 0.5 * np.sin(np.pi * np.clip(s * 1.12, 0, 1) ** 1.5) ** 1.1) * width
            radius = profile * (1 + 0.3 * n)
            crown = 0.62 * s ** 3 * np.maximum(np.sin(theta * tongues - TAU * t + n * 1.4), 0) ** 1.5
            turn = theta + 0.9 * s
            sway = 0.1 * s * s * math.sin(TAU * t)
            body = np.stack([radius * np.cos(turn) + sway, 0.1 + s * 1.28 + crown, radius * np.sin(turn)], axis=1)
            h = 0.72 - 0.56 * s + heat + 0.24 * n
            parts.append((body, rgba(ramp(np.clip(h, 0, 1), FIRE), np.clip(1.4 - s ** 4, 0, 1))))
        face = mask[0] + np.array([0, 1.0, 0.27])
        coal = 0.05 + 0.12 * np.clip(np.sin(mask[0][:, 0] * 40) * np.sin(mask[0][:, 1] * 30), 0, 1)
        parts.append((face, rgba(np.repeat(coal[:, None], 3, axis=1) * np.array([1.1, 0.9, 0.8]), np.ones(len(face)))))
        for side in (-1, 1):
            parts.append((slit(small, side, 0.09, 1.06, 0.42), rgba(np.tile(np.array([1.0, 0.92, 0.5]), (len(small), 1)), np.ones(len(small)))))
        for side in (-1, 1):
            placed = horn @ rotation((0, 0, 1), -side * 0.5).T + np.array([side * 0.15, 1.2, 0.22])
            parts.append((placed, rgba(np.tile(np.array([0.09, 0.06, 0.05]), (len(horn), 1)), np.ones(len(horn)))))
        for i in range(4):
            a = i / 4 * TAU + TAU * t
            tilt = rotation((math.cos(a), 0.3, math.sin(a)), 1.2 + TAU * t)
            placed = shard @ tilt.T + np.array([math.cos(a) * 0.72, 0.72 + 0.18 * math.sin(a * 2), math.sin(a) * 0.72])
            hot = np.clip(shard[:, 1] / 0.34, 0, 1) * 0.5 + 0.1
            parts.append((placed, rgba(ramp(hot, MAGMA), np.ones(len(shard)))))
        result.append(stack(parts))
    save("mob_fire", result, quads)


def mob_water():
    """Омутник: сгорбленный хищник из тёмной воды. Ледяной хребет, челюсть с клыками открывается, передние лапы загребают."""
    frames = 24
    dirs, ball, *_ = sphere(34, 24, axis=1)
    small, small_q, *_ = sphere(8, 6, axis=1)
    fin, fin_q = crystal(0.4, 0.075, sides=4)
    fang, fang_q = crystal(0.17, 0.03, sides=4)
    nodes, nu = 10, 9
    limb = grid(nu, nodes)
    spine = [(0.1 + i * -0.2, 0.92 - abs(i - 1.3) * 0.08) for i in range(5)]
    teeth = 8
    quads = faces([(len(dirs), ball), (len(dirs), ball), (nodes * nu, limb), (nodes * nu, limb), (len(small), small_q), (len(small), small_q)]
                  + [(len(fin), fin_q)] * len(spine) + [(len(fang), fang_q)] * teeth)
    swell = Flow(811, freq=1.8, octaves=3, gain=0.5, speed=1)
    ripple = Flow(812, freq=4.2, octaves=2, speed=2)
    along = np.linspace(0, 1, nodes)[:, None]
    result = []
    for f in range(frames):
        t = f / frames
        bite = max(0.0, math.sin(TAU * t)) ** 2
        bob = 0.05 * math.sin(TAU * t + 1)
        n = swell(dirs, t)
        m = ripple(dirs, t)
        hunch = dirs * (1 + 0.1 * n)[:, None] * np.array([0.46, 0.4, 0.74])
        hunch[:, 1] += 0.22 * (1 - (hunch[:, 2] + 0.1) ** 2 * 1.6)
        body = hunch + np.array([0, 0.5 + bob, -0.12])
        skull = dirs * (1 + 0.06 * n)[:, None] * np.array([0.3, 0.2 - 0.03 * bite, 0.38]) + np.array([0, 0.58 + bob + 0.05 * bite, 0.6])
        def dark(points, lift):
            h = 0.12 + 0.3 * (m * 0.5 + 0.5) + lift
            return rgba(ramp(np.clip(h, 0, 1), WATER), np.full(len(points), 0.92))
        parts = [(body, dark(body, 0.1 * np.clip(dirs[:, 1], 0, 1))), (skull, dark(skull, 0.16))]
        for side in (-1, 1):
            swing = 0.26 * math.sin(TAU * t + side)
            start = np.array([side * 0.38, 0.58 + bob, 0.26])
            hand = np.array([side * 0.56, 0.05, 0.62 + swing])
            elbow = (start + hand) / 2 + np.array([side * 0.26, 0.24, -0.1])
            path = (1 - along) ** 2 * start + 2 * along * (1 - along) * elbow + along ** 2 * hand
            arm = tube(path, 0.12 - 0.06 * along[:, 0], nu)
            parts.append((arm, rgba(ramp(np.full(len(arm), 0.3), WATER), np.full(len(arm), 0.92))))
        for side in (-1, 1):
            parts.append((slit(small, side, 0.14, 0.66 + bob + 0.05 * bite, 0.88, 0.075, 0.02, 0.4), rgba(np.tile(np.array([0.72, 1.0, 0.98]), (len(small), 1)), np.ones(len(small)))))
        for z, top in spine:
            placed = fin @ rotation((1, 0, 0), -0.75).T + np.array([0, top + bob, z])
            tall = np.clip(fin[:, 1] / 0.4, 0, 1)[:, None]
            parts.append((placed, rgba(np.array([0.2, 0.5, 0.82]) * (1 - tall) + np.array([0.88, 0.98, 1.0]) * tall, np.full(len(fin), 0.96))))
        for i in range(teeth):
            a = (i + 0.5) / teeth * math.pi
            x = math.cos(a) * 0.26
            z = 0.6 + math.sin(a) * 0.34
            placed = fang @ rotation((1, 0, 0), math.pi).T + np.array([x, 0.54 + bob + 0.05 * bite, z])
            parts.append((placed, rgba(np.tile(np.array([0.9, 0.98, 1.0]), (len(fang), 1)), np.ones(len(fang)))))
        result.append(stack(parts))
    save("mob_water", result, quads)


def mob_earth():
    """Глыбень: сутулый голем, голова вдавлена в плечи, длинные руки почти до земли, по груди тлеют трещины."""
    frames = 24
    chest = rock(821, cuts=8, planes=16, scale=(0.74, 0.56, 0.48), depth=0.72)
    head = rock(822, cuts=5, planes=11, scale=(0.24, 0.2, 0.26), depth=0.72)
    upper = rock(823, cuts=4, planes=10, scale=(0.2, 0.36, 0.2), depth=0.7)
    fist = rock(826, cuts=4, planes=10, scale=(0.3, 0.27, 0.3), depth=0.7)
    leg = rock(824, cuts=4, planes=10, scale=(0.24, 0.27, 0.26), depth=0.7)
    eye_dirs, eye_q, *_ = sphere(8, 6, axis=1)
    quads = faces([(len(chest[0]), chest[1]), (len(head[0]), head[1]), (len(upper[0]), upper[1]), (len(upper[0]), upper[1]),
                   (len(fist[0]), fist[1]), (len(fist[0]), fist[1]), (len(leg[0]), leg[1]), (len(leg[0]), leg[1]),
                   (len(eye_dirs), eye_q), (len(eye_dirs), eye_q)])
    stone = np.array([0.5, 0.47, 0.43])
    moss = np.array([0.24, 0.36, 0.14])
    soil = Flow(825, freq=5.0, octaves=2, speed=0)
    veins = Flow(827, freq=2.6, octaves=3, gain=0.6, speed=0)
    ember = Flow(828, freq=1.6, octaves=2, speed=1)

    def coat(points, base, shape, t, glow):
        up = normals(points, shape) @ np.array([0, 1.0, 0])
        tone = np.clip(up * 1.6 - 0.5 + 0.5 * soil(points, 0.0), 0, 1)[:, None]
        rgb = baked(points, shape, base * stone * (1 - tone) + moss * tone)
        if glow:
            crack = np.clip(1 - np.abs(veins(points, 0.0)) * 7.5, 0, 1)[:, None] * (0.75 + 0.25 * ember(points, t))[:, None]
            rgb = rgb * (1 - crack) + np.array([1.0, 0.52, 0.12]) * crack
        return rgb

    result = []
    for f in range(frames):
        t = f / frames
        swing = math.sin(TAU * t)
        bob = 0.05 * abs(math.cos(TAU * t))
        lean = rotation((1, 0, 0), 0.26)
        parts = [(chest[0] @ lean.T + np.array([0, 1.08 + bob, 0.06]), chest, True)]
        parts.append((head[0] + np.array([0, 1.46 + bob, 0.36]), head, False))
        hands = []
        for side in (-1, 1):
            turn = rotation((1, 0, 0), -0.55 * swing * side)
            parts.append(((upper[0] + np.array([0, -0.32, 0])) @ turn.T + np.array([side * 0.86, 1.4 + bob, 0.1]), upper, False))
            hands.append(((fist[0] + np.array([0, -0.88, 0])) @ turn.T + np.array([side * 0.9, 1.4 + bob, 0.1]), fist, False))
        parts.extend(hands)
        for side in (-1, 1):
            turn = rotation((1, 0, 0), 0.6 * swing * side)
            parts.append(((leg[0] + np.array([0, -0.24, 0])) @ turn.T + np.array([side * 0.36, 0.52 + bob, 0]), leg, False))
        pos, col = [], []
        for points, (_, shape, colour), glow in parts:
            pos.append(points)
            col.append(rgba(coat(points, colour[:, :3], shape, t, glow), np.ones(len(points))))
        for side in (-1, 1):
            pos.append(slit(eye_dirs, side, 0.1, 1.5 + bob, 0.6, 0.075, 0.022, 0.3))
            col.append(rgba(np.tile(np.array([1.0, 0.7, 0.2]), (len(eye_dirs), 1)), np.ones(len(eye_dirs))))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("mob_earth", result, quads)


def mob_air():
    """Грозовик: тёмная птица бури. Рваные стреловидные крылья с прожилкой молнии, крючковатый клюв, гребень и разряд вместо хвоста."""
    frames, span, chord = 16, 26, 8
    dirs, ball, *_ = sphere(18, 12, axis=1)
    small, small_q, *_ = sphere(8, 6, axis=1)
    wing = grid(chord, span, wrap=False)
    u = np.repeat(np.linspace(0, 1, span), chord)
    v = np.tile(np.linspace(0, 1, chord), span)
    beak, beak_q = crystal(0.3, 0.075, sides=4)
    crest, crest_q = crystal(0.3, 0.04, sides=4)
    nodes, nu = 9, 5
    bolt_q = grid(nu, nodes)
    quads = faces([(len(dirs), ball), (len(dirs), ball), (span * chord, wing), (span * chord, wing), (len(beak), beak_q),
                   (len(small), small_q), (len(small), small_q)] + [(len(crest), crest_q)] * 3 + [(nodes * nu, bolt_q)] * 2)
    along = np.linspace(0, 1, nodes)
    churn = Flow(831, freq=3.0, octaves=2, speed=1)
    result = []
    for f in range(frames):
        t = f / frames
        flap = math.sin(TAU * t)
        n = churn(dirs, t)
        body = dirs * (1 + 0.1 * n)[:, None] * np.array([0.2, 0.2, 0.58]) + np.array([0, 0.5, -0.02])
        head = dirs * (1 + 0.05 * n)[:, None] * np.array([0.15, 0.15, 0.22]) + np.array([0, 0.6, 0.6])
        h = 0.04 + 0.24 * (dirs[:, 1] + 1) / 2 + 0.08 * n
        parts = [(body, rgba(ramp(np.clip(h, 0, 1), GALE), np.ones(len(dirs)))), (head, rgba(ramp(np.clip(h + 0.05, 0, 1), GALE), np.ones(len(dirs))))]
        for side in (-1, 1):
            elbow = np.clip(u * 2.2, 0, 1)
            lift = 0.44 * flap * elbow + 0.5 * math.sin(TAU * t - 0.9) * np.clip(u - 0.45, 0, 1) * 1.8
            feathers = 0.62 + 0.38 * np.abs(np.sin(u * math.pi * 7))
            width = 0.72 * (1 - u ** 2.2) * feathers + 0.02
            x = side * (0.12 + u * 1.5)
            z = 0.1 - 0.7 * u ** 1.7 - v * width
            y = 0.56 + lift + 0.05 * np.sin(v * math.pi)
            vein = np.exp(-((v - 0.32 - 0.14 * np.sin(u * 19 + side)) / 0.09) ** 2)
            edge = np.clip(1 - v * 5, 0, 1)
            shade = 0.06 + 0.2 * edge + 0.74 * vein * np.clip(0.55 + 0.45 * math.sin(TAU * t * 2 + side), 0, 1)
            parts.append((np.stack([x, y, z], axis=1), rgba(ramp(np.clip(shade, 0, 1), GALE), np.ones(len(u)))))
        hook = beak @ rotation((1, 0, 0), math.pi / 2 + 0.42).T + np.array([0, 0.61, 0.76])
        tip = np.clip(beak[:, 1] / 0.3, 0, 1)[:, None]
        parts.append((hook, rgba(np.array([0.2, 0.22, 0.26]) * (1 - tip) + np.array([0.08, 0.08, 0.1]) * tip, np.ones(len(beak)))))
        for side in (-1, 1):
            parts.append((slit(small, side, 0.1, 0.66, 0.74, 0.05, 0.016, 0.45), rgba(np.tile(np.array([0.82, 0.93, 1.0]), (len(small), 1)), np.ones(len(small)))))
        for i in (-1, 0, 1):
            placed = crest @ rotation((1, 0, 0), -1.1 - 0.15 * abs(i)).T + np.array([i * 0.07, 0.72, 0.56 - abs(i) * 0.04])
            parts.append((placed, rgba(np.tile(np.array([0.28, 0.36, 0.48]), (len(crest), 1)), np.ones(len(crest)))))
        for k in (-1, 1):
            rng = np.random.default_rng(830 + f * 2 + k)
            path = np.stack([k * 0.08 * along + rng.normal(size=nodes) * 0.08 * along, 0.48 - 0.14 * along + rng.normal(size=nodes) * 0.06 * along, -0.56 - along * 0.9], axis=1)
            tail = tube(path, 0.04 - 0.03 * along, nu)
            parts.append((tail, rgba(np.tile(np.array([0.86, 0.94, 1.0]), (len(tail), 1)), np.ones(len(tail)))))
        result.append(stack(parts))
    save("mob_air", result, quads)
