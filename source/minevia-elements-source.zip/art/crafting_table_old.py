# Старый потёртый верстак: пиксельные текстуры 32x32 и модель во встроенном паке мода.
# Запуск: python crafting_table_old.py. Рисуется кодом по ручным правилам, без генераторов картинок.
import json
import os
import random

from PIL import Image

PACK = r"D:\Rudnik\elements-mod\src\main\resources\resourcepacks\minevia_fixes\assets"
TEX = os.path.join(PACK, "minevia_elements", "textures", "block")
S = 32

# Выцветший дуб: серо-коричневые тона, как у дерева, долго стоявшего под дождём.
WOOD = [(46, 34, 25), (66, 49, 35), (86, 66, 47), (104, 82, 59), (122, 99, 73), (140, 118, 90)]
ASH = (118, 110, 98)
GROOVE = (34, 25, 19)
IRON = [(40, 39, 42), (62, 60, 63), (88, 86, 88), (116, 113, 112)]
RUST = [(92, 46, 26), (124, 66, 34), (154, 92, 48)]
ROPE = [(92, 76, 52), (128, 108, 74), (150, 130, 92)]


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def planks(img, rng, x0, y0, w, h, vertical, boards):
    """Доски с волокнами, сучками, трещинами и серым налётом по краям."""
    size = (w if vertical else h) / boards
    for b in range(boards):
        start = int(round(b * size))
        end = int(round((b + 1) * size))
        tone = rng.choice([2, 3, 3, 4])
        grain = [rng.random() for _ in range(64)]
        for i in range(start, end):
            for j in range(h if vertical else w):
                x, y = (x0 + i, y0 + j) if vertical else (x0 + j, y0 + i)
                across = i - start
                level = tone
                if across == 0:
                    level = 1
                elif across == end - start - 1:
                    level = tone - 1
                if grain[(j // 3 + across * 5) % 64] > 0.82:
                    level -= 1
                if grain[(j // 5 + across * 3 + 7) % 64] > 0.9:
                    level += 1
                c = WOOD[max(0, min(5, level))]
                if rng.random() < 0.22:
                    c = mix(c, ASH, 0.35)
                img.putpixel((x, y), c)
        if rng.random() < 0.7:
            kx = x0 + (start + (end - start) // 2 if vertical else rng.randrange(2, w - 3))
            ky = y0 + (rng.randrange(2, h - 3) if vertical else start + (end - start) // 2)
            # Сучок: тёмный овал вдоль волокон, без крестиков.
            long_x = not vertical
            for dx, dy, c in ((0, 0, WOOD[0]), (1 if long_x else 0, 0 if long_x else 1, WOOD[0]),
                              (-1 if long_x else 0, 0 if long_x else -1, WOOD[1]), (2 if long_x else 0, 0 if long_x else 2, WOOD[1])):
                if x0 <= kx + dx < x0 + w and y0 <= ky + dy < y0 + h:
                    img.putpixel((kx + dx, ky + dy), c)


def crack(img, rng, x, y, steps, dx, dy, area):
    for _ in range(steps):
        if area[0] <= x < area[2] and area[1] <= y < area[3]:
            img.putpixel((x, y), GROOVE)
        x += dx if rng.random() < 0.8 else 0
        y += dy if rng.random() < 0.8 else 0
        if rng.random() < 0.3:
            x += rng.choice((-1, 1)) * (dy != 0)
            y += rng.choice((-1, 1)) * (dx != 0)


def plate(img, x, y, w, h, rusty):
    """Железная накладка с заклёпками, местами съеденная ржавчиной."""
    rng = random.Random(x * 31 + y)
    for i in range(w):
        for j in range(h):
            edge = i in (0, w - 1) or j in (0, h - 1)
            c = IRON[0] if edge else IRON[2 if (i + j) % 5 else 3]
            if rusty and rng.random() < 0.45 and not edge:
                c = rng.choice(RUST)
            img.putpixel((x + i, y + j), c)
    for i, j in ((1, 1), (w - 2, 1), (1, h - 2), (w - 2, h - 2)):
        if w > 3 and h > 3:
            img.putpixel((x + i, y + j), IRON[3])


def top():
    rng = random.Random(11)
    img = Image.new("RGB", (S, S))
    planks(img, rng, 0, 0, S, S, False, 4)
    # Рама: тёмные бортики по краю столешницы.
    for i in range(S):
        for k in range(2):
            for x, y in ((i, k), (i, S - 1 - k), (k, i), (S - 1 - k, i)):
                img.putpixel((x, y), WOOD[1] if k else WOOD[0])
    # Сетка 3x3: процарапанные и местами стёртые бороздки.
    for g in (11, 20):
        for i in range(3, S - 3):
            if rng.random() > 0.12:
                img.putpixel((g, i), GROOVE)
                img.putpixel((i, g), GROOVE)
            if rng.random() < 0.5:
                img.putpixel((g + 1, i), WOOD[1])
                img.putpixel((i, g + 1), WOOD[1])
    # Следы работы: порезы ножом, пятно и выщербленный угол.
    for _ in range(9):
        x, y = rng.randrange(4, S - 6), rng.randrange(4, S - 6)
        for k in range(rng.randrange(2, 5)):
            img.putpixel((x + k, y + k), WOOD[5])
    for x in range(22, 28):
        for y in range(4, 9):
            if (x - 25) ** 2 + (y - 6) ** 2 < 7:
                img.putpixel((x, y), mix(img.getpixel((x, y)), (30, 22, 18), 0.55))
    crack(img, rng, 5, 24, 9, 1, 0, (2, 2, S - 2, S - 2))
    for x, y in ((2, 2), (3, 2), (2, 3)):
        img.putpixel((x, y), GROOVE)
    for x, y in ((0, 0), (S - 6, 0), (0, S - 6), (S - 6, S - 6)):
        plate(img, x, y, 6, 6, True)
    return img


def side(front):
    rng = random.Random(23 if front else 29)
    img = Image.new("RGB", (S, S))
    planks(img, rng, 0, 0, S, S, True, 4)
    # Толстая столешница сверху и обвязка снизу.
    for x in range(S):
        for y in range(0, 6):
            img.putpixel((x, y), WOOD[[4, 3, 3, 2, 1, 0][y]] if rng.random() > 0.15 else WOOD[2])
        for y in range(S - 3, S):
            img.putpixel((x, y), WOOD[1 if y < S - 1 else 0])
    plate(img, 0, 6, 32, 2, True)
    crack(img, rng, 8, 10, 12, 0, 1, (0, 8, S, S - 3))
    if front:
        # Полка с инструментами: молоток и клещи висят на гвоздях.
        for x in range(4, 28):
            img.putpixel((x, 20), WOOD[5])
            img.putpixel((x, 21), WOOD[1])
        for y in range(10, 20):
            img.putpixel((8, y), ROPE[1] if y < 13 else WOOD[4])
        for x in range(5, 12):
            for y in range(10, 13):
                img.putpixel((x, y), IRON[2] if y < 12 else IRON[1])
        img.putpixel((5, 10), RUST[1])
        for k in range(8):
            img.putpixel((18 + k // 2, 10 + k), IRON[2])
            img.putpixel((24 - k // 2, 10 + k), IRON[1])
        for x in range(19, 24):
            img.putpixel((x, 18), RUST[0])
    else:
        # Старая пила на верёвке: зубья потемнели, полотно в ржавчине.
        for y in range(9, 12):
            img.putpixel((16, y), ROPE[2 if y % 2 else 0])
        for x in range(9, 24):
            for y in range(13, 17):
                if y == 16 and x % 2:
                    c = IRON[0]
                else:
                    c = IRON[2] if rng.random() > 0.35 else rng.choice(RUST)
                img.putpixel((x, y), c)
        for x in range(23, 27):
            for y in range(12, 18):
                img.putpixel((x, y), WOOD[1] if x in (23, 26) or y in (12, 17) else WOOD[4])
    return img


def bottom():
    rng = random.Random(41)
    img = Image.new("RGB", (S, S))
    planks(img, rng, 0, 0, S, S, False, 4)
    return img


os.makedirs(TEX, exist_ok=True)
for name, image in (("old_crafting_table_top", top()), ("old_crafting_table_front", side(True)),
                    ("old_crafting_table_side", side(False)), ("old_crafting_table_bottom", bottom())):
    image.save(os.path.join(TEX, name + ".png"))

model = {
    "parent": "minecraft:block/cube",
    "textures": {
        "particle": "minevia_elements:block/old_crafting_table_front",
        "down": "minevia_elements:block/old_crafting_table_bottom",
        "up": "minevia_elements:block/old_crafting_table_top",
        "north": "minevia_elements:block/old_crafting_table_front",
        "south": "minevia_elements:block/old_crafting_table_side",
        "east": "minevia_elements:block/old_crafting_table_side",
        "west": "minevia_elements:block/old_crafting_table_front",
    },
}
# Свой файл модели и состояния блока перекрывают 3D-верстак из пака Reimagined.
for folder, name, data in (("models/block", "crafting_table.json", model),
                           ("blockstates", "crafting_table.json", {"variants": {"": {"model": "minecraft:block/crafting_table"}}})):
    path = os.path.join(PACK, "minecraft", folder)
    os.makedirs(path, exist_ok=True)
    json.dump(data, open(os.path.join(path, name), "w", encoding="utf-8", newline="\n"), indent=2)

sheet = Image.new("RGB", (S * 4 * 8 + 30, S * 8))
for i, name in enumerate(("top", "front", "side", "bottom")):
    sheet.paste(Image.open(os.path.join(TEX, f"old_crafting_table_{name}.png")).resize((S * 8, S * 8), Image.NEAREST), (i * (S * 8 + 10), 0))
sheet.save(os.path.join(os.environ.get("TEMP", "."), "old_table_sheet.png"))
print("верстак готов")
