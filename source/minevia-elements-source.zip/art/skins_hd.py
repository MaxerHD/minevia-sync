"""HD-версии скинов персонажей: 128x128 вместо 64x64, рисунок тот же, детали в каждом пикселе.

Каждый пиксель обычного скина становится квадратом 2x2, и в нём появляется то, чего в 64x64 не уместить:
свет сверху и тень снизу на каждой грани, тёмная кромка по краю части тела, шов на границе цветов,
фактура ткани, пряди в волосах и блик в глазах. Генератор детерминированный, без нейросетей.
Ещё сюда дописываются пиксели для живых глаз из пака Just Expressions (моргание, взгляд).

Запуск: python skins_hd.py. Исходники 64x64 лежат в art/skins-64 и не меняются.
"""
import colorsys
import hashlib
from pathlib import Path
from PIL import Image

from skins_detail import decorate

ART = Path(__file__).resolve().parent
SRC = ART / "skins-64"
OUT_SYNC = Path(r"D:\Rudnik\sync\skins")
OUT_BUILTIN = Path(r"D:\Rudnik\src\renderer\skins")
BUILTIN_NAMES = {"Alither": "alither", "Niga": "niga", "Zlauka": "zlauka", "Master of slaves": "master_of_slaves"}
K = 2

# Глаза 2x1 на пятой строке лица, как у Стива: так их понимает Just Expressions.
# Строка 2 пустого угла: веки цвета кожи, строка 3: белок, зрачок, зрачок, белок.
EYE_ROW = 4


def parts(slim):
    arm = 3 if slim else 4
    # (размер w, h, d), развёртка основы, развёртка внешнего слоя, мягкость градиента
    return [
        ((8, 8, 8), (0, 0), (32, 0), 0.5),
        ((8, 12, 4), (16, 16), (16, 32), 1.0),
        ((arm, 12, 4), (40, 16), (40, 32), 1.0),
        ((arm, 12, 4), (32, 48), (48, 48), 1.0),
        ((4, 12, 4), (0, 16), (0, 32), 1.0),
        ((4, 12, 4), (16, 48), (0, 48), 1.0),
    ]


def faces(size, uv):
    w, h, d = size
    u, v = uv
    return {
        "top": (u + d, v, w, d),
        "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h),
        "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h),
        "back": (u + d + w + d, v + d, w, h),
    }


def noise(x, y, salt):
    """Повторяемый шум: одинаковый при каждом запуске, поэтому скин не «плывёт» между версиями."""
    digest = hashlib.blake2s(f"{salt}:{x}:{y}".encode(), digest_size=2).digest()
    return (digest[0] / 255.0) * 2 - 1


def luma(p):
    return 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2]


def is_skin(p):
    h, s, v = colorsys.rgb_to_hsv(p[0] / 255, p[1] / 255, p[2] / 255)
    return 0.02 <= h <= 0.12 and 0.18 <= s <= 0.6 and v >= 0.45


def is_hair(p, kind):
    return kind == "head" and luma(p) < 80 and not is_skin(p)


def shade(p, factor, add=0.0):
    return tuple(max(0, min(255, int(round(c * factor + add)))) for c in p[:3]) + (p[3],)


def enhance(src, dst, rect, kind, side, soft, salt):
    x0, y0, w, h = rect
    for sy in range(h):
        for sx in range(w):
            p = src.getpixel((x0 + sx, y0 + sy))
            if p[3] == 0:
                continue
            skin = is_skin(p)
            # На лице ниже лба тёмное это брови, глаза или синяк, а не волосы: прядей там нет.
            hair = is_hair(p, kind) and not (side == "front" and sy >= 3)
            for dy in range(K):
                for dx in range(K):
                    X = (x0 + sx) * K + dx
                    Y = (y0 + sy) * K + dy
                    fx = (sx * K + dx + 0.5) / (w * K)
                    fy = (sy * K + dy + 0.5) / (h * K)
                    f = 1.0
                    a = 0.0
                    if side in ("front", "back", "left", "right"):
                        # Свет сверху: верх грани чуть светлее, низ темнее.
                        f *= 1.045 - 0.10 * fy * soft
                        # Кромка по краю части тела: объём без чёрного контура.
                        if sx * K + dx == 0 or sx * K + dx == w * K - 1:
                            f *= 0.9
                        if sy * K + dy == h * K - 1:
                            f *= 0.88
                    elif side == "top":
                        f *= 1.03
                    else:
                        f *= 0.92
                    n = noise(X, Y, salt)
                    if hair:
                        # Пряди: светлые вертикальные ниточки там, где шум совпал по столбцу.
                        if noise(X, 0, salt + "h") > 0.35 and (dy + sy) % 3 != 2:
                            a += 14
                        a += n * 4
                    elif skin:
                        a += n * 2
                    else:
                        # Ткань: мелкая неровность и полоса переплетения. На светлой ткани слабее, иначе похоже на грязь.
                        light = luma(p) > 170
                        a += n * (2 if light else 3.5) + (0 if light else 2 if (X + Y) % 4 == 0 else 0)
                    # Шов на границе цветов внутри грани: тёмная сторона получает тонкую линию. На лице швов нет.
                    face = kind == "head" and side == "front"
                    for nx, ny, edge in ([] if face else ((-1, 0, dx == 0), (1, 0, dx == K - 1), (0, -1, dy == 0), (0, 1, dy == K - 1))):
                        if not edge or not (0 <= sx + nx < w and 0 <= sy + ny < h):
                            continue
                        q = src.getpixel((x0 + sx + nx, y0 + sy + ny))
                        if q[3] and luma(q) - luma(p) > 45:
                            f *= 0.86
                    dst.putpixel((X, Y), shade(p, f, a))


def eyes(src, dst):
    """Глаза: зрачок рядом с белком получает блик сверху, белок и сам зрачок остаются чистыми.

    Глазами считается только верхняя строка, где белок стоит рядом с тёмным: ниже бывают не глаза,
    а часть лица. У Master of slaves там врождённый синяк, и его трогать нельзя.
    """
    def pair(y):
        return any(luma(src.getpixel((x, y))) < 90 and (luma(src.getpixel((x - 1, y))) > 200 or luma(src.getpixel((x + 1, y))) > 200)
                   for x in range(9, 15))
    rows = [y for y in range(8 + 2, 8 + 7) if pair(y)]
    for y in rows[:1]:
        for x in range(8, 16):
            p = src.getpixel((x, y))
            if luma(p) >= 90:
                continue
            left = luma(src.getpixel((x - 1, y))) > 200 if x > 8 else False
            right = luma(src.getpixel((x + 1, y))) > 200 if x < 15 else False
            if not (left or right):
                continue
            near = 0 if left else 1
            dst.putpixel((x * K + near, y * K), (238, 240, 246, 255))
            dst.putpixel((x * K + 1 - near, y * K), p[:3] + (255,))
            dst.putpixel((x * K, y * K + 1), p[:3] + (255,))
            dst.putpixel((x * K + 1, y * K + 1), p[:3] + (255,))
        for x in range(8, 16):
            p = src.getpixel((x, y))
            if luma(p) > 200:
                for dy in range(K):
                    for dx in range(K):
                        dst.putpixel((x * K + dx, y * K + dy), p[:3] + (255,))


def expressions(src, dst):
    """Пиксели для Just Expressions, только для глаз 2x1 на пятой строке лица."""
    row = [src.getpixel((x, 8 + EYE_ROW)) for x in range(8, 16)]
    whites = [i for i, p in enumerate(row) if luma(p) > 200]
    if whites != [1, 6]:
        return False
    lid = src.getpixel((9, 8 + EYE_ROW + 1))
    marks = {(4, 2): lid, (5, 2): lid, (6, 2): lid, (7, 2): lid,
             (4, 3): row[1], (5, 3): row[2], (6, 3): row[5], (7, 3): row[6]}
    for (x, y), p in marks.items():
        for dy in range(K):
            for dx in range(K):
                dst.putpixel((x * K + dx, y * K + dy), p[:3] + (255,))
    return True


def convert(path):
    src = Image.open(path).convert("RGBA")
    slim = src.getpixel((54, 20))[3] == 0
    dst = Image.new("RGBA", (64 * K, 64 * K), (0, 0, 0, 0))
    salt = path.stem
    for index, (size, base, layer, soft) in enumerate(parts(slim)):
        kind = "head" if index == 0 else "body"
        for uv in (base, layer):
            for side, rect in faces(size, uv).items():
                enhance(src, dst, rect, kind, side, soft, f"{salt}{index}{uv}")
    eyes(src, dst)
    decorate(dst, src, path.stem, slim)
    alive = expressions(src, dst)
    return dst, slim, alive


def main():
    for path in sorted(SRC.glob("*.png")):
        image, slim, alive = convert(path)
        image.save(OUT_SYNC / path.name, optimize=True)
        image.save(OUT_BUILTIN / f"{BUILTIN_NAMES[path.stem]}.png", optimize=True)
        size = (OUT_SYNC / path.name).stat().st_size
        print(f"{path.stem}: 128x128, {'узкие' if slim else 'широкие'} руки, живые глаза: {'да' if alive else 'нет'}, {size} байт")


if __name__ == "__main__":
    main()
