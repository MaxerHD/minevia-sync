# Рендерит кадры готовых моделей: для проверки формы и для иконок способностей.
# Запуск: blender -b --factory-startup -P preview.py -- <папка> <размер> <колонок> <кадр 0..1> [имена]
import gzip
import math
import os
import struct
import sys

import bpy
import numpy as np
from mathutils import Vector

MESH = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements\mesh"


def load(name, position):
    data = gzip.open(os.path.join(MESH, name + ".mesh"), "rb").read()
    _, verts, quads, frames, extent = struct.unpack(">iiiif", data[:20])
    at = 20
    faces = np.frombuffer(data, ">u2", quads * 4, at).reshape(-1, 4).astype(int)
    at += quads * 8
    frame = min(frames - 1, int(position * frames))
    at += frame * verts * 13
    pos = np.frombuffer(data, ">i2", verts * 3, at).reshape(-1, 3).astype(float) / 32767 * extent
    at += verts * 6 + verts * 3
    col = np.frombuffer(data, np.uint8, verts * 4, at).reshape(-1, 4).astype(float) / 255
    return pos, faces, col


# Камни и ленты в файле модели серые: цвет им задаёт игра, а для иконок он задан здесь.
TINTS = {
    "ground_ring": (0.62, 0.52, 0.42), "stone_plates": (0.6, 0.56, 0.5), "stone_spike": (0.62, 0.56, 0.48),
    "stone_wall": (0.56, 0.54, 0.5), "helix": (0.42, 0.95, 0.85), "lightning": (0.75, 0.85, 1.0),
    "rock_orbit": (0.8, 0.7, 0.58), "rock_fist": (0.62, 0.55, 0.47), "ground_slab": (0.6, 0.52, 0.44),
    "ball_lightning": (0.72, 0.84, 1.0), "dust_puff": (0.95, 0.8, 0.52),
}


def material():
    mat = bpy.data.materials.new("Spell")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    mix = nodes.new("ShaderNodeMixShader")
    clear = nodes.new("ShaderNodeBsdfTransparent")
    body = nodes.new("ShaderNodeBsdfDiffuse")
    glow = nodes.new("ShaderNodeEmission")
    add = nodes.new("ShaderNodeAddShader")
    attr = nodes.new("ShaderNodeVertexColor")
    attr.layer_name = "Col"
    links.new(attr.outputs["Color"], body.inputs["Color"])
    links.new(attr.outputs["Color"], glow.inputs["Color"])
    glow.inputs["Strength"].default_value = 0.55
    links.new(body.outputs[0], add.inputs[0])
    links.new(glow.outputs[0], add.inputs[1])
    links.new(attr.outputs["Alpha"], mix.inputs[0])
    links.new(clear.outputs[0], mix.inputs[1])
    links.new(add.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], out.inputs["Surface"])
    return mat


def scene_for(size):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 24
    scene.cycles.use_denoising = False
    scene.cycles.transparent_max_bounces = 24
    scene.render.resolution_x = scene.render.resolution_y = size
    scene.render.film_transparent = True
    scene.render.image_settings.color_mode = "RGBA"
    scene.view_settings.view_transform = "Standard"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        prefs.compute_device_type = "OPTIX"
        prefs.get_devices()
        for device in prefs.devices:
            device.use = device.type == "OPTIX"
        scene.cycles.device = "GPU"
    except (KeyError, TypeError):
        pass
    sun = bpy.data.objects.new("Sun", bpy.data.lights.new("Sun", "SUN"))
    sun.data.energy = 2.2
    sun.rotation_euler = (0.9, 0.2, 0.6)
    scene.collection.objects.link(sun)
    world = bpy.data.worlds.new("World")
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs[0].default_value = (0.5, 0.55, 0.6, 1)
    world.node_tree.nodes["Background"].inputs[1].default_value = 0.6
    scene.world = world
    cam = bpy.data.objects.new("Camera", bpy.data.cameras.new("Camera"))
    scene.collection.objects.link(cam)
    scene.camera = cam
    return scene


def show(scene, names, position, file):
    objects = []
    mat = material()
    low = np.full(3, 1e9)
    high = -low
    for name in names:
        pos, faces, col = load(name, position)
        col = col.copy()
        col[:, :3] *= TINTS.get(name, (1, 1, 1))
        # В игре Y смотрит вверх, а в Blender Z.
        pos = pos[:, [0, 2, 1]] * np.array([1, -1, 1])
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(pos.tolist(), [], faces.tolist())
        attr = mesh.color_attributes.new("Col", "FLOAT_COLOR", "POINT")
        attr.data.foreach_set("color", col.ravel())
        mesh.materials.append(mat)
        for poly in mesh.polygons:
            poly.use_smooth = True
        obj = bpy.data.objects.new(name, mesh)
        scene.collection.objects.link(obj)
        objects.append(obj)
        low = np.minimum(low, pos.min(axis=0))
        high = np.maximum(high, pos.max(axis=0))
    center = Vector(((low + high) / 2).tolist())
    size = float(np.linalg.norm(high - low))
    cam = scene.camera
    cam.location = center + Vector((1.0, -1.25, 0.55)).normalized() * size * 1.6
    cam.rotation_euler = (center - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = 50
    scene.render.filepath = file
    bpy.ops.render.render(write_still=True)
    for obj in objects:
        bpy.data.objects.remove(obj)


GROUPS = {
    "fireball": ["fireball_core", "fireball_mid", "fireball_outer"],
    "fire_burst": ["fire_burst_core", "fire_burst_outer", "fire_shock"],
    "flame_jet": ["flame_jet_core", "flame_jet_outer"],
    "rock_storm": ["rock_tornado", "rock_orbit"],
    "meteor_full": ["meteor", "meteor_tail"],
}

args = sys.argv[sys.argv.index("--") + 1:]
folder, size, position = args[0], int(args[1]), float(args[3])
names = args[4:] or sorted(n[:-5] for n in os.listdir(MESH))
scene = scene_for(size)
os.makedirs(folder, exist_ok=True)
for name in names:
    show(scene, GROUPS.get(name, [name]), position, os.path.join(folder, name + ".png"))
print("Рендер готов")
