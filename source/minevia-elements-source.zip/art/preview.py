# Рендерит кадры готовых моделей: для проверки формы и для иконок способностей.
# Запуск: blender -b --factory-startup -P preview.py -- <папка> <размер> <колонок> <кадр 0..1> [имена]
import gzip
import math
import os
import struct
import sys

import bpy
import numpy as np
from mathutils import Vector

MESH = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements\mesh"


def load(name, position):
    data = gzip.open(os.path.join(MESH, name + ".mesh"), "rb").read()
    _, verts, quads, frames, extent = struct.unpack(">iiiif", data[:20])
    at = 20
    faces = np.frombuffer(data, ">u2", quads * 4, at).reshape(-1, 4).astype(int)
    at += quads * 8
    frame = min(frames - 1, int(position * frames))
    at += frame * verts * 13
    pos = np.frombuffer(data, ">i2", verts * 3, at).reshape(-1, 3).astype(float) / 32767 * extent
    at += verts * 6 + verts * 3
    col = np.frombuffer(data, np.uint8, verts * 4, at).reshape(-1, 4).astype(float) / 255
    return pos, faces, col


# Камни и ленты в файле модели серые: цвет им задаёт игра, а для иконок он задан здесь.
TINTS = {
    "ground_ring": (0.62, 0.52, 0.42), "stone_plates": (0.6, 0.56, 0.5), "stone_spike": (0.62, 0.56, 0.48),
    "stone_wall": (0.56, 0.54, 0.5), "helix": (0.42, 0.95, 0.85), "lightning": (0.75, 0.85, 1.0),
    "rock_orbit": (0.8, 0.7, 0.58), "rock_fist": (0.62, 0.55, 0.47), "ground_slab": (0.6, 0.52, 0.44),
    "ball_lightning": (0.72, 0.84, 1.0), "dust_puff": (0.95, 0.8, 0.52),
}


def material():
    mat = bpy.data.materials.new("Spell")
    mat.use_nodes = True
    nodes, links = mat.node_tree.nodes, mat.node_tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    mix = nodes.new("ShaderNodeMixShader")
    clear = nodes.new("ShaderNodeBsdfTransparent")
    body = nodes.new("ShaderNodeBsdfDiffuse")
    glow = nodes.new("ShaderNodeEmission")
    add = nodes.new("ShaderNodeAddShader")
    attr = nodes.new("ShaderNodeVertexColor")
    attr.layer_name = "Col"
    links.new(attr.outputs["Color"], body.inputs["Color"])
    links.new(attr.outputs["Color"], glow.inputs["Color"])
    glow.inputs["Strength"].default_value = 0.55
    links.new(body.outputs[0], add.inputs[0])
    links.new(glow.outputs[0], add.inputs[1])
    links.new(attr.outputs["Alpha"], mix.inputs[0])
    links.new(clear.outputs[0], mix.inputs[1])
    links.new(add.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], out.inputs["Surface"])
    return mat


def scene_for(size):
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 24
    scene.cycles.use_denoising = False
    scene.cycles.transparent_max_bounces = 24
    scene.render.resolution_x = scene.render.resolution_y = size
    scene.render.film_transparent = True
    scene.render.image_settings.color_mode = "RGBA"
    scene.view_settings.view_transform = "Standard"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        prefs.compute_device_type = "OPTIX"
        prefs.get_devices()
        for device in prefs.devices:
            device.use = device.type == "OPTIX"
        scene.cycles.device = "GPU"
    except (KeyError, TypeError):
        pass
    sun = bpy.data.objects.new("Sun", bpy.data.lights.new("Sun", "SUN"))
    sun.data.energy = 2.2
    sun.rotation_euler = (0.9, 0.2, 0.6)
    scene.collection.objects.link(sun)
    world = bpy.data.worlds.new("World")
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs[0].default_value = (0.5, 0.55, 0.6, 1)
    world.node_tree.nodes["Background"].inputs[1].default_value = 0.6
    scene.world = world
    cam = bpy.data.objects.new("Camera", bpy.data.cameras.new("Camera"))
    scene.collection.objects.link(cam)
    scene.camera = cam
    return scene


def show(scene, names, position, file):
    objects = []
    mat = material()
    low = np.full(3, 1e9)
    high = -low
    for name in names:
        pos, faces, col = load(name, position)
        col = col.copy()
        col[:, :3] *= TINTS.get(name, (1, 1, 1))
        # В игре Y смотрит вверх, а в Blender Z.
        pos = pos[:, [0, 2, 1]] * np.array([1, -1, 1])
        mesh = bpy.data.meshes.new(name)
        mesh.from_pydata(pos.tolist(), [], faces.tolist())
        attr = mesh.color_attributes.new("Col", "FLOAT_COLOR", "POINT")
        attr.data.foreach_set("color", col.ravel())
        mesh.materials.append(mat)
        for poly in mesh.polygons:
            poly.use_smooth = True
        obj = bpy.data.objects.new(name, mesh)
        scene.collection.objects.link(obj)
        objects.append(obj)
        low = np.minimum(low, pos.min(axis=0))
        high = np.maximum(high, pos.max(axis=0))
    center = Vector(((low + high) / 2).tolist())
    size = float(np.linalg.norm(high - low))
    cam = scene.camera
    cam.location = center + Vector((1.0, -1.25, 0.55)).normalized() * size * 1.6
    cam.rotation_euler = (center - cam.location).to_track_quat("-Z", "Y").to_euler()
    cam.data.lens = 50
    scene.render.filepath = file
    bpy.ops.render.render(write_still=True)
    for obj in objects:
        bpy.data.objects.remove(obj)


GROUPS = {
    "fireball": ["fireball_core", "fireball_mid", "fireball_outer"],
    "fire_burst": ["fire_burst_core", "fire_burst_outer", "fire_shock"],
    "flame_jet": ["flame_jet_core", "flame_jet_outer"],
    "rock_storm": ["rock_tornado", "rock_orbit"],
    "meteor_full": ["meteor", "meteor_tail"],
    "flame_stream": ["flame_stream_body", "flame_stream_core", "flame_stream_sparks"],
    "sand_stream": ["sand_stream_body", "sand_stream_sparks"],
    "lava_field": ["magma_pool_crust", "magma_pool"],
    "sword_cleave": ["sword_cleave_body", "sword_cleave_glow"],
    "sword_vortex": ["sword_vortex_body", "sword_vortex_glow"],
    "sword_parry": ["sword_parry_body", "sword_parry_glow"],
    "sword_lunge": ["sword_lunge_body", "sword_lunge_glow"],
    "sword_fallblade": ["sword_fallblade_body", "sword_fallblade_glow"],
    "sword_notch": ["sword_notch_body", "sword_notch_glow"],
    "sword_ring": ["sword_ring_body", "sword_ring_glow"],
    "sword_thousand": ["sword_thousand_body", "sword_thousand_glow"],
    "sword_riposte": ["sword_riposte_body", "sword_riposte_glow"],
    "sword_flow": ["sword_flow_body", "sword_flow_glow"],
    "sword_rage": ["sword_rage_body", "sword_rage_glow"],
    "sword_execution": ["sword_execution_body", "sword_execution_glow"],
    "bow_aimed": ["bow_aimed_body", "bow_aimed_glow"],
    "bow_fan": ["bow_fan_body", "bow_fan_glow"],
    "bow_retreat": ["bow_retreat_body", "bow_retreat_glow"],
    "bow_rain": ["bow_rain_body", "bow_rain_glow"],
    "bow_harpoon": ["bow_harpoon_body", "bow_harpoon_glow"],
    "bow_trap": ["bow_trap_body", "bow_trap_glow"],
    "bow_explosive": ["bow_explosive_body", "bow_explosive_glow"],
    "bow_celestial": ["bow_celestial_body", "bow_celestial_glow"],
    "bow_piercing": ["bow_piercing_body", "bow_piercing_glow"],
    "bow_focus": ["bow_focus_body", "bow_focus_glow"],
    "bow_seekers": ["bow_seekers_body", "bow_seekers_glow"],
    "bow_thicket": ["bow_thicket_body", "bow_thicket_glow"],
    "dark_sphere": ["dark_sphere_body", "dark_sphere_glow"],
    "dark_drain": ["dark_drain_body", "dark_drain_glow"],
    "dark_curse": ["dark_curse_body", "dark_curse_glow"],
    "dark_hands": ["dark_hands_body", "dark_hands_glow"],
    "dark_hole": ["dark_hole_body", "dark_hole_glow"],
    "dark_nightmare": ["dark_nightmare_body", "dark_nightmare_glow"],
    "dark_ghosts": ["dark_ghosts_body", "dark_ghosts_glow"],
    "dark_eclipse": ["dark_eclipse_body", "dark_eclipse_glow"],
    "dark_wraith": ["dark_wraith_body", "dark_wraith_glow"],
    "dark_soulguard": ["dark_soulguard_body", "dark_soulguard_glow"],
    "dark_plague": ["dark_plague_body", "dark_plague_glow"],
    "dark_pact": ["dark_pact_body", "dark_pact_glow"],
    "light_ray": ["light_ray_body", "light_ray_glow"],
    "light_heal": ["light_heal_body", "light_heal_glow"],
    "light_faith": ["light_faith_body", "light_faith_glow"],
    "light_cleanse": ["light_cleanse_body", "light_cleanse_glow"],
    "light_column": ["light_column_body", "light_column_glow"],
    "light_wings": ["light_wings_body", "light_wings_glow"],
    "light_spark": ["light_spark_body", "light_spark_glow"],
    "light_judgment": ["light_judgment_body", "light_judgment_glow"],
    "light_hammer": ["light_hammer_body", "light_hammer_glow"],
    "light_armor": ["light_armor_body", "light_armor_glow"],
    "light_sanctuary": ["light_sanctuary_body", "light_sanctuary_glow"],
    "light_blessing": ["light_blessing_body", "light_blessing_glow"],
    "sword1": ["weapon_sword_1_body", "weapon_sword_1_glow"],
    "bow1": ["weapon_bow_1_body", "weapon_bow_1_glow"],
    "gd1": ["weapon_glove_dark_1_body", "weapon_glove_dark_1_glow"],
    "gl1": ["weapon_glove_light_1_body", "weapon_glove_light_1_glow"],
    "sword2": ["weapon_sword_2_body", "weapon_sword_2_glow"],
    "bow2": ["weapon_bow_2_body", "weapon_bow_2_glow"],
    "gd2": ["weapon_glove_dark_2_body", "weapon_glove_dark_2_glow"],
    "gl2": ["weapon_glove_light_2_body", "weapon_glove_light_2_glow"],
    "sword3": ["weapon_sword_3_body", "weapon_sword_3_glow"],
    "bow3": ["weapon_bow_3_body", "weapon_bow_3_glow"],
    "gd3": ["weapon_glove_dark_3_body", "weapon_glove_dark_3_glow"],
    "gl3": ["weapon_glove_light_3_body", "weapon_glove_light_3_glow"],
    "sword4": ["weapon_sword_4_body", "weapon_sword_4_glow"],
    "bow4": ["weapon_bow_4_body", "weapon_bow_4_glow"],
    "gd4": ["weapon_glove_dark_4_body", "weapon_glove_dark_4_glow"],
    "gl4": ["weapon_glove_light_4_body", "weapon_glove_light_4_glow"],
    "sword5": ["weapon_sword_5_body", "weapon_sword_5_glow"],
    "bow5": ["weapon_bow_5_body", "weapon_bow_5_glow"],
    "gd5": ["weapon_glove_dark_5_body", "weapon_glove_dark_5_glow"],
    "gl5": ["weapon_glove_light_5_body", "weapon_glove_light_5_glow"],
    "slash": ["slash_arc_body", "slash_arc_glow"],
    "slashbig": ["slash_big_body", "slash_big_glow"],
    "arrow": ["arrow_power_body", "arrow_power_glow"],
    "gwave": ["great_wave_body", "great_wave_glow"],
    "lava_rock": ["magma_boulder", "magma_boulder_core"],
    "mire": ["mud_pool", "mud_bubbles"],
}

args = sys.argv[sys.argv.index("--") + 1:]
folder, size, position = args[0], int(args[1]), float(args[3])
names = args[4:] or sorted(n[:-5] for n in os.listdir(MESH))
scene = scene_for(size)
os.makedirs(folder, exist_ok=True)
for name in names:
    show(scene, GROUPS.get(name, [name]), position, os.path.join(folder, name + ".png"))
print("Рендер готов")
