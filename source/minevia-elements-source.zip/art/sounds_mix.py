# Сводит звуки мода: настоящие записи CC0 (rubberduck, OpenGameArt) и мягкий синтез для ветра и пара.
# Запуск: python sounds_mix.py. Записи лежат в art/sound-sources, пишет .ogg в ресурсы мода и sounds.json.
import glob
import json
import os
import shutil
import subprocess
import tempfile
import wave

import numpy as np

import sounds_water

SR = 44100
ART = os.path.dirname(os.path.abspath(__file__))
SOURCES = os.path.join(ART, "sound-sources")
SYNTH = os.path.join(SOURCES, "synth")
OUT = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements"
FOLDER = os.path.join(OUT, "sounds")
FILES = {os.path.basename(p): p for p in glob.glob(os.path.join(SOURCES, "**", "*.ogg"), recursive=True) if "synth" not in p}
rng = np.random.default_rng(77)


def decode(path):
    raw = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", path, "-f", "f32le", "-ac", "1", "-ar", str(SR), "-"], capture_output=True, check=True).stdout
    return np.frombuffer(raw, np.float32).astype(np.float64)


def repitch(x, ratio):
    if ratio == 1:
        return x
    n = int(len(x) / ratio)
    return np.interp(np.arange(n) * ratio, np.arange(len(x)), x)


def bands(x, low, high):
    """Мягкий срез спектра: без резких граней, поэтому не звенит."""
    spectrum = np.fft.rfft(x)
    f = np.fft.rfftfreq(len(x), 1 / SR)
    gain = 1 / np.sqrt(1 + (f / high) ** 6) * (1 / np.sqrt(1 + (low / np.maximum(f, 1)) ** 4))
    return np.fft.irfft(spectrum * gain, len(x))


def room(x, wet, seconds=0.9):
    """Короткий хвост комнаты: звук не обрывается сухо и не бьёт по ушам."""
    if wet <= 0:
        return x
    n = int(seconds * SR)
    tail = rng.normal(size=n) * np.exp(-np.arange(n) / (0.22 * SR))
    tail = bands(tail, 180, 3200)
    tail /= np.sqrt((tail ** 2).sum())
    size = len(x) + n
    length = 1 << int(size - 1).bit_length()
    wet_signal = np.fft.irfft(np.fft.rfft(x, length) * np.fft.rfft(tail, length), length)[:size]
    dry = np.zeros(size)
    dry[:len(x)] = x
    return dry + wet * wet_signal


def layer(parts):
    out = np.zeros(1)
    for part in parts:
        name, pitch, gain, delay = (list(part) + [1.0, 1.0, 0.0])[:4] if isinstance(part, tuple) else (part, 1.0, 1.0, 0.0)
        path = os.path.join(SYNTH, name) if name.startswith("synth:") is False and name not in FILES else FILES.get(name)
        if name.startswith("synth:"):
            path = os.path.join(SYNTH, name[6:] + ".ogg")
        x = decode(path)
        x = x / max(1e-6, np.sqrt(np.mean(x[np.abs(x) > 0.1 * np.abs(x).max()] ** 2)))
        x = repitch(x, pitch) * gain
        start = int(delay * SR)
        size = max(len(out), start + len(x))
        mixed = np.zeros(size)
        mixed[:len(out)] = out
        mixed[start:start + len(x)] += x
        out = mixed
    return out


def master(x, top, low, wet, level, longest):
    x = bands(x, low, top)
    x = x[:int(longest * SR)]
    x = room(x, wet)
    # Плотный, но не бьющий сигнал: мягкое ограничение вершин вместо жёсткого пика.
    x = x / max(1e-6, np.percentile(np.abs(x), 99.7))
    x = np.tanh(x * 0.9)
    head = min(len(x), int(0.012 * SR))
    x[:head] *= np.linspace(0, 1, head) ** 2
    tail = min(len(x), int(0.08 * SR))
    x[-tail:] *= np.linspace(1, 0, tail) ** 2
    return x / max(1e-6, np.abs(x).max()) * level


# Имя: (варианты, потолок частот, низ, комната, громкость). Вариант это список слоёв: файл, высота, громкость, задержка.
def s(prefix, number, pitch=1.0, gain=1.0, delay=0.0):
    return (f"{prefix}_{number:02d}.ogg", pitch, gain, delay)


def syn(name, pitch=1.0, gain=1.0, delay=0.0):
    return ("synth:" + name, pitch, gain, delay)


FIRE = "spell_fire"
MIX = {
    "fire_cast": ([[s(FIRE, 6)], [s(FIRE, 1)], [s(FIRE, 4)]], 6000, 90, 0.16, 0.55),
    "fire_blast": ([[s("bang", 9, 0.85), s(FIRE, 7, 1, 0.8)], [s("bang", 7, 0.85), s(FIRE, 7, 0.9, 0.8)], [s("bang", 1, 0.8), s(FIRE, 5, 1, 0.8)]], 4800, 45, 0.2, 0.62),
    "fire_ring": ([[s(FIRE, 3)], [s(FIRE, 4, 0.9)]], 5500, 90, 0.18, 0.55),
    "fire_armor": ([[s(FIRE, 5, 0.85)], [s(FIRE, 7, 0.9)]], 5000, 80, 0.14, 0.5),
    "fire_charge": ([[s(FIRE, 3, 0.75)], [s(FIRE, 5, 0.7)]], 4500, 70, 0.2, 0.5),
    "flame_loop": ([[syn("flame_loop")]], 2600, 70, 0.0, 0.34),
    "water_heal": ([[s("bubble", 1, 1.1), s("gong", 2, 2.0, 0.22, 0.05)], [s("bubble", 2, 1.2), s("gong", 2, 2.2, 0.2, 0.05)]], 4200, 120, 0.35, 0.45),
    "ice_form": ([[s("item_gem", 1, 0.9)], [s("item_gem", 3, 0.75)]], 4500, 160, 0.3, 0.42),
    "earth_rise": ([[("bfh1_rock_falling_02.ogg", 0.7, 1, 0)], [("bfh1_rock_falling_01.ogg", 0.75, 1, 0)], [s("stones", 1, 0.8)]], 3800, 50, 0.14, 0.56),
    "earth_throw": ([[s("stones", 4, 0.75), syn("air_dash", 0.8, 0.5)], [("bfh1_rock_falling_07.ogg", 0.75, 1, 0), syn("air_dash", 0.8, 0.5)]], 3800, 60, 0.12, 0.5),
    "earth_hit": ([[("bfh1_rock_breaking_02.ogg", 0.75, 1, 0), s("bang", 3, 1, 0.7)], [("bfh1_rock_falling_02.ogg", 0.7, 1, 0), s("bang", 10, 0.9, 0.7)]], 3600, 40, 0.16, 0.62),
    "earth_quake": ([[s("cannon", 2, 0.6, 0.9), ("bfh1_rock_falling_01.ogg", 0.6, 1, 0.05)], [s("bang", 3, 0.6, 0.9), ("bfh1_rock_falling_03.ogg", 0.6, 1, 0.05)]], 2600, 35, 0.22, 0.66),
    "earth_armor": ([[s("stones", 2, 0.9)], [s("item_stone", 1, 0.9)]], 4000, 70, 0.12, 0.48),
    "earth_spike": ([[("bfh1_rock_breaking_02.ogg", 0.9, 1, 0)], [("bfh1_rock_falling_02.ogg", 0.85, 1, 0)]], 4000, 60, 0.12, 0.54),
    "earth_wall": ([[("bfh1_rock_falling_01.ogg", 0.6, 1, 0), s("stones", 3, 0.7, 0.7)], [("bfh1_rock_falling_03.ogg", 0.6, 1, 0), s("stones", 2, 0.65, 0.7)]], 3000, 40, 0.18, 0.6),
    "air_dash": ([[syn("air_dash")]], 3000, 120, 0.14, 0.42),
    "air_saw": ([[syn("air_saw")]], 2800, 150, 0.1, 0.3),
    "air_gust": ([[syn("air_gust")]], 3000, 110, 0.18, 0.44),
    "air_tornado": ([[syn("air_tornado")]], 2400, 80, 0.18, 0.36),
    "air_dome": ([[syn("air_dome")]], 3000, 110, 0.22, 0.4),
    "combo": ([[s("gong", 2, 1.25), s("bang", 10, 1, 0.4)]], 3600, 60, 0.32, 0.55),
    "steam": ([[syn("steam")]], 3200, 120, 0.14, 0.36),
    "magma": ([[s("bubble", 1, 0.55), ("loop_bubbles_1.ogg", 0.6, 0.7, 0)], [s("bubble", 2, 0.5), ("loop_bubbles_02.ogg", 0.6, 0.7, 0)]], 2600, 45, 0.16, 0.5),
    "lightning": ([[s("cannon", 3, 1.1), syn("lightning", 1, 0.4)], [s("cannon", 5, 1.1), syn("lightning", 1, 0.4)]], 4200, 70, 0.2, 0.55),
    "thunder": ([[s("cannon", 2, 0.7), s("bang", 3, 0.6, 0.8, 0.06)], [s("bang", 9, 0.6), s("cannon", 1, 0.65, 0.7, 0.08)]], 2400, 30, 0.4, 0.64),
    "metal": ([[("bfh1_metal_hit_01.ogg", 0.8, 1, 0)], [("bfh1_metal_hit_03.ogg", 0.8, 1, 0)]], 4000, 120, 0.16, 0.42),
    "sand": ([[syn("sand")]], 3000, 110, 0.1, 0.36),
    "vacuum": ([[syn("vacuum")]], 2600, 70, 0.22, 0.42),
    "altar": ([[s("gong", 1, 0.8)]], 3000, 50, 0.42, 0.55),
    "trap": ([[("bfh1_metal_hit_02.ogg", 0.8, 1, 0)]], 3600, 110, 0.14, 0.42),
    "boss_awake": ([[s("creature_roar", 3, 0.75), s("gong", 2, 0.6, 0.5)], [s("creature_roar", 2, 0.75), s("gong", 2, 0.6, 0.5)]], 2800, 35, 0.34, 0.66),
    "boss_hurt": ([[s("creature_hurt", 1, 0.8)], [s("creature_hurt", 2, 0.8)]], 3200, 60, 0.18, 0.5),
    "boss_death": ([[s("creature_die", 1, 0.75), s("bang", 3, 0.65, 0.9, 0.05)]], 2800, 30, 0.4, 0.68),
    "seal_break": ([[("bfh1_glass_breaking_02.ogg", 0.75, 1, 0), s("gong", 2, 1.1, 0.4)]], 4200, 90, 0.34, 0.5),
    "wheel": ([[syn("wheel")]], 2400, 200, 0.0, 0.18),
    "sword_swing": ([[s("blade", 1, 0.82)], [s("blade", 2, 0.8)], [s("blade", 3, 0.84)]], 5000, 200, 0.1, 0.42),
    "sword_hit": ([[("bfh1_metal_hit_04.ogg", 0.85, 1, 0)], [("bfh1_metal_hit_05.ogg", 0.85, 1, 0)]], 4500, 130, 0.14, 0.46),
    "bow_shot": ([[s("blade", 1, 1.05, 0.7), ("spring_01.ogg", 1.2, 0.5, 0)], [s("blade", 3, 1.1, 0.7), ("spring_02.ogg", 1.2, 0.5, 0)]], 4800, 150, 0.08, 0.42),
    "bow_hit": ([[("wood_hit_01.ogg", 1, 1, 0)], [("wood_hit_03.ogg", 1, 1, 0)]], 4000, 100, 0.08, 0.44),
    "dark_cast": ([[s("spell", 2, 0.6), s("creature_monster", 3, 0.7, 0.7)], [s("spell", 1, 0.6), s("creature_monster", 4, 0.7, 0.7)]], 3000, 45, 0.36, 0.5),
    "dark_hit": ([[s("creature_monster", 4, 0.8), s("bang", 10, 0.7, 0.5)], [s("creature_monster", 3, 0.8), s("bang", 8, 0.7, 0.5)]], 2800, 45, 0.24, 0.5),
    "light_cast": ([[s("bell", 1, 0.9), s("gong", 2, 2.0, 0.3, 0.03)], [s("bell", 1, 1.0), s("gong", 1, 1.6, 0.25, 0.03)]], 3600, 200, 0.42, 0.42),
    "light_hit": ([[s("item_gem", 1, 0.9), s("bell", 2, 0.7, 0.3)], [s("item_gem", 3, 0.8), s("bell", 1, 1.2, 0.25)]], 3800, 200, 0.32, 0.42),
}
FAR = {"boss_awake": 64, "boss_death": 64, "seal_break": 48, "thunder": 40, "altar": 40}
LONGEST = {"magma": 1.6, "earth_quake": 2.0}


def write(data, path):
    with tempfile.TemporaryDirectory() as temp:
        raw = os.path.join(temp, "s.wav")
        with wave.open(raw, "wb") as out:
            out.setnchannels(1)
            out.setsampwidth(2)
            out.setframerate(SR)
            out.writeframes((np.clip(data, -1, 1) * 32767).astype("<i2").tobytes())
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-c:a", "libvorbis", "-q:a", "5", path], check=True)


def main():
    os.makedirs(SYNTH, exist_ok=True)
    # Старый синтез хранится как сырьё: ветер и пар дальше смягчаются из него.
    for path in glob.glob(os.path.join(FOLDER, "*.ogg")):
        target = os.path.join(SYNTH, os.path.basename(path))
        if not os.path.exists(target) and "_1." not in path and "_2." not in path and "_3." not in path:
            shutil.copy(path, target)
    for path in glob.glob(os.path.join(FOLDER, "*.ogg")):
        os.remove(path)
    table = {}
    for name, (variants, top, low, wet, level) in MIX.items():
        entries = []
        for i, parts in enumerate(variants, 1):
            data = master(layer(parts), top, low, wet, level, LONGEST.get(name, 6.0))
            file = f"{name}_{i}"
            write(data, os.path.join(FOLDER, file + ".ogg"))
            entry = {"name": f"minevia_elements:{file}"}
            if name in FAR:
                entry["attenuation_distance"] = FAR[name]
            entries.append(entry)
            print(f"{file}: {len(data) / SR:.2f} с, пик {np.abs(data).max():.2f}, среднее {np.sqrt(np.mean(data ** 2)):.3f}")
        table[name] = {"sounds": entries}
    # Вода синтезируется отдельно: запись льющейся воды звучала как слив.
    for name, variants in sounds_water.make_all().items():
        for i, data in enumerate(variants, 1):
            write(data, os.path.join(FOLDER, f"{name}_{i}.ogg"))
        table[name] = {"sounds": [{"name": f"minevia_elements:{name}_{i}"} for i in range(1, len(variants) + 1)]}
    with open(os.path.join(OUT, "sounds.json"), "w", encoding="utf-8") as out:
        json.dump(table, out, indent=2)
    print("готово:", len(table))


main()
