# Рисует значки навыков как спрайты игры: 32 на 32 точки, тёмный контур и своя светотень у каждой стихии, без плашки.
# Запуск: python icons.py [папка для листа проверки]
import math
import os
import sys

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

OUT = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements\textures\gui\ability"
S = 512
ZOOM = 0.86
N = 32
TAU = math.tau

# Цвета от тени к свету, как на предметах игры: тень уходит в другой оттенок, а не просто темнеет.
RAMPS = {
    "fire": ["#4a1208", "#8c1f0c", "#c8400e", "#ee7a12", "#fbb52c", "#ffe68a"],
    "water": ["#10245c", "#1c4a96", "#2a7cc4", "#4eb0e2", "#94dcf2", "#e6fbff"],
    "earth": ["#2c2218", "#4c3c2a", "#6e5a3e", "#8f7c58", "#b4a47a", "#d8cfa4"],
    "air": ["#2e3e54", "#4c6480", "#7490aa", "#a0b8cc", "#cfdde8", "#ffffff"],
}
OUTLINE = {"fire": "#2a0a06", "water": "#0a1434", "earth": "#17110c", "air": "#18222f"}
# Реликвии: у каждой свой материал. Значение LOOK говорит, какой светотенью он рисуется.
RAMPS.update({
    "soul": ["#0a1c3c", "#123c70", "#1f6fa8", "#3fb2d8", "#8fe6f2", "#eaffff"],
    "bone": ["#3a2e20", "#6a5a44", "#94836a", "#bcae92", "#ddd2b8", "#f6f0dc"],
    "bronze": ["#2e1a0a", "#5e3614", "#8e5a20", "#bc8630", "#e4b856", "#fff0a8"],
    "storm": ["#1c2838", "#34506e", "#5a7c9c", "#8eacc4", "#c4d8e6", "#ffffff"],
    "horn": ["#2c1408", "#5c2c10", "#8e4a1a", "#c2702a", "#eea04a", "#ffe09a"],
    "granite": ["#1e1c20", "#3a363c", "#5a5458", "#7c7476", "#a09a98", "#ccc6c0"],
    "thread": ["#3c1420", "#6e2234", "#a23a48", "#d0605c", "#ee9a7c", "#ffdcae"],
})
OUTLINE.update({"soul": "#071226", "bone": "#1e170e", "bronze": "#180c04", "storm": "#0e1622", "horn": "#160904", "granite": "#0e0d10", "thread": "#1e0a10"})
LOOK = {"soul": "water", "bone": "air", "bronze": "earth", "storm": "air", "horn": "fire", "granite": "earth", "thread": "water"}
MOSS = ["#2f4a1c", "#4d7028", "#76a03a"]
GOLD = ["#6a4208", "#b07a14", "#eec23a", "#fff0a0"]
PALETTE_NAMES = ("fire", "water", "earth", "air")
BAYER = np.array([[0, 2], [3, 1]]) / 4.0 - 0.375


class Pen:
    """Рисует в единичных координатах: от -1 до 1, ось y вниз. Закрашивает белым, а cut вырезает."""

    def __init__(self):
        self.image = Image.new("L", (S, S), 0)
        self.draw = ImageDraw.Draw(self.image)

    @staticmethod
    def at(x, y):
        return ((x * ZOOM + 1) / 2 * S, (y * ZOOM + 1) / 2 * S)

    def poly(self, points, ink=255):
        self.draw.polygon([self.at(x, y) for x, y in points], fill=ink)

    def circle(self, x, y, r, ink=255):
        cx, cy = self.at(x, y)
        r = r * ZOOM * S / 2
        self.draw.ellipse((cx - r, cy - r, cx + r, cy + r), fill=ink)

    def ring(self, x, y, r, width):
        self.circle(x, y, r + width / 2)
        self.circle(x, y, r - width / 2, 0)

    def line(self, points, width, ink=255):
        pixels = width * ZOOM * S / 2
        at = [self.at(x, y) for x, y in points]
        self.draw.line(at, fill=ink, width=int(pixels), joint="curve")
        for x, y in (at[0], at[-1]):
            self.draw.ellipse((x - pixels / 2, y - pixels / 2, x + pixels / 2, y + pixels / 2), fill=ink)

    def blob(self, points, ink=255, x=0, y=0, s=1.0, turn=0.0):
        """Гладкий замкнутый контур через точки."""
        placed = [place(p, x, y, s, turn) for p in points]
        self.poly(smooth(placed), ink)

    def shape(self, points, ink=255, x=0, y=0, s=1.0, turn=0.0):
        self.poly([place(p, x, y, s, turn) for p in points], ink)


def place(point, x, y, s, turn):
    c, n = math.cos(turn), math.sin(turn)
    px, py = point
    return (x + (px * c - py * n) * s, y + (px * n + py * c) * s)


def smooth(points, steps=10):
    out = []
    n = len(points)
    for i in range(n):
        p0, p1, p2, p3 = points[i - 1], points[i], points[(i + 1) % n], points[(i + 2) % n]
        for k in range(steps):
            t = k / steps
            out.append(tuple(0.5 * (2 * b + (c - a) * t + (2 * a - 5 * b + 4 * c - d) * t * t + (3 * b - a - 3 * c + d) * t ** 3)
                             for a, b, c, d in zip(p0, p1, p2, p3)))
    return out


FLAME = [(0.08, -1), (0.2, -0.5), (0.62, -0.08), (0.64, 0.45), (0.3, 0.92), (-0.3, 0.92), (-0.64, 0.5), (-0.56, 0.05), (-0.3, -0.18), (-0.2, -0.52)]
DROP = [(0, -1), (0.3, -0.42), (0.62, 0.18), (0.42, 0.78), (0, 0.98), (-0.42, 0.78), (-0.62, 0.18), (-0.3, -0.42)]
BOLT = [(0.22, -1), (-0.5, 0.16), (-0.06, 0.16), (-0.26, 1), (0.52, -0.2), (0.06, -0.2), (0.42, -1)]
SHIELD = [(-0.72, -0.78), (0, -0.92), (0.72, -0.78), (0.72, 0.1), (0, 0.96), (-0.72, 0.1)]
ROCK = [(-0.74, -0.2), (-0.34, -0.8), (0.36, -0.72), (0.82, -0.12), (0.62, 0.62), (-0.1, 0.84), (-0.68, 0.5)]
SHARD = [(0, -1), (0.3, -0.4), (0.2, 0.9), (-0.2, 0.9), (-0.3, -0.4)]
BLADE = [(0, -1), (0.2, -0.1), (0.1, 0.72), (-0.1, 0.72), (-0.2, -0.1)]


def flame(p, x=0, y=0, s=1.0, hollow=True):
    p.blob(FLAME, x=x, y=y, s=s)
    if hollow:
        p.blob(FLAME, 0, x=x, y=y + 0.36 * s, s=s * 0.44)


def comet(p, x, y, r, tail):
    """Шар и сужающийся хвост с двумя языками пламени."""
    k = math.sqrt(0.5)
    tip = (x + (r + tail) * k * 1.25, y - (r + tail) * k * 1.25)
    p.shape([(x - r * k, y - r * k), tip, (x + r * k, y + r * k)])
    p.shape([(x - r * 0.95, y + r * 0.1), (x - r * 0.2, y - r * 2.3), (x + r * 0.2, y - r * 0.6)])
    p.shape([(x + r * 0.95, y - r * 0.1), (x + r * 2.3, y + r * 0.2), (x + r * 0.6, y + r * 0.6)])
    p.circle(x, y, r)
    p.circle(x - r * 0.1, y + r * 0.1, r * 0.42, 0)


def cloud(p, x, y, s):
    for cx, cy, r in ((-0.5, 0.1, 0.36), (-0.08, -0.2, 0.5), (0.44, 0.04, 0.4)):
        p.circle(x + cx * s, y + cy * s, r * s)
    p.shape([(-0.8, 0.1), (0.8, 0.1), (0.8, 0.44), (-0.8, 0.44)], x=x, y=y, s=s)


def wave(p, y, width=0.2, amp=0.2, span=0.95, shift=0.0):
    p.line([(-span + 2 * span * i / 30, y + amp * math.sin(i / 30 * TAU * 1.5 + shift)) for i in range(31)], width)


def spiral(p, r, turns, width, x=0, y=0):
    p.line([(x + r * (i / 90) * math.cos(i / 90 * turns * TAU), y + r * (i / 90) * math.sin(i / 90 * turns * TAU)) for i in range(4, 91)], width)


def chevrons(p, count, x=0.0, gap=0.5):
    for i in range(count):
        cx = x + (i - (count - 1) / 2) * gap
        p.line([(cx - 0.3, -0.62), (cx + 0.3, 0), (cx - 0.3, 0.62)], 0.27)


def funnel(p, rows, wide):
    for i in range(rows):
        t = i / (rows - 1)
        half = wide * (1 - t) ** 1.25 + 0.1
        y = -0.82 + 1.7 * t
        off = 0.12 * math.sin(t * 5)
        p.line([(off - half, y), (off + half, y)], 0.22 - 0.05 * t)


def saw(p, teeth=9):
    points = []
    for i in range(teeth * 2):
        r = 0.98 if i % 2 == 0 else 0.68
        a = i / (teeth * 2) * TAU + (0.12 if i % 2 else 0)
        points.append((r * math.cos(a), r * math.sin(a)))
    p.shape(points)
    p.circle(0, 0, 0.27, 0)


def spikes(p, heights=(0.75, 1.15, 0.8)):
    for x, h in zip((-0.58, 0, 0.58), heights):
        p.shape([(x - 0.33, 0.8), (x, 0.8 - h * 1.35), (x + 0.33, 0.8)])
    p.line([(-0.9, 0.84), (0.9, 0.84)], 0.14)


def fist(p):
    p.shape([(-0.42, 0.25), (0.42, 0.25), (0.34, 1.0), (-0.34, 1.0)])
    p.blob([(-0.66, -0.2), (0.66, -0.2), (0.68, 0.34), (-0.68, 0.34)])
    for x in (-0.48, -0.16, 0.16, 0.48):
        p.circle(x, -0.34, 0.2)
    p.line([(0.08, 0.1), (0.68, 0.0)], 0.26)
    p.line([(0.1, 0.12), (0.68, 0.02)], 0.06, 0)


def crack(p, width=0.26):
    p.line([(0.12, -1), (-0.22, -0.46), (0.2, -0.12), (-0.18, 0.3), (0.12, 0.62), (-0.04, 1)], width)


def guardian(p):
    p.circle(0, -0.62, 0.27)
    p.blob([(-0.72, -0.36), (0.72, -0.36), (0.46, 0.2), (0.16, 0.42), (-0.16, 0.42), (-0.46, 0.2)])
    p.line([(-0.7, -0.26), (-0.94, 0.3)], 0.25)
    p.line([(0.7, -0.26), (0.94, 0.3)], 0.25)
    wave(p, 0.72, 0.24, 0.1, 0.78)
    for x, top in ((-0.28, -1.08), (0.0, -1.2), (0.28, -1.08)):
        p.shape([(x - 0.09, -0.86), (x, top), (x + 0.09, -0.86)])


def snowflake(p):
    for i in range(3):
        a = i / 3 * math.pi + math.pi / 2
        dx, dy = math.cos(a) * 0.96, math.sin(a) * 0.96
        p.line([(-dx, -dy), (dx, dy)], 0.17)
        for sign in (-1, 1):
            ex, ey = dx * 0.62 * sign, dy * 0.62 * sign
            for side in (-0.5, 0.5):
                b = a + side * 2.1 + (math.pi if sign < 0 else 0)
                p.line([(ex, ey), (ex - math.cos(b + math.pi) * -0.3, ey - math.sin(b + math.pi) * -0.3)], 0.13)


def ring_of_flames(p):
    p.ring(0, 0, 0.62, 0.17)
    for i in range(6):
        a = i / 6 * TAU - math.pi / 2
        p.blob(FLAME, x=math.cos(a) * 0.72, y=math.sin(a) * 0.72, s=0.3, turn=a + math.pi / 2)


def cross_in_drop(p):
    p.blob(DROP, s=1.04)
    p.line([(0, -0.02), (0, 0.62)], 0.2, 0)
    p.line([(-0.32, 0.3), (0.32, 0.3)], 0.2, 0)


def blades_crossed(p):
    p.shape(BLADE, turn=0.72, s=1.15)
    p.shape(BLADE, turn=-0.72, s=1.15)


def steel_ring(p):
    for i in range(6):
        a = i / 6 * TAU
        p.shape(BLADE, x=math.cos(a) * 0.62, y=math.sin(a) * 0.62, s=0.5, turn=a + 1.0)
    p.circle(0, 0, 0.2)


def wing(p):
    for i, length in enumerate((1.5, 1.2, 0.9)):
        y = -0.5 + i * 0.44
        p.line([(-0.8, y + 0.3)] + [(-0.8 + length * t / 8, y + 0.3 - 0.8 * math.sin(t / 8 * 1.5)) for t in range(1, 9)], 0.2)


def gust(p):
    p.line([(-0.95, -0.44)] + [(-0.95 + 1.4 * t / 10, -0.44) for t in range(1, 11)] + [(0.66, -0.56), (0.62, -0.8), (0.34, -0.8)], 0.2)
    p.line([(-0.95, 0.02), (0.76, 0.02)], 0.2)
    p.line([(-0.95, 0.46)] + [(-0.95 + 1.2 * t / 10, 0.46) for t in range(1, 11)] + [(0.46, 0.6), (0.4, 0.82), (0.14, 0.8)], 0.2)


def dome(p, dotted=False):
    steps = 16 if dotted else 40
    arc = [(0.9 * math.cos(math.pi + math.pi * i / steps), 0.42 + 0.9 * math.sin(math.pi + math.pi * i / steps)) for i in range(steps + 1)]
    if dotted:
        for x, y in arc[::2]:
            p.circle(x, y, 0.12)
    else:
        p.line(arc, 0.2)
    p.line([(-0.98, 0.56), (0.98, 0.56)], 0.17)


def inward(p):
    for i in range(4):
        a = i / 4 * TAU + math.pi / 4
        c, s = math.cos(a), math.sin(a)
        p.line([(c * 0.98, s * 0.98), (c * 0.4, s * 0.4)], 0.2)
        p.line([(c * 0.4 + -s * 0.24 + c * 0.2, s * 0.4 + c * 0.24 + s * 0.2), (c * 0.4, s * 0.4), (c * 0.4 + s * 0.24 + c * 0.2, s * 0.4 - c * 0.24 + s * 0.2)], 0.16)
    p.circle(0, 0, 0.14)


def bricks(p):
    for row in range(4):
        y = -0.8 + row * 0.42
        shift = 0.0 if row % 2 else -0.3
        for x in (-0.92, -0.32, 0.28):
            a, b = max(-0.9, x + shift), min(0.9, x + shift + 0.54)
            p.shape([(a, y), (b, y), (b, y + 0.34), (a, y + 0.34)])


def leap(p):
    p.line([(-0.9, 0.42)] + [(-0.9 + 1.7 * t / 16, 0.42 - 1.25 * math.sin(t / 16 * math.pi * 0.86)) for t in range(1, 17)], 0.2)
    p.shape([(0.5, 0.3), (1.0, 0.0), (0.92, 0.56)])
    p.shape([(-0.98, 0.62), (0.2, 0.62), (0.1, 0.92), (-0.88, 0.92)])


def quake(p):
    crack(p, 0.22)
    for side in (-1, 1):
        for r in (0.5, 0.82):
            p.line([(side * r, -0.42), (side * (r + 0.14), 0), (side * r, 0.42)], 0.16)


def geyser(p):
    p.shape([(-0.24, 0.84), (-0.14, -0.3), (0.14, -0.3), (0.24, 0.84)])
    p.blob(DROP, y=-0.62, s=0.42)
    for side in (-1, 1):
        p.circle(side * 0.56, -0.26, 0.13)
        p.circle(side * 0.72, 0.24, 0.1)
    wave(p, 0.82, 0.2, 0.06, 0.92)


def whip(p):
    p.line([(-0.86, 0.84), (-0.5, 0.2), (0.28, 0.42), (0.52, -0.06), (0.1, -0.34), (0.42, -0.82)], 0.2)
    p.blob(DROP, x=0.62, y=-0.76, s=0.26, turn=2.6)


def spears(p):
    for x, y, s in ((-0.58, 0.22, 0.72), (0, -0.05, 0.95), (0.58, 0.22, 0.72)):
        p.shape(SHARD, x=x, y=y, s=s, turn=0.4)


def prison(p):
    p.shape([(0, -1), (0.78, -0.3), (0.5, 0.92), (-0.5, 0.92), (-0.78, -0.3)])
    p.shape([(0, -0.62), (0.44, -0.2), (0.28, 0.6), (-0.28, 0.6), (-0.44, -0.2)], 0)
    p.circle(0, 0.08, 0.2)


def mist(p):
    wave(p, -0.5, 0.2, 0.13, 0.9, 0.6)
    wave(p, 0.0, 0.2, 0.13, 0.96, 2.2)
    wave(p, 0.5, 0.2, 0.13, 0.84, 4.0)


def rain(p):
    cloud(p, 0, -0.26, 0.95)
    for x, y in ((-0.5, 0.56), (0, 0.72), (0.5, 0.56)):
        p.blob(DROP, x=x, y=y, s=0.27)


def storm(p):
    cloud(p, 0, -0.42, 0.95)
    p.shape(BOLT, x=0.02, y=0.5, s=0.52)


def sky(p):
    p.shape(BOLT, x=-0.42, y=0.0, s=0.68)
    p.shape(BOLT, x=0.44, y=0.14, s=0.56)


def ball_lightning(p):
    p.circle(0, 0, 0.4)
    for i in range(5):
        a = i / 5 * TAU - math.pi / 2
        c, s = math.cos(a), math.sin(a)
        p.line([(c * 0.5, s * 0.5), (c * 0.7 - s * 0.14, s * 0.7 + c * 0.14), (c * 0.76 + s * 0.14, s * 0.76 - c * 0.14), (c * 1.0, s * 1.0)], 0.13)


def volcano(p):
    p.shape([(-1, 0.9), (-0.32, -0.32), (0.32, -0.32), (1, 0.9)])
    p.shape([(-0.1, -0.32), (0.1, -0.32), (0.04, 0.34), (-0.05, 0.34)], 0)
    p.circle(-0.3, -0.72, 0.12)
    p.circle(0.06, -0.96, 0.14)
    p.circle(0.36, -0.68, 0.1)


def lava_shield(p):
    p.ring(0, 0, 0.82, 0.12)
    for i in range(4):
        a = i / 4 * TAU + math.pi / 4
        p.blob(ROCK, x=math.cos(a) * 0.82, y=math.sin(a) * 0.82, s=0.34, turn=i)
    p.circle(0, 0, 0.26)


def sand(p):
    for x, y, r in ((-0.72, 0.0, 0.2), (-0.26, -0.3, 0.16), (-0.24, 0.3, 0.17), (0.2, -0.56, 0.13), (0.22, 0.0, 0.15), (0.2, 0.56, 0.13),
                    (0.64, -0.3, 0.11), (0.66, 0.3, 0.11), (0.92, -0.74, 0.08), (0.92, 0.0, 0.09), (0.92, 0.74, 0.08)):
        p.circle(x, y, r)


def armor_flame(p):
    p.blob(SHIELD)
    p.blob(FLAME, 0, y=0.02, s=0.52)


def armor_stone(p):
    p.shape(SHIELD)
    p.line([(-0.72, -0.2), (-0.2, -0.3), (-0.02, 0.1), (0.3, -0.1), (0.72, -0.12)], 0.1, 0)
    p.line([(0, 0.1), (0.04, 0.9)], 0.1, 0)


def big_ball(p):
    p.blob(FLAME, s=1.1, y=-0.06)
    p.circle(0, 0.26, 0.34, 0)


def cone(p):
    """Струя огня: языки растут от руки слева вправо."""
    for x, size in ((-0.72, 0.3), (-0.26, 0.5), (0.4, 0.8)):
        p.blob(FLAME, x=x, y=0.0, s=size, turn=1.2)


def sparks(p):
    for x, y, s in ((-0.44, -0.42, 0.64), (0.5, -0.12, 0.54), (-0.14, 0.56, 0.52)):
        p.shape([(0, -1), (0.2, -0.2), (1, 0), (0.2, 0.2), (0, 1), (-0.2, 0.2), (-1, 0), (-0.2, -0.2)], x=x, y=y, s=s)


def step(p):
    flame(p, -0.34, 0.08, 0.72, False)
    chevrons(p, 2, 0.5, 0.42)


def rock_mark(p):
    p.blob(ROCK, s=1.05)
    p.line([(-0.42, -0.34), (0.02, -0.06), (-0.08, 0.32)], 0.1, 0)
    p.line([(0.02, -0.06), (0.42, -0.2)], 0.1, 0)


def fissure(p):
    p.shape([(-1, 0.86), (-1, 0.1), (-0.24, 0.0), (-0.1, 0.86)])
    p.shape([(1, 0.86), (1, -0.02), (0.3, 0.1), (0.14, 0.86)])
    p.shape(FLAME_SPOUT, x=0.02, y=-0.26, s=0.76)


FLAME_SPOUT = [(0.04, -1), (0.2, -0.36), (0.36, 0.1), (0.14, 0.96), (-0.14, 0.96), (-0.34, 0.1), (-0.18, -0.36)]

def great_wave_icon(p):
    p.blob([(-1,.9),(-1,-.3),(-.85,-.8),(-.35,-1),(.25,-.85),(.65,-.4),(.3,-.55),(-.1,-.4),(.1,0),(.75,.35),(1,.9)])
    p.line([(-.8,.65),(-.65,.1),(-.5,-.4),(-.1,-.65)],.08,0)
    p.line([(-.4,.75),(-.25,.35),(.3,.55),(.7,.75)],.06,0)


ICONS = {
    "fire_1": lambda p: comet(p, -0.28, 0.28, 0.54, 0.76),
    "fire_5": ring_of_flames,
    "fire_3": armor_flame,
    "fire_4": big_ball,
    "fire_2": cone,
    "fire_8": step,
    "fire_9": sparks,
    "fire_10": lambda p: comet(p, -0.34, 0.34, 0.62, 0.84),
    "fire_path1": lambda p: p.shape(BOLT, s=1.08),
    "fire_path1b": ball_lightning,
    "fire_path2": volcano,
    "fire_path2b": lava_shield,
    "water_5": lambda p: p.blob(DROP, s=1.06),
    "water_2": cross_in_drop,
    "water_3": snowflake,
    "water_4": whip,
    "water_1": great_wave_icon,
    "water_8": geyser,
    "water_9": lambda p: (p.ring(0, 0, 0.82, 0.17), p.circle(-0.28, -0.3, 0.2), p.circle(0.3, 0.32, 0.1)),
    "water_10": guardian,
    "water_path1": spears,
    "water_path1b": prison,
    "water_path2": mist,
    "water_path2b": rain,
    "earth_4": rock_mark,
    "earth_2": quake,
    "earth_3": armor_stone,
    "earth_1": spikes,
    "earth_5": bricks,
    "earth_8": fist,
    "earth_9": leap,
    "earth_10": fissure,
    "earth_path1": lambda p: spiral(p, 0.98, 2.3, 0.2),
    "earth_path1b": sand,
    "earth_path2": blades_crossed,
    "earth_path2b": steel_ring,
    "air_2": lambda p: spiral(p, 0.98, 2.1, 0.22),
    "air_3": saw,
    "air_1": lambda p: chevrons(p, 3),
    "air_4": lambda p: funnel(p, 5, 0.88),
    "air_5": dome,
    "air_8": wing,
    "air_9": gust,
    "air_10": lambda p: funnel(p, 6, 1.02),
    "air_path1": storm,
    "air_path1b": sky,
    "air_path2": inward,
    "air_path2b": lambda p: dome(p, True),
}


def rgb(text):
    return np.array([int(text[i:i + 2], 16) for i in (1, 3, 5)], dtype=np.uint8)


def spread(mask, steps):
    """Сколько точек до края фигуры, не дальше steps."""
    depth = np.zeros(mask.shape)
    layer = mask.copy()
    for _ in range(steps):
        depth += layer
        edge = np.zeros_like(layer)
        edge[1:-1, 1:-1] = layer[1:-1, 1:-1] & layer[:-2, 1:-1] & layer[2:, 1:-1] & layer[1:-1, :-2] & layer[1:-1, 2:]
        layer = edge
    return depth


def grains(seed):
    """Крупное зерно для камня и пены: случайный шум, размытый до размера нескольких точек."""
    rng = np.random.default_rng(seed)
    noise = Image.fromarray((rng.random((N, N)) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.1))
    grain = np.asarray(noise, dtype=float) / 255
    return (grain - grain.mean()) / (grain.std() + 1e-6)


def shade(element, mask, seed):
    """Значение от 0 до 1 для каждой точки: свет сверху слева плюс характер вещества."""
    depth = spread(mask, 4)
    soft = np.asarray(Image.fromarray((mask * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.6)), dtype=float) / 255
    gy, gx = np.gradient(soft)
    length = np.hypot(gx, gy) + 1e-6
    light = (gx + gy) / length * np.clip(length * 5, 0, 1) * 0.7071
    y, x = np.mgrid[0:N, 0:N] / (N - 1)
    grain = grains(seed)
    if element == "fire":
        # Пламя светится изнутри: края тлеют, середина раскалена, низ горячее верха.
        return 0.12 + depth / 4 * 0.74 + (y - 0.5) * 0.22 + grain * 0.05
    if element == "water":
        # Вода темнеет к глубине, а по верхнему краю лежит блик.
        return 0.62 - y * 0.44 + light * 0.3 + np.sin((x * 1.4 + y) * 15) * 0.05
    if element == "earth":
        # Камень сколот: плоские грани со случайной яркостью и жёсткая светотень по краю.
        facets = np.round(grain * 1.4) / 1.4
        return 0.46 + light * 0.34 + facets * 0.13 + (depth < 2) * -0.06
    # Воздух бледный и лёгкий: косые полосы бегут по форме.
    return 0.66 + light * 0.2 + np.sin((x - y * 0.7) * 26) * 0.1 - y * 0.12


def sprite(name, draw, element=None):
    element = element or name.split("_")[0]
    pen = Pen()
    draw(pen)
    cover = np.asarray(pen.image.resize((N, N), Image.BOX), dtype=float) / 255
    mask = cover > 0.46
    mask[0, :] = mask[-1, :] = False
    mask[:, 0] = mask[:, -1] = False
    seed = sum(map(ord, name))
    value = shade(LOOK.get(element, element), mask, seed)
    tile = np.tile(BAYER, (N // 2, N // 2))
    ramp = [rgb(c) for c in RAMPS[element]]
    steps = np.clip(value + tile * 0.16, 0, 0.999) * len(ramp)
    out = np.zeros((N, N, 4), dtype=np.uint8)
    for index, colour in enumerate(ramp):
        where = mask & (steps.astype(int) == index)
        out[where, :3] = colour
    out[mask, 3] = 255

    if element == "earth":
        # Мох лежит только на верхних гранях: живая деталь в одном цвете, без шума по всей форме.
        top = mask & ~np.roll(mask, 1, axis=0)
        wide = top | (np.roll(top, 1, axis=0) & mask & (grains(seed + 7) > 0.15))
        for index, colour in enumerate(MOSS):
            band = wide & ((grains(seed + 3) * 0.9 + 1.2).astype(int).clip(0, 2) == index)
            out[band, :3] = rgb(colour)

    around = np.zeros_like(mask)
    around[1:, :] |= mask[:-1, :]
    around[:-1, :] |= mask[1:, :]
    around[:, 1:] |= mask[:, :-1]
    around[:, :-1] |= mask[:, 1:]
    rim = around & ~mask
    special = name.endswith("_10")
    out[rim, :3] = rgb(GOLD[1]) if special else rgb(OUTLINE[element])
    out[rim, 3] = 255

    if special:
        # Супер-навык: золотой контур и две искры рядом.
        for cx, cy in ((4, 5), (27, 26)):
            out[cy, cx] = (*rgb(GOLD[3]), 255)
            for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                out[cy + dy, cx + dx] = (*rgb(GOLD[2]), 255)
    return Image.fromarray(out, "RGBA")


ITEMS = r"D:\\Rudnik\\elements-mod\\src\\main\\resources\\assets\\minevia_elements\\textures\\item"
ESSENCE = [(0, -1.02), (0.5, -0.46), (0.42, 0.42), (0, 1.02), (-0.42, 0.42), (-0.5, -0.46)]


def essence(p):
    """Огранённый кристалл: внутренние грани вырезаны, поэтому он читается и в размере предмета."""
    p.shape(ESSENCE)
    p.line([(-0.42, -0.42), (0, -0.14), (0.42, -0.42)], 0.07, 0)
    p.line([(0, -0.14), (0, 0.9)], 0.07, 0)


def soul_staff(p):
    p.line([(-0.86, 0.92), (0.46, -0.42)], 0.17)
    p.ring(0.6, -0.62, 0.34, 0.13)
    p.blob(FLAME, x=0.6, y=-0.64, s=0.26)
    p.line([(-0.32, 0.38), (-0.08, 0.62)], 0.12)
    p.line([(0.3, -0.26), (0.5, -0.06)], 0.12)


def bone_charm(p):
    for sign in (-1, 1):
        p.line([(-0.62 * sign, -0.62), (0.62 * sign, 0.62)], 0.2)
        for end in (-1, 1):
            x, y = 0.74 * sign * end, 0.74 * end
            p.circle(x + 0.1 * sign * end, y - 0.1 * end, 0.17)
            p.circle(x - 0.1 * sign * end, y + 0.1 * end, 0.17)
    p.circle(0, -0.02, 0.36)
    p.circle(-0.14, -0.04, 0.09, 0)
    p.circle(0.14, -0.04, 0.09, 0)
    p.shape([(-0.05, 0.08), (0.05, 0.08), (0, 0.18)], 0)


def abbot_lantern(p):
    p.ring(0, -0.84, 0.2, 0.09)
    p.shape([(-0.42, -0.66), (0.42, -0.66), (0.56, -0.42), (-0.56, -0.42)])
    p.shape([(-0.46, -0.42), (0.46, -0.42), (0.46, 0.66), (-0.46, 0.66)])
    p.shape([(-0.3, -0.28), (0.3, -0.28), (0.3, 0.52), (-0.3, 0.52)], 0)
    p.blob(FLAME, y=0.14, s=0.34)
    p.shape([(-0.58, 0.66), (0.58, 0.66), (0.48, 0.9), (-0.48, 0.9)])


def bell_hammer(p):
    p.line([(-0.84, 0.92), (0.24, -0.16)], 0.18)
    p.shape([(-0.12, -0.92), (0.2, -1.0), (0.96, -0.24), (0.88, 0.08), (0.46, 0.2), (-0.2, -0.46)])
    p.line([(0.02, -0.72), (0.72, -0.02)], 0.08, 0)
    p.circle(-0.84, 0.92, 0.14)


def hand_bell(p):
    p.line([(0, -1.02), (0, -0.62)], 0.16)
    p.ring(0, -0.98, 0.14, 0.08)
    p.blob([(0, -0.72), (0.36, -0.56), (0.46, -0.08), (0.62, 0.36), (0.88, 0.58), (0, 0.66), (-0.88, 0.58), (-0.62, 0.36), (-0.46, -0.08), (-0.36, -0.56)])
    p.line([(-0.62, 0.26), (0.62, 0.26)], 0.07, 0)
    p.circle(0, 0.8, 0.17)


def storm_feather(p):
    p.blob([(0.82, -0.94), (0.5, -0.3), (0.12, 0.3), (-0.34, 0.6), (-0.42, 0.34), (-0.34, -0.2), (0.12, -0.68)])
    p.line([(0.74, -0.84), (-0.84, 0.92)], 0.08)
    for x, y, dx, dy in ((0.3, -0.34, 0.26, 0.08), (0.04, -0.06, 0.26, 0.1), (-0.2, 0.2, 0.2, 0.1), (0.12, -0.44, -0.1, -0.2), (-0.14, -0.14, -0.14, -0.2)):
        p.line([(x, y), (x + dx, y + dy)], 0.06, 0)
    p.shape(BOLT, x=-0.56, y=-0.52, s=0.34)


def ram_horn(p):
    """Рог: толстое основание с кольцами плавной дугой сходит на острие."""
    centre = [(0.82 + 1.62 * math.cos(math.pi + t / 20 * math.pi * 0.52), 0.82 + 1.62 * math.sin(math.pi + t / 20 * math.pi * 0.52)) for t in range(21)]
    width = [0.4 * (1 - t / 20) ** 0.75 + 0.012 for t in range(21)]
    outer, inner = [], []
    for t, (x, y) in enumerate(centre):
        a = math.pi + t / 20 * math.pi * 0.52
        outer.append((x + math.cos(a) * width[t], y + math.sin(a) * width[t]))
        inner.append((x - math.cos(a) * width[t], y - math.sin(a) * width[t]))
    p.shape(outer + inner[::-1])
    for t in (2, 5, 8):
        p.line([outer[t], inner[t]], 0.07, 0)


def stone_heart(p):
    p.blob([(0, -0.46), (0.42, -0.86), (0.92, -0.56), (0.9, -0.02), (0.44, 0.5), (0, 0.96), (-0.44, 0.5), (-0.9, -0.02), (-0.92, -0.56), (-0.42, -0.86)])
    p.line([(0.04, -0.46), (-0.16, -0.08), (0.16, 0.14), (-0.04, 0.52)], 0.08, 0)
    p.line([(0.16, 0.14), (0.54, -0.02)], 0.06, 0)


def maze_thread(p):
    p.circle(-0.14, 0.04, 0.72)
    for k, tilt in ((-0.3, 0.5), (0.1, 0.5), (0.42, 0.5)):
        p.line([(-0.72 + i * 0.12, k + 0.26 * math.sin(i * 0.5) - 0.2) for i in range(12)], 0.07, 0)
    p.line([(0.46, 0.5), (0.8, 0.86), (0.98, 0.5), (0.72, 0.2), (0.98, -0.1)], 0.1)


RELICS = {"soul_staff": ("soul", soul_staff), "bone_charm": ("bone", bone_charm), "abbot_lantern": ("soul", abbot_lantern), "bell_hammer": ("bronze", bell_hammer),
          "hand_bell": ("bronze", hand_bell), "storm_feather": ("storm", storm_feather), "ram_horn": ("horn", ram_horn), "stone_heart": ("granite", stone_heart),
          "maze_thread": ("thread", maze_thread)}


def main():
    relics = Image.new("RGBA", (9 * 136, 136), (58, 66, 60, 255))
    for index, (name, (material, draw)) in enumerate(RELICS.items()):
        icon = sprite(name, draw, material)
        icon.save(os.path.join(ITEMS, name + ".png"))
        big = icon.resize((128, 128), Image.NEAREST)
        relics.paste(big, (index * 136 + 4, 4), big)
    if len(sys.argv) > 1:
        relics.save(os.path.join(sys.argv[1], "relics.png"))
    for element in PALETTE_NAMES:
        sprite(element + "_essence", essence).save(os.path.join(ITEMS, "essence_" + element + ".png"))
    sheet = Image.new("RGBA", (12 * 104, 4 * 104 + 4 * 44), (58, 66, 60, 255))
    for index, (name, draw) in enumerate(ICONS.items()):
        icon = sprite(name, draw)
        icon.resize((64, 64), Image.NEAREST).save(os.path.join(OUT, name + ".png"))
        x, y = index % 12, index // 12
        big = icon.resize((96, 96), Image.NEAREST)
        sheet.paste(big, (x * 104 + 4, y * 104 + 4), big)
        sheet.paste(icon, (x * 104 + 36, 4 * 104 + y * 44 + 6), icon)
    if len(sys.argv) > 1:
        sheet.save(os.path.join(sys.argv[1], "new-icons.png"))
    print(len(ICONS), "значков")


main()
