# Значки 32x32, ручные силуэты и светотень материалов.
# Запуск: python art/icons_styles.py
import math
from pathlib import Path
from icons_weapons import Sprite, png, RAMPS, grip

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'elements-mod/src/main/resources/assets/minevia_elements/textures/gui/ability'
RAMPS['gold'] = [(int(h[0:2],16), int(h[2:4],16), int(h[4:6],16),255) for h in ['39230b','78501b','b0832d','e3b94d','ffe6a3']]
RAMPS['violet'] = [(int(h[0:2],16), int(h[2:4],16), int(h[4:6],16),255) for h in ['140b23','302044','573476','8b50ba','bb8ee3']]
RAMPS['leaf'] = [(int(h[0:2],16), int(h[2:4],16), int(h[4:6],16),255) for h in ['10251b','244c35','3e7950','75af69','b8dfa1']]


def sword(s, x=0, y=0, scale=1, material='iron', flip=False):
    def p(points):
        return [(round((31-a if flip else a)*scale+x),round(b*scale+y)) for a,b in points]
    s.poly(p([(10,21),(14,13),(27,2),(25,13),(17,22)]),material,True)
    s.line(p([(15,18),(21,11),(25,6)]),material,tone=4)
    s.line(p([(7,19),(17,28)]),'gold',2)
    s.line(p([(5,28),(11,22)]),'wood',3)
    s.oval((round(3*scale+x),round(26*scale+y),round(7*scale+x),round(30*scale+y)),'gold')


def arrow(s,x=0,y=0,scale=1,material='leaf'):
    def p(points): return [(round(a*scale+x),round(b*scale+y)) for a,b in points]
    s.line(p([(5,27),(25,7)]),'wood',2)
    s.poly(p([(18,7),(29,2),(24,14),(24,8)]),'iron')
    s.line(p([(7,27),(7,21),(3,21)]),material,2)
    s.line(p([(10,24),(10,18),(6,18)]),material,2)
    s.line(p([(19,8),(26,4)]),material,tone=4)


def arc(s,center,r,start,end,material='iron',width=2):
    points=[(round(center[0]+r*math.cos(start+(end-start)*i/30)),round(center[1]+r*math.sin(start+(end-start)*i/30))) for i in range(31)]
    s.line(points,material,width)


def star(s,x=16,y=16,r=9,material='gold'):
    s.poly([(x,y-r),(x+2,y-2),(x+r,y),(x+2,y+2),(x,y+r),(x-2,y+2),(x-r,y),(x-2,y-2)],material)


def ring(s,material='violet',r=10):
    arc(s,(16,16),r,0,math.tau,material,2)


def shield(s,material='gold'):
    s.poly([(5,5),(16,2),(27,5),(26,18),(16,29),(6,18)],material)
    s.poly([(9,8),(16,6),(23,8),(22,17),(16,24),(10,17)],'bone')
    sun(s,16,14,5,material)


def sword_icon(i):
    s=Sprite()
    if i==0:
        arc(s,(8,12),17,-1.15,1.15,'iron',4)
        arc(s,(8,12),18,-1.0,1.0,'water',1)
        s.line([(5,23),(13,19)],'iron',2)
    elif i==1:
        ring(s,'iron',10)
        sword(s,-3,0,.7); sword(s,11,10,.6,flip=True)
        s.line([(5,6),(8,3),(12,4)],'water',2)
    elif i==2:
        shield(s,'iron'); sword(s,2,1,.7)
    elif i==3:
        sword(s)
        for y in (15,20,25): s.line([(2,y),(10,y-3)],'water',2)
    elif i==4:
        sword(s,0,-4,1)
        s.poly([(3,29),(10,25),(15,28),(19,25),(29,29)],'coal')
        s.line([(16,29),(16,31)],'fire',2)
    elif i==5:
        sword(s,0,0,.9)
        s.line([(5,7),(11,13)],'fire',2); s.line([(3,12),(7,16)],'fire',2)
    elif i==6:
        ring(s,'water',11)
        for x,y in ((0,2),(13,1),(6,15)): sword(s,x,y,.5)
    elif i==7:
        for x in (-3,5,13): sword(s,x,-1,.6)
        s.line([(3,25),(10,19),(7,27)],'water',2)
        s.line([(14,25),(23,20),(19,29)],'water',2)
    elif i==8:
        sword(s,-3,0,.8); sword(s,9,2,.8,flip=True)
        star(s,16,16,5,'water')
    elif i==9:
        sword(s,3,3,.8)
        arc(s,(16,16),12,1,5.8,'water',2)
    elif i==10:
        sword(s,0,0,1,'coal')
        s.line([(17,17),(16,12),(22,9),(21,4)],'fire',2)
        for x in (4,11,27): s.line([(x,13),(x,7)],'fire',2)
    else:
        sword(s,1,-1,1,'iron')
        s.poly([(2,27),(9,23),(15,26),(21,22),(29,26),(24,30),(7,30)],'coal')
        s.line([(12,28),(16,25),(20,29)],'fire',2)
    return s


def bow_icon(i):
    s=Sprite()
    if i==0:
        arc(s,(8,16),17,-1.25,1.25,'wood',3)
        s.line([(13,2),(5,16),(13,30)],'bone')
        s.line([(5,16),(28,16)],'leaf',2)
        s.poly([(24,12),(31,16),(24,20)],'iron')
    elif i==1:
        for x,y in ((-3,5),(6,0),(12,7)): arrow(s,x,y,.65)
    elif i==2:
        s.poly([(12,17),(23,17),(28,25),(22,29),(10,28),(6,22)],'iron')
        star(s,18,22,5,'leaf')
        s.line([(11,2),(3,8),(10,13)],'leaf',3)
    elif i==3:
        for x,y in ((-2,2),(9,-1),(14,10)): arrow(s,x,y,.65)
        s.line([(3,30),(13,28),(26,30)],'wood',2)
    elif i==4:
        arrow(s)
        s.line([(21,8),(16,7),(15,12)],'iron',2)
        s.line([(26,12),(27,17),(22,18)],'iron',2)
        s.line([(3,29),(9,30),(12,27)],'gold',2)
    elif i==5:
        arc(s,(16,22),11,math.pi,math.tau,'iron',3)
        s.line([(6,24),(25,24)],'wood',3)
        for x in (7,12,17,22): s.poly([(x,22),(x+2,14),(x+4,22)],'iron')
    elif i==6:
        arrow(s)
        s.oval((8,13,19,24),'coal')
        s.line([(11,14),(14,19),(12,22)],'fire',2)
        star(s,24,5,4,'fire')
    elif i==7:
        arrow(s,-1,-2,1.05,'gold')
        arc(s,(15,17),11,0,math.tau,'gold',2)
        s.line([(2,4),(7,8)],'leaf',2);s.line([(20,28),(27,30)],'leaf',2)
    elif i==8:
        arrow(s,0,0,1,'leaf')
        s.line([(12,9),(20,17)],'iron',2)
        s.line([(17,4),(25,12)],'iron',2)
    elif i==9:
        ring(s,'leaf',11)
        for a in range(4):
            x=16+round(math.cos(a*math.pi/2)*14);y=16+round(math.sin(a*math.pi/2)*14)
            s.line([(x,y),(round((x+16)/2),round((y+16)/2))],'gold',2)
        arrow(s,7,6,.55)
    elif i==10:
        arrow(s)
        for side in (-1,1): s.poly([(16,13),(16+side*12,13),(16+side*8,18),(16+side*5,17)],'leaf')
    else:
        for x,y in ((5,24),(14,27),(23,24)):
            s.line([(x,y),(x+2,y-17)],'wood',3)
            s.poly([(x,y-9),(x-4,y-14),(x+2,y-12),(x+7,y-18),(x+4,y-7)],'leaf')
    return s


def dark_icon(i):
    s=Sprite()
    if i==0:
        s.oval((6,6,25,25),'night');arc(s,(16,16),12,-.6,4.8,'violet',2)
        s.line([(10,11),(15,9),(14,16),(20,21)],'violet',2)
    elif i==1:
        s.oval((2,3,12,13),'night');s.oval((21,21,29,29),'soul')
        s.line([(8,10),(17,12),(12,20),(24,25)],'violet',3)
        s.line([(15,15),(19,16),(15,20)],'soul',1)
    elif i==2:
        ring(s,'violet',11)
        s.poly([(16,4),(21,14),(27,17),(20,20),(16,29),(12,20),(5,17),(11,14)],'night')
        s.line([(12,11),(17,15),(13,21),(20,23)],'violet',2)
    elif i==3:
        for x,h in ((6,13),(11,6),(16,4),(21,8)):
            s.line([(x,25),(x,h)],'night',3)
            s.line([(x,h),(x+3,h+3)],'violet',2)
        s.poly([(5,15),(22,15),(24,23),(18,30),(9,28)],'night')
        s.line([(9,20),(16,24),(21,19)],'violet',2)
    elif i==4:
        ring(s,'violet',12);s.oval((8,8,24,24),'night')
        arc(s,(16,16),9,0,5,'violet',2)
        arc(s,(16,16),5,2,6,'violet',2)
    elif i==5:
        s.poly([(3,9),(11,5),(16,9),(22,5),(29,10),(26,22),(16,28),(5,22)],'night')
        s.line([(6,12),(12,14),(10,16)],'violet',2)
        s.line([(26,12),(20,14),(22,16)],'violet',2)
        s.poly([(16,17),(19,22),(13,22)],'violet')
    elif i==6:
        sword(s,0,0,1,'violet');sword(s,-1,0,.65,'night',True)
    elif i==7:
        s.oval((5,4,27,26),'gold');s.oval((3,5,23,27),'night')
        arc(s,(16,16),13,0,math.tau,'violet',2)
        s.line([(6,28),(13,25),(23,29)],'violet',2)
    elif i==8:
        s.poly([(6,29),(9,15),(10,7),(16,2),(22,7),(23,16),(28,28),(22,26),(17,30),(13,26)],'night')
        s.line([(11,11),(14,12)],'violet',2);s.line([(19,12),(22,11)],'violet',2)
        s.line([(12,21),(17,18),(21,23)],'violet',2)
    elif i==9:
        shield(s,'night');s.oval((11,10,21,21),'violet')
        s.line([(14,13),(18,13),(17,18)],'soul',2)
    elif i==10:
        ring(s,'violet',11)
        for x,y in ((9,9),(22,10),(15,23)):
            s.oval((x-4,y-4,x+4,y+4),'night');star(s,x,y,3,'soul')
    else:
        s.poly([(5,5),(15,8),(26,4),(28,24),(17,29),(4,25)],'night')
        s.line([(16,10),(15,26)],'gold',2)
        s.line([(8,12),(12,14),(8,18),(12,22)],'violet',2)
        s.line([(20,12),(24,10),(22,18),(24,22),(20,24)],'violet',2)
    return s


def sun(s,x=16,y=16,r=7,material='gold'):
    s.oval((x-r,y-r,x+r,y+r),material)
    s.oval((x-r+3,y-r+3,x+r-3,y+r-3),'bone')
    for j in range(7):
        a=j*math.tau/7-.2
        s.line([(round(x+math.cos(a)*(r+2)),round(y+math.sin(a)*(r+2))),
                (round(x+math.cos(a)*(r+4)),round(y+math.sin(a)*(r+4)))],material,1)


def light_icon(i):
    s=Sprite()
    if i==0:
        s.line([(3,28),(26,5)],'gold',4);s.line([(5,27),(28,4)],'bone',1)
        sun(s,25,6,6,'gold')
    elif i==1:
        s.poly([(4,17),(7,13),(12,16),(16,21),(21,18),(28,18),(26,25),(18,29),(9,25)],'bone')
        sun(s,17,9,7,'gold')
    elif i==2: shield(s)
    elif i==3:
        ring(s,'gold',11);s.line([(7,24),(24,7)],'bone',3);sun(s,23,8,5,'gold')
        s.line([(3,6),(6,9)],'gold',2);s.line([(25,23),(28,26)],'gold',2)
    elif i==4:
        for x in (10,16,22): s.line([(x,4),(x,27)],'gold',3)
        s.line([(6,28),(26,28)],'bone',3);sun(s,16,5,6,'gold')
    elif i==5:
        for side in (-1,1):
            s.poly([(16,21),(16+side*3,12),(16+side*13,3),(16+side*11,13),(16+side*7,18)],'bone')
            for j in range(3): s.line([(16+side*4,20-j*3),(16+side*(10+j),9-j*2)],'gold',2)
    elif i==6:
        sun(s,16,16,9,'gold');ring(s,'gold',12)
        s.oval((14,14,18,18),'bone')
    elif i==7:
        sword(s,3,-2,.8,'gold');s.line([(5,27),(27,27)],'bone',3)
        for x in (5,13,23): s.line([(x,7),(x,18)],'gold',2)
    elif i==8:
        grip(s,(6,28),(20,13))
        sun(s,21,11,7,'gold')
    elif i==9:
        s.poly([(5,6),(11,3),(16,7),(21,3),(28,7),(24,16),(25,29),(7,29),(8,16)],'bone')
        sun(s,16,17,5,'gold')
    elif i==10:
        s.poly([(3,27),(7,14),(16,4),(25,14),(29,27)],'gold')
        s.poly([(9,26),(9,17),(16,10),(23,17),(23,26)],'bone')
        sun(s,16,18,5,'gold')
    else:
        s.line([(5,11),(5,22),(16,28),(27,22),(27,11)],'gold',3)
        sun(s,16,11,8,'gold')
        for x in (4,27):s.line([(x,5),(x,8)],'bone',2)
    return s


def main():
    sprites=[]
    suffixes=['1','2','3','4','5','8','9','10','path1','path1b','path2','path2b']
    for style,draw in [('sword',sword_icon),('bow',bow_icon),('dark',dark_icon),('light',light_icon)]:
        for i,suffix in enumerate(suffixes):
            mapping={'bow':{1:2,2:1},'dark':{0:1,1:2,2:0},'light':{0:4,4:0}}
            s=draw(mapping.get(style,{}).get(i,i))
            png(OUT / (style+'_'+suffix+'.png'),s.pix)
            sprites.append(s.pix)
    sheet=[[(27,34,45,255)]*(12*100) for _ in range(4*100)]
    for i,sprite in enumerate(sprites):
        ox,oy=(i%12)*100+2,(i//12)*100+2
        for y in range(96):
            for x in range(96):
                pixel=sprite[y//3][x//3]
                if pixel[3]:sheet[oy+y][ox+x]=pixel
    png(ROOT/'verification/styles-icons.png',sheet)
    print('48 icons, 32x32 RGBA; preview verification/styles-icons.png')


if __name__=='__main__':
    main()
