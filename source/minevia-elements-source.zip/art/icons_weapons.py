# Предметные спрайты 32x32: ручные силуэты, тёмный контур, свет по материалу, прозрачный фон.
# Только стандартная библиотека. Запуск: python art/icons_weapons.py
import math
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "elements-mod/src/main/resources/assets/minevia_elements/textures"
RAMPS = {
    "iron": ["181821", "30333f", "515a68", "81909e", "b7c8cf"],
    "coal": ["150f15", "29202a", "43343b", "67505a", "93747b"],
    "fire": ["431707", "8d2d0c", "d96013", "f59c25", "ffe18a"],
    "copper": ["28190e", "583722", "94613a", "c59356", "f3d28b"],
    "water": ["0b2330", "164752", "287a85", "69bfbd", "c6f4e7"],
    "night": ["140f22", "29213e", "483a65", "7e70a2", "b9aad5"],
    "soul": ["0b252a", "175254", "338e88", "80d7bd", "d9ffdf"],
    "wood": ["24180f", "4b2b1d", "795035", "ab7d4e", "d3af72"],
    "bone": ["322b25", "62574c", "948879", "c1b7a0", "f2e5c3"],
}
RAMPS = {k: [tuple(bytes.fromhex(c)) + (255,) for c in v] for k, v in RAMPS.items()}


def png(file, pixels):
    h, w = len(pixels), len(pixels[0])
    def chunk(name, data):
        return struct.pack(">I", len(data)) + name + data + struct.pack(">I", zlib.crc32(name + data) & 0xffffffff)
    raw = b"".join(b"\0" + bytes(c for p in row for c in p) for row in pixels)
    file.parent.mkdir(parents=True, exist_ok=True)
    file.write_bytes(b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))


class Sprite:
    def __init__(self):
        self.pix = [[(0, 0, 0, 0)] * 32 for _ in range(32)]

    def paint(self, mask, material, texture=False):
        colors = RAMPS[material]
        for x, y in mask:
            for dx, dy in ((0, -1), (-1, 0), (0, 1), (1, 0)):
                xx, yy = x + dx, y + dy
                if (xx, yy) not in mask and 0 <= xx < 32 and 0 <= yy < 32:
                    self.pix[yy][xx] = (10, 10, 16, 255)
        for x, y in mask:
            if not (0 <= x < 32 and 0 <= y < 32):
                continue
            top = (x - 1, y) not in mask or (x, y - 1) not in mask
            bottom = (x + 1, y) not in mask or (x, y + 1) not in mask
            tone = 4 if top and not bottom else 1 if bottom else 3 if (x + y) % 4 < 2 else 2
            if texture and (x * 17 + y * 7) % 19 == 0:
                tone = max(1, tone - 1)
            self.pix[y][x] = colors[tone]

    def poly(self, points, material, texture=False):
        mask = set()
        for y in range(32):
            for x in range(32):
                inside = False
                for a, b in zip(points, points[1:] + points[:1]):
                    if (a[1] > y + 0.5) != (b[1] > y + 0.5) and x + 0.5 < (b[0] - a[0]) * (y + 0.5 - a[1]) / (b[1] - a[1]) + a[0]:
                        inside = not inside
                if inside:
                    mask.add((x, y))
        self.paint(mask, material, texture)

    def line(self, points, material, width=1, tone=None):
        mask = set()
        for a, b in zip(points, points[1:]):
            steps = max(abs(b[0] - a[0]), abs(b[1] - a[1])) * 3 + 1
            for i in range(steps + 1):
                t = i / steps
                x, y = round(a[0] + (b[0] - a[0]) * t), round(a[1] + (b[1] - a[1]) * t)
                for dx in range(-(width // 2), (width + 1) // 2):
                    for dy in range(-(width // 2), (width + 1) // 2):
                        mask.add((x + dx, y + dy))
        if tone is None:
            self.paint(mask, material)
        else:
            for x, y in mask:
                if 0 <= x < 32 and 0 <= y < 32:
                    self.pix[y][x] = RAMPS[material][tone]

    def oval(self, bounds, material):
        x0, y0, x1, y1 = bounds
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        rx, ry = max(0.5, (x1 - x0) / 2), max(0.5, (y1 - y0) / 2)
        self.paint({(x, y) for x in range(32) for y in range(32) if ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2 <= 1}, material)


def grip(s, a, b, material="wood"):
    s.line([a, b], material, 3)
    x0, y0 = a
    for i in (2, 5, 8):
        t = i / 12
        x, y = round(x0 + (b[0] - x0) * t), round(y0 + (b[1] - y0) * t)
        s.line([(x - 1, y - 1), (x + 1, y + 1)], "copper", tone=1)


def cinderwing(s):
    grip(s, (5, 28), (13, 20))
    s.poly([(11, 19), (12, 15), (16, 14), (18, 9), (22, 8), (27, 2), (27, 10), (23, 16), (18, 19), (15, 22)], "coal", True)
    s.line([(14, 19), (18, 16), (18, 14), (23, 10), (24, 6)], "fire", 2)
    s.line([(11, 17), (17, 23)], "copper", 2)
    s.oval((3, 26, 6, 29), "copper")


def tidal_trident(s):
    grip(s, (4, 28), (22, 10))
    s.line([(7, 25), (23, 9)], "water", 2)
    s.poly([(18, 12), (14, 8), (16, 3), (18, 7), (20, 8), (23, 4), (24, 0), (26, 2), (25, 8), (27, 9), (29, 8), (31, 8), (28, 13), (23, 13), (20, 16)], "water")
    s.line([(18, 12), (22, 10), (25, 4)], "bone", tone=3)
    s.oval((19, 10, 22, 13), "copper")


def night_shard(s):
    grip(s, (8, 26), (14, 20), "night")
    s.poly([(12, 18), (16, 11), (25, 5), (23, 15), (17, 21)], "night", True)
    s.line([(15, 18), (18, 14), (23, 8)], "iron", tone=3)
    s.line([(10, 17), (18, 24)], "iron", 2)
    s.oval((7, 25, 10, 28), "night")
    s.line([(16, 13), (19, 15)], "night", tone=0)


def chime_maul(s):
    grip(s, (6, 28), (21, 13))
    s.poly([(9, 10), (15, 4), (20, 5), (29, 13), (28, 18), (23, 22), (18, 18), (14, 17)], "copper", True)
    s.poly([(11, 10), (16, 6), (19, 7), (25, 13), (21, 17)], "iron", True)
    s.line([(13, 10), (18, 12), (17, 14), (21, 16)], "copper", tone=0)
    s.line([(23, 12), (27, 16), (24, 19)], "copper", 2)
    s.oval((22, 15, 25, 18), "fire")


def windcutter(s):
    for off in (0, 9):
        grip(s, (4 + off, 28 - off // 3), (10 + off, 20 - off // 3), "wood")
        s.poly([(8 + off, 18 - off // 3), (9 + off, 10 - off // 3), (17 + off, 2), (16 + off, 9), (13 + off, 14 - off // 3), (13 + off, 21 - off // 3)], "iron")
        s.line([(10 + off, 18 - off // 3), (11 + off, 12 - off // 3), (15 + off, 6)], "water", tone=3)
        s.line([(6 + off, 18 - off // 3), (13 + off, 23 - off // 3)], "copper", 2)


def gravity_flail(s):
    grip(s, (5, 28), (13, 18), "night")
    s.line([(12, 18), (17, 20), (22, 18), (24, 14)], "iron", 2)
    for x, y in ((15, 19), (19, 19), (23, 16)):
        s.pix[y][x] = RAMPS["night"][0]
    s.poly([(19, 5), (22, 5), (24, 1), (26, 5), (30, 6), (28, 9), (30, 13), (26, 13), (24, 16), (22, 13), (18, 12), (20, 9)], "iron", True)
    s.oval((21, 6, 27, 12), "night")
    s.line([(23, 7), (22, 9), (25, 11), (26, 9)], "night", tone=4)


def storm_bow(s, pull=-1):
    s.poly([(10, 2), (16, 4), (20, 8), (21, 12), (24, 16), (21, 20), (20, 24), (15, 28), (10, 29), (12, 25), (16, 23), (18, 18), (20, 16), (18, 13), (16, 8), (12, 6)], "iron")
    s.line([(11, 3), (17, 7), (19, 12), (22, 16), (19, 21), (17, 25), (11, 28)], "water", tone=3)
    mid = 10 if pull < 0 else (8, 5, 2)[pull]
    s.line([(10, 3), (mid, 16), (10, 28)], "bone", tone=2)
    s.poly([(18, 13), (22, 14), (23, 17), (19, 19), (17, 16)], "wood")
    if pull >= 0:
        s.line([(mid, 16), (28, 16)], "wood", tone=3)
        s.poly([(27, 14), (31, 16), (27, 18)], "iron")
        s.line([(mid, 14), (mid + 3, 16), (mid, 18)], "bone", tone=3)


def soul_scythe(s):
    grip(s, (5, 29), (21, 9))
    s.poly([(10, 8), (15, 4), (24, 2), (29, 5), (30, 10), (28, 17), (27, 11), (25, 8), (20, 7), (15, 9)], "iron", True)
    s.line([(13, 7), (21, 4), (26, 6), (28, 10), (28, 14)], "soul", tone=3)
    s.line([(19, 8), (23, 11)], "copper", 2)
    s.oval((18, 6, 22, 10), "soul")
    s.line([(11, 23), (13, 25)], "soul", tone=2)


def cinder_heart(s):
    s.poly([(6, 12), (8, 6), (14, 5), (17, 9), (22, 5), (27, 9), (26, 18), (17, 28), (8, 22)], "coal", True)
    s.line([(15, 8), (12, 13), (17, 16), (15, 21), (17, 25)], "fire", 2)
    s.line([(17, 16), (23, 12)], "fire", tone=3)


def smith_tongs(s):
    for side in (-1, 1):
        s.line([(16 + side * 5, 28), (16 + side * 2, 18), (16 - side * 3, 11), (16 - side * 6, 5), (16 - side * 2, 3)], "iron", 3)
    s.oval((13, 14, 19, 20), "copper")
    s.oval((15, 16, 17, 18), "iron")


def bellows_relic(s):
    s.poly([(3, 19), (8, 6), (15, 4), (24, 17), (20, 23), (11, 25)], "wood", True)
    s.poly([(5, 19), (9, 9), (16, 9), (22, 18), (18, 23), (11, 23)], "coal")
    for x in (9, 12, 15, 18):
        s.line([(x, 12), (x - 2, 21)], "copper", tone=2)
    s.poly([(21, 19), (28, 13), (30, 15), (24, 23)], "iron")
    s.line([(6, 7), (16, 3)], "copper", 2)


def pearl_of_air(s):
    s.line([(8, 5), (5, 10), (7, 15), (16, 22), (25, 14), (27, 9), (23, 5)], "copper", 2)
    s.oval((9, 12, 23, 27), "bone")
    s.oval((11, 14, 17, 20), "water")
    s.line([(12, 15), (14, 14)], "bone", tone=4)


def tidal_shell(s):
    s.poly([(4, 17), (5, 10), (10, 5), (16, 3), (22, 5), (27, 10), (28, 17), (23, 24), (17, 27), (10, 25)], "bone")
    for x in (7, 12, 20, 25):
        s.line([(x, 9), (16, 24)], "water", tone=2)
    s.oval((13, 20, 19, 26), "water")
    s.line([(7, 16), (9, 11)], "bone", tone=4)


def deep_lantern(s):
    s.oval((12, 2, 20, 10), "water")
    s.poly([(9, 9), (23, 9), (26, 13), (23, 27), (9, 27), (6, 13)], "iron")
    s.poly([(10, 12), (22, 12), (21, 24), (11, 24)], "water")
    s.oval((12, 15, 20, 22), "soul")
    for x in (10, 21):
        s.line([(x, 12), (x + (1 if x == 10 else -1), 25)], "iron", 2)
    s.line([(8, 27), (24, 27)], "copper", 2)


def star_lens(s):
    grip(s, (6, 27), (13, 20), "copper")
    s.oval((9, 3, 29, 23), "copper")
    s.oval((12, 6, 26, 20), "night")
    s.line([(15, 9), (21, 7), (24, 10)], "iron", tone=4)
    s.line([(19, 10), (19, 16)], "night", tone=4)
    s.line([(16, 13), (22, 13)], "night", tone=4)


def orbit_stone(s):
    s.poly([(13, 8), (20, 6), (25, 13), (22, 23), (13, 26), (7, 18)], "night", True)
    s.line([(13, 10), (18, 13), (16, 18), (21, 22)], "soul", tone=2)
    s.line([(4, 18), (8, 23), (20, 25), (28, 17), (28, 12), (24, 8)], "copper", 2)
    s.oval((23, 5, 27, 9), "bone")


def sky_anchor(s):
    s.line([(16, 7), (16, 26)], "iron", 3)
    s.oval((12, 2, 20, 10), "copper")
    s.line([(7, 13), (25, 13)], "copper", 3)
    s.poly([(3, 18), (8, 22), (16, 26), (24, 22), (29, 17), (28, 24), (24, 28), (17, 30), (9, 27), (5, 24)], "iron")
    s.line([(7, 23), (16, 27), (26, 23)], "water", tone=3)


DRAW = {f.__name__: f for f in (cinderwing, tidal_trident, night_shard, chime_maul, windcutter, gravity_flail, storm_bow, soul_scythe,
                                cinder_heart, smith_tongs, bellows_relic, pearl_of_air, tidal_shell, deep_lantern, star_lens, orbit_stone, sky_anchor)}


def main():
    sprites = []
    for name, draw in DRAW.items():
        s = Sprite()
        draw(s)
        png(OUT / f"item/{name}.png", s.pix)
        sprites.append(s.pix)
    for i in range(3):
        s = Sprite()
        storm_bow(s, i)
        png(OUT / f"item/storm_bow_pulling_{i}.png", s.pix)
    # Печати: светящийся узор на прозрачном каменном круге.
    for i, material in enumerate(("fire", "water", "night"), 3):
        s = Sprite()
        for y in range(32):
            for x in range(32):
                r = math.hypot(x - 15.5, y - 15.5)
                if r < 15:
                    s.pix[y][x] = (18, 23, 28, 255)
                if abs(r - 12) < 0.7 or abs(r - 8) < 0.55:
                    s.pix[y][x] = RAMPS[material][3]
        for k in range(8):
            a = k / 8 * math.tau
            x, y = round(15.5 + math.cos(a) * 10), round(15.5 + math.sin(a) * 10)
            s.line([(x, y), (x + round(math.cos(a) * 3), y + round(math.sin(a) * 3))], material, tone=4)
        s.line([(11, 19), (16, 10), (21, 19), (11, 19)], material, tone=4)
        png(OUT / f"block/dungeon_sigil_{i}.png", s.pix)
    # Лист проверки, увеличение только ближайшим соседом.
    sheet = [[(43, 48, 54, 255)] * (9 * 136) for _ in range(2 * 136)]
    for i, sprite in enumerate(sprites):
        ox, oy = (i % 9) * 136 + 4, (i // 9) * 136 + 4
        for y in range(128):
            for x in range(128):
                p = sprite[y // 4][x // 4]
                if p[3]:
                    sheet[oy + y][ox + x] = p
    png(ROOT / "art/weapons-preview.png", sheet)
    print(f"{len(sprites)} item sprites, 3 bow frames, 3 sigils ready")


if __name__ == "__main__":
    main()
