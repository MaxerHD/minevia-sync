# Библиотека эффектов и модели навыков стилей: вместо простых фигур языки энергии, рваные кольца, искры, детальные клинки, когти, перья.
# Подключается после spells_styles.py и заменяет те же имена мешей: <навык>_body твёрдый слой, <навык>_glow светящийся.

FX_FRAMES = 12
THEMES = {
    "steel": [(0.0, (0.03, 0.2, 0.62)), (0.5, (0.1, 0.5, 0.95)), (0.8, (0.45, 0.82, 1.0)), (1.0, (0.92, 0.98, 1.0))],
    "green": [(0.0, (0.02, 0.26, 0.14)), (0.5, (0.08, 0.6, 0.3)), (0.8, (0.4, 0.92, 0.5)), (1.0, (0.9, 1.0, 0.72))],
    "void": [(0.0, (0.1, 0.0, 0.22)), (0.45, (0.34, 0.04, 0.68)), (0.8, (0.66, 0.2, 1.0)), (1.0, (0.92, 0.72, 1.0))],
    "sun": [(0.0, (0.56, 0.24, 0.02)), (0.45, (0.95, 0.58, 0.08)), (0.8, (1.0, 0.84, 0.32)), (1.0, (1.0, 0.98, 0.8))],
    "blood": [(0.0, (0.28, 0.0, 0.03)), (0.5, (0.72, 0.05, 0.05)), (0.8, (1.0, 0.3, 0.1)), (1.0, (1.0, 0.76, 0.4))],
    "plague": [(0.0, (0.06, 0.16, 0.04)), (0.5, (0.3, 0.5, 0.08)), (0.8, (0.62, 0.86, 0.16)), (1.0, (0.92, 1.0, 0.5))],
}


class Layer:
    """Слой эффекта: постоянная сетка и функция, дающая вершины и цвета на момент t от 0 до 1."""

    def __init__(self, quads, frame):
        self.quads = np.asarray(quads, dtype=np.int32)
        self.frame = frame


def fx_save(name, layers, frames=FX_FRAMES, loop=True):
    if not layers:
        layers = [fx_stub()]
    offsets, total, quads = [], 0, []
    result = []
    for f in range(frames):
        t = f / frames if loop else f / (frames - 1)
        pos, col = [], []
        for layer in layers:
            p, c = layer.frame(t)
            pos.append(p)
            col.append(c)
        result.append((np.concatenate(pos), np.concatenate(col)))
    for layer, first in zip(layers, [(l.frame(0.0)[0]) for l in layers]):
        quads.append(layer.quads + total)
        total += len(first)
    assert total < 65536, name
    save(name, result, np.concatenate(quads))


def fx_stub():
    p = np.array([(0, 0, 0), (0.001, 0, 0), (0.001, 0.001, 0), (0, 0.001, 0)], dtype=float)
    return Layer([(0, 1, 2, 3)], lambda t: (p, rgba(np.ones((4, 3)), np.zeros(4))))


def fx_strip(rows, count):
    """Индексы двух скрещённых лент на count объектов по rows рядов: лента видна с любой стороны."""
    quads = []
    per = rows * 4
    for k in range(count):
        base = k * per
        for r in range(rows - 1):
            a = base + r * 4
            quads += [(a, a + 1, a + 5, a + 4), (a + 2, a + 3, a + 7, a + 6)]
    return quads


def fx_cross(path, width, row):
    """Вершины скрещённых лент вдоль пути."""
    way = np.gradient(path, axis=0)
    way /= np.maximum(1e-6, np.linalg.norm(way, axis=1, keepdims=True))
    ref = np.array([0.0, 0.0, 1.0]) if abs(way[len(way) // 2][2]) < 0.8 else np.array([1.0, 0.0, 0.0])
    u = np.cross(way, ref)
    u /= np.maximum(1e-6, np.linalg.norm(u, axis=1, keepdims=True))
    v = np.cross(way, u)
    w = width[:, None]
    out = np.stack([path - u * w, path + u * w, path - v * w, path + v * w], axis=1)
    return out.reshape(-1, 3)


def L_wisps(theme, count=14, radius=0.8, height=1.8, seed=1, width=0.09, rows=10, curl=1.0, inward=0.3):
    """Языки энергии: поднимаются от кольца, закручиваются и тают заострённым концом."""
    rng = np.random.default_rng(seed)
    plan = [(rng.uniform(0, TAU), rng.uniform(0.8, 1.15), rng.uniform(0, 1), rng.uniform(0.7, 1.25), rng.uniform(-1, 1)) for _ in range(count)]
    ramp_stops = THEMES[theme]
    s = np.linspace(0, 1, rows)
    quads = fx_strip(rows, count)

    def frame(t):
        pos, col = [], []
        for a, far, phase, tall, twist in plan:
            k = (t + phase) % 1.0
            life = math.sin(k * math.pi) ** 0.8
            top = height * tall * (0.45 + 0.55 * k)
            angle = a + twist * curl * (s * 1.8 + k * 1.2)
            r = radius * far * (1 - inward * s) + 0.05 * np.sin(s * 9 + phase * 9)
            path = np.stack([np.cos(angle) * r, s * top, np.sin(angle) * r], axis=1)
            w = width * life * (1 - s) ** 0.7 * (0.5 + 0.8 * s ** 0.4) * 1.5
            pos.append(fx_cross(path, np.maximum(w, 0.0015), None))
            col.append(np.repeat(ramp(np.clip(1.02 - 0.74 * s + 0.12 * math.sin(phase * 7), 0, 1), ramp_stops), 4, axis=0))
        pos = np.concatenate(pos)
        return pos, rgba(np.concatenate(col), np.ones(len(pos)))

    return Layer(quads, frame)


def L_swirl(theme, arms=3, radius=1.0, height=1.5, turns=1.4, seed=2, width=0.1, rows=26, lift=0.0):
    """Спиральные ленты вокруг оси."""
    s = np.linspace(0, 1, rows)
    quads = fx_strip(rows, arms)
    wob = Flow(seed, freq=2.4, octaves=2, speed=1)
    stops = THEMES[theme]

    def frame(t):
        pos, col = [], []
        for i in range(arms):
            a = i / arms * TAU + TAU * t + s * turns * TAU
            r = radius * (0.42 + 0.58 * s ** 0.8)
            spot = np.stack([np.cos(a) * r, lift + s * height, np.sin(a) * r], axis=1)
            n = wob(spot, t)
            spot[:, 1] += 0.09 * n
            w = width * np.sin(s * math.pi) ** 0.7 * (0.8 + 0.4 * n)
            pos.append(fx_cross(spot, np.maximum(w, 0.002), None))
            col.append(np.repeat(ramp(np.clip(0.48 + 0.5 * np.sin(s * math.pi) + 0.2 * n, 0, 1), stops), 4, axis=0))
        pos = np.concatenate(pos)
        return pos, rgba(np.concatenate(col), np.ones(len(pos)))

    return Layer(quads, frame)


def L_rays(theme, count=12, r0=0.3, r1=1.3, seed=3, width=0.07, tilt=0.0, center=(0, 0, 0), plane="y", rows=6):
    """Лучи: острые клинья расходятся от центра и дышат."""
    rng = np.random.default_rng(seed)
    plan = [(k / count * TAU + rng.uniform(-0.08, 0.08), rng.uniform(0.6, 1.1), rng.uniform(0, 1)) for k in range(count)]
    s = np.linspace(0, 1, rows)
    quads = fx_strip(rows, count)
    stops = THEMES[theme]
    middle = np.asarray(center, dtype=float)

    def frame(t):
        pos, col = [], []
        for a, reach, phase in plan:
            k = 0.76 + 0.24 * math.sin(TAU * (t + phase))
            a2 = a + 0.25 * t * TAU * (1 if plane == "y" else 0)
            d = (np.array([math.cos(a2), tilt, math.sin(a2)]) if plane == "y" else np.array([math.cos(a2), math.sin(a2), tilt]))
            d /= np.linalg.norm(d)
            path = middle + d[None, :] * (r0 + (r1 - r0) * reach * k * s)[:, None]
            w = width * (1 - s) ** 0.9 + 0.0015
            pos.append(fx_cross(path, w, None))
            col.append(np.repeat(ramp(np.clip(1.0 - 0.7 * s, 0, 1), stops), 4, axis=0))
        pos = np.concatenate(pos)
        return pos, rgba(np.concatenate(col), np.ones(len(pos)))

    return Layer(quads, frame)


def L_shock(theme, radius=1.2, seed=4, thick=0.14, y=0.04, waves=2):
    """Рваная ударная волна по земле, бежит кольцом и тает."""
    nu = 72
    a = np.linspace(0, TAU, nu, endpoint=False)
    rip = Flow(seed, freq=3.2, octaves=3, gain=0.65, speed=0)
    ring = np.stack([np.cos(a), a * 0, np.sin(a)], axis=1)
    edge = 0.72 + 0.6 * np.abs(rip(ring, 0.0))
    quads = []
    for w in range(waves):
        base = w * nu * 2
        for i in range(nu):
            j = (i + 1) % nu
            quads.append((base + i * 2, base + j * 2, base + j * 2 + 1, base + i * 2 + 1))
    quads = quads + [q[::-1] for q in quads]
    stops = THEMES[theme]

    def frame(t):
        pos, col = [], []
        for w in range(waves):
            k = (t + w / waves) % 1.0
            r = radius * (0.2 + 0.8 * k ** 0.7)
            fat = thick * radius * (1 - k) ** 0.8 * edge
            inner = np.stack([np.cos(a) * r, a * 0 + y, np.sin(a) * r], axis=1)
            outer = np.stack([np.cos(a) * (r + fat), a * 0 + y + 0.02, np.sin(a) * (r + fat)], axis=1)
            pos.append(np.stack([inner, outer], axis=1).reshape(-1, 3))
            tone = ramp(np.full(nu * 2, np.clip(1 - 0.75 * k, 0, 1)), stops)
            col.append(tone)
        pos = np.concatenate(pos)
        return pos, rgba(np.concatenate(col), np.ones(len(pos)))

    return Layer(quads, frame)


def fx_diamonds(count):
    quads = []
    for k in range(count):
        b = k * 6
        for a, c in ((1, 2), (2, 3), (3, 4), (4, 1)):
            quads.append((b, b + a, b + c, b + c))
            quads.append((b + 5, b + c, b + a, b + a))
    return quads


def L_embers(theme, count=30, radius=1.0, height=2.0, size=0.04, seed=5, fall=False, stretch=2.4):
    """Мелкие гранёные искры: поднимаются или падают и гаснут."""
    rng = np.random.default_rng(seed)
    plan = [(rng.uniform(0, TAU), rng.uniform(0.1, 1) ** 0.6, rng.uniform(0, 1), rng.uniform(0.6, 1.3), rng.uniform(-1, 1)) for _ in range(count)]
    quads = fx_diamonds(count)
    stops = THEMES[theme]

    def frame(t):
        pos, col = [], []
        for a, far, phase, speed, sway in plan:
            k = (t + phase) % 1.0
            y = height * (1 - k if fall else k) * speed
            ang = a + sway * k * 1.4
            c = np.array([math.cos(ang) * radius * far, y, math.sin(ang) * radius * far])
            r = size * math.sin(k * math.pi) ** 0.5
            pos.append(c + np.array([(0, r * stretch, 0), (r, 0, 0), (0, 0, r), (-r, 0, 0), (0, 0, -r), (0, -r * stretch, 0)]))
            col.append(np.tile(ramp(np.array([1.0 - 0.45 * k]), stops), (6, 1)))
        pos = np.concatenate(pos)
        return pos, rgba(np.concatenate(col), np.ones(len(pos)))

    return Layer(quads, frame)


def L_core(theme, radius=0.5, seed=6, void=False, nu=30, nv=20):
    """Сгусток: кипящая поверхность с бегущими жилами. void: чёрная середина со светлыми жилами."""
    dirs, quads, *_ = sphere(nu, nv, axis=1)
    boil = Flow(seed, freq=2.4, octaves=3, gain=0.6, speed=1)
    veins = Flow(seed + 1, freq=3.4, octaves=2, speed=1)
    stops = THEMES[theme]

    def frame(t):
        n = boil(dirs, t)
        lines = (1 - np.abs(veins(dirs, t))) ** 7
        pos = dirs * (radius * (1 + 0.14 * n))[:, None]
        if void:
            rgb = np.array([0.03, 0.01, 0.06])[None, :] * (1 + n[:, None]) + ramp(np.clip(lines * 1.3, 0, 1), stops) * lines[:, None]
        else:
            rgb = ramp(np.clip(0.5 + 0.4 * n + 0.7 * lines, 0, 1), stops)
        return pos, rgba(np.clip(rgb, 0, 1), np.ones(len(pos)))

    return Layer(quads, frame)


def L_glyph(theme, radius=1.0, seed=7, y=0.03, spokes=9):
    """Знак на земле: рваные концентрические дуги и зубцы. Без крестов."""
    rng = np.random.default_rng(seed)
    bands = [(0.98, 0.05, 0, TAU), (0.74, 0.03, 0.2, TAU * 0.8), (0.5, 0.04, 1.4, TAU * 0.66), (0.28, 0.03, 0, TAU)]
    seg = 48
    quads, rows = [], []
    for r, w, a0, span in bands:
        base = len(rows) * 2
        for i in range(seg):
            a = a0 + span * i / (seg - 1)
            rows.append((a, r, w))
            if i < seg - 1:
                quads.append((base + i * 2, base + i * 2 + 2, base + i * 2 + 3, base + i * 2 + 1))
    ticks = []
    for k in range(spokes):
        ticks.append((k / spokes * TAU + rng.uniform(-0.05, 0.05), rng.uniform(0.54, 0.7)))
    base = len(rows) * 2
    for k, (a, r) in enumerate(ticks):
        b = base + k * 4
        quads.append((b, b + 1, b + 2, b + 3))
    quads = quads + [q[::-1] for q in quads]
    stops = THEMES[theme]
    a_rows = np.array([q[0] for q in rows])
    r_rows = np.array([q[1] for q in rows])
    w_rows = np.array([q[2] for q in rows])

    def frame(t):
        turn = TAU * t
        spin = np.where(r_rows > 0.6, turn, -turn) + a_rows
        inner = np.stack([np.cos(spin) * (r_rows - w_rows) * radius, spin * 0 + y, np.sin(spin) * (r_rows - w_rows) * radius], axis=1)
        outer = np.stack([np.cos(spin) * (r_rows + w_rows) * radius, spin * 0 + y, np.sin(spin) * (r_rows + w_rows) * radius], axis=1)
        pos = [np.stack([inner, outer], axis=1).reshape(-1, 3)]
        for a, r in ticks:
            d = np.array([math.cos(a + turn * 0.5), 0, math.sin(a + turn * 0.5)])
            s = np.array([-d[2], 0, d[0]])
            c = d * r * radius + np.array([0, y, 0])
            pos.append(np.array([c - s * 0.03 * radius, c + s * 0.03 * radius, c + d * 0.14 * radius, c + d * 0.14 * radius]))
        pos = np.concatenate(pos)
        pulse = 0.72 + 0.2 * math.sin(TAU * t)
        return pos, rgba(ramp(np.full(len(pos), pulse), stops), np.ones(len(pos)))

    return Layer(quads, frame)


def L_beam(theme, strands=4, width=0.05, seed=8, rows=30, twist=3.0):
    """Луч вдоль +Z длиной 1: скрученные нити вокруг яркой жилы."""
    s = np.linspace(0, 1, rows)
    quads = fx_strip(rows, strands + 1)
    wob = Flow(seed, freq=5.0, octaves=2, speed=2)
    stops = THEMES[theme]

    def frame(t):
        pos, col = [], []
        core = np.stack([s * 0, s * 0, s], axis=1)
        pos.append(fx_cross(core, np.full(rows, width * 0.7), None))
        col.append(np.repeat(ramp(np.full(rows, 1.0), stops), 4, axis=0))
        for i in range(strands):
            a = i / strands * TAU + s * twist * TAU - TAU * t * 2
            n = wob(core + i, t)
            r = width * (2.0 + 0.9 * n)
            path = np.stack([np.cos(a) * r, np.sin(a) * r, s], axis=1)
            pos.append(fx_cross(path, np.full(rows, width * 0.42), None))
            col.append(np.repeat(ramp(np.clip(0.62 + 0.3 * n, 0, 1), stops), 4, axis=0))
        pos = np.concatenate(pos)
        return pos, rgba(np.concatenate(col), np.ones(len(pos)))

    return Layer(quads, frame)


def L_tail(theme, strands=10, length=1.6, spread=0.14, seed=9, width=0.03, rows=9):
    """След летящего снаряда: шлейф острых полос назад вдоль -Z."""
    rng = np.random.default_rng(seed)
    plan = [(rng.uniform(0, TAU), rng.uniform(0.2, 1), rng.uniform(0, 1), rng.uniform(0.6, 1.2)) for _ in range(strands)]
    s = np.linspace(0, 1, rows)
    quads = fx_strip(rows, strands)
    stops = THEMES[theme]

    def frame(t):
        pos, col = [], []
        for a, far, phase, reach in plan:
            k = (t + phase) % 1.0
            r = spread * far * (0.5 + s)
            z = -s * length * reach * (0.7 + 0.3 * k)
            path = np.stack([np.cos(a + s * 2) * r, np.sin(a + s * 2) * r, z], axis=1)
            pos.append(fx_cross(path, width * (1 - s) ** 0.8 + 0.001, None))
            col.append(np.repeat(ramp(np.clip(1.0 - 0.8 * s, 0, 1), stops), 4, axis=0))
        pos = np.concatenate(pos)
        return pos, rgba(np.concatenate(col), np.ones(len(pos)))

    return Layer(quads, frame)


def L_fixed(part, at=(0, 0, 0), turn=None):
    """Неподвижная твёрдая деталь."""
    pos, quads, col = part
    pos = pos @ turn.T if turn is not None else pos
    pos = pos + np.asarray(at, dtype=float)
    return Layer(quads, lambda t: (pos, col))


def L_orbit(part, count=6, radius=1.0, y=0.9, spin=1, pitch=0.0, outward=True, seed=10, bob=0.06):
    """Копии детали кружат вокруг оси."""
    p0, q0, c0 = part
    quads = np.concatenate([q0 + i * len(p0) for i in range(count)])

    def frame(t):
        pos = []
        for i in range(count):
            a = i / count * TAU + TAU * t * spin
            turn = rotation((0, 1, 0), -a + math.pi / 2) @ rotation((1, 0, 0), pitch)
            spot = np.array([math.cos(a) * radius, y + bob * math.sin(TAU * t * 2 + i * 1.7), math.sin(a) * radius])
            pos.append(p0 @ turn.T + spot)
        return np.concatenate(pos), np.tile(c0, (count, 1))

    return Layer(quads, frame)


def L_move(part, path, spin=None):
    """Деталь с движением: path(t) даёт смещение, spin(t) поворот."""
    p0, q0, c0 = part

    def frame(t):
        p = p0 @ spin(t).T if spin else p0
        return p + np.asarray(path(t)), c0

    return Layer(q0, frame)


# ---------------------------------------------------------------- твёрдые детали

def P_blade(scale=1.0, tone=W_STEEL, guard=W_SILVER, wrap=None, seed=1, up=(0, 0, 1)):
    """Клинок с гардой и обмоткой, остриём вдоль up."""
    parts = [w_blade(1.15, 0.082, 0.014, 0.9, 0.0, 0.0, seed, np.asarray(tone))]
    parts.append(g_guardbar(0.18, -0.02, 0.028, np.asarray(guard)))
    for side in (-1, 1):
        parts.append(w_rod(w_bezier((side * 0.15, 0.05, 0), (side * 0.22, 0.08, 0), (side * 0.2, 0.17, 0), 7), np.linspace(0.024, 0.004, 7), np.asarray(guard), sides=5, hard=True))
    parts += g_hilt(0.24, wrap if wrap is not None else W_LEATHER, np.asarray(guard), 7)
    parts.append(w_gem((0, -0.29, 0), 0.034, np.asarray(guard), stretch=1.3))
    pos, quads, col = merged(parts)
    pos = pos * scale
    if tuple(up) == (0, 0, 1):
        pos = pos @ rotation((1, 0, 0), math.pi / 2).T
    return pos, quads, col


def P_arrow(scale=1.0, shaft=W_WOOD, head=W_SILVER, feather=np.array([0.2, 0.62, 0.36])):
    """Стрела вдоль +Z: гранёный наконечник с шипами, древко, оперение из трёх перьев."""
    rings = [w_ring((0, 0, z), (1, 0, 0), (0, 1, 0), r, 4) for z, r in ((1.0, 0.002), (0.84, 0.05), (0.72, 0.075), (0.7, 0.02))]
    parts = [w_rod(np.linspace((0, 0, -0.9), (0, 0, 0.72), 6), 0.016, np.asarray(shaft), sides=6), w_loft(rings, np.asarray(head), 3)]
    for k in range(3):
        a = k / 3 * TAU
        u = (math.cos(a), math.sin(a), 0)
        path = w_bezier((u[0] * 0.012, u[1] * 0.012, -0.58), (u[0] * 0.11, u[1] * 0.11, -0.72), (u[0] * 0.07, u[1] * 0.07, -0.96), 9)
        parts.append(g_rod(path, np.array([0.006, 0.03, 0.044, 0.05, 0.05, 0.046, 0.04, 0.03, 0.012]), np.full(9, 0.004), np.asarray(feather), along=(-u[1], u[0], 0)))
    pos, quads, col = merged(parts)
    return pos * scale, quads, col


def P_shard(seed=1, scale=1.0, tone=W_STEEL):
    pos, quads, col = crag(seed, cuts=3, planes=9, depth=0.4, shards=5, groove=0.05)
    return pos * np.array([0.5, 1.4, 0.5]) * scale, quads, rgba(col[:, :3] * np.asarray(tone)[None, :], col[:, 3])


def P_feather(scale=1.0, tone=W_CLOTH, curve=0.2):
    """Перо: стержень и опахало с прорезями."""
    y = np.linspace(0, 1, 18)
    x = curve * y ** 2
    shape = np.sin(y * math.pi) ** 0.6 * 0.15 * (1 - 0.5 * y)
    parts = [w_rod(np.stack([x, y, y * 0], axis=1), 0.008 * (1 - y) + 0.002, np.asarray(tone) * 0.86, sides=4)]
    for side in (-1, 1):
        rows = [np.array([(x[i], y[i], 0.0), (x[i] + side * shape[i] * (1.0 if i % 3 else 0.72), y[i] + 0.05, 0.012)]) for i in range(18)]
        pos = np.concatenate(rows)
        quads = np.array([(i * 2, i * 2 + 1, i * 2 + 3, i * 2 + 2) for i in range(17)], dtype=np.int32)
        quads = np.concatenate([quads, quads[:, ::-1]])
        parts.append((pos, quads, w_paint(pos, np.asarray(tone), 5, 0.05)))
    pos, quads, col = merged(parts)
    return pos * scale, quads, col


def P_claw_hand(scale=1.0, tone=np.array([0.14, 0.08, 0.2]), seed=3):
    """Рука из тени: узловатые пальцы с когтями тянутся вверх."""
    parts = []
    wrist = w_bezier((0, -0.2, 0), (0.04, 0.3, 0.02), (0, 0.72, 0), 12)
    parts.append(w_rod(wrist, np.linspace(0.17, 0.11, 12), tone, sides=8))
    palm = [w_ring((0, y, 0), (1, 0, 0), (0, 0, 0.7), r, 8) for y, r in ((0.7, 0.12), (0.82, 0.17), (0.94, 0.17), (1.0, 0.13))]
    parts.append(w_loft(palm, tone * 1.1, 3, hard=False))
    for i, x in enumerate((-0.14, -0.05, 0.05, 0.14, 0.22)):
        tall = (0.42, 0.56, 0.6, 0.5, 0.34)[i]
        root = np.array([x, 0.98 if i < 4 else 0.82, 0])
        mid = root + np.array([x * 0.4, tall * 0.55, -0.1])
        tip = root + np.array([x * 0.6, tall, 0.14])
        path = w_bezier(root, mid, tip, 10)
        parts.append(w_rod(path, np.linspace(0.05, 0.022, 10) * (1 + 0.2 * np.abs(np.sin(np.linspace(0, 9, 10)))), tone * 1.15, sides=7))
        end = tip + (tip - mid) / max(1e-6, np.linalg.norm(tip - mid)) * 0.2
        parts.append(w_rod(np.linspace(tip, end, 6), np.linspace(0.024, 0.002, 6), np.array([0.5, 0.42, 0.56]), sides=5, hard=True))
    pos, quads, col = merged(parts)
    return pos * scale, quads, col


def P_hammer(scale=1.0):
    """Боевой молот света: голова вдоль +Z. Солнце на бойке, без крестов."""
    parts = [w_rod(np.linspace((0, 0, -1.1), (0, 0, 0.9), 8), 0.05, W_BRONZE, sides=8)]
    for z in (-0.9, -0.4, 0.2):
        parts.append(w_rod([(0, 0, z - 0.03), (0, 0, z + 0.03)], 0.066, W_GOLD, sides=8))
    head = []
    for y, s in ((-0.5, 0.22), (-0.42, 0.3), (0, 0.32), (0.42, 0.3), (0.5, 0.22)):
        head.append(w_ring((0, y, 1.0), (1, 0, 0), (0, 0, 1), s, 8))
    parts.append(w_loft(head, W_GOLD, 4))
    parts.append(w_gem((0, 0, 1.33), 0.08, W_SILVER, stretch=1.3))
    pos, quads, col = merged(parts)
    return pos * scale, quads, col


def P_trap(scale=1.0):
    """Капкан: две дуги зубьев."""
    parts = []
    a = np.linspace(0, TAU, 26)
    parts.append(w_rod(np.stack([np.cos(a) * 0.95, a * 0 + 0.06, np.sin(a) * 0.95], axis=1), 0.05, W_IRON, sides=6))
    parts.append(w_rod(np.stack([np.cos(a) * 0.6, a * 0 + 0.05, np.sin(a) * 0.6], axis=1), 0.04, W_DARKSTEEL * 1.2, sides=6))
    for k in range(18):
        b = k / 18 * TAU
        base = np.array([math.cos(b) * 0.92, 0.08, math.sin(b) * 0.92])
        tip = base * np.array([0.72, 1, 0.72]) + np.array([0, 0.34, 0])
        parts.append(w_rod(np.linspace(base, tip, 5), np.linspace(0.06, 0.002, 5), W_SILVER, sides=4, hard=True))
    pos, quads, col = merged(parts)
    return pos * scale, quads, col


def P_vine(seed, scale=1.0, tone=np.array([0.2, 0.34, 0.12])):
    """Терновая лоза: извивается вверх, с шипами."""
    rng = np.random.default_rng(seed)
    a = rng.uniform(0, TAU)
    s = np.linspace(0, 1, 18)
    path = np.stack([np.cos(a + s * 3) * 0.2 * s + math.cos(a) * 0.4, s * 1.5, np.sin(a + s * 3) * 0.2 * s + math.sin(a) * 0.4], axis=1)
    parts = [w_rod(path, 0.06 * (1 - s) + 0.008, tone, sides=6)]
    for k in range(3, 17, 2):
        d = rng.normal(size=3)
        d /= np.linalg.norm(d)
        parts.append(w_rod(np.linspace(path[k], path[k] + d * 0.16, 4), np.linspace(0.02, 0.002, 4), np.array([0.5, 0.42, 0.26]), sides=4, hard=True))
    pos, quads, col = merged(parts)
    return pos * scale, quads, col


def P_cloak(scale=1.0):
    """Плащ призрака: рваный подол, капюшон."""
    nu, nv = 24, 16
    a = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    tear = Flow(77, freq=3.0, octaves=3, speed=0)
    ring = np.stack([np.cos(a), a * 0, np.sin(a)], axis=1)
    n = tear(ring * 2, 0.0)
    r = (0.62 - 0.46 * s ** 0.8 + 0.12 * n * (1 - s)) * (1 + 0.1 * np.sin(a * 5) * (1 - s))
    y = s * 2.0 - 0.3 * np.abs(n) * (1 - s) ** 3
    pos = np.stack([np.cos(a) * r, y, np.sin(a) * r], axis=1)
    quads = grid(nu, nv)
    col = w_paint(pos, np.array([0.14, 0.09, 0.2]), 9, 0.14)
    return pos * scale, w_orient(pos, quads, np.stack([pos[quads].mean(axis=1)[:, 0] * 0, pos[quads].mean(axis=1)[:, 1], pos[quads].mean(axis=1)[:, 2] * 0], axis=1)), col


def fx_blades_ring(count, radius, y, tone, pitch, up=False):
    return L_orbit(P_blade(0.72, tone, W_SILVER, up=(0, 1, 0) if up else (0, 0, 1)), count, radius, y, 1, pitch)


# ---------------------------------------------------------------- разрезы

def w_slash(name, radius, wide, frames=14):
    """Разрез: острый серп пробегает вперёд, за ним тают два призрака, с кромки летят искры. Всё светится само."""
    nu = 64
    stops = THEMES["steel"]
    u = np.linspace(0, 1, nu)
    rip = Flow(731, freq=6.0, octaves=3, gain=0.65, speed=0)
    tear = rip(np.stack([u * 4, u * 0, u * 0], axis=1), 0.0)
    plan = [(0.0, 1.0, 1.0), (-0.22, 0.66, 0.86), (-0.46, 0.42, 0.74)]
    bands = 4
    per = nu * bands
    base = []
    for i in range(nu - 1):
        for b in range(bands - 1):
            a = i * bands + b
            base.append((a, a + 1, a + bands + 1, a + bands))
    base = np.array(base, dtype=np.int32)
    base = np.concatenate([base, base[:, ::-1]])
    quads = np.concatenate([base + k * per for k in range(len(plan))])
    sparks = 34
    rng = np.random.default_rng(733)
    spark_plan = [(rng.uniform(0.1, 0.9), rng.uniform(-0.2, 1), rng.uniform(0.5, 1.4), rng.uniform(0.0, 0.5)) for _ in range(sparks)]
    spark_quads = np.array(fx_strip(4, sparks), dtype=np.int32)
    body, glow = [], []
    span = 2.5
    for f in range(frames):
        t = f / (frames - 1)
        head = 1 - (1 - min(1.0, t * 2.1)) ** 2.4
        tail = max(0.0, (t - 0.22) / 0.78) ** 1.4
        alive = 1.0 if t < 0.97 else 0.0
        pos, col = [], []
        for lag, fat, tone in plan:
            h = max(0.0, head + lag * 0.3)
            tl = max(0.0, tail + lag * 0.1)
            place = tl + max(0.0, h - tl) * u
            ang = (place - 0.5) * span
            taper = np.sin(np.clip(u, 0, 1) * math.pi) ** 0.55
            thick = wide * fat * taper * (1 - 0.5 * t)
            rows = []
            for v, rag in ((-0.5, 0.0), (0.0, 0.0), (0.42, 0.0), (0.5, 1.0)):
                r = radius * (1 + 0.04 * lag) + thick * (v + rag * 0.35 * tear)
                rows.append(np.stack([np.sin(ang) * r, np.cos(ang) * r - radius * 0.72, -np.abs(np.sin(ang)) ** 1.5 * radius * 0.5 + lag * radius * 0.5 + t * radius * 0.5], axis=1))
            ring = np.stack(rows, axis=1).reshape(-1, 3)
            pos.append(ring)
            heat = np.tile(np.array([0.72, 1.0, 0.92, 0.66]), nu) * tone
            col.append(ramp(np.clip(heat, 0, 1), stops))
        pos = np.concatenate(pos)
        body.append((pos, rgba(np.concatenate(col), np.full(len(pos), alive))))
        gp, gc = [], []
        for at, delay, speed, up in spark_plan:
            k = np.clip((t - 0.08 * delay - 0.05) / 0.8, 0, 1)
            a = (at - 0.5) * span
            start = np.array([math.sin(a) * radius, math.cos(a) * radius - radius * 0.72, 0.0])
            way = np.array([math.cos(a) * speed, -math.sin(a) * speed + up * 0.4, 0.8 * speed])
            path = np.stack([start + way * (k * radius * 0.9 - d * 0.14) for d in (0, 0.33, 0.66, 1)], axis=0)
            gp.append(fx_cross(path, np.array([0.002, 0.016, 0.012, 0.002]) * (1 - k) + 0.0005, None))
            gc.append(ramp(np.full(16, 1 - 0.5 * k), stops))
        gp = np.concatenate(gp)
        glow.append((gp, rgba(np.concatenate(gc), np.full(len(gp), alive))))
    save(name + "_body", body, quads)
    save(name + "_glow", glow, spark_quads)


def slash_effects():
    w_slash("slash_arc", 1.55, 0.3)
    w_slash("slash_big", 3.1, 0.6)


# Навыки стилей (меч, лук, тьма, свет) лепятся в spells_clean.py.
