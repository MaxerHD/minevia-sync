# Модели хоррора: гигант на горизонте, призрак за спиной, глаза в темноте, висельник.
# Ось Y вверх, лицо смотрит на +Z. Подключается из spells.py после spells_fx.py.

H_DARK = np.array([0.03, 0.03, 0.042])
H_ASH = np.array([0.075, 0.07, 0.085])
H_BONE = np.array([0.62, 0.58, 0.5])
H_SKIN = np.array([0.46, 0.43, 0.4])
H_RAG = np.array([0.05, 0.045, 0.05])


def h_chain(points, rows=4):
    """Ломаная из суставов с равномерными рядами между ними."""
    points = np.asarray(points, dtype=float)
    out = [points[0]]
    for a, b in zip(points[:-1], points[1:]):
        for k in range(1, rows + 1):
            out.append(a + (b - a) * k / rows)
    return np.array(out)


def h_tube(path, radii, sides=7, ref=None):
    """Трубка вдоль пути. Тройка осей правая, поэтому грани смотрят наружу и не исчезают у твёрдых моделей."""
    path = np.asarray(path, dtype=float)
    radii = np.broadcast_to(np.asarray(radii, dtype=float), (len(path),))
    way = np.gradient(path, axis=0)
    way /= np.maximum(1e-9, np.linalg.norm(way, axis=1, keepdims=True))
    base = np.array(ref if ref is not None else (0.13, 0.05, 0.99), dtype=float)
    u = np.cross(np.cross(way, base), way)
    u /= np.maximum(1e-9, np.linalg.norm(u, axis=1, keepdims=True))
    v = np.cross(way, u)
    theta = np.linspace(0, TAU, sides, endpoint=False)
    ring = np.cos(theta)[None, :, None] * u[:, None, :] + np.sin(theta)[None, :, None] * v[:, None, :]
    return (path[:, None, :] + ring * radii[:, None, None]).reshape(-1, 3)


def h_taper(rows, start, end, tip=0.0):
    r = np.linspace(start, end, rows)
    r[-1] = tip
    return r


class HBody:
    """Набор трубок с постоянной сеткой: поза на каждый кадр считается заново."""

    def __init__(self):
        self.pos, self.col, self.quads, self.offset = [], [], [], 0

    def add(self, path, radii, tone, sides=7, ref=None):
        p = h_tube(path, radii, sides, ref)
        rows = len(path)
        self.pos.append(p)
        tone = np.asarray(tone, dtype=float)
        c = np.broadcast_to(tone, (len(p), 3)) if tone.ndim == 1 else tone.reshape(-1, 3)
        self.col.append(rgba(c, np.ones(len(p))))
        self.quads.append(grid(sides, rows) + self.offset)
        self.offset += len(p)

    def frame(self):
        return np.concatenate(self.pos), np.concatenate(self.col)

    def faces(self):
        return np.concatenate(self.quads)


def h_animate(name, pose, frames):
    result, quads = [], None
    for f in range(frames):
        body = HBody()
        pose(body, f / frames)
        result.append(body.frame())
        quads = body.faces()
    save(name, result, quads)


def h_limb(body, joints, r0, r1, tone, rows=4, sides=6):
    path = h_chain(joints, rows)
    body.add(path, h_taper(len(path), r0, r1), tone, sides)


def h_noise(seed, count):
    return np.random.default_rng(seed).uniform(-1, 1, count)


def h_antler(body, root, side, seed, scale):
    """Голые ветви вместо рогов: у силуэта на горизонте это главный признак."""
    n = h_noise(seed, 16)
    root = np.asarray(root)
    trunk = [root, root + scale * np.array([side * 0.5, 0.6, -0.08]), root + scale * np.array([side * 0.8, 1.25, -0.2]),
             root + scale * np.array([side * 0.72, 2.0, -0.12])]
    h_limb(body, trunk, 0.1 * scale, 0.02 * scale, H_DARK, 3, 5)
    for k, joint in enumerate(trunk[1:]):
        for branch in range(2):
            i = k * 4 + branch * 2
            turn = side * (0.45 + 0.3 * abs(n[i])) * (1 if branch else -0.7)
            tip = joint + scale * np.array([turn, 0.5 + 0.25 * n[i + 1], 0.25 * n[i + 2]])
            mid = (joint + tip) / 2 + scale * np.array([0.08 * side, 0.08, 0])
            h_limb(body, [joint, mid, tip], 0.045 * scale, 0.01 * scale, H_DARK, 2, 4)


def h_colossus_points(t):
    ph = TAU * t
    sway = 0.012 * math.sin(ph)
    hip = np.array([sway, 0.47 + 0.012 * math.cos(2 * ph), 0.0])
    chest = hip + np.array([sway * 1.6, 0.27, 0.075])
    neck = chest + np.array([0.0, 0.055, 0.085])
    head = neck + np.array([0.012 * math.sin(ph * 0.5 + 1.0), 0.03, 0.05])
    return ph, sway, hip, chest, neck, head


def horror_colossus_pose(body, t):
    ph, sway, hip, chest, neck, head = h_colossus_points(t)
    spine = h_chain([hip, (hip + chest) / 2 + np.array([0, 0, -0.03]), chest, neck], 4)
    profile = np.interp(np.linspace(0, 1, len(spine)), [0, 0.35, 0.72, 1], [0.05, 0.036, 0.062, 0.014])
    body.add(spine, profile, H_DARK, 8)
    ribs = h_noise(5, 8)
    for k in range(4):
        y = 0.45 + 0.13 * k
        at = hip + (chest - hip) * y
        for s in (-1, 1):
            h_limb(body, [at + np.array([s * 0.02, 0, 0.03]), at + np.array([s * 0.062, -0.012, 0.012 + 0.006 * ribs[k]]),
                          at + np.array([s * 0.05, -0.02, -0.03])], 0.007, 0.004, H_ASH, 2, 4)
    skull = h_chain([head + np.array([0, -0.03, 0.012]), head + np.array([0, 0.0, 0.0]), head + np.array([0, 0.04, -0.012])], 3)
    body.add(skull, np.interp(np.linspace(0, 1, len(skull)), [0, 0.5, 1], [0.008, 0.032, 0.003]), H_ASH, 8)
    for s in (-1, 1):
        h_antler(body, head + np.array([s * 0.02, 0.025, -0.008]), s, 11 + s, 0.09)
        phase = ph + (0 if s > 0 else math.pi)
        foot = np.array([s * 0.075, max(0.0, 0.055 * math.sin(phase)), 0.19 * math.cos(phase)])
        root = hip + np.array([s * 0.05, 0, 0])
        knee = (root + foot) / 2 + np.array([s * 0.018, 0.0, 0.115])
        h_limb(body, [root, knee, foot], 0.034, 0.012, H_DARK, 4, 6)
        h_limb(body, [foot, foot + np.array([0, -0.004, 0.06])], 0.015, 0.004, H_DARK, 2, 5)
        swing = math.cos(phase + math.pi)
        shoulder = chest + np.array([s * 0.095, 0.012, 0.0])
        elbow = shoulder + np.array([s * 0.055, -0.235, 0.05 * swing])
        wrist = elbow + np.array([s * 0.01, -0.235, 0.06 + 0.075 * swing])
        h_limb(body, [chest + np.array([0, 0.012, 0]), shoulder], 0.024, 0.02, H_DARK, 2, 5)
        h_limb(body, [shoulder, elbow, wrist], 0.021, 0.009, H_DARK, 4, 6)
        for finger in range(4):
            spread = (finger - 1.5) * 0.024
            knuckle = wrist + np.array([spread, -0.05, 0.012])
            tip = knuckle + np.array([spread * 1.3, -0.075, 0.03 + 0.012 * swing])
            h_limb(body, [wrist, knuckle, tip], 0.0055, 0.0015, H_DARK, 2, 4)
        for rag in range(4):
            at = shoulder + (elbow - shoulder) * (0.25 + 0.22 * rag)
            drift = 0.018 * math.sin(ph + rag * 1.7 + s)
            path = h_chain([at, at + np.array([s * 0.016, -0.09, -0.02 + drift]), at + np.array([s * 0.02, -0.2 - 0.03 * rag, -0.035 + 2 * drift])], 3)
            body.add(path, h_taper(len(path), 0.012, 0.005), H_RAG, 4)


def horror_colossus_eye_pose(body, t):
    _, _, _, _, _, head = h_colossus_points(t)
    for s in (-1, 1):
        at = head + np.array([s * 0.013, 0.004, 0.029])
        path = h_chain([at + np.array([-0.0075, 0, 0]), at, at + np.array([0.0075, 0, 0])], 3)
        body.add(path, np.interp(np.linspace(0, 1, len(path)), [0, 0.5, 1], [0.0005, 0.0062, 0.0005]), (1.0, 0.1, 0.04), 8, (0, 0, 1))


def horror_colossus():
    h_animate("horror_colossus_body", horror_colossus_pose, 30)
    h_animate("horror_colossus_eyes", horror_colossus_eye_pose, 30)


def h_face_colors(rows, sides):
    """Бледная маска с провалами глаз и слишком длинным ртом."""
    col = np.zeros((rows, sides, 3))
    for r in range(rows):
        h = r / (rows - 1)
        for k in range(sides):
            a = (k / sides * 360 + 90) % 360
            a = a - 360 if a > 180 else a
            tone = H_DARK.copy()
            if abs(a) < 72 and 0.1 < h < 0.84:
                tone = H_BONE * (1 - 0.35 * abs(a) / 72)
                if 0.56 < h < 0.72 and 12 < abs(a) < 42:
                    tone = np.array([0.0, 0.0, 0.0])
                if 0.13 < h < 0.42 and abs(a) < 30 - 40 * abs(h - 0.27):
                    tone = np.array([0.012, 0.0, 0.0])
            col[r, k] = tone
    return col


def h_wraith_points(t):
    ph = TAU * t
    twitch = math.sin(ph * 7) * max(0.0, math.sin(ph * 2 + 0.6)) ** 6
    breath = 0.5 + 0.5 * math.sin(ph * 2)
    hip = np.array([0.0, 1.05, -0.04])
    chest = hip + np.array([0.0, 0.75 + 0.02 * breath, 0.3])
    neck = chest + np.array([0.0, 0.2, 0.2])
    head = neck + np.array([0.0, 0.12, 0.14])
    tilt = 0.5 + 0.34 * twitch
    return ph, twitch, breath, hip, chest, neck, head, tilt


def horror_wraith_pose(body, t):
    ph, twitch, breath, hip, chest, neck, head, tilt = h_wraith_points(t)
    spine = h_chain([hip, (hip + chest) / 2 + np.array([0, 0.02, -0.1]), chest, neck], 4)
    body.add(spine, np.interp(np.linspace(0, 1, len(spine)), [0, 0.4, 0.75, 1], [0.15, 0.1, 0.17, 0.05]), H_DARK, 8)
    rot = rotation((0, 0, 1), tilt)
    rows, sides = 15, 16
    h = np.linspace(-0.27, 0.23, rows)
    skull = head + (np.stack([np.zeros(rows), h, 0.05 * np.sin(h * 3)], axis=1) @ rot.T)
    profile = 0.145 * np.sqrt(np.clip(1 - ((np.linspace(0, 1, rows) - 0.56) / 0.56) ** 2, 0, 1)) + 0.002
    profile[0] = 0.0
    profile[-1] = 0.0
    body.add(skull, profile, h_face_colors(rows, sides), sides, rot @ np.array([1.0, 0.0, 0.0]))
    for s in (-1, 1):
        root = hip + np.array([s * 0.12, 0, 0])
        foot = np.array([s * 0.2, 0.03, -0.14 if s > 0 else 0.1])
        knee = (root + foot) / 2 + np.array([s * 0.06, 0.03, 0.2])
        h_limb(body, [root, knee, foot], 0.085, 0.03, H_DARK, 4, 6)
        h_limb(body, [foot, foot + np.array([0, -0.01, 0.2])], 0.04, 0.012, H_ASH, 2, 5)
        reach = 0.1 * math.sin(ph + s) + 0.09 * twitch * s
        shoulder = chest + np.array([s * 0.28, 0.08, 0.02])
        elbow = shoulder + np.array([s * 0.2, -0.56, 0.2 + reach])
        wrist = elbow + np.array([-s * 0.05, -0.62, 0.3 + reach])
        h_limb(body, [chest + np.array([0, 0.08, 0]), shoulder], 0.075, 0.06, H_DARK, 2, 5)
        h_limb(body, [shoulder, elbow, wrist], 0.06, 0.032, H_ASH, 4, 6)
        for finger in range(5):
            spread = (finger - 2) * 0.065
            curl = 0.05 * math.sin(ph * 3 + finger + s) + 0.07 * twitch
            knuckle = wrist + np.array([spread, -0.14, 0.09])
            mid = knuckle + np.array([spread * 0.7, -0.17, 0.1 + curl])
            tip = mid + np.array([spread * 0.4, -0.16, -0.015 + curl])
            h_limb(body, [wrist, knuckle, mid, tip], 0.017, 0.002, H_BONE * 0.7, 2, 4)
    noise = h_noise(31, 42)
    for strip in range(14):
        a = TAU * strip / 14
        top = chest + np.array([0.3 * math.cos(a), 0.0, 0.22 * math.sin(a)])
        length = 1.15 + 0.55 * abs(noise[strip])
        drift = 0.07 * math.sin(ph + strip * 1.3)
        low = max(0.04, top[1] - length)
        path = h_chain([top, top + np.array([0.09 * math.cos(a), -length * 0.45, 0.07 * math.sin(a) + drift]),
                        np.array([top[0] + 0.15 * math.cos(a), low, top[2] + 0.1 * math.sin(a) + 2 * drift])], 4)
        body.add(path, h_taper(len(path), 0.09, 0.024), H_RAG, 5)


def horror_wraith_eye_pose(body, t):
    _, _, _, _, _, _, head, tilt = h_wraith_points(t)
    rot = rotation((0, 0, 1), tilt)
    for s in (-1, 1):
        at = head + rot @ np.array([s * 0.062, 0.055, 0.135])
        path = h_chain([at + rot @ np.array([0, -0.024, 0]), at, at + rot @ np.array([0, 0.024, 0])], 2)
        body.add(path, np.interp(np.linspace(0, 1, len(path)), [0, 0.5, 1], [0.002, 0.02, 0.002]), (0.96, 0.92, 0.72), 7)


def horror_wraith():
    h_animate("horror_wraith_body", horror_wraith_pose, 32)
    h_animate("horror_wraith_eyes", horror_wraith_eye_pose, 32)


def horror_eyes_pose(body, t):
    rng = np.random.default_rng(77)
    for pair in range(11):
        x, y, z = rng.uniform(-2.6, 2.6), rng.uniform(-1.1, 1.3), rng.uniform(-0.5, 0.5)
        size = rng.uniform(0.045, 0.1)
        gap = size * rng.uniform(1.9, 2.8)
        turn = rng.uniform(-0.28, 0.28)
        start, length = rng.uniform(0, 1), rng.uniform(0.05, 0.1)
        tone = (1.0, rng.uniform(0.1, 0.62), rng.uniform(0.02, 0.1))
        since = (t - start) % 1.0
        lid = min(1.0, abs(since - length / 2) / (length / 2)) if since < length else 1.0
        rot = rotation((0, 0, 1), turn)
        for s in (-1, 1):
            at = np.array([x, y, z]) + rot @ np.array([s * gap, 0, 0])
            path = h_chain([at + rot @ np.array([-size * 1.25, 0, 0]), at, at + rot @ np.array([size * 1.25, 0, 0])], 4)
            radii = np.interp(np.linspace(0, 1, len(path)), [0, 0.5, 1], [0.0005, size * 0.55, 0.0005])
            tube = h_tube(path, radii, 8, (0, 0, 1))
            rows = len(path)
            centre = np.repeat(path, 8, axis=0)
            flat = centre + (tube - centre) @ np.diag([1.0, 0.1 + 0.9 * lid, 0.2])
            body.pos.append(flat)
            colors = np.tile(np.array(tone), (rows, 8, 1))
            colors[rows // 2] = (0.02, 0.0, 0.0)
            body.col.append(rgba(colors.reshape(-1, 3), np.ones(rows * 8)))
            body.quads.append(grid(8, rows) + body.offset)
            body.offset += rows * 8


def horror_eyes():
    h_animate("horror_eyes", horror_eyes_pose, 40)


def horror_cocoon_pose(body, t):
    """Кокон на нитях: внутри кто-то ещё шевелится, наружу торчит рука."""
    ph = TAU * t
    swing = 0.07 * math.sin(ph)
    rot = rotation((0, 0, 1), swing) @ rotation((0, 1, 0), 0.5 * math.sin(ph) + 0.2)
    silk = np.array([0.34, 0.33, 0.3])
    pulse = 0.5 + 0.5 * math.sin(ph * 3)
    kick = max(0.0, math.sin(ph * 2 + 1.0)) ** 8

    def at(*p):
        return rot @ np.array(p, dtype=float)

    for k in range(6):
        a = TAU * k / 6
        top = at(0.5 * math.cos(a), 0.15, 0.5 * math.sin(a))
        low = at(0.1 * math.cos(a), -0.62, 0.1 * math.sin(a))
        body.add(h_chain([top, (top + low) / 2 + at(0, -0.04, 0), low], 3), h_taper(7, 0.022, 0.014, 0.012), silk, 4)
    rows, sides = 26, 12
    h = np.linspace(0, 1, rows)
    path = np.stack([rot @ np.array([0.05 * math.sin(v * 7 + ph), -0.55 - 2.2 * v, 0.03 * math.cos(v * 5)]) for v in h])
    shape = np.interp(h, [0, 0.1, 0.32, 0.62, 0.9, 1], [0.0, 0.2, 0.42, 0.36, 0.17, 0.0])
    shape = shape * (1 + 0.05 * pulse * np.sin(h * math.pi)) * (1 + 0.1 * np.sin(h * 37))
    colors = np.zeros((rows, sides, 3))
    grain = np.random.default_rng(9).uniform(0.7, 1.15, (rows, sides))
    for r in range(rows):
        for k in range(sides):
            band = 0.5 + 0.5 * math.sin(h[r] * 44 + k / sides * TAU * 2)
            colors[r, k] = (H_RAG + (silk - H_RAG) * band ** 3) * grain[r, k]
    body.add(path, shape, colors, sides)
    for k in range(9):
        y = -0.8 - 0.21 * k
        turn = k * 0.8
        ring = [at(0.47 * (1 - abs(k - 3.4) * 0.09) * math.cos(a + turn), y + 0.1 * math.sin(a), 0.47 * (1 - abs(k - 3.4) * 0.09) * math.sin(a + turn)) for a in np.linspace(0, TAU, 12)]
        body.add(np.array(ring), 0.022, silk * 0.8, 4)
    shoulder = at(0.3, -1.25, 0.24)
    elbow = at(0.52 + 0.04 * kick, -1.72, 0.3)
    wrist = at(0.48 + 0.1 * kick, -2.18 + 0.05 * pulse, 0.36)
    h_limb(body, [shoulder, elbow, wrist], 0.06, 0.036, H_SKIN * 0.55, 4, 6)
    for finger in range(5):
        spread = (finger - 2) * 0.04
        curl = 0.05 * math.sin(ph * 4 + finger) + 0.09 * kick
        knuckle = wrist + rot @ np.array([spread, -0.1, 0.03])
        mid = knuckle + rot @ np.array([spread * 0.6, -0.12, 0.05 + curl])
        tip = mid + rot @ np.array([spread * 0.3, -0.1, 0.02 + curl])
        h_limb(body, [wrist, knuckle, mid, tip], 0.016, 0.003, H_SKIN * 0.7, 2, 4)


def horror_cocoon():
    h_animate("horror_cocoon", horror_cocoon_pose, 48)
