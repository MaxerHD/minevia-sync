# Личное оружие, пять силуэтов по уровням. Только стандартная библиотека.
from pathlib import Path
from icons_weapons import Sprite, png, storm_bow
from icons_styles import sword, sun, RAMPS
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'elements-mod/src/main/resources/assets/minevia_elements/textures/item'

def gear(kind,level):
    s=Sprite()
    if kind=='style_sword':
        sword(s,0,0,1,'iron')
        for i in range(level-1):
            x,y=17+i*2,16-i*3
            s.line([(x-2,y),(x+1,y-3)],'water',2)
        if level>=3:s.poly([(8,18),(8,13),(13,18),(16,24),(21,24),(18,28)],'gold')
        if level==5:s.oval((11,18,15,22),'water')
    elif kind=='style_bow':
        storm_bow(s)
        for i in range(level-1):
            y=7+i*5
            s.poly([(19,y),(25,y-2),(22,y+2)],'leaf')
        if level==5:s.line([(5,15),(28,15)],'gold',2)
    else:
        material='night' if kind=='dark_gloves' else 'bone'
        accent='violet' if kind=='dark_gloves' else 'gold'
        s.poly([(8,29),(6,18),(3,13),(4,9),(7,10),(10,17),(10,5),(13,3),(15,15),(16,2),(19,2),(20,15),(23,4),(26,6),(25,18),(28,11),(30,13),(27,24),(23,29)],material,True)
        s.line([(9,27),(23,27)],accent,2)
        for i in range(level):s.line([(11+i*3,23),(12+i*3,19)],accent,1)
        if level>=3:s.oval((12,14,22,23),accent)
        if level==5:sun(s,17,18,4,accent)
    return s.pix

def main():
    kinds=['style_sword','style_bow','dark_gloves','light_gloves']
    sheet=[[(27,34,45,255)]*400 for _ in range(320)]
    for row,kind in enumerate(kinds):
        for level in range(1,6):
            pixels=gear(kind,level)
            png(OUT/(kind+'_'+str(level)+'.png'),pixels)
            for y in range(64):
                for x in range(64):
                    pixel=pixels[y//2][x//2]
                    if pixel[3]:sheet[row*80+8+y][(level-1)*80+8+x]=pixel
    png(ROOT/'verification/gear-icons.png',sheet)
    print('20 gear icons, 32x32 RGBA')
if __name__=='__main__':main()
