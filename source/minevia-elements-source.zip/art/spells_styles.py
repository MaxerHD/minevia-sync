# Твёрдые тела и отдельные светящиеся кромки. Подключается из spells.py.
# Все поверхности замкнуты, порядок граней направлен наружу.

STYLE_STEEL = (0.56, 0.63, 0.72)
STYLE_EDGE = (0.10, 0.62, 0.96)
STYLE_GOLD = (0.93, 0.72, 0.30)
STYLE_LIGHT = (1.0, 0.80, 0.30)
STYLE_DARK = (0.14, 0.08, 0.21)
STYLE_VIOLET = (0.56, 0.12, 0.94)
STYLE_WOOD = (0.32, 0.44, 0.27)
STYLE_GREEN = (0.12, 0.76, 0.42)


def sty_color(pos, color, seed=0):
    grain = 0.88 + 0.08 * np.sin(pos[:, 0] * 47 + pos[:, 2] * 31 + seed)
    light = np.clip(0.82 + pos[:, 1] * 0.045, 0.65, 1.12)
    return rgba(np.clip(np.array(color)[None, :] * (grain * light)[:, None], 0, 1), np.ones(len(pos)))


def sty_tube(points, radius, color, sides=8):
    points = np.asarray(points, dtype=float)
    radius = np.broadcast_to(np.asarray(radius), (len(points),))
    pos = []
    for i, at in enumerate(points):
        direction = points[min(i + 1, len(points) - 1)] - points[max(i - 1, 0)]
        direction /= max(1e-9, np.linalg.norm(direction))
        other = np.array([0., 1., 0.]) if abs(direction[1]) < 0.9 else np.array([1., 0., 0.])
        u = np.cross(other, direction)
        u /= np.linalg.norm(u)
        v = np.cross(direction, u)
        for j in range(sides):
            a = j * TAU / sides
            pos.append(at + radius[i] * (u * math.cos(a) + v * math.sin(a)))
    pos = np.asarray(pos)
    quads = list(grid(sides, len(points)))
    # Плоские торцы замыкают трубку.
    for end, reverse in ((0, True), (len(points) - 1, False)):
        center = len(pos)
        pos = np.vstack([pos, points[end]])
        for j in range(sides):
            a, b = end * sides + j, end * sides + (j + 1) % sides
            quads.append((center, b, a, a) if reverse else (center, a, b, b))
    return pos, np.asarray(quads, dtype=np.int32), sty_color(pos, color)


def sty_ring(center, radius, thickness, color, t=0, axis=1, count=64, arc=TAU):
    a = np.linspace(t, t + arc, count)
    center = np.asarray(center)
    coords = np.stack([np.cos(a) * radius, np.sin(a) * radius, np.zeros(count)], axis=1)
    if axis == 1:
        coords = coords[:, [0, 2, 1]]
    elif axis == 0:
        coords = coords[:, [2, 0, 1]]
    return sty_tube(coords + center, thickness, color, 6)


def sty_place(part, at=(0, 0, 0), scale=1, turn=None):
    p, q, c = part
    p = p * np.asarray(scale)
    if turn is not None:
        p = p @ turn.T
    return p + np.array(at), q, c


def sty_gem(at, size, color, t=0):
    p, q = cube_sphere(2)
    p *= np.array(size)
    p *= (1 + 0.08 * np.sin(p[:, 0] * 7 + p[:, 2] * 5 + t * TAU))[:, None]
    p += np.array(at)
    return p, q, sty_color(p, color)


def sty_blade(at=(0, 0, 0), scale=1, turn=None, dark=False, gold=False, serrated=False):
    body, glow = [], []
    metal = STYLE_DARK if dark else STYLE_GOLD if gold else STYLE_STEEL
    edge = STYLE_VIOLET if dark else STYLE_LIGHT if gold else STYLE_EDGE
    # Ромбическое сечение: острые грани и выраженный дол.
    z = np.linspace(-0.5, 1.7, 18)
    width = np.where(z < 0, 0.09, 0.19 * (1 - np.clip(z / 1.7, 0, 1)) ** 0.45 + 0.008)
    if serrated:
        width += 0.045 * np.maximum(0, np.sin(z * 38)) * (z > 0)
    shaft = sty_tube(np.stack([z * 0, z * 0, z], axis=1), width, metal, 4)
    p, q, c = shaft
    p[:, 1] *= 0.32
    body.append((p, q, c))
    body.append(sty_tube([(-0.42, 0, -0.1), (-0.2, 0.035, 0.02), (0.2, 0.035, 0.02), (0.42, 0, -0.1)], [0.035, 0.065, 0.065, 0.035], STYLE_GOLD))
    body.append(sty_tube([(0, 0, -0.62), (0, 0, -0.18)], 0.075, (0.065, 0.055, 0.075)))
    for j in range(5):
        body.append(sty_ring((0, 0, -0.58 + j * 0.075), 0.076, 0.014, STYLE_GOLD, axis=2, count=12))
    for side in (-1, 1):
        glow.append(sty_tube([(side * (float(w) + 0.006), 0, float(zz)) for zz, w in zip(z[4:], width[4:])], 0.013, edge, 4))
    glow.append(sty_gem((0, 0, -0.06), (0.07, 0.075, 0.09), edge))
    return ([sty_place(p, at, scale, turn) for p in body], [sty_place(p, at, scale, turn) for p in glow])


def sty_arrow(at=(0, 0, 0), scale=1, turn=None, variant=0):
    body, glow = [], []
    length = 1.9 + variant * 0.06
    body.append(sty_tube([(0, 0, -0.8), (0, 0, length)], [0.035, 0.025], STYLE_WOOD))
    body.append(sty_tube([(0, 0, length - 0.5), (0, 0, length - 0.3), (0, 0, length + 0.18)], [0.04, 0.19, 0.001], STYLE_STEEL, 4))
    for j in range(4):
        a = j * math.pi / 2 + variant * 0.12
        x, y = math.cos(a), math.sin(a)
        body.append(sty_tube([(x * 0.02, y * 0.02, -0.75), (x * 0.22, y * 0.22, -0.6), (x * 0.07, y * 0.07, -0.25)], [0.02, 0.035, 0.02], STYLE_GOLD, 4))
        glow.append(sty_tube([(x * 0.01, y * 0.01, length - 0.45), (x * 0.19, y * 0.19, length - 0.3), (x * 0.001, y * 0.001, length + 0.18)], 0.014, STYLE_GREEN, 4))
    for j in range(4 + variant % 3):
        z = j * 0.27
        body.append(sty_ring((0, 0, z), 0.055, 0.013, STYLE_GOLD, axis=2, count=12))
        glow.append(sty_gem((0, 0.05, z), (0.018, 0.018, 0.055), STYLE_GREEN))
    return ([sty_place(p, at, scale, turn) for p in body], [sty_place(p, at, scale, turn) for p in glow])


def sty_runes(body, glow, radius, y, count, t, dark=False):
    color = STYLE_VIOLET if dark else STYLE_LIGHT
    metal = STYLE_DARK if dark else STYLE_GOLD
    body.append(sty_ring((0, y, 0), radius, 0.045, metal, count=72))
    glow.append(sty_ring((0, y + 0.018, 0), radius - 0.08, 0.018, color, t * TAU, count=72))
    for j in range(count):
        a = j * TAU / count + t * TAU
        out = np.array([math.cos(a), 0, math.sin(a)])
        across = np.array([-out[2], 0, out[0]])
        base = out * radius + np.array([0, y, 0])
        points = [base - across * 0.1 - out * 0.16, base + across * 0.1, base - across * 0.04 + out * 0.18]
        glow.append(sty_tube(points, 0.027, color, 4))
        body.append(sty_gem(base, (0.06, 0.10, 0.06), metal))


def sty_sword(index, t):
    body, glow = [], []
    def blade(at=(0, 0, 0), scale=1, angle=0, axis=(0, 1, 0), **kw):
        b, g = sty_blade(at, scale, rotation(axis, angle), **kw)
        body.extend(b); glow.extend(g)
    if index == 0:
        # Замкнутый объём полумесяца, обе кромки читаются сбоку.
        a = np.linspace(-1.4, 1.4, 70)
        points = np.stack([np.sin(a) * 1.3, np.cos(a) * 1.3 - 0.6, a * 0], axis=1)
        radii = 0.035 + 0.16 * np.sin(np.linspace(0, math.pi, len(a)))
        b = sty_tube(points, radii, STYLE_STEEL)
        p, q, c = b; p[:, 2] *= 0.32; body.append((p, q, c))
        glow.append(sty_tube(points + np.array([0, 0.05, 0.02]), radii * 0.22, STYLE_EDGE))
        for j in range(9):
            glow.append(sty_gem((math.sin(j * 0.35 - 1.4) * 1.2, math.cos(j * 0.35 - 1.4) * 1.2 - 0.6, -0.15 - (j % 3) * 0.08), (0.025, 0.07, 0.14), STYLE_EDGE))
    elif index in (1, 6, 7, 9):
        count = {1: 7, 6: 12, 7: 30, 9: 5}[index]
        radius = {1: 1.8, 6: 0.95, 7: 0.7, 9: 0.8}[index]
        for j in range(count):
            a = j * TAU / count + t * TAU * (2 if index == 1 else 1)
            height = 0.8 + (j % 3) * 0.25 if index != 7 else 0.4 + (j % 5) * 0.5
            blade((math.cos(a) * radius, height, math.sin(a) * radius), 0.7 if index == 1 else 0.38 if index == 7 else 0.6,
                  a + (math.pi if index == 7 else math.pi / 2))
        sty_runes(body, glow, radius * 0.8, 0.08, 12, t)
    elif index == 2:
        for side in (-1, 1):
            b, g = sty_blade((side * 0.28, 1.1, 0.6),0.9,rotation((0,0,1),side*0.65) @ rotation((1,0,0),-math.pi/2))
            body.extend(b); glow.extend(g)
        for r in (0.6, 0.8):
            body.append(sty_ring((0, 1.1, 0.65), r, 0.045, STYLE_STEEL, axis=2))
        glow.append(sty_ring((0, 1.1, 0.67), 0.7, 0.025, STYLE_EDGE, t * TAU, axis=2, arc=5.2))
    elif index == 3:
        blade((0, 1, 0.4), 1.3)
        for j in range(6):
            x = (j % 2 * 2 - 1) * (0.4 + j * 0.07)
            glow.append(sty_tube([(x, 1, -2.2 + t * 0.4), (x * 0.3, 1, 0.5)], [0.01, 0.055], STYLE_EDGE, 4))
    elif index in (4, 11):
        blade(scale=2.3 if index == 4 else 1.8, serrated=index == 11)
        for j in range(4):
            a = j * TAU / 4
            body.append(sty_tube([(0, 0, -0.02), (math.cos(a) * 0.44, math.sin(a) * 0.44, 0.2), (0, 0, 0.7)], [0.025, 0.05, 0.01], STYLE_GOLD))
    elif index == 5:
        for j in range(3):
            blade((0, 1, 0), 0.7, j * math.pi / 3 + t * 0.3, (0, 0, 1))
    elif index == 8:
        for side in (-1, 1):
            b, g = sty_blade((side*0.4,1,0),1.1,rotation((0,0,1),side*(0.9+math.sin(t*TAU)*0.25)) @ rotation((1,0,0),-math.pi/2))
            body.extend(b); glow.extend(g)
    elif index == 10:
        for j in range(4):
            blade((math.cos(j * math.pi / 2) * 0.7, 0.5, math.sin(j * math.pi / 2) * 0.7), 0.8, j * math.pi / 2 + t * TAU, serrated=True)
        sty_runes(body, glow, 1, 0.07, 8, t)
    return body, glow


def sty_bow(index, t):
    body, glow = [], []
    def arrow(at=(0, 0, 0), scale=1, turn=None):
        b, g = sty_arrow(at, scale, turn, index)
        body.extend(b); glow.extend(g)
    if index in (0, 1, 4, 6, 7, 8, 10):
        arrow(scale=1.4 if index == 8 else 1)
        if index == 4:
            for side in (-1, 1):
                body.append(sty_tube([(side * 0.05, 0, 1.6), (side * 0.35, 0, 1.3), (side * 0.18, 0, 1.1)], 0.04, STYLE_STEEL))
        if index == 6:
            body.append(sty_gem((0, 0, 0.7), (0.22, 0.22, 0.45), STYLE_STEEL))
            for j in range(3):
                glow.append(sty_ring((0, 0, 0.4 + j * 0.26), 0.23, 0.035, (0.82, 0.23, 0.025), t * TAU, axis=2))
        if index == 7:
            for j in range(4):
                body.append(sty_ring((0, 0, j * 0.3), 0.23 + j * 0.06, 0.04, STYLE_GOLD, axis=2))
                glow.append(sty_ring((0, 0, j * 0.3 + 0.03), 0.25 + j * 0.06, 0.018, STYLE_GREEN, t * TAU, axis=2))
        if index == 10:
            for side in (-1, 1):
                for j in range(4):
                    body.append(sty_tube([(side * 0.08, 0, 0.5), (side * (0.42 + j * 0.08), 0.07, -j * 0.22)], [0.055, 0.01], STYLE_STEEL, 4))
    elif index in (2, 5):
        sty_runes(body, glow, 0.7, 0.08, 8 if index == 5 else 6, t)
        for side in (-1, 1):
            for j in range(7):
                x = -0.65 + j * 0.21
                z = side * math.sqrt(max(0, 0.7 ** 2 - x ** 2))
                body.append(sty_tube([(x, 0.1, z), (x, 0.35 + 0.12 * math.sin(t * TAU), z * 0.8)], [0.07, 0.001], STYLE_STEEL, 4))
        if index == 2:
            body.append(sty_gem((0, 0.15, 0), (0.32, 0.16, 0.32), STYLE_WOOD))
            glow.append(sty_gem((0, 0.3, 0), (0.08, 0.1, 0.08), STYLE_GREEN))
    elif index == 3:
        for j in range(7):
            a = j * TAU / 7
            arrow((math.cos(a) * 0.7, 0, math.sin(a) * 0.7), 0.45, rotation((1, 0, 0), math.pi / 2))
        sty_runes(body, glow, 0.9, 0, 9, t)
    elif index == 9:
        for r, axis in ((0.65, 2), (0.8, 0), (0.95, 1)):
            body.append(sty_ring((0, 1.2, 0), r, 0.026, STYLE_WOOD, axis=axis))
            glow.append(sty_ring((0, 1.2, 0), r * 0.9, 0.015, STYLE_GREEN, t * TAU, axis=axis, arc=4.8))
        arrow((0, 1.2, 0), 0.5)
    elif index == 11:
        sty_runes(body, glow, 0.9, 0.06, 8, t)
        for j in range(7):
            a = j * TAU / 7
            tip = (math.cos(a) * 0.8, 1.2 + 0.3 * math.sin(j), math.sin(a) * 0.8)
            body.append(sty_tube([(math.cos(a) * 0.4, 0, math.sin(a) * 0.4), tip], [0.12, 0.001], STYLE_WOOD, 5))
            glow.append(sty_gem(np.array(tip) * 0.85, (0.045, 0.18, 0.045), STYLE_GREEN))
    return body, glow


def sty_dark(index, t):
    body, glow = [], []
    if index == 0:
        p, q, c = crag(1701, cuts=10, planes=12, scale=(0.7, 0.65, 0.7), shards=22, groove=0.12)
        body.append((p * (1 + 0.025 * math.sin(t * TAU)), q, sty_color(p, STYLE_DARK)))
        for j in range(3):
            glow.append(sty_ring((0, 0, 0), 0.78 + j * 0.08, 0.025, STYLE_VIOLET, t * TAU + j, axis=j, arc=5.2))
    elif index == 1:
        s = np.linspace(0, 1, 55)
        for j in range(3):
            a = s * TAU * 3 + j * TAU / 3 - t * TAU
            points = np.stack([np.cos(a) * 0.10 * np.sin(s * math.pi), np.sin(a) * 0.10 * np.sin(s * math.pi), s], axis=1)
            body.append(sty_tube(points, 0.045, STYLE_DARK))
            glow.append(sty_tube(points + np.array([0.015, 0, 0]), 0.012, STYLE_VIOLET, 4))
    elif index == 2:
        sty_runes(body, glow, 0.8, 0.25, 7, t, True)
        for j in range(4):
            a = j * TAU / 4 + t * TAU
            body.append(sty_tube([(math.cos(a) * 0.7, 0.2, math.sin(a) * 0.7), (math.cos(a) * 0.8, 1.6, math.sin(a) * 0.8)], [0.05, 0.001], STYLE_DARK, 5))
            glow.append(sty_gem((math.cos(a) * 0.8, 1.3, math.sin(a) * 0.8), (0.045, 0.14, 0.045), STYLE_VIOLET))
    elif index == 3:
        # Ладони и суставчатые пальцы из обсидиановой тени.
        for j in range(4):
            a = j * TAU / 4
            base = np.array([math.cos(a) * 0.7, 0, math.sin(a) * 0.7])
            body.append(sty_tube([base + (0, -0.1, 0), base + (0, 0.65, 0), base + (0, 0.9, 0)], [0.14, 0.17, 0.22], STYLE_DARK))
            for finger in range(5):
                x = (finger - 2) * 0.095
                height = 1.2 + 0.18 * math.sin(finger * 0.8)
                points = [base + (x, 0.8, 0), base + (x * 1.7, height, 0.08), base + (x * 1.2, height + 0.2, 0.22 + 0.06 * math.sin(t * TAU))]
                body.append(sty_tube(points, [0.055, 0.045, 0.008], STYLE_DARK, 6))
                glow.append(sty_tube(points[1:], 0.012, STYLE_VIOLET, 4))
        sty_runes(body, glow, 1, 0.04, 12, t, True)
    elif index in (4, 7):
        p, q = cube_sphere(8)
        body.append((p * (0.52 if index == 4 else 0.8) + (0, 0.5 if index == 4 else 1.8, 0), q, sty_color(p, (0.008, 0.003, 0.018))))
        for j in range(6 if index == 4 else 9):
            r = 0.7 + j * 0.12
            y = 0.5 + 0.025 * math.sin(j + t * TAU) if index == 4 else 1.8 + math.sin(j) * 0.2
            glow.append(sty_ring((0, y, 0), r, 0.02 + j * 0.001, STYLE_VIOLET, t * TAU * (1 if j % 2 else -1) + j, axis=1 if index == 4 else 2, arc=5.6))
        sty_runes(body, glow, 1.15, 0.04, 16, t, True)
    elif index == 5:
        for side in (-1, 1):
            body.append(sty_gem((side * 0.35, 1.2, 0), (0.44, 0.12, 0.1), STYLE_DARK))
            glow.append(sty_gem((side * 0.35, 1.22, 0.09), (0.24, 0.035, 0.025), STYLE_VIOLET))
            body.append(sty_tube([(side * 0.8, 0.6, 0), (side * 0.9, 1.5, 0), (side * 0.5, 2.1, 0)], [0.06, 0.10, 0.001], STYLE_DARK))
        sty_runes(body, glow, 1.1, 0.1, 11, t, True)
    elif index == 6:
        b, g = sty_blade(scale=1.1, dark=True)
        body.extend(b); glow.extend(g)
        for side in (-1, 1):
            glow.append(sty_tube([(side * 0.4, 0, -0.8), (side * 0.15, 0, 1.2)], [0.006, 0.028], STYLE_VIOLET))
    elif index == 8:
        body.append(sty_tube([(0, 0.1, 0), (0, 0.9, 0), (0, 1.7, 0), (0, 2.1, 0)], [0.55, 0.34, 0.4, 0.02], STYLE_DARK, 12))
        for j in range(9):
            a = j * TAU / 9
            body.append(sty_tube([(math.cos(a) * 0.5, 0, math.sin(a) * 0.5), (math.cos(a) * 0.35, 1, math.sin(a) * 0.35), (math.cos(a) * 0.6, 1.6, math.sin(a) * 0.6)], [0.10, 0.04, 0.001], STYLE_DARK))
        glow.append(sty_gem((-0.14, 1.65, 0.24), (0.08, 0.035, 0.03), STYLE_VIOLET))
        glow.append(sty_gem((0.14, 1.65, 0.24), (0.08, 0.035, 0.03), STYLE_VIOLET))
    elif index == 9:
        for j in range(6):
            a = j * TAU / 6 + t * TAU
            body.append(sty_gem((math.cos(a) * 0.9, 1, math.sin(a) * 0.9), (0.2, 0.44, 0.08), STYLE_DARK))
            glow.append(sty_gem((math.cos(a) * 0.91, 1.1, math.sin(a) * 0.91), (0.06, 0.22, 0.06), STYLE_VIOLET))
        sty_runes(body, glow, 0.95, 0.08, 10, t, True)
    elif index == 10:
        sty_runes(body, glow, 1, 0.04, 13, t, True)
        for j in range(9):
            a = j * TAU / 9
            p = (math.cos(a) * 0.7, 0.2 + 0.2 * math.sin(t * TAU + j), math.sin(a) * 0.7)
            body.append(sty_gem(p, (0.15, 0.18, 0.15), STYLE_DARK))
            glow.append(sty_ring(p, 0.2, 0.018, (0.14, 0.42, 0.035), t * TAU, axis=j % 3))
    elif index == 11:
        sty_runes(body, glow, 0.95, 0.1, 12, t, True)
        for j in range(3):
            a = j * TAU / 3 + t * TAU
            body.append(sty_tube([(math.cos(a) * 0.9, 0.1, math.sin(a) * 0.9), (0, 1.8, 0)], [0.08, 0.02], STYLE_DARK))
        glow.append(sty_gem((0, 1.3, 0), (0.18, 0.3, 0.18), STYLE_VIOLET))
    return body, glow



def sty_plate(outline, thickness, color):
    points=np.asarray(outline,dtype=float)
    area=sum(a[0]*b[1]-b[0]*a[1] for a,b in zip(points,np.roll(points,-1,axis=0)))
    if area<0:points=points[::-1]
    n=len(points)
    p=np.vstack([np.column_stack([points,np.full(n,-thickness)]),np.column_stack([points,np.full(n,thickness)]),[0,0,-thickness],[0,0,thickness]])
    q=[]
    for i in range(n):
        j=(i+1)%n
        q.extend([(i,j,j+n,i+n),(2*n,j,i,i),(2*n+1,i+n,j+n,j+n)])
    return p,np.asarray(q,dtype=np.int32),sty_color(p,color)


def sty_light(index, t):
    body, glow = [], []
    if index == 0:
        # Единичный луч вдоль +Z, длину задаёт сервер.
        s = np.linspace(0, 1, 32)
        for j in range(4):
            a = s * TAU * 2 + j * TAU / 4 + t * TAU
            points = np.stack([np.cos(a) * 0.045, np.sin(a) * 0.045, s], axis=1)
            body.append(sty_tube(points, 0.012, STYLE_GOLD, 4))
            glow.append(sty_tube(points, 0.006, STYLE_LIGHT, 4))
    elif index in (1, 3, 10, 11):
        sty_runes(body, glow, 0.95, 0.06, 8 + index % 4, t)
        for j in range(3):
            a = np.linspace(0, TAU * 1.7, 70) + j * TAU / 3 + t * TAU
            y = np.linspace(0.1, 2, len(a))
            points = np.stack([np.cos(a) * (0.75 - y * 0.13), y, np.sin(a) * (0.75 - y * 0.13)], axis=1)
            glow.append(sty_tube(points, 0.025 if index == 1 else 0.018, STYLE_LIGHT, 5))
        if index == 10:
            for j in range(8):
                a = j * TAU / 8
                body.append(sty_tube([(math.cos(a), 0, math.sin(a)), (math.cos(a), 0.65, math.sin(a))], [0.08, 0.03], STYLE_GOLD))
    elif index in (2, 9):
        for j in range(6):
            a = j * TAU / 6 + (t * TAU if index == 9 else 0)
            at = (math.cos(a) * 0.85, 1, math.sin(a) * 0.85)
            body.append(sty_place(sty_plate([(-0.26,0.35),(0,0.5),(0.26,0.35),(0.2,-0.15),(0,-0.55),(-0.2,-0.15)],0.06,(0.52,0.43,0.27)),at,turn=rotation((0,1,0),math.pi/2-a)))
            glow.append(sty_tube([np.array(at) + (0, -0.32, 0.1), np.array(at) + (0, 0.32, 0.1)], 0.025, STYLE_LIGHT))
        sty_runes(body, glow, 0.95, 0.07, 12, t)
    elif index in (4, 7):
        count = 6 if index == 4 else 12
        for j in range(count):
            a = j * TAU / count
            radius = 0.55 if index == 4 else 0.85
            x, z = math.cos(a) * radius, math.sin(a) * radius
            points = [(x, 0, z), (x, 1.5, z), (x * 0.5, 3.5, z * 0.5), (0, 4.5, 0)]
            body.append(sty_tube(points, [0.05, 0.035, 0.02, 0.001], STYLE_GOLD, 6))
            glow.append(sty_tube(np.asarray(points) * (1.025, 1, 1.025), 0.016, STYLE_LIGHT, 4))
        for y in (0.1, 1.2, 3.2):
            sty_runes(body, glow, 0.8 if index == 4 else 1, y, 10, t if index == 7 else -t)
        if index == 7:
            b, g = sty_blade((0, 2.5, 0), 1.4, rotation((1, 0, 0), math.pi / 2), gold=True)
            body.extend(b); glow.extend(g)
    elif index == 5:
        for side in (-1, 1):
            for j in range(11):
                x = side * (0.45 + j * 0.12)
                y = 1.4 + 0.3 * math.sin(t * TAU) + j * 0.055
                z = -0.25 - j * 0.08
                end = (side * (1.8 + j * 0.015), y + 0.8 - j * 0.11, z - 0.6)
                points = [(x * 0.4, 1.4, -0.1), (x, y, z), end]
                body.append(sty_tube(points, [0.03, 0.11, 0.001], (0.58, 0.45, 0.25), 4))
                glow.append(sty_tube(points, [0.01, 0.022, 0.001], STYLE_LIGHT, 4))
    elif index == 6:
        body.append(sty_gem((0, 0, 0), (0.18, 0.3, 0.18), STYLE_GOLD))
        for j in range(3):
            glow.append(sty_ring((0, 0, 0), 0.32, 0.025, STYLE_LIGHT, t * TAU, axis=j))
        for j in range(6):
            a = j * TAU / 6 + t * TAU
            glow.append(sty_tube([(math.cos(a) * 0.4, 0, math.sin(a) * 0.4), (math.cos(a) * 0.65, 0, math.sin(a) * 0.65)], [0.025, 0.001], STYLE_LIGHT, 4))
    elif index == 8:
        body.append(sty_tube([(0, 0, -0.8), (0, 0, 1.1)], 0.07, STYLE_GOLD))
        body.append(sty_gem((0, 0, 1), (0.55, 0.30, 0.28), (0.48, 0.38, 0.21)))
        for x in (-0.4, 0, 0.4):
            glow.append(sty_ring((x, 0, 1), 0.31, 0.02, STYLE_LIGHT, t * TAU, axis=0, count=24))
        for j in range(5):
            body.append(sty_ring((0, 0, -0.7 + j * 0.25), 0.075, 0.018, (0.2, 0.12, 0.035), axis=2, count=12))
    if index == 3:
        # Очищение расходится низким венцом, без спирали лечения.
        body, glow = [], []
        sty_runes(body, glow, 0.85 + 0.12 * math.sin(t * TAU), 0.06, 12, -t)
        for j in range(8):
            a = j * TAU / 8
            out = np.array([math.cos(a), 0, math.sin(a)])
            body.append(sty_tube([out * 0.3 + (0,0.15,0),out * 0.8 + (0,0.4,0),out * 1.3 + (0,0.1,0)],[0.02,0.09,0.001],STYLE_GOLD,4))
            glow.append(sty_tube([out * 0.4 + (0,0.16,0),out * 1.2 + (0,0.18,0)],[0.025,0.001],STYLE_LIGHT,4))
    if index == 10:
        # Каменные арки святилища образуют защитный навес.
        for j in range(6):
            a=j*TAU/6
            points=[(math.cos(a)*0.9,0.15,math.sin(a)*0.9),(math.cos(a)*0.9,1.1,math.sin(a)*0.9),(math.cos(a)*0.5,1.7,math.sin(a)*0.5),(0,1.85,0)]
            body.append(sty_tube(points,[0.055,0.055,0.045,0.025],STYLE_GOLD,6))
            glow.append(sty_tube(np.array(points)+(0,0.02,0),0.015,STYLE_LIGHT,4))
    if index == 11:
        # Над благословением парят четыре креста, у каждого металлическая оправа.
        for j in range(4):
            a=j*TAU/4+t*TAU
            at=np.array([math.cos(a)*0.6,1.8,math.sin(a)*0.6])
            body.append(sty_tube([at+(0,-0.3,0),at+(0,0.3,0)],0.045,STYLE_GOLD,4))
            body.append(sty_tube([at+(-0.2,0.08,0),at+(0.2,0.08,0)],0.045,STYLE_GOLD,4))
            glow.append(sty_tube([at+(0,-0.25,0.05),at+(0,0.25,0.05)],0.015,STYLE_LIGHT,4))
            glow.append(sty_tube([at+(-0.16,0.08,0.05),at+(0.16,0.08,0.05)],0.015,STYLE_LIGHT,4))
    return body, glow


def sty_export(name, builder, index):
    body_frames, glow_frames = [], []
    body_quads = glow_quads = None
    for frame in range(16):
        body, glow = builder(index, frame / 16)
        p, q, c = merged(body)
        g, h, d = merged(glow)
        # Небольшое движение металла и пульс кромки даже у летящего оружия.
        phase = frame / 16 * TAU
        p = p * (1 + 0.006 * math.sin(phase))
        g = g * (1 + 0.006 * math.sin(phase))
        d[:, :3] *= 0.9 + 0.1 * np.sin(phase + g[:, 2] * 2)[:, None]
        if body_quads is not None:
            assert np.array_equal(q, body_quads) and np.array_equal(h, glow_quads), name
        body_quads, glow_quads = q, h
        assert len(p) < 65536 and len(g) < 65536, name
        assert np.all(c[:, 3] == 1) and np.all(d[:, 3] == 1), name
        body_frames.append((p, c)); glow_frames.append((g, d))
    save(name + '_body', body_frames, body_quads)
    save(name + '_glow', glow_frames, glow_quads)


def sword_cleave():
    sty_export("sword_cleave", sty_sword, 0)

def sword_vortex():
    sty_export("sword_vortex", sty_sword, 1)

def sword_parry():
    sty_export("sword_parry", sty_sword, 2)

def sword_lunge():
    sty_export("sword_lunge", sty_sword, 3)

def sword_fallblade():
    sty_export("sword_fallblade", sty_sword, 4)

def sword_notch():
    sty_export("sword_notch", sty_sword, 5)

def sword_ring():
    sty_export("sword_ring", sty_sword, 6)

def sword_thousand():
    sty_export("sword_thousand", sty_sword, 7)

def sword_riposte():
    sty_export("sword_riposte", sty_sword, 8)

def sword_flow():
    sty_export("sword_flow", sty_sword, 9)

def sword_rage():
    sty_export("sword_rage", sty_sword, 10)

def sword_execution():
    sty_export("sword_execution", sty_sword, 11)

def bow_aimed():
    sty_export("bow_aimed", sty_bow, 0)

def bow_fan():
    sty_export("bow_fan", sty_bow, 1)

def bow_retreat():
    sty_export("bow_retreat", sty_bow, 2)

def bow_rain():
    sty_export("bow_rain", sty_bow, 3)

def bow_harpoon():
    sty_export("bow_harpoon", sty_bow, 4)

def bow_trap():
    sty_export("bow_trap", sty_bow, 5)

def bow_explosive():
    sty_export("bow_explosive", sty_bow, 6)

def bow_celestial():
    sty_export("bow_celestial", sty_bow, 7)

def bow_piercing():
    sty_export("bow_piercing", sty_bow, 8)

def bow_focus():
    sty_export("bow_focus", sty_bow, 9)

def bow_seekers():
    sty_export("bow_seekers", sty_bow, 10)

def bow_thicket():
    sty_export("bow_thicket", sty_bow, 11)

def dark_sphere():
    sty_export("dark_sphere", sty_dark, 0)

def dark_drain():
    sty_export("dark_drain", sty_dark, 1)

def dark_curse():
    sty_export("dark_curse", sty_dark, 2)

def dark_hands():
    sty_export("dark_hands", sty_dark, 3)

def dark_hole():
    sty_export("dark_hole", sty_dark, 4)

def dark_nightmare():
    sty_export("dark_nightmare", sty_dark, 5)

def dark_ghosts():
    sty_export("dark_ghosts", sty_dark, 6)

def dark_eclipse():
    sty_export("dark_eclipse", sty_dark, 7)

def dark_wraith():
    sty_export("dark_wraith", sty_dark, 8)

def dark_soulguard():
    sty_export("dark_soulguard", sty_dark, 9)

def dark_plague():
    sty_export("dark_plague", sty_dark, 10)

def dark_pact():
    sty_export("dark_pact", sty_dark, 11)

def light_ray():
    sty_export("light_ray", sty_light, 0)

def light_heal():
    sty_export("light_heal", sty_light, 1)

def light_faith():
    sty_export("light_faith", sty_light, 2)

def light_cleanse():
    sty_export("light_cleanse", sty_light, 3)

def light_column():
    sty_export("light_column", sty_light, 4)

def light_wings():
    sty_export("light_wings", sty_light, 5)

def light_spark():
    sty_export("light_spark", sty_light, 6)

def light_judgment():
    sty_export("light_judgment", sty_light, 7)

def light_hammer():
    sty_export("light_hammer", sty_light, 8)

def light_armor():
    sty_export("light_armor", sty_light, 9)

def light_sanctuary():
    sty_export("light_sanctuary", sty_light, 10)

def light_blessing():
    sty_export("light_blessing", sty_light, 11)
