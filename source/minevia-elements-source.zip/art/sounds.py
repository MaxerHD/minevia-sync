# Синтез всех звуков мода. Записей нет: шум и тона складываются формулами, поэтому и прав чужих тут нет.
# Запуск: python sounds.py [имена]. Пишет .ogg в ресурсы мода и sounds.json рядом.
import json
import os
import subprocess
import sys
import tempfile
import wave

import numpy as np

SR = 44100
OUT = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements"
rng = np.random.default_rng(2026)


def times(dur):
    return np.arange(int(dur * SR)) / SR


def shaped(dur, center, width=0.6, gain=None, frame=1024):
    """Шум с меняющимся спектром: center(t) задаёт частоту в герцах, width ширину полосы в октавах."""
    n = int(dur * SR)
    hop = frame // 4
    window = np.hanning(frame)
    freqs = np.fft.rfftfreq(frame, 1 / SR)
    logf = np.log2(np.maximum(freqs, 20))
    out = np.zeros(n + frame)
    norm = np.zeros(n + frame)
    for start in range(0, n, hop):
        u = min(1.0, start / max(1, n))
        c = center(u) if callable(center) else center
        w = width(u) if callable(width) else width
        spectrum = np.fft.rfft(rng.normal(size=frame) * window)
        spectrum *= np.exp(-0.5 * ((logf - np.log2(c)) / w) ** 2)
        out[start:start + frame] += np.fft.irfft(spectrum) * window
        norm[start:start + frame] += window ** 2
    out = out[:n] / np.maximum(norm[:n], 1e-3)
    out /= max(1e-9, np.abs(out).max())
    return out * (gain(times(dur) / dur) if gain else 1)


def env(dur, attack=0.01, release=0.2, curve=2.0):
    t = times(dur)
    rise = np.clip(t / max(attack, 1e-4), 0, 1)
    fall = np.clip((dur - t) / max(dur * release, 1e-4), 0, 1) ** curve
    return rise * fall


def decay(dur, rate):
    return np.exp(-times(dur) * rate)


def sweep(dur, f0, f1, shape=1.0):
    """Синус, плавно идущий от f0 к f1."""
    u = np.linspace(0, 1, int(dur * SR)) ** shape
    freq = f0 * (f1 / f0) ** u
    return np.sin(np.cumsum(freq) * 2 * np.pi / SR)


def thump(dur, f0=120, f1=38, rate=9):
    return sweep(dur, f0, f1, 0.5) * decay(dur, rate)


def lay(total, *parts):
    """Складывает части на общей дорожке: (сдвиг в секундах, звук)."""
    out = np.zeros(int(total * SR))
    for at, sound in parts:
        start = int(at * SR)
        end = min(len(out), start + len(sound))
        if end > start:
            out[start:end] += sound[:end - start]
    return out


def crackle(dur, rate, low=1800, high=6500, size=0.012):
    """Потрескивание: редкие щелчки случайной высоты."""
    out = np.zeros(int(dur * SR))
    for _ in range(int(dur * rate)):
        at = rng.integers(0, max(1, len(out) - 800))
        length = int(SR * rng.uniform(0.3, 1.0) * size)
        t = np.arange(length) / SR
        click = np.sin(2 * np.pi * rng.uniform(low, high) * t) * np.exp(-t * rng.uniform(300, 900))
        out[at:at + length] += click * rng.uniform(0.2, 1.0)
    return out


def bubbles(dur, rate, low=350, high=1400):
    """Капли и пузыри: короткие тона, взлетающие вверх. Именно так звучит вода."""
    out = np.zeros(int(dur * SR))
    for _ in range(int(dur * rate)):
        length = int(SR * rng.uniform(0.03, 0.09))
        at = rng.integers(0, max(1, len(out) - length))
        t = np.arange(length) / SR
        f = rng.uniform(low, high)
        pitch = f * (1 + t * rng.uniform(4, 14))
        drop = np.sin(np.cumsum(pitch) * 2 * np.pi / SR) * np.exp(-t * rng.uniform(40, 90)) * np.minimum(1, t * 900)
        out[at:at + length] += drop * rng.uniform(0.3, 1.0)
    return out


def rubble(dur, rate, low=250, high=2200):
    """Осыпь: множество коротких глухих ударов камней."""
    out = np.zeros(int(dur * SR))
    for _ in range(int(dur * rate)):
        length = int(SR * rng.uniform(0.012, 0.05))
        at = rng.integers(0, max(1, len(out) - length))
        t = np.arange(length) / SR
        grain = rng.normal(size=length) * 0.5 + np.sin(2 * np.pi * rng.uniform(low, high) * t)
        out[at:at + length] += grain * np.exp(-t * rng.uniform(90, 260)) * rng.uniform(0.25, 1.0)
    return out


def ring(dur, base, ratios, rate, weights=None):
    """Звон: неровные обертоны как у металла и льда."""
    t = times(dur)
    weights = weights or [1 / (i + 1) for i in range(len(ratios))]
    out = np.zeros(len(t))
    for ratio, weight in zip(ratios, weights):
        out += weight * np.sin(2 * np.pi * base * ratio * t + rng.uniform(0, 6)) * np.exp(-t * rate * (0.7 + ratio * 0.3))
    return out


METAL = [1.0, 2.76, 5.40, 8.93, 13.34]
GLASS = [1.0, 2.32, 3.87, 5.13, 7.41]


def whoosh(dur, f0, f1, width=0.8):
    return shaped(dur, lambda u: f0 * (f1 / f0) ** u, width, lambda u: np.sin(np.pi * u) ** 1.3)


def flame(dur, center=420, width=1.1):
    """Гул пламени: низкий шум с неровной громкостью и треском."""
    t = times(dur)
    flutter = 0.72 + 0.28 * np.sin(2 * np.pi * 7.3 * t + 2 * np.sin(2 * np.pi * 2.1 * t))
    return shaped(dur, center, width) * flutter + 0.16 * crackle(dur, 28)


# ---------------------------------------------------------------- стихии

def fire_cast():
    d = 0.75
    return whoosh(d, 380, 1500, 1.0) * 0.8 + flame(d, 520) * env(d, 0.03, 0.8) * 0.5 + thump(d, 150, 60, 12) * 0.35


def fire_blast():
    d = 1.5
    return (thump(d, 130, 34, 4.5) * 0.9 + shaped(d, lambda u: 2200 * 0.08 ** u, 1.5) * decay(d, 5.5) * 0.9
            + crackle(d, 40) * decay(d, 3.0) * 0.35)


def fire_ring():
    d = 1.1
    return shaped(d, lambda u: 260 + 1100 * u, 1.2, lambda u: np.sin(np.pi * u ** 0.6) ** 1.1) * 0.9 + crackle(d, 45) * env(d, 0.05, 0.6) * 0.3


def fire_armor():
    d = 1.3
    return flame(d, 300, 0.9) * env(d, 0.3, 0.45) * 0.9 + sweep(d, 70, 130) * env(d, 0.2, 0.5) * 0.3


def fire_charge():
    d = 1.15
    return (shaped(d, lambda u: 180 * 9 ** u, 0.8, lambda u: u ** 1.6) * 0.9 + sweep(d, 90, 420, 1.6) * env(d, 0.3, 0.1) * 0.25
            + crackle(d, 60) * np.linspace(0.1, 0.6, int(d * SR)))


def flame_loop():
    d = 0.7
    return flame(d, 620, 1.3) * env(d, 0.05, 0.3) * 0.95


def water_rise():
    d = 0.8
    return (shaped(d, lambda u: 500 + 1800 * u, 1.0, lambda u: np.sin(np.pi * u ** 0.7)) * 0.55 + bubbles(d, 60) * 0.5)


def water_hit():
    d = 0.9
    return (shaped(d, lambda u: 2600 * 0.25 ** u, 1.4) * decay(d, 7) * 0.9 + thump(d, 170, 70, 13) * 0.5
            + lay(d, (0.08, bubbles(0.7, 45, 500, 1800) * 0.5)))


def water_heal():
    d = 1.4
    t = times(d)
    bell = sum(np.sin(2 * np.pi * f * t) * np.exp(-t * (3 + i)) / (i + 1) for i, f in enumerate((660, 990, 1320)))
    return bubbles(d, 22, 700, 2000) * env(d, 0.1, 0.5) * 0.45 + bell * 0.32 + shaped(d, 3000, 0.9) * env(d, 0.3, 0.6) * 0.12


def water_whip():
    d = 0.55
    return whoosh(d, 700, 3400, 0.7) * 0.8 + lay(d, (0.2, shaped(0.3, 2800, 1.2) * decay(0.3, 22))) * 0.8 + bubbles(d, 40) * 0.2


def water_wave():
    d = 1.8
    return shaped(d, lambda u: 260 + 500 * u, 1.3, lambda u: np.sin(np.pi * u ** 0.55) ** 1.2) + bubbles(d, 34, 300, 900) * env(d, 0.2, 0.4) * 0.3


def ice_form():
    d = 1.1
    cracks = lay(d, *[(rng.uniform(0, 0.5), ring(0.35, rng.uniform(1600, 3400), GLASS, 26) * rng.uniform(0.3, 0.9)) for _ in range(9)])
    return cracks * 0.55 + crackle(d, 55, 3000, 9000, 0.008) * env(d, 0.01, 0.6) * 0.4 + thump(d, 240, 120, 16) * 0.3


def earth_rise():
    d = 1.1
    return (shaped(d, lambda u: 90 + 160 * u, 0.9, lambda u: np.sin(np.pi * u ** 0.55)) * 0.95 + rubble(d, 95) * env(d, 0.05, 0.5) * 0.5
            + thump(d, 95, 42, 5) * 0.5)


def earth_throw():
    d = 0.7
    return whoosh(d, 170, 620, 0.9) * 0.85 + thump(d, 110, 55, 9) * 0.55


def earth_hit():
    d = 1.3
    return thump(d, 105, 30, 5.5) * 1.0 + shaped(d, lambda u: 900 * 0.2 ** u, 1.3) * decay(d, 9) * 0.5 + lay(d, (0.04, rubble(1.1, 80) * decay(1.1, 3.5) * 0.55))


def earth_quake():
    d = 1.8
    t = times(d)
    rumble = shaped(d, 62, 0.7) * (0.65 + 0.35 * np.sin(2 * np.pi * 11 * t))
    return rumble * env(d, 0.02, 0.7) * 1.0 + thump(d, 90, 28, 3.5) * 0.7 + rubble(d, 70, 200, 1300) * env(d, 0.03, 0.75) * 0.4


def earth_armor():
    d = 0.9
    return lay(d, *[(i * 0.13, thump(0.3, 230 - i * 20, 90, 22) * 0.8 + rubble(0.3, 90) * decay(0.3, 15) * 0.5) for i in range(5)])


def earth_spike():
    d = 0.6
    return shaped(d, lambda u: 1500 * 0.3 ** u, 1.1) * decay(d, 12) * 0.8 + thump(d, 190, 70, 13) * 0.7 + rubble(d, 70) * decay(d, 8) * 0.4


def earth_wall():
    d = 1.3
    return shaped(d, lambda u: 80 + 240 * u, 1.0, lambda u: np.sin(np.pi * u ** 0.45) ** 1.2) * 0.9 + lay(d, (0.72, thump(0.55, 110, 36, 8))) + rubble(d, 80) * env(d, 0.04, 0.4) * 0.45


def air_dash():
    d = 0.6
    return shaped(d, lambda u: 500 * 7 ** np.sin(np.pi * u), 1.0, lambda u: np.sin(np.pi * u ** 0.6) ** 1.4)


def air_saw():
    d = 0.5
    t = times(d)
    teeth = 0.55 + 0.45 * np.sign(np.sin(2 * np.pi * 46 * t))
    return shaped(d, 3200, 0.8) * teeth * env(d, 0.02, 0.25) * 0.85 + sweep(d, 1500, 1700) * 0.07


def air_gust():
    d = 1.0
    return whoosh(d, 240, 1500, 1.1) * 0.95


def air_tornado():
    d = 1.5
    t = times(d)
    swirl = 0.68 + 0.32 * np.sin(2 * np.pi * 3.2 * t)
    return shaped(d, lambda u: 480 + 300 * np.sin(2 * np.pi * u * 2), 1.0) * swirl * env(d, 0.15, 0.3) * 0.95


def air_dome():
    d = 1.1
    return shaped(d, lambda u: 2400 * 0.2 ** u, 0.9, lambda u: np.sin(np.pi * u ** 0.5)) * 0.85 + sweep(d, 340, 160) * env(d, 0.1, 0.6) * 0.18


# ---------------------------------------------------------------- комбо и вторая ступень

def combo():
    d = 1.1
    t = times(d)
    chord = sum(np.sin(2 * np.pi * f * t) * np.exp(-t * 3.2) * w for f, w in ((293.7, 1), (440, 0.8), (587.3, 0.6), (880, 0.34)))
    return chord * 0.42 + thump(d, 170, 60, 7) * 0.6 + shaped(d, lambda u: 4000 * 0.3 ** u, 1.0) * decay(d, 8) * 0.4


def steam():
    d = 1.6
    return shaped(d, lambda u: 5200 - 1400 * u, 1.0) * env(d, 0.02, 0.8, 1.5) * 0.85


def magma():
    d = 1.6
    deep = shaped(d, 95, 0.7) * env(d, 0.04, 0.5)
    gloop = bubbles(d, 18, 110, 300)
    return deep * 0.8 + gloop * 0.8 + crackle(d, 24, 900, 3000) * env(d, 0.05, 0.5) * 0.3


def lightning():
    d = 0.9
    snap = shaped(d, 5000, 1.5) * decay(d, 38)
    t = times(d)
    buzz = np.sign(np.sin(2 * np.pi * 116 * t)) * decay(d, 8) * 0.25
    return snap * 1.0 + buzz * shaped(d, 2500, 1.2) * 1.2 + crackle(d, 90, 2500, 9000, 0.006) * decay(d, 6) * 0.6 + thump(d, 80, 40, 5) * 0.4


def thunder():
    d = 2.6
    t = times(d)
    roll = 0.5 + 0.5 * np.sin(2 * np.pi * 2.6 * t + 3 * np.sin(2 * np.pi * 0.7 * t))
    return shaped(d, lambda u: 190 * 0.3 ** u, 1.1) * (0.5 + 0.5 * roll) * env(d, 0.01, 0.8, 1.6) + shaped(d, 3800, 1.3) * decay(d, 26) * 0.5


def metal():
    d = 0.8
    return ring(d, 820, METAL, 9) * 0.6 + whoosh(d, 900, 3200, 0.8) * 0.3


def sand():
    d = 1.6
    grains = crackle(d, 260, 3500, 11000, 0.004)
    return shaped(d, 2300, 1.4) * env(d, 0.25, 0.4) * 0.5 + grains * env(d, 0.1, 0.4) * 0.34 + shaped(d, 90, 0.7) * env(d, 0.2, 0.5) * 0.4


def vacuum():
    d = 1.6
    pull = shaped(d, lambda u: 2600 * 0.09 ** u, 0.8, lambda u: u ** 1.4)
    return pull * 0.8 + lay(d, (1.42, thump(0.18, 150, 60, 20))) + sweep(d, 700, 90, 1.5) * env(d, 0.4, 0.05) * 0.18


# ---------------------------------------------------------------- храмы и стражи

def altar():
    d = 2.6
    t = times(d)
    drone = sum(np.sin(2 * np.pi * f * t + 0.6 * np.sin(2 * np.pi * 0.7 * t)) * w for f, w in ((73.4, 1), (110, 0.7), (146.8, 0.5), (220, 0.28)))
    return drone * env(d, 0.7, 0.4) * 0.5 + shaped(d, lambda u: 500 + 2500 * u, 0.8, lambda u: u ** 2) * 0.32


def trap():
    d = 0.45
    return lay(d, (0.0, ring(0.2, 1400, METAL, 30) * 0.6), (0.1, ring(0.2, 1100, METAL, 30) * 0.6)) + thump(d, 180, 90, 18) * 0.4


def boss_awake():
    d = 3.0
    t = times(d)
    roar = shaped(d, lambda u: 120 + 170 * np.sin(np.pi * u), 0.9, lambda u: np.sin(np.pi * u ** 0.6))
    growl = 0.6 + 0.4 * np.sin(2 * np.pi * 31 * t)
    return roar * growl * 0.9 + thump(d, 80, 26, 1.6) * 0.8 + shaped(d, 2200, 1.2) * env(d, 0.9, 0.4) * 0.14


def boss_hurt():
    d = 0.5
    return thump(d, 200, 90, 14) * 0.8 + shaped(d, 900, 1.0) * decay(d, 14) * 0.6


def boss_death():
    d = 3.0
    t = times(d)
    fall = sweep(d, 260, 34, 0.7) * env(d, 0.02, 0.6) * 0.55
    return fall + shaped(d, lambda u: 2600 * 0.05 ** u, 1.4) * decay(d, 1.8) * 0.8 + thump(d, 100, 28, 2.0) * 0.9 + rubble(d, 80) * decay(d, 1.5) * 0.3


def seal_break():
    d = 1.3
    cracks = ring(d, 620, GLASS, 5) * 0.55
    return cracks + lay(d, *[(i * 0.05, ring(0.4, 2200 + i * 340, GLASS, 20) * 0.35) for i in range(6)]) + thump(d, 150, 50, 7) * 0.6


def wheel():
    d = 0.06
    t = times(d)
    return np.sin(2 * np.pi * 1250 * t) * np.exp(-t * 95) * 0.5


SOUNDS = [fire_cast, fire_blast, fire_ring, fire_armor, fire_charge, flame_loop, water_rise, water_hit, water_heal, water_whip, water_wave,
          ice_form, earth_rise, earth_throw, earth_hit, earth_quake, earth_armor, earth_spike, earth_wall, air_dash, air_saw, air_gust,
          air_tornado, air_dome, combo, steam, magma, lightning, thunder, metal, sand, vacuum, altar, trap, boss_awake, boss_hurt,
          boss_death, seal_break, wheel]
# Звуки босса слышны через весь зал, остальные как обычно.
FAR = {"boss_awake": 64, "boss_death": 64, "seal_break": 48, "thunder": 40, "altar": 40}
# Громкость подобрана так, чтобы удары не заглушали всё остальное.
PEAK = {"wheel": 0.35, "flame_loop": 0.6, "air_saw": 0.55, "air_tornado": 0.6, "trap": 0.6}


def finish(sound, peak):
    sound = sound - np.mean(sound)
    fade = min(len(sound), int(0.03 * SR))
    sound[-fade:] *= np.linspace(1, 0, fade)
    sound[:64] *= np.linspace(0, 1, 64)
    return sound / max(1e-9, np.abs(sound).max()) * peak


def main():
    wanted = sys.argv[1:]
    folder = os.path.join(OUT, "sounds")
    os.makedirs(folder, exist_ok=True)
    table = {}
    for make in SOUNDS:
        name = make.__name__
        entry = {"name": f"minevia_elements:{name}"}
        if name in FAR:
            entry["attenuation_distance"] = FAR[name]
        table[name] = {"sounds": [entry]}
        if wanted and name not in wanted:
            continue
        data = finish(make(), PEAK.get(name, 0.85))
        with tempfile.TemporaryDirectory() as temp:
            raw = os.path.join(temp, "s.wav")
            with wave.open(raw, "wb") as out:
                out.setnchannels(1)
                out.setsampwidth(2)
                out.setframerate(SR)
                out.writeframes((data * 32767).astype("<i2").tobytes())
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", raw, "-c:a", "libvorbis", "-q:a", "5", os.path.join(folder, name + ".ogg")], check=True)
        print(f"{name}: {len(data) / SR:.2f} с, пик {np.abs(data).max():.2f}, сред. {np.sqrt(np.mean(data ** 2)):.3f}")
    with open(os.path.join(OUT, "sounds.json"), "w", encoding="utf-8") as out:
        json.dump(table, out, indent=2)
    print("Звуки готовы")


main()
