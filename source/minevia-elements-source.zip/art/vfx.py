# Рендерит покадровые анимации частиц мода.
# Запуск: blender -b --factory-startup -P vfx.py
import math
import os

import bpy

OUT = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements\textures\particle"
SIZE = 64


def setup():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 24
    scene.cycles.use_denoising = False
    scene.render.resolution_x = SIZE
    scene.render.resolution_y = SIZE
    scene.render.film_transparent = True
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.view_settings.view_transform = "Standard"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        prefs.compute_device_type = "OPTIX"
        prefs.get_devices()
        for device in prefs.devices:
            device.use = device.type == "OPTIX"
        scene.cycles.device = "GPU"
    except (KeyError, TypeError):
        pass
    camera = bpy.data.cameras.new("Camera")
    camera.type = "ORTHO"
    camera.ortho_scale = 2.0
    obj = bpy.data.objects.new("Camera", camera)
    scene.collection.objects.link(obj)
    obj.location = (0, 0, 5)
    scene.camera = obj
    return scene


def noise_sprite(colors, scale, detail):
    """Плоскость, форму которой на каждом кадре задаёт шум, маска и порог."""
    bpy.ops.mesh.primitive_plane_add(size=2)
    plane = bpy.context.object
    mat = bpy.data.materials.new("Sprite")
    mat.use_nodes = True
    tree = mat.node_tree
    nodes, links = tree.nodes, tree.links
    nodes.clear()

    out = nodes.new("ShaderNodeOutputMaterial")
    mix = nodes.new("ShaderNodeMixShader")
    clear = nodes.new("ShaderNodeBsdfTransparent")
    emit = nodes.new("ShaderNodeEmission")
    emit.inputs["Strength"].default_value = 1.0
    coords = nodes.new("ShaderNodeTexCoord")

    flow = nodes.new("ShaderNodeMapping")
    flow.name = "Flow"
    noise = nodes.new("ShaderNodeTexNoise")
    noise.name = "Noise"
    noise.noise_dimensions = "4D"
    noise.inputs["Scale"].default_value = scale
    noise.inputs["Detail"].default_value = detail
    noise.inputs["Roughness"].default_value = 0.55

    shape = nodes.new("ShaderNodeMapping")
    shape.name = "Shape"
    length = nodes.new("ShaderNodeVectorMath")
    length.operation = "LENGTH"
    radial = nodes.new("ShaderNodeMath")
    radial.name = "Radius"
    radial.operation = "DIVIDE"
    inverse = nodes.new("ShaderNodeMath")
    inverse.operation = "SUBTRACT"
    inverse.inputs[0].default_value = 1.0

    centred = nodes.new("ShaderNodeMath")
    centred.operation = "SUBTRACT"
    centred.inputs[1].default_value = 0.5
    strength = nodes.new("ShaderNodeMath")
    strength.name = "Amount"
    strength.operation = "MULTIPLY"
    total = nodes.new("ShaderNodeMath")
    total.operation = "ADD"
    cut = nodes.new("ShaderNodeMath")
    cut.name = "Cut"
    cut.operation = "SUBTRACT"

    soft = nodes.new("ShaderNodeMapRange")
    soft.name = "Soft"
    soft.clamp = True
    soft.inputs["From Min"].default_value = 0.0
    soft.inputs["From Max"].default_value = 0.22

    heat = nodes.new("ShaderNodeMapRange")
    heat.clamp = True
    heat.inputs["From Min"].default_value = 0.0
    heat.inputs["From Max"].default_value = 0.7
    ramp = nodes.new("ShaderNodeValToRGB")
    elements = ramp.color_ramp.elements
    elements[0].position = 0.0
    elements[0].color = (*colors[0], 1)
    elements[1].position = 1.0
    elements[1].color = (*colors[2], 1)
    middle = elements.new(0.5)
    middle.color = (*colors[1], 1)

    fade = nodes.new("ShaderNodeMath")
    fade.name = "Fade"
    fade.operation = "MULTIPLY"

    links.new(coords.outputs["Object"], flow.inputs["Vector"])
    links.new(flow.outputs[0], noise.inputs["Vector"])
    split = nodes.new("ShaderNodeSeparateXYZ")
    lift = nodes.new("ShaderNodeMath")
    lift.operation = "ADD"
    lift.inputs[1].default_value = 1.0
    taper = nodes.new("ShaderNodeMath")
    taper.name = "Taper"
    taper.operation = "MULTIPLY"
    grow = nodes.new("ShaderNodeMath")
    grow.operation = "ADD"
    grow.inputs[1].default_value = 1.0
    squeeze = nodes.new("ShaderNodeMath")
    squeeze.operation = "MULTIPLY"
    join = nodes.new("ShaderNodeCombineXYZ")
    links.new(coords.outputs["Object"], split.inputs[0])
    links.new(split.outputs["Y"], lift.inputs[0])
    links.new(lift.outputs[0], taper.inputs[0])
    links.new(taper.outputs[0], grow.inputs[0])
    links.new(split.outputs["X"], squeeze.inputs[0])
    links.new(grow.outputs[0], squeeze.inputs[1])
    links.new(squeeze.outputs[0], join.inputs["X"])
    links.new(split.outputs["Y"], join.inputs["Y"])
    links.new(join.outputs[0], shape.inputs["Vector"])
    links.new(shape.outputs[0], length.inputs[0])
    links.new(length.outputs["Value"], radial.inputs[0])
    links.new(radial.outputs[0], inverse.inputs[1])
    links.new(noise.outputs["Fac"], centred.inputs[0])
    links.new(centred.outputs[0], strength.inputs[0])
    links.new(inverse.outputs[0], total.inputs[0])
    links.new(strength.outputs[0], total.inputs[1])
    links.new(total.outputs[0], cut.inputs[0])
    links.new(cut.outputs[0], soft.inputs["Value"])
    links.new(cut.outputs[0], heat.inputs["Value"])
    links.new(heat.outputs[0], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], emit.inputs["Color"])
    links.new(soft.outputs[0], fade.inputs[0])
    links.new(fade.outputs[0], mix.inputs[0])
    links.new(clear.outputs[0], mix.inputs[1])
    links.new(emit.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], out.inputs["Surface"])
    plane.data.materials.append(mat)
    return tree.nodes


def tune(nodes, w, flow_y, stretch, offset, radius, amount, cut, fade, taper=0.0):
    nodes["Taper"].inputs[1].default_value = taper
    nodes["Noise"].inputs["W"].default_value = w
    nodes["Flow"].inputs["Location"].default_value[1] = flow_y
    nodes["Shape"].inputs["Scale"].default_value = (1.0, stretch, 1.0)
    nodes["Shape"].inputs["Location"].default_value[1] = offset
    nodes["Radius"].inputs[1].default_value = radius
    nodes["Amount"].inputs[1].default_value = amount
    nodes["Cut"].inputs[1].default_value = cut
    nodes["Fade"].inputs[1].default_value = fade


def save(scene, name, frame):
    scene.render.filepath = os.path.join(OUT, f"{name}_{frame:02d}.png")
    bpy.ops.render.render(write_still=True)


def flame():
    scene = setup()
    nodes = noise_sprite(((0.3, 0.04, 0.02), (0.74, 0.22, 0.04), (0.95, 0.56, 0.2)), 4.2, 5)
    for f in range(12):
        t = f / 11
        grow = min(1.0, t * 3.2)
        tune(nodes, t * 2.6, -t * 3.4, 0.46, 0.12, 0.16 + 0.26 * grow, 0.62, t ** 1.5 * 0.5, 1 - t ** 3, 1.15)
        save(scene, "flame", f)


def water():
    scene = setup()
    nodes = noise_sprite(((0.03, 0.17, 0.42), (0.1, 0.42, 0.72), (0.58, 0.82, 0.93)), 4.2, 4)
    for f in range(10):
        t = f / 9
        tune(nodes, t * 1.6, 0.0, 1.0, 0.0, 0.3 + 0.6 * t, 1.25, t ** 1.4 * 0.62, 1 - t ** 3)
        save(scene, "water", f)


def dust():
    scene = setup()
    nodes = noise_sprite(((0.13, 0.11, 0.09), (0.3, 0.26, 0.2), (0.48, 0.43, 0.35)), 3.0, 6)
    for f in range(10):
        t = f / 9
        tune(nodes, t * 1.1, t * 0.3, 1.0, 0.0, 0.34 + 0.56 * t, 0.9, t * 0.45, (1 - t) ** 0.8 * 0.85)
        save(scene, "dust", f)


def charge():
    """Заряд: мягкое ядро и две вращающиеся дуги. Серый: цвет стихии задаётся в коде мода."""
    scene = setup()
    nodes = noise_sprite(((0.34, 0.34, 0.34), (0.66, 0.66, 0.66), (0.96, 0.96, 0.96)), 3.0, 3)
    mat = bpy.data.materials.new("Arc")
    mat.use_nodes = True
    tree = mat.node_tree
    tree.nodes.clear()
    out = tree.nodes.new("ShaderNodeOutputMaterial")
    emit = tree.nodes.new("ShaderNodeEmission")
    emit.inputs["Color"].default_value = (0.82, 0.82, 0.82, 1)
    emit.inputs["Strength"].default_value = 1.0
    tree.links.new(emit.outputs[0], out.inputs["Surface"])
    arcs = []
    for index, (tilt, reach) in enumerate(((math.radians(62), 0.74), (math.radians(-58), 0.62))):
        curve = bpy.data.curves.new(f"Arc{index}", "CURVE")
        curve.dimensions = "3D"
        curve.bevel_depth = 0.035
        curve.bevel_resolution = 2
        spline = curve.splines.new("POLY")
        count = 30
        spline.points.add(count - 1)
        for i, point in enumerate(spline.points):
            k = i / (count - 1)
            angle = k * math.pi * 1.25
            point.co = (math.cos(angle) * reach, math.sin(angle) * reach, 0, 1)
            point.radius = math.sin(k * math.pi) ** 0.6
        curve.materials.append(mat)
        arc = bpy.data.objects.new(f"Arc{index}", curve)
        scene.collection.objects.link(arc)
        arc.location = (0, 0, 0.5)
        arcs.append((arc, tilt))
    for f in range(8):
        angle = math.tau * f / 8
        tune(nodes, 0.5 + 0.3 * math.sin(angle), 0.3 * math.cos(angle), 1.0, 0.0, 0.42, 0.34, 0.03, 0.95)
        for index, (arc, tilt) in enumerate(arcs):
            arc.rotation_euler = (tilt, 0, angle * (1 if index == 0 else -1))
        bpy.context.view_layer.update()
        save(scene, "charge", f)


def wind():
    """Ветер это не пятно, а тонкие завитки: настоящая геометрия, а не шум."""
    scene = setup()
    mat = bpy.data.materials.new("Wind")
    mat.use_nodes = True
    tree = mat.node_tree
    nodes, links = tree.nodes, tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    mix = nodes.new("ShaderNodeMixShader")
    clear = nodes.new("ShaderNodeBsdfTransparent")
    emit = nodes.new("ShaderNodeEmission")
    emit.inputs["Color"].default_value = (0.66, 0.78, 0.86, 1)
    emit.inputs["Strength"].default_value = 1.0
    links.new(clear.outputs[0], mix.inputs[1])
    links.new(emit.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], out.inputs["Surface"])

    holder = bpy.data.objects.new("Holder", None)
    scene.collection.objects.link(holder)
    for index, (start, reach, turns) in enumerate(((0.0, 0.8, 0.9), (2.1, 0.62, 0.75), (4.2, 0.46, 0.65))):
        curve = bpy.data.curves.new(f"Stroke{index}", "CURVE")
        curve.dimensions = "3D"
        curve.bevel_depth = 0.045
        curve.bevel_resolution = 2
        spline = curve.splines.new("POLY")
        count = 40
        spline.points.add(count - 1)
        for i, point in enumerate(spline.points):
            k = i / (count - 1)
            angle = start + k * turns * math.tau
            radius = reach * (0.3 + 0.7 * k)
            point.co = (math.cos(angle) * radius, math.sin(angle) * radius, 0, 1)
            point.radius = math.sin(k * math.pi) ** 0.8
        stroke = bpy.data.objects.new(f"Stroke{index}", curve)
        scene.collection.objects.link(stroke)
        stroke.parent = holder
        curve.materials.append(mat)

    for f in range(10):
        t = f / 9
        holder.rotation_euler = (0, 0, -t * 2.6)
        size = 0.5 + 0.55 * t
        holder.scale = (size, size, 1)
        mix.inputs[0].default_value = math.sin(min(1.0, t * 1.2) * math.pi) ** 0.7 * 0.85
        bpy.context.view_layer.update()
        save(scene, "wind", f)


os.makedirs(OUT, exist_ok=True)
for make in (flame, charge):
    make()
print("ЧАСТИЦЫ ГОТОВЫ")
