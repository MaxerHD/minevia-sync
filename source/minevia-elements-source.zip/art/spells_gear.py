# Оружие в руках, вторая версия: плотная сетка, гравировка в геометрии, запечённые тени и потёртости на рёбрах.
# Заменяет простые формы из spells_weapons.py, имена мешей те же.
from mathutils import Vector
from mathutils.bvhtree import BVHTree


def g_hemisphere(count, seed=5):
    rng = np.random.default_rng(seed)
    d = rng.normal(size=(count, 3))
    return d / np.linalg.norm(d, axis=1, keepdims=True)


G_RAYS = g_hemisphere(26)


def g_bake(pos, quads, col, reach=0.16, dark=0.72, wear=0.5):
    """Запекает в цвет вершин затенение щелей и светлые потёртости на острых рёбрах: без текстур это главный источник объёма."""
    clean = [tuple(int(v) for v in q) for q in quads if len(set(q.tolist())) == 4]
    verts = [Vector(p) for p in pos.tolist()]
    tree = BVHTree.FromPolygons(verts, clean, all_triangles=False)
    nrm = normals(pos, quads)
    hidden = np.zeros(len(pos))
    for i, (p, n) in enumerate(zip(verts, nrm.tolist())):
        n = Vector(n)
        start = p + n * 0.0015
        blocked = total = 0
        for ray in G_RAYS.tolist():
            ray = Vector(ray)
            if ray.dot(n) < 0:
                ray = -ray
            total += 1
            if tree.ray_cast(start, ray, reach)[0] is not None:
                blocked += 1
        hidden[i] = blocked / max(1, total)
    # Кривизна на сваренных вершинах: швы между гранями не должны считаться рёбрами отдельно.
    _, weld = np.unique(np.round(pos * 3000).astype(np.int64), axis=0, return_inverse=True)
    weld = weld.ravel()
    count = weld.max() + 1
    sums = np.zeros((count, 3))
    hits = np.zeros(count)
    wnormal = np.zeros((count, 3))
    wpos = np.zeros((count, 3))
    np.add.at(wnormal, weld, nrm)
    np.add.at(wpos, weld, pos)
    wpos /= np.maximum(1, np.bincount(weld, minlength=count))[:, None]
    wnormal /= np.maximum(1e-6, np.linalg.norm(wnormal, axis=1, keepdims=True))
    for a, b in ((0, 1), (1, 2), (2, 3), (3, 0)):
        ia, ib = weld[quads[:, a]], weld[quads[:, b]]
        np.add.at(sums, ia, wpos[ib])
        np.add.at(sums, ib, wpos[ia])
        np.add.at(hits, ia, 1)
        np.add.at(hits, ib, 1)
    around = sums / np.maximum(1, hits)[:, None] - wpos
    size = np.maximum(1e-4, np.linalg.norm(around, axis=1))
    bend = np.sum(around * wnormal, axis=1) / np.maximum(size, 0.004)
    bend = bend[weld]
    out = col.copy()
    shade = 1 - dark * np.clip(hidden * 1.5, 0, 1) ** 1.2
    shade = shade * (1 - 0.4 * np.clip(bend * 2.0, 0, 1))
    out[:, :3] = out[:, :3] * shade[:, None] + wear * np.clip(-bend * 2.4, 0, 1)[:, None] * (0.55 + 0.45 * out[:, :3])
    out[:, :3] = np.clip(out[:, :3], 0, 1)
    return out


def g_finish(parts, reach=0.16):
    pos, quads, col = merged(parts)
    return pos, quads, g_bake(pos, quads, col, reach)


def g_rod(path, wide, thin, color, seed=1, sides=10, along=(1, 0, 0)):
    """Плоский стержень: сечение овальное, ширина вдоль заданного направления."""
    path = np.asarray(path, dtype=float)
    wide = np.broadcast_to(np.asarray(wide, dtype=float), (len(path),))
    thin = np.broadcast_to(np.asarray(thin, dtype=float), (len(path),))
    rings = []
    a = np.linspace(0, TAU, sides, endpoint=False)
    for i, at in enumerate(path):
        way = path[min(i + 1, len(path) - 1)] - path[max(i - 1, 0)]
        way /= max(1e-9, np.linalg.norm(way))
        u = np.asarray(along, dtype=float) - way * float(np.dot(along, way))
        u /= max(1e-9, np.linalg.norm(u))
        v = np.cross(way, u)
        rings.append(at[None, :] + np.outer(np.cos(a) * wide[i], u) + np.outer(np.sin(a) * thin[i], v))
    return w_loft(rings, color, seed, hard=False)


def g_rivets(points, size, metal):
    parts = []
    for p in points:
        p = np.asarray(p, dtype=float)
        rings = [w_ring(p + np.array([0, 0, d]), (1, 0, 0), (0, 1, 0), r, 6) for d, r in ((-size * 0.6, size), (0, size), (size * 0.6, size * 0.55))]
        parts.append(w_loft(rings, metal, 7, hard=False))
    return parts


def g_blade(length, left, right, thick, fuller_end, etch, paint, cut=None, seed=1, curve=None):
    """Клинок сеткой: контур задают функции ширины слева и справа, гравировка и дол вдавлены в поверхность."""
    rows, cols = 190, 16
    t = np.repeat(np.linspace(0, 1, rows), cols * 2 + 1)
    c = np.tile(np.linspace(-1, 1, cols * 2 + 1), rows)
    L, R = left(t), right(t)
    bend = curve(t) if curve else t * 0
    x = np.where(c < 0, c * L, c * R) + bend
    y = 0.1 + t * length
    ground = np.clip((1 - np.abs(c)) / 0.34, 0, 1)
    body = thick * (1 - 0.72 * t ** 2) * np.minimum(1, (1 - t) * 14 + 0.05)
    groove = np.exp(-(c / 0.2) ** 2) * np.clip((fuller_end - t) * 9, 0, 1)
    carve = etch(c, t)
    z = body * ground ** 0.9 * (1 - 0.62 * groove) - 0.0026 * carve * (ground > 0.9)
    grid_quads = grid(cols * 2 + 1, rows, wrap=False)
    if cut is not None:
        keep = ~cut(c, t)[grid_quads].any(axis=1)
        grid_quads = grid_quads[keep]
    faces_list = []
    for side in (1, -1):
        pos = np.stack([x, y, z * side], axis=1)
        quads = grid_quads if side > 0 else grid_quads[:, ::-1]
        faces_list.append((pos, quads, paint(pos, c, t, ground, groove, carve)))
    return faces_list


def g_steel(tone, inlay=None, seed=11):
    """Сталь: узор ковки по плоскости, заточка светлая и зернистая, дол темнее, гравировка залита цветом или тенью."""
    wave = Flow(seed, freq=9.0, octaves=4, gain=0.62, speed=0)
    scratch = Flow(seed + 1, freq=31.0, octaves=2, speed=0)

    def paint(pos, c, t, ground, groove, carve):
        n = wave(pos * np.array([1.5, 0.25, 1.5]), 0.0)
        polish = 0.5 + 0.5 * np.sin(c * 11 + 0.8 * n)
        shade = 0.8 + 0.1 * polish - 0.42 * groove
        bevel = ground < 0.98
        shade = shade + 0.3 * bevel * (0.9 + 0.1 * scratch(pos, 0.0))
        rgb = np.asarray(tone)[None, :] * shade[:, None]
        if inlay is None:
            rgb = rgb * (1 - 0.5 * carve[:, None])
        else:
            rgb = rgb * (1 - carve[:, None]) + np.asarray(inlay)[None, :] * carve[:, None]
        return rgba(np.clip(rgb, 0, 1), np.ones(len(pos)))

    return paint


def g_knot(period, width=0.12):
    """Плетёный орнамент вдоль дола."""
    def etch(c, t):
        a = np.abs(np.sin(t * period) * 0.42 - c)
        b = np.abs(-np.sin(t * period) * 0.42 - c)
        lines = np.clip(1 - np.minimum(a, b) / width, 0, 1)
        return (lines > 0.35) * (t > 0.03) * (t < 0.72)
    return etch


def g_none(c, t):
    return c * 0


def g_scroll(side, span, height, metal, thick=0.024):
    """Завиток на конце гарды."""
    a = np.linspace(0, 2.6 * math.pi, 26)
    r = np.linspace(span * 0.46, span * 0.08, 26)
    path = np.stack([side * (span * 0.54 + r * np.sin(a) * 0.95), height + r * (1 - np.cos(a)) * 0.5, a * 0], axis=1)
    return g_rod(path, np.linspace(thick, thick * 0.34, 26), np.linspace(thick * 0.8, thick * 0.3, 26), metal, along=(0, 0, 1))


def g_hilt(length, wrap, metal, wraps=11, flat=0.024):
    y = np.linspace(-length, 0.075, 60)
    a = np.linspace(0, TAU, 12, endpoint=False)
    rings = []
    for yy in y:
        swell = 1 + 0.14 * math.sin((yy + length) / (length + 0.075) * math.pi)
        rib = [1 + 0.11 * math.sin(yy * wraps * TAU / length + q) for q in a]
        rings.append(np.stack([np.cos(a) * flat * 1.14 * swell * rib, np.full(12, yy), np.sin(a) * flat * 0.92 * swell * rib], axis=1))

    def colour(pos, side, along):
        ridge = 0.5 + 0.5 * np.sin(pos[:, 1] * wraps * TAU / length + np.arctan2(pos[:, 2], pos[:, 0]))
        return rgba(np.clip(np.asarray(wrap)[None, :] * (0.5 + 0.75 * ridge)[:, None], 0, 1), np.ones(len(pos)))

    parts = [w_loft(rings, colour, hard=False)]
    for yy in (-length, 0.06):
        band = [w_ring((0, yy + d, 0), (1, 0, 0), (0, 0, 1), r, 10) for d, r in ((-0.012, flat * 1.2), (-0.006, flat * 1.42), (0.006, flat * 1.42), (0.012, flat * 1.2))]
        parts.append(w_loft(band, metal, 3, hard=False))
    return parts


def g_guardbar(span, arc, thick, metal):
    """Перекладина гарды: кованая, широкая в середине, с гранями."""
    x = np.linspace(-span, span, 30)
    path = np.stack([x, 0.062 + arc * (x / span) ** 2, x * 0], axis=1)
    wide = thick * (1.5 - 0.7 * np.abs(x / span) ** 0.8)
    return g_rod(path, wide, wide * 0.72, metal, sides=8, along=(0, 1, 0))


def g_sword(tier):
    def W(base, tip=0.86):
        return lambda t: base * np.minimum(1.0, (1 - t) * 7) ** 0.72 * (1 - (1 - tip) * t) * (0.86 + 0.14 * np.minimum(1, t * 16))

    parts, glow = [], []
    rng = np.random.default_rng(800 + tier)
    if tier == 1:
        # Простой рабочий меч: сколы на лезвии, грубая гарда на заклёпках.
        nick = lambda t, s: 1 - 0.1 * (np.abs(np.sin(t * s)) > 0.985)
        faces_ = g_blade(1.0, lambda t: W(0.062)(t) * nick(t, 57), lambda t: W(0.062)(t) * nick(t, 83), 0.0135, 0.0, g_none, g_steel(W_IRON * 1.55, seed=31))
        parts += faces_
        parts.append(g_guardbar(0.13, 0.0, 0.03, W_IRON))
        parts += g_rivets([(-0.08, 0.062, 0.022), (0.08, 0.062, 0.022)], 0.008, W_SILVER * 0.8)
        parts += g_hilt(0.25, W_LEATHER, W_IRON, 9)
        parts.append(w_pommel(-0.3, 0.036, W_IRON))
    elif tier == 2:
        # Рыцарский: длинный дол, рикассо, бронзовые завитки.
        ric = lambda t: 0.74 + 0.26 * np.clip((t - 0.09) * 40, 0, 1)
        parts += g_blade(1.1, lambda t: W(0.072)(t) * ric(t), lambda t: W(0.072)(t) * ric(t), 0.0145, 0.74, g_knot(19, 0.05), g_steel(W_STEEL, seed=32))
        parts.append(g_guardbar(0.12, -0.012, 0.03, W_BRONZE))
        parts.append(g_scroll(-1, 0.2, 0.03, W_BRONZE))
        parts.append(g_scroll(1, 0.2, 0.03, W_BRONZE))
        parts += g_hilt(0.27, W_LEATHER * 1.15, W_BRONZE, 12)
        ring = np.stack([np.cos(np.linspace(0, TAU, 20)) * 0.04, -0.33 + np.sin(np.linspace(0, TAU, 20)) * 0.04, np.zeros(20)], axis=1)
        parts.append(g_rod(ring, 0.012, 0.012, W_BRONZE, along=(0, 0, 1)))
    elif tier == 3:
        # Фламберг: волнистая кромка и рунный дол.
        wavy = lambda t, p: 1 + 0.2 * np.sin(t * 24 + p) * np.clip((0.9 - t) * 6, 0, 1)
        parts += g_blade(1.2, lambda t: W(0.078)(t) * wavy(t, 0), lambda t: W(0.078)(t) * wavy(t, math.pi), 0.015, 0.82, g_knot(27, 0.06), g_steel(W_SILVER, (0.1, 0.34, 0.6), seed=33))
        parts.append(g_guardbar(0.2, 0.05, 0.03, W_SILVER))
        for side in (-1, 1):
            parts.append(g_rod(w_bezier((side * 0.18, 0.1, 0), (side * 0.3, 0.17, 0), (side * 0.2, 0.3, 0), 14), np.linspace(0.024, 0.003, 14), np.linspace(0.012, 0.002, 14), W_SILVER, along=(1, 0, 0.3)))
        parts += g_hilt(0.28, np.array([0.14, 0.2, 0.42]), W_SILVER, 14)
        parts.append(w_gem((0, -0.34, 0), 0.04, W_SILVER, stretch=1.3))
        glow += [w_gem((0, 0.075, z), 0.024, (1, 1, 1), stretch=1.2) for z in (-0.02, 0.02)]
        glow += w_runes(1.2, 0.078, 8, 913)
    elif tier == 4:
        # Ночной клинок: несимметричный, зубья на обухе, крюк у острия, светящаяся жила.
        teeth = lambda t: 1 + 0.42 * (np.abs(((t * 11) % 1) - 0.5) * 2) * (t > 0.34) * (t < 0.86)
        hook = lambda t: 1 + 1.3 * np.exp(-((t - 0.86) / 0.035) ** 2)
        parts += g_blade(1.28, lambda t: W(0.07)(t) * teeth(t), lambda t: W(0.098, 0.8)(t) * hook(t), 0.017, 0.7, g_knot(33, 0.05), g_steel(W_DARKSTEEL * 1.55, (0.04, 0.3, 0.46), seed=34))
        parts.append(g_guardbar(0.17, -0.03, 0.036, W_DARKSTEEL * 1.3))
        for side, reach in ((-1, 0.28), (1, 0.34)):
            parts.append(g_rod(w_bezier((side * 0.14, 0.05, 0), (side * 0.26, 0.04, 0), (side * reach, 0.2, 0), 14), np.linspace(0.03, 0.002, 14), np.linspace(0.016, 0.002, 14), W_DARKSTEEL * 1.6, along=(0, 1, 0.2)))
            parts.append(g_rod(w_bezier((side * 0.12, 0.05, 0), (side * 0.2, 0.0, 0), (side * 0.24, -0.1, 0), 12), np.linspace(0.024, 0.002, 12), np.linspace(0.012, 0.002, 12), W_DARKSTEEL * 1.4, along=(0, 1, 0.2)))
        parts += g_hilt(0.3, np.array([0.1, 0.16, 0.34]), W_DARKSTEEL * 1.4, 15)
        parts.append(w_gem((0, -0.35, 0), 0.042, W_DARKSTEEL * 1.5, stretch=1.7))
        glow.append(w_gem((0, 0.08, 0.024), 0.03, (1, 1, 1), stretch=1.4))
        glow.append(w_gem((0, 0.08, -0.024), 0.03, (1, 1, 1), stretch=1.4))
        glow += w_runes(1.28, 0.078, 10, 914)
        path = np.stack([np.zeros(40), 0.14 + np.linspace(0, 0.78, 40), np.zeros(40) + 0.0115], axis=1)
        for z in (1, -1):
            glow.append(w_rod(path * np.array([1, 1, z]), 0.0045, (1, 1, 1), sides=4))
    else:
        # Солнечный клинок: сквозные окна в лезвии, золото, диск за гардой, кружащие осколки.
        win = lambda c, t: (np.abs(c) < 0.28 * np.clip(1 - np.abs(((t * 6.5) % 1) - 0.5) * 2.6, 0, 1) * 2.4) & (t > 0.1) & (t < 0.62)
        parts += g_blade(1.36, W(0.104), W(0.104), 0.0165, 0.0, g_knot(23, 0.05), g_steel(W_SILVER * 1.1, W_GOLD, seed=35), cut=win)
        disc_a = np.linspace(0, TAU, 40)
        parts.append(g_rod(np.stack([np.cos(disc_a) * 0.1, 0.1 + np.sin(disc_a) * 0.1, disc_a * 0], axis=1), 0.016, 0.012, W_GOLD, along=(0, 0, 1)))
        for k in range(12):
            a = k / 12 * TAU
            if abs(math.sin(a)) > 0.82 and math.sin(a) > 0:
                continue
            root = np.array([math.cos(a) * 0.11, 0.1 + math.sin(a) * 0.11, 0])
            tip = np.array([math.cos(a) * (0.27 if k % 2 else 0.2), 0.1 + math.sin(a) * (0.27 if k % 2 else 0.2), 0])
            parts.append(g_rod(np.linspace(root, tip, 8), np.linspace(0.02, 0.002, 8), np.linspace(0.009, 0.002, 8), W_GOLD, along=(math.sin(a), -math.cos(a), 0)))
        parts += g_hilt(0.31, np.array([0.42, 0.1, 0.12]), W_GOLD, 15)
        parts.append(w_gem((0, -0.37, 0), 0.05, W_GOLD, stretch=1.5))
        # Свет в окнах лезвия.
        y = 0.1 + np.linspace(0.08, 0.64, 40) * 1.36
        glow.append(w_rod(np.stack([np.zeros(40), y, np.zeros(40)], axis=1), 0.02, (1, 1, 1), sides=6))
        glow.append(w_gem((0, 0.1, 0.02), 0.03, (1, 1, 1), stretch=1.1))
        glow.append(w_gem((0, 0.1, -0.02), 0.03, (1, 1, 1), stretch=1.1))
    return parts, glow


def weapon_swords():
    for tier in range(1, 6):
        parts, glow = g_sword(tier)
        blade = 2
        hilt = g_finish(parts[blade:], 0.1)
        pos, quads, col = merged(parts[:blade] + [hilt])
        save(f"weapon_sword_{tier}_body", [(pos, col)], quads)
        if not glow:
            glow.append(w_rod([(0, 0.08, 0.016), (0, 0.082, 0.016)], 0.0004, (1, 1, 1), sides=3))
        shards = [w_gem((0, 0, 0), 0.02, (1, 1, 1), stretch=2.6) for _ in range(5)] if tier == 5 else None
        frames, frame_quads = w_glow_frames(glow, W_SUN if tier == 5 else W_RUNE, 12, shards)
        save(f"weapon_sword_{tier}_glow", frames, frame_quads)


# ---------------------------------------------------------------- лук

def g_limb(side, length, pull, belly, recurve, count=46):
    s = np.linspace(0.05, 1, count)
    y = side * length * s * (1 - 0.12 * pull)
    z = -(belly + 0.3 * pull) * s ** 1.7 + recurve * np.clip((s - 0.74) / 0.26, 0, 1) ** 2 * (1 - 0.5 * pull)
    return np.stack([s * 0, y, z], axis=1), s


def g_bow_parts(tier, pull):
    length = 0.64 + 0.05 * tier
    belly = 0.19
    recurve = (0.0, 0.07, 0.13, 0.16, 0.2)[tier - 1]
    wood = (W_WOOD, W_WOOD * 0.72, W_DARKSTEEL * 1.3, W_DARKSTEEL, W_GOLD * 0.86)[tier - 1]
    cap = (W_LEATHER, W_BRONZE, W_SILVER, W_SILVER, W_GOLD)[tier - 1]
    parts, glow, tips = [], [], []

    def limb_colour(pos, side, along):
        grain = 0.5 + 0.5 * np.sin(pos[:, 1] * 95 + 5 * np.sin(pos[:, 2] * 50 + pos[:, 1] * 12))
        return rgba(np.clip(wood[None, :] * (0.62 + 0.56 * grain)[:, None], 0, 1), np.ones(len(pos)))

    for side in (-1, 1):
        path, s = g_limb(side, length, pull, belly, recurve)
        wide = 0.034 * (1 - 0.7 * s ** 1.2) + 0.004
        thin = 0.019 * (1 - 0.6 * s) + 0.004
        parts.append(g_rod(path, wide, thin, limb_colour, sides=10))
        tips.append(path[-1])
        # Обмотки и накладки вдоль плеча.
        for k in ((8, 17, 27) if tier >= 2 else (10,)):
            a = max(0, k - 1)
            parts.append(g_rod(path[a:a + 3], wide[a:a + 3] * 1.16, thin[a:a + 3] * 1.3, cap, sides=8))
        parts.append(g_rod(path[-5:], wide[-5:] * 1.3, thin[-5:] * 1.4, cap, sides=8))
        if tier >= 3:
            spine = path[8:38] + np.array([0, 0, 0.018])
            glow.append(w_rod(spine, 0.005, (1, 1, 1), sides=4))
        if tier >= 4:
            # Лезвия на плечах.
            for k in (12, 20, 28, 36):
                root = path[k]
                tip = root + np.array([0, side * 0.05, 0.12 - 0.0012 * k])
                parts.append(g_rod(w_bezier(root, root + np.array([0, -side * 0.01, 0.06]), tip, 10), np.linspace(0.03, 0.002, 10), np.linspace(0.009, 0.0015, 10), W_SILVER * 1.1, along=(0, 1, 0)))
        if tier == 5:
            # Веер золотых перьев и камень на конце.
            for k, reach in ((14, 0.15), (21, 0.19), (28, 0.2), (35, 0.16)):
                root = path[k]
                tip = root + np.array([0, side * 0.09, -0.02 + reach])
                parts.append(g_rod(w_bezier(root, root + np.array([0, side * 0.02, reach * 0.6]), tip, 12), np.array([0.006, 0.02, 0.03, 0.034, 0.034, 0.032, 0.03, 0.026, 0.02, 0.014, 0.008, 0.002]), np.full(12, 0.004), W_GOLD, along=(0, 1, 0)))
            glow.append(w_gem(path[-1] + np.array([0, side * 0.06, 0]), 0.028, (1, 1, 1), stretch=2.2))
    # Рукоять: обмотка, полка, накладка.
    parts += [(p * np.array([1, 1, 1]) + np.array([0, 0, -0.008]), q, c) for p, q, c in g_hilt(0.1, (W_LEATHER, W_LEATHER * 1.2, np.array([0.14, 0.2, 0.42]), np.array([0.14, 0.2, 0.42]), np.array([0.42, 0.1, 0.12]))[tier - 1], cap, 12, flat=0.031)]
    parts += [(p + np.array([0, 0.012, 0]), q, c) for p, q, c in [w_gem((0, 0.1, 0.03), 0.02, cap, stretch=0.9)]]
    if tier >= 3:
        glow.append(w_gem((0, 0.1, 0.048), 0.018, (1, 1, 1)))
    nock = np.array([0, 0, -(belly * 0.8 + 0.03) - 0.56 * pull])
    string = glow if tier >= 4 else parts
    tone = (1, 1, 1) if tier >= 4 else np.array([0.84, 0.82, 0.72])
    for tip in tips:
        string.append(w_rod(np.linspace(tip, nock, 8), 0.0075, tone, sides=4, hard=False))
    if not glow:
        glow.append(w_rod([(0, 0.0, 0.03), (0, 0.001, 0.03)], 0.0004, (1, 1, 1), sides=3))
    return parts, glow


def weapon_bows():
    frames = 8
    for tier in range(1, 6):
        hue = np.array(W_SUN if tier == 5 else W_RUNE)
        body, shine = [], []
        baked = None
        for f in range(frames):
            parts, glow = g_bow_parts(tier, f / (frames - 1))
            pos, quads, col = merged(parts)
            if baked is None:
                baked = g_bake(pos, quads, col, 0.07)
            body.append((pos, baked))
            gpos, gquads, _ = merged(glow)
            shine.append((gpos, rgba(np.tile(hue, (len(gpos), 1)), np.ones(len(gpos)))))
        save(f"weapon_bow_{tier}_body", body, quads)
        save(f"weapon_bow_{tier}_glow", shine, gquads)


# ---------------------------------------------------------------- латные перчатки

def g_square(y, wide, deep, count=32, power=0.42):
    """Скруглённый квадрат: сечение точно по руке игрока, у которой четыре угла."""
    a = np.linspace(0, TAU, count, endpoint=False)
    c, s = np.cos(a), np.sin(a)
    return np.stack([np.sign(c) * np.abs(c) ** power * wide, np.full(count, y), np.sign(s) * np.abs(s) ** power * deep], axis=1)


def g_plate(y0, y1, wide, deep, color, flare=0.012, seed=1):
    """Кольцевая пластина наруча: край отогнут наружу, поэтому пластины ложатся внахлёст."""
    rows = [(y0, 1.0 + flare / wide * 1.4), (y0 - 0.006, 1.0 + flare / wide), (y0 * 0.5 + y1 * 0.5, 1.0), (y1, 0.98)]
    rings = [g_square(y, wide * k, deep * k, 32) for y, k in rows]
    return w_loft(rings, color, seed, hard=False, caps=False)


def g_finger(x, length, width, curl, plate, soft, seed, spike=None):
    """Палец из трёх сегментов брони с мягким суставом между ними."""
    parts = []
    at = np.array([x, -0.14, 0.04])
    angle = 0.1
    for i, share in enumerate((0.42, 0.34, 0.24)):
        step = length * share
        way = np.array([0, -math.cos(angle), -math.sin(angle)])
        end = at + way * step
        w = width * (1 - 0.13 * i)
        rings = []
        for k, r in ((0.0, 0.72), (0.1, 1.0), (0.82, 1.0), (1.0, 0.7)):
            c = at + way * step * k
            rings.append(w_ring(c, (1, 0, 0), np.cross(way, (1, 0, 0)), w * r, 8))
        parts.append(w_loft(rings, plate, seed + i, hard=True))
        parts.append(w_rod([at - way * 0.008, at + way * 0.008], width * 0.74, soft, sides=6))
        at = end
        angle += curl
    return parts, at, way


def g_gauntlet(tier, plate, trim, soft, kind):
    parts, glow = [], []
    wide, deep = 0.158, 0.156
    # Наруч из накладывающихся пластин.
    lames = ((0.13, 0.078), (0.085, 0.034), (0.04, -0.012), (-0.005, -0.06))
    for i, (a, b) in enumerate(lames):
        parts.append(g_plate(a, b, wide + 0.005 * (3 - i) + 0.002 * tier, deep + 0.005 * (3 - i) + 0.002 * tier, plate * (1.05 - 0.04 * i), seed=50 + i))
    edge_a = np.linspace(0, TAU, 40)
    top = g_square(0.14, wide + 0.024, deep + 0.024, 40)
    parts.append(w_rod(np.vstack([top, top[:1]]), 0.0105, trim, sides=6))
    if tier >= 2:
        mid = g_square(0.04, wide + 0.016, deep + 0.016, 40)
        parts.append(w_rod(np.vstack([mid, mid[:1]]), 0.0065, trim, sides=5))
    # Кисть: ладонь мягкая, тыл закрыт выпуклой пластиной.
    palm = [(-0.04, 0.156, 0.156), (-0.1, 0.156, 0.15), (-0.14, 0.15, 0.13), (-0.168, 0.12, 0.07)]
    parts.append(w_loft([g_square(y, w, d, 24) for y, w, d in palm], soft, 60, hard=False))
    back_rows = np.linspace(-0.05, -0.15, 8)
    back_u = np.linspace(-1, 1, 11)
    back = []
    for y in back_rows:
        back.append(np.stack([back_u * 0.16, np.full(11, y), 0.185 - 0.05 * back_u ** 2 + 0.05 * (y + 0.1)], axis=1))
    bpos = np.concatenate(back)
    bquads = grid(11, 8, wrap=False)
    parts.append((bpos, bquads[:, ::-1] if np.cross(bpos[1] - bpos[0], bpos[11] - bpos[0])[2] < 0 else bquads, w_paint(bpos, plate * 1.1, 61)))
    parts += g_rivets([(-0.13, -0.06, 0.176), (0.13, -0.06, 0.176), (-0.14, -0.14, 0.16), (0.14, -0.14, 0.16)], 0.0095, trim)
    tips = []
    for i, x in enumerate((-0.122, -0.042, 0.042, 0.122)):
        finger, tip, way = g_finger(x, 0.2 + (0.035 if i in (1, 2) else 0), 0.037, 0.3, plate * 1.08, soft, 70 + i * 3)
        parts += finger
        tips.append((tip, way))
        knuckle = [w_ring((x, -0.15 + d, 0.135), (1, 0, 0), (0, 1, 0.1), r, 6) for d, r in ((0.024, 0.016), (0.0, 0.036), (-0.024, 0.016))]
        parts.append(w_loft(knuckle, trim, 80 + i, hard=True))
    thumb = w_bezier((0.15, -0.05, 0.02), (0.205, -0.09, -0.03), (0.18, -0.175, -0.07), 12)
    parts.append(w_rod(thumb, np.linspace(0.042, 0.03, 12), plate * 1.05, sides=8))
    parts.append(w_rod(thumb[3:8] + np.array([0.004, 0, 0.012]), 0.03, trim, sides=6))
    if kind == "dark":
        if tier >= 2:
            for i, x in enumerate((-0.122, -0.042, 0.042, 0.122)):
                base = np.array([x, -0.15, 0.16])
                parts.append(w_rod(np.linspace(base, base + np.array([0, -0.01, 0.05 + 0.01 * tier]), 7), np.linspace(0.016, 0.0015, 7), W_DARKSTEEL * 1.6, sides=5, hard=True))
        if tier >= 3:
            for x in (-0.09, 0.09):
                glow.append(w_rod([(x, 0.12, 0.2), (x * 1.3, 0.08, 0.2), (x * 0.8, 0.04, 0.197), (x * 1.1, -0.01, 0.19)], 0.006, (1, 1, 1), sides=4, hard=True))
            glow.append(w_gem((0, -0.09, 0.188), 0.03, (1, 1, 1), stretch=1.3))
        if tier >= 4:
            for tip, way in tips:
                far = tip + way * (0.09 + 0.02 * (tier - 4))
                parts.append(w_rod(w_bezier(tip, tip * 0.45 + far * 0.55 + np.array([0, 0, 0.018]), far, 8), np.linspace(0.024, 0.002, 8), W_DARKSTEEL * 1.7, sides=5, hard=True))
        if tier == 5:
            for k in range(7):
                b = k / 7 * TAU
                root = np.array([math.cos(b) * 0.19, 0.1, math.sin(b) * 0.19])
                tip = root * 1.5 + np.array([0, 0.11, 0])
                parts.append(w_rod(np.linspace(root, tip, 7), np.linspace(0.02, 0.002, 7), W_DARKSTEEL * 1.4, sides=5, hard=True))
    else:
        if tier >= 2:
            v = np.linspace(0, TAU, 30)
            parts.append(w_rod(np.stack([np.cos(v) * 0.05, -0.095 + np.sin(v) * 0.05, np.full(30, 0.19 - 0.05 * (np.cos(v) * 0.05 / 0.16) ** 2)], axis=1), 0.0065, trim, sides=5))
        if tier >= 3:
            for k in range(10):
                b = k / 10 * TAU
                inner = np.array([math.cos(b) * 0.03, -0.095 + math.sin(b) * 0.03, 0.2])
                outer = np.array([math.cos(b) * (0.05 if k % 2 else 0.07), -0.095 + math.sin(b) * (0.05 if k % 2 else 0.07), 0.2])
                glow.append(w_rod([inner, outer], 0.0055, (1, 1, 1), sides=4, hard=True))
            glow.append(w_gem((0, -0.095, 0.196), 0.024, (1, 1, 1), stretch=1.0))
        if tier >= 4:
            for side in (-1, 1):
                for i in range(4):
                    root = np.array([side * 0.185, 0.12 - 0.04 * i, 0.03])
                    tip = root + np.array([side * (0.15 + 0.03 * i), 0.14 - 0.02 * i, -0.03])
                    parts.append(g_rod(w_bezier(root, root * 0.45 + tip * 0.55 + np.array([0, 0.05, 0]), tip, 12), np.array([0.006, 0.018, 0.028, 0.034, 0.036, 0.034, 0.03, 0.026, 0.02, 0.014, 0.008, 0.002]), np.full(12, 0.005), W_CLOTH, along=(0, 1, 0.2)))
        if tier == 5:
            b = np.linspace(0, TAU, 40)
            glow.append(w_rod(np.stack([np.cos(b) * 0.29, np.full(40, 0.07), np.sin(b) * 0.29], axis=1), 0.008, (1, 1, 1), sides=4))
    if not glow:
        glow.append(w_rod([(0, -0.07, 0.19), (0, -0.069, 0.19)], 0.0004, (1, 1, 1), sides=3))
    return parts, glow


def weapon_gloves():
    black = W_DARKSTEEL * 0.72
    for name, plates, trims, soft, hue in (
            ("dark", [black * 1.3, black * 1.25, black * 1.2, black * 1.15, black * 1.1],
             [W_IRON * 0.9, W_IRON, W_DARKSTEEL * 1.5, np.array([0.5, 0.36, 0.72]), np.array([0.58, 0.32, 0.86])], W_DARKLEATHER * 1.4, W_VIOLET),
            ("light", [W_CLOTH * 0.92, W_CLOTH * 0.96, W_CLOTH, W_CLOTH, W_CLOTH * 1.03],
             [W_SILVER, W_GOLD * 0.9, W_GOLD, W_GOLD, W_GOLD * 1.05], W_CLOTH * 0.82, W_SUN)):
        for tier in range(1, 6):
            parts, glow = g_gauntlet(tier, plates[tier - 1], trims[tier - 1], soft, name)
            pos, quads, col = g_finish(parts, 0.09)
            save(f"weapon_glove_{name}_{tier}_body", [(pos, col)], quads)
            frames, frame_quads = w_glow_frames(glow, hue, 12)
            save(f"weapon_glove_{name}_{tier}_glow", frames, frame_quads)
