# Рендерит зацикленные 3D-ядра стихий.
# Запуск: blender -b --factory-startup -P orbs.py
import math
import os
import random

import bpy

OUT = r"D:\Rudnik\art\orbs"
FRAMES = 24
SIZE = 256


def clean():
    bpy.ops.wm.read_factory_settings(use_empty=True)


def setup_render():
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 48
    scene.cycles.use_denoising = False
    scene.render.resolution_x = SIZE
    scene.render.resolution_y = SIZE
    scene.render.film_transparent = True
    scene.render.image_settings.file_format = "PNG"
    scene.render.image_settings.color_mode = "RGBA"
    scene.view_settings.view_transform = "Standard"
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        for kind in ("OPTIX", "CUDA"):
            try:
                prefs.compute_device_type = kind
                prefs.get_devices()
                usable = [d for d in prefs.devices if d.type == kind]
                if usable:
                    for device in prefs.devices:
                        device.use = device.type == kind
                    scene.cycles.device = "GPU"
                    print("Рендер на", kind)
                    break
            except TypeError:
                continue
    except KeyError:
        pass

    world = bpy.data.worlds.new("World")
    world.use_nodes = True
    world.node_tree.nodes["Background"].inputs[0].default_value = (0.02, 0.03, 0.05, 1)
    scene.world = world

    camera = bpy.data.cameras.new("Camera")
    camera.type = "ORTHO"
    camera.ortho_scale = 4.4
    obj = bpy.data.objects.new("Camera", camera)
    scene.collection.objects.link(obj)
    obj.location = (0, -8, 0)
    obj.rotation_euler = (math.radians(90), 0, 0)
    scene.camera = obj

    for name, kind, energy, where in (
        ("Key", "SUN", 3.0, (math.radians(55), 0, math.radians(35))),
        ("Fill", "SUN", 0.8, (math.radians(100), 0, math.radians(-60))),
    ):
        light = bpy.data.lights.new(name, kind)
        light.energy = energy
        lamp = bpy.data.objects.new(name, light)
        scene.collection.objects.link(lamp)
        lamp.rotation_euler = where


def material(name):
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    return mat, mat.node_tree


def emission_noise(name, dark, bright, strength, scale=3.0, low=0.38, high=0.68):
    mat, tree = material(name)
    nodes, links = tree.nodes, tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    emit = nodes.new("ShaderNodeEmission")
    coords = nodes.new("ShaderNodeTexCoord")
    noise = nodes.new("ShaderNodeTexNoise")
    noise.inputs["Scale"].default_value = scale
    noise.inputs["Detail"].default_value = 7
    noise.inputs["Distortion"].default_value = 1.2
    ramp = nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.elements[0].position = low
    ramp.color_ramp.elements[0].color = (*dark, 1)
    ramp.color_ramp.elements[1].position = high
    ramp.color_ramp.elements[1].color = (*bright, 1)
    links.new(coords.outputs["Object"], noise.inputs["Vector"])
    links.new(noise.outputs["Fac"], ramp.inputs["Fac"])
    links.new(ramp.outputs["Color"], emit.inputs["Color"])
    emit.inputs["Strength"].default_value = strength
    links.new(emit.outputs[0], out.inputs["Surface"])
    return mat


def solid(name, color, roughness=0.6, metallic=0.0, glow=None, strength=0.0, transmission=0.0):
    mat, tree = material(name)
    shader = next(n for n in tree.nodes if n.type == "BSDF_PRINCIPLED")
    shader.inputs["Base Color"].default_value = (*color, 1)
    shader.inputs["Roughness"].default_value = roughness
    shader.inputs["Metallic"].default_value = metallic
    if "Transmission Weight" in shader.inputs:
        shader.inputs["Transmission Weight"].default_value = transmission
    if glow:
        shader.inputs["Emission Color"].default_value = (*glow, 1)
        shader.inputs["Emission Strength"].default_value = strength
    return mat


def rock_with_veins(name, stone, vein, strength):
    mat, tree = material(name)
    nodes, links = tree.nodes, tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    shader = nodes.new("ShaderNodeBsdfPrincipled")
    shader.inputs["Base Color"].default_value = (*stone, 1)
    shader.inputs["Roughness"].default_value = 0.85
    coords = nodes.new("ShaderNodeTexCoord")
    voronoi = nodes.new("ShaderNodeTexVoronoi")
    voronoi.feature = "DISTANCE_TO_EDGE"
    voronoi.inputs["Scale"].default_value = 2.6
    ramp = nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.elements[0].position = 0.0
    ramp.color_ramp.elements[0].color = (1, 1, 1, 1)
    ramp.color_ramp.elements[1].position = 0.05
    ramp.color_ramp.elements[1].color = (0, 0, 0, 1)
    shader.inputs["Emission Color"].default_value = (*vein, 1)
    links.new(coords.outputs["Object"], voronoi.inputs["Vector"])
    links.new(voronoi.outputs["Distance"], ramp.inputs["Fac"])
    math_node = nodes.new("ShaderNodeMath")
    math_node.operation = "MULTIPLY"
    math_node.inputs[1].default_value = strength
    links.new(ramp.outputs["Color"], math_node.inputs[0])
    links.new(math_node.outputs[0], shader.inputs["Emission Strength"])
    links.new(shader.outputs[0], out.inputs["Surface"])
    return mat


def halo(color, size, strength):
    mat, tree = material("Halo")
    nodes, links = tree.nodes, tree.links
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    mix = nodes.new("ShaderNodeMixShader")
    clear = nodes.new("ShaderNodeBsdfTransparent")
    emit = nodes.new("ShaderNodeEmission")
    emit.inputs["Color"].default_value = (*color, 1)
    emit.inputs["Strength"].default_value = strength
    coords = nodes.new("ShaderNodeTexCoord")
    gradient = nodes.new("ShaderNodeTexGradient")
    gradient.gradient_type = "SPHERICAL"
    power = nodes.new("ShaderNodeMath")
    power.operation = "POWER"
    power.inputs[1].default_value = 2.4
    links.new(coords.outputs["Object"], gradient.inputs["Vector"])
    links.new(gradient.outputs["Fac"], power.inputs[0])
    links.new(power.outputs[0], mix.inputs[0])
    links.new(clear.outputs[0], mix.inputs[1])
    links.new(emit.outputs[0], mix.inputs[2])
    links.new(mix.outputs[0], out.inputs["Surface"])
    bpy.ops.mesh.primitive_plane_add(size=2, location=(0, 1.8, 0), rotation=(math.radians(90), 0, 0))
    plane = bpy.context.object
    plane.scale = (size, size, size)
    plane.data.materials.append(mat)
    plane.visible_shadow = False


def core(mat, radius=1.0, bumpy=0.0):
    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=5, radius=radius)
    obj = bpy.context.object
    bpy.ops.object.shade_smooth()
    if bumpy:
        texture = bpy.data.textures.new("Bumps", "CLOUDS")
        texture.noise_scale = 0.55
        mod = obj.modifiers.new("Displace", "DISPLACE")
        mod.texture = texture
        mod.strength = bumpy
    obj.data.materials.append(mat)
    return obj


def pivot(tilt):
    empty = bpy.data.objects.new("Pivot", None)
    bpy.context.scene.collection.objects.link(empty)
    empty.rotation_euler = tilt
    spin = bpy.data.objects.new("Spin", None)
    bpy.context.scene.collection.objects.link(spin)
    spin.parent = empty
    return spin


def ring_of_blocks(mat, count, radius, size, tilt, seed, kind="cube"):
    spin = pivot(tilt)
    rnd = random.Random(seed)
    for i in range(count):
        angle = math.tau * i / count
        where = (math.cos(angle) * radius, math.sin(angle) * radius, rnd.uniform(-0.1, 0.1))
        scale = size * rnd.uniform(0.7, 1.25)
        if kind == "cube":
            bpy.ops.mesh.primitive_cube_add(size=scale, location=where)
            obj = bpy.context.object
            bevel = obj.modifiers.new("Bevel", "BEVEL")
            bevel.width = scale * 0.12
            bevel.segments = 2
            obj.rotation_euler = [rnd.uniform(0, math.tau) for _ in range(3)]
        else:
            bpy.ops.mesh.primitive_uv_sphere_add(radius=scale * 0.6, location=where, segments=24, ring_count=16)
            obj = bpy.context.object
            bpy.ops.object.shade_smooth()
        obj.data.materials.append(mat)
        obj.parent = spin
    return spin


def ribbon(mat, radius, thickness, tilt):
    spin = pivot(tilt)
    bpy.ops.mesh.primitive_torus_add(major_radius=radius, minor_radius=thickness, major_segments=96, minor_segments=12)
    obj = bpy.context.object
    bpy.ops.object.shade_smooth()
    obj.scale = (1, 1, 0.45)
    obj.data.materials.append(mat)
    obj.parent = spin
    return spin


def build(element):
    tilt_a = (math.radians(74), math.radians(12), 0)
    tilt_b = (math.radians(104), math.radians(-18), 0)
    spins = []
    if element == "fire":
        halo((1.0, 0.33, 0.06), 2.1, 2.0)
        body = core(emission_noise("Fire", (0.42, 0.03, 0.0), (1.0, 0.5, 0.06), 1.5, 3.2, 0.34, 0.66), 0.95, 0.14)
        ember = solid("Ember", (0.1, 0.03, 0.01), glow=(1.0, 0.3, 0.04), strength=1.6)
        spins.append((ring_of_blocks(ember, 12, 1.48, 0.17, tilt_a, 3), 1))
        spins.append((ring_of_blocks(ember, 9, 1.72, 0.1, tilt_b, 4), -2))
    elif element == "water":
        halo((0.08, 0.46, 1.0), 2.1, 1.7)
        body = core(emission_noise("Water", (0.005, 0.07, 0.34), (0.2, 0.62, 1.0), 1.25, 2.2, 0.35, 0.72), 0.95, 0.08)
        drop = solid("Drop", (0.2, 0.5, 0.9), 0.08, glow=(0.1, 0.45, 1.0), strength=1.0)
        spins.append((ring_of_blocks(drop, 10, 1.5, 0.24, tilt_a, 5, "sphere"), 1))
        spins.append((ring_of_blocks(drop, 7, 1.72, 0.14, tilt_b, 6, "sphere"), -1))
    elif element == "earth":
        halo((0.35, 0.75, 0.16), 2.0, 0.9)
        body = core(rock_with_veins("Stone", (0.32, 0.26, 0.19), (0.4, 1.0, 0.15), 2.2), 0.98, 0.3)
        stone = solid("Rock", (0.36, 0.3, 0.22), 0.9)
        moss = solid("Moss", (0.2, 0.42, 0.1), 0.9, glow=(0.4, 0.9, 0.15), strength=0.5)
        spins.append((ring_of_blocks(stone, 9, 1.5, 0.3, tilt_a, 7), 1))
        spins.append((ring_of_blocks(moss, 7, 1.72, 0.16, tilt_b, 8), -1))
    else:
        halo((0.72, 0.86, 1.0), 2.1, 1.2)
        body = core(emission_noise("Air", (0.2, 0.34, 0.5), (0.82, 0.93, 1.0), 1.0, 1.8, 0.3, 0.7), 0.74, 0.05)
        wind = solid("Wind", (0.6, 0.72, 0.85), 0.3, glow=(0.62, 0.8, 1.0), strength=0.8)
        spins.append((ribbon(wind, 1.2, 0.05, tilt_a), 2))
        spins.append((ribbon(wind, 1.46, 0.04, tilt_b), -2))
        spins.append((ribbon(wind, 1.72, 0.03, (math.radians(60), math.radians(40), 0)), 1))
        spins.append((ring_of_blocks(wind, 8, 1.92, 0.07, tilt_a, 9), 1))
    return body, spins


def render(element):
    clean()
    setup_render()
    body, spins = build(element)
    folder = os.path.join(OUT, element)
    os.makedirs(folder, exist_ok=True)
    scene = bpy.context.scene
    for frame in range(FRAMES):
        turn = math.tau * frame / FRAMES
        body.rotation_euler = (0, 0, turn)
        for spin, speed in spins:
            spin.rotation_euler = (0, 0, turn * speed)
        bpy.context.view_layer.update()
        scene.render.filepath = os.path.join(folder, f"{frame:02d}.png")
        bpy.ops.render.render(write_still=True)
    print("Готово:", element)


for name in ("fire", "water", "earth", "air"):
    render(name)
print("ВСЕ ЯДРА ГОТОВЫ")
