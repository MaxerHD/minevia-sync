# Оружие стилей: меч, лук и перчатки, по пять ступеней. Рядом разрезы, стрела силы и огромная волна.
# У каждой вещи два слоя: *_body твёрдый и освещается миром, *_glow светится сам.

W_STEEL = np.array([0.72, 0.76, 0.82])
W_DARKSTEEL = np.array([0.30, 0.33, 0.40])
W_IRON = np.array([0.40, 0.42, 0.45])
W_BRONZE = np.array([0.70, 0.46, 0.20])
W_GOLD = np.array([0.95, 0.74, 0.30])
W_SILVER = np.array([0.82, 0.85, 0.90])
W_LEATHER = np.array([0.34, 0.20, 0.11])
W_DARKLEATHER = np.array([0.15, 0.11, 0.17])
W_WOOD = np.array([0.46, 0.29, 0.15])
W_CLOTH = np.array([0.92, 0.92, 0.88])
W_RUNE = (0.15, 0.68, 1.0)
W_VIOLET = (0.62, 0.16, 1.0)
W_SUN = (1.0, 0.78, 0.26)


def w_paint(pos, color, seed=1, grain=0.08):
    """Материал вершины: цвет с лёгкой неровностью, чтобы поверхность не была пластиковой."""
    noise = np.sin(pos[:, 0] * 91 + seed) * np.sin(pos[:, 1] * 53 + seed * 2) * np.sin(pos[:, 2] * 77 + seed * 3)
    return rgba(np.clip(np.asarray(color)[None, :] * (1 + grain * noise)[:, None], 0, 1), np.ones(len(pos)))


def w_orient(pos, quads, centers):
    """Разворачивает грани от оси детали: твёрдый слой не рисует обратную сторону."""
    a, b, c = pos[quads[:, 0]], pos[quads[:, 1]], pos[quads[:, 2]]
    normal = np.cross(b - a, c - a)
    mid = pos[quads].mean(axis=1)
    flip = np.sum(normal * (mid - centers), axis=1) < 0
    out = quads.copy()
    out[flip] = out[flip][:, ::-1]
    return out


def w_loft(rings, color, seed=1, hard=True, caps=True):
    """Тело по сечениям. hard: у каждой грани свои вершины, поэтому рёбра острые. color: цвет или функция (pos, сторона, доля длины)."""
    rings = [np.asarray(r, dtype=float) for r in rings]
    n, k = len(rings), len(rings[0])
    pos, quads, centers, tone = [], [], [], []
    if hard:
        for side in range(k):
            base = len(pos)
            for i, ring in enumerate(rings):
                pos.append(ring[side])
                pos.append(ring[(side + 1) % k])
                tone.append((side, i / max(1, n - 1)))
                tone.append((side, i / max(1, n - 1)))
            for i in range(n - 1):
                a = base + i * 2
                quads.append((a, a + 1, a + 3, a + 2))
                centers.append((rings[i].mean(axis=0) + rings[i + 1].mean(axis=0)) / 2)
    else:
        for i, ring in enumerate(rings):
            for j in range(k):
                pos.append(ring[j])
                tone.append((j, i / max(1, n - 1)))
        for i in range(n - 1):
            for j in range(k):
                a, b = i * k + j, i * k + (j + 1) % k
                quads.append((a, b, b + k, a + k))
                centers.append((rings[i].mean(axis=0) + rings[i + 1].mean(axis=0)) / 2)
    pos = np.array(pos)
    tone = np.array(tone)
    if caps:
        for ring, outward in ((rings[0], rings[0].mean(axis=0) - rings[1].mean(axis=0)), (rings[-1], rings[-1].mean(axis=0) - rings[-2].mean(axis=0))):
            base = len(pos)
            middle = ring.mean(axis=0)
            pos = np.vstack([pos, ring, middle[None, :]])
            tone = np.vstack([tone, np.tile([0.0, 0.0 if ring is rings[0] else 1.0], (k + 1, 1))])
            for j in range(k):
                a, b = base + j, base + (j + 1) % k
                quads.append((a, b, base + k, base + k))
                centers.append(middle - outward)
    quads = w_orient(pos, np.array(quads, dtype=np.int32), np.array(centers))
    col = color(pos, tone[:, 0], tone[:, 1]) if callable(color) else w_paint(pos, color, seed)
    return pos, quads, col


def w_ring(center, u, v, radius, sides):
    """Сечение: точки по кругу в плоскости двух векторов."""
    angle = np.linspace(0, TAU, sides, endpoint=False)
    r = np.broadcast_to(radius, (sides,))
    return np.asarray(center)[None, :] + (np.cos(angle) * r)[:, None] * np.asarray(u)[None, :] + (np.sin(angle) * r)[:, None] * np.asarray(v)[None, :]


def w_rod(path, radius, color, sides=8, seed=1, hard=False):
    """Стержень вдоль пути. radius: число или список по точкам."""
    path = np.asarray(path, dtype=float)
    radius = np.broadcast_to(np.asarray(radius, dtype=float), (len(path),))
    rings = []
    for i, at in enumerate(path):
        way = path[min(i + 1, len(path) - 1)] - path[max(i - 1, 0)]
        way /= max(1e-9, np.linalg.norm(way))
        other = np.array([0.0, 0.0, 1.0]) if abs(way[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
        u = np.cross(way, other)
        u /= np.linalg.norm(u)
        rings.append(w_ring(at, u, np.cross(way, u), radius[i], sides))
    return w_loft(rings, color, seed, hard=hard)


def w_gem(at, size, color, stretch=1.6):
    """Огранённый камень."""
    at = np.asarray(at, dtype=float)
    sides = 6
    rings = [w_ring(at + np.array([0, -size * stretch, 0]), (1, 0, 0), (0, 0, 1), size * 0.04, sides),
             w_ring(at, (1, 0, 0), (0, 0, 1), size, sides),
             w_ring(at + np.array([0, size * stretch, 0]), (1, 0, 0), (0, 0, 1), size * 0.04, sides)]
    return w_loft(rings, color, 3)


def w_bezier(a, b, c, count):
    t = np.linspace(0, 1, count)[:, None]
    a, b, c = (np.asarray(p, dtype=float) for p in (a, b, c))
    return (1 - t) ** 2 * a + 2 * t * (1 - t) * b + t ** 2 * c


def w_mirror(part):
    pos, quads, col = part
    return pos * np.array([-1, 1, 1]), quads[:, ::-1], col


# ---------------------------------------------------------------- меч

def w_blade(length, width, thick, fuller, curve=0.0, serrate=0.0, seed=1, metal=W_STEEL):
    """Клинок: ромбическое сечение с долом, острые грани, светлая кромка заточки и волнистый рисунок стали."""
    count = 34
    t = np.linspace(0, 1, count)
    # Ширина: у гарды плечи, ближе к острию плавное сужение, само острие короткое.
    profile = np.minimum(1.0, (1 - t) * 5.2) ** 0.75 * (1 - 0.3 * t ** 1.5) * (0.92 + 0.08 * np.minimum(1.0, t * 12))
    notch = 1 - serrate * (np.abs(np.sin(t * 30)) ** 2) * (t < 0.42)
    half = width * profile * notch
    body = thick * np.maximum(0.05, profile)
    rings = []
    for i in range(count):
        y = 0.1 + t[i] * length
        x = curve * t[i] ** 2
        w, h = max(half[i], 0.002), max(body[i], 0.0012)
        groove = fuller * (1 - np.clip((t[i] - 0.62) / 0.2, 0, 1))
        ring = [(w, 0), (0.42 * w, h), (0.17 * w, h * (1 - 0.75 * groove)), (-0.17 * w, h * (1 - 0.75 * groove)), (-0.42 * w, h), (-w, 0),
                (-0.42 * w, -h), (-0.17 * w, -h * (1 - 0.75 * groove)), (0.17 * w, -h * (1 - 0.75 * groove)), (0.42 * w, -h)]
        rings.append(np.array([(x + a, y, b) for a, b in ring]))
    wave = Flow(seed, freq=9.0, octaves=3, gain=0.6, speed=0)

    def colour(pos, side, along):
        # Стороны 0, 4, 5, 9 это заточка: она светлее, дол темнее, по плоскости идёт рисунок стали.
        edge = np.isin(side, (0, 4, 5, 9))
        valley = np.isin(side, (2, 7))
        pattern = 0.5 + 0.5 * np.sin(pos[:, 1] * 38 + 6 * wave(pos * 2, 0.0))
        shade = 0.82 + 0.16 * pattern + 0.24 * edge - 0.3 * valley
        return rgba(np.clip(metal[None, :] * shade[:, None], 0, 1), np.ones(len(pos)))

    return w_loft(rings, colour, seed, hard=True)


def w_grip(length, radius, wrap, metal, wraps=9):
    """Рукоять с обмоткой: валики ложатся витками, между ними тень."""
    y = np.linspace(-length, 0.08, 34)
    swell = radius * (1 + 0.16 * np.sin((y + length) / (length + 0.08) * math.pi))
    rings = [w_ring((0, yy, 0), (1, 0, 0), (0, 0, 1), r * (1 + 0.1 * math.sin(yy * wraps * TAU / length)), 10) for yy, r in zip(y, swell)]

    def colour(pos, side, along):
        ridge = 0.5 + 0.5 * np.sin(pos[:, 1] * wraps * TAU / length + np.arctan2(pos[:, 2], pos[:, 0]))
        return rgba(np.clip(wrap[None, :] * (0.62 + 0.6 * ridge)[:, None], 0, 1), np.ones(len(pos)))

    return w_loft(rings, colour, hard=False)


def w_guard(span, drop, thick, metal, wings=False):
    """Гарда: кованая перекладина, концы уходят вниз или вверх, в середине утолщение."""
    parts = []
    for side in (-1, 1):
        far = np.array([side * span, drop, 0])
        path = w_bezier((0, 0.06, 0), (side * span * 0.6, 0.05, 0), far, 12)
        radius = np.linspace(thick, thick * 0.42, 12)
        parts.append(w_rod(path, radius, metal, sides=6, hard=True))
        parts.append(w_gem(far, thick * 0.6, metal * 1.05, stretch=1.2))
        if wings:
            for i, lift in enumerate((0.1, 0.18, 0.26)):
                tip = np.array([side * (span * (0.95 - 0.1 * i) + 0.08), 0.1 + lift, 0])
                root = np.array([side * span * (0.32 + 0.16 * i), 0.07, 0])
                parts.append(w_rod(w_bezier(root, root * 0.5 + tip * 0.5 + np.array([0, 0.06, 0]), tip, 8), np.linspace(0.024, 0.004, 8), metal * (1.05 - 0.05 * i), sides=5, hard=True))
    collar = [w_ring((0, y, 0), (1, 0, 0), (0, 0, 1), r, 8) for y, r in ((0.0, thick * 1.1), (0.06, thick * 1.5), (0.12, thick * 1.0))]
    parts.append(w_loft(collar, metal, 4))
    return parts


def w_pommel(y, size, metal):
    rings = [w_ring((0, y + size * d, 0), (1, 0, 0), (0, 0, 1), size * r, 8) for d, r in ((1.0, 0.3), (0.6, 0.8), (0.0, 1.0), (-0.6, 0.8), (-1.0, 0.18))]
    return w_loft(rings, metal, 5)


def w_runes(length, width, count, seed):
    """Руны в доле клинка: короткие штрихи разной формы на обеих сторонах."""
    rng = np.random.default_rng(seed)
    parts = []
    for i in range(count):
        y = 0.24 + (length * 0.62) * i / max(1, count - 1)
        for z in (-1, 1):
            for _ in range(2):
                a = np.array([rng.uniform(-1, 1) * width * 0.13, y + rng.uniform(-0.016, 0.016), z * 0.0105])
                b = a + np.array([rng.uniform(-1, 1) * width * 0.16, rng.uniform(0.02, 0.045), 0])
                parts.append(w_rod([a, b], 0.0048, (1, 1, 1), sides=4, hard=True))
    return parts


def w_edge_line(length, width, curve):
    """Светящаяся кромка лезвия."""
    t = np.linspace(0.05, 0.97, 22)
    profile = np.minimum(1.0, (1 - t) * 5.2) ** 0.75 * (1 - 0.3 * t ** 1.5)
    parts = []
    for side in (-1, 1):
        path = np.stack([curve * t ** 2 + side * (width * profile + 0.0015), 0.1 + t * length, t * 0], axis=1)
        parts.append(w_rod(path, 0.0075, (1, 1, 1), sides=4, hard=True))
    return parts


def w_glow_frames(parts, hue, frames, shards=None):
    """Кадры светящегося слоя: цвет пульсирует, осколки кружат вокруг гарды."""
    pos, quads, _ = merged(parts)
    pulse = Flow(61, freq=7.0, octaves=2, speed=1)
    result = []
    hot = np.array(hue)
    extra_pos, extra_quads = None, None
    if shards:
        extra_quads = faces([(len(pos), quads)] + [(len(p), q) for p, q, _ in shards])
    for f in range(frames):
        t = f / frames
        n = pulse(pos, t)
        rgb = np.clip(hot[None, :] * (0.82 + 0.3 * n)[:, None], 0, 1)
        if shards:
            spots, colors = [pos], [rgba(rgb, np.ones(len(pos)))]
            for i, (p, q, _) in enumerate(shards):
                angle = TAU * (t + i / len(shards))
                center = np.array([math.cos(angle) * 0.2, 0.16 + 0.03 * math.sin(angle * 2), math.sin(angle) * 0.2])
                spots.append(p @ rotation((0, 1, 0), angle).T + center)
                colors.append(rgba(np.tile(hot, (len(p), 1)), np.ones(len(p))))
            result.append((np.concatenate(spots), np.concatenate(colors)))
        else:
            result.append((pos, rgba(rgb, np.ones(len(pos)))))
    return result, (extra_quads if shards else quads)


def weapon_swords():
    plans = [
        dict(length=1.02, width=0.062, thick=0.012, fuller=0.0, metal=W_IRON * 1.45, guard=(0.14, 0.05, 0.022, W_IRON), wrap=W_LEATHER, pommel=W_IRON),
        dict(length=1.10, width=0.074, thick=0.013, fuller=0.8, metal=W_STEEL, guard=(0.18, -0.04, 0.026, W_BRONZE), wrap=W_LEATHER * 1.1, pommel=W_BRONZE),
        dict(length=1.18, width=0.080, thick=0.014, fuller=1.0, metal=W_SILVER, guard=(0.20, -0.07, 0.028, W_SILVER), wrap=np.array([0.14, 0.2, 0.42]), pommel=W_SILVER, runes=7),
        dict(length=1.26, width=0.088, thick=0.015, fuller=1.0, metal=W_DARKSTEEL * 1.5, serrate=0.32, guard=(0.24, 0.05, 0.03, W_SILVER), wrap=np.array([0.1, 0.16, 0.34]), pommel=W_SILVER, runes=8, edge=True, wings=True),
        dict(length=1.36, width=0.096, thick=0.016, fuller=1.0, curve=0.05, metal=W_SILVER * 1.08, guard=(0.27, 0.1, 0.034, W_GOLD), wrap=np.array([0.32, 0.1, 0.12]), pommel=W_GOLD, runes=9, edge=True, wings=True, shards=5),
    ]
    for tier, plan in enumerate(plans, 1):
        parts = [w_blade(plan["length"], plan["width"], plan["thick"], plan["fuller"], plan.get("curve", 0.0), plan.get("serrate", 0.0), 700 + tier, plan["metal"])]
        span, drop, thick, metal = plan["guard"]
        parts += w_guard(span, drop, thick, metal, plan.get("wings", False))
        parts.append(w_grip(0.27, 0.026, plan["wrap"], metal))
        parts.append(w_pommel(-0.31, 0.04 + 0.004 * tier, plan["pommel"]))
        if tier >= 3:
            parts.append(w_gem((0, 0.075, 0.03), 0.018, W_SILVER))
        pos, quads, col = merged(parts)
        save(f"weapon_sword_{tier}_body", [(pos, col)], quads)
        glow = []
        if plan.get("runes"):
            glow += w_runes(plan["length"], plan["width"], plan["runes"], 710 + tier)
        if plan.get("edge"):
            glow += w_edge_line(plan["length"], plan["width"], plan.get("curve", 0.0))
        if tier >= 3:
            glow.append(w_gem((0, 0.075, 0.034), 0.02, (1, 1, 1)))
        if not glow:
            glow.append(w_rod([(0, 0.08, 0.016), (0, 0.082, 0.016)], 0.0004, (1, 1, 1), sides=3))
        shards = [w_gem((0, 0, 0), 0.016, (1, 1, 1), stretch=2.4) for _ in range(plan.get("shards", 0))] or None
        frames, frame_quads = w_glow_frames(glow, W_SUN if tier == 5 else W_RUNE, 12, shards)
        save(f"weapon_sword_{tier}_glow", frames, frame_quads)


# ---------------------------------------------------------------- лук

def w_limb_path(side, length, pull, belly, recurve):
    """Плечо лука: от рукояти к концу, при натяжении концы уходят назад."""
    s = np.linspace(0.06, 1, 22)
    y = side * length * s * (1 - 0.12 * pull)
    z = -(belly + 0.3 * pull) * s ** 1.7 + recurve * np.clip((s - 0.78) / 0.22, 0, 1) ** 2 * (1 - 0.5 * pull)
    return np.stack([s * 0, y, z], axis=1), s


def w_bow_tier(tier, pull):
    length = 0.62 + 0.05 * tier
    wood = [W_WOOD, W_WOOD * 0.8, W_DARKSTEEL * 1.3, W_DARKSTEEL * 1.1, W_GOLD * 0.85][tier - 1]
    belly = 0.18 + 0.01 * tier
    recurve = 0.0 if tier == 1 else 0.05 + 0.03 * tier
    parts, glow = [], []
    tips = []
    for side in (-1, 1):
        path, s = w_limb_path(side, length, pull, belly, recurve)
        radius = 0.03 * (1 - 0.68 * s ** 1.3) + 0.003 * tier
        parts.append(w_rod(path, radius, lambda pos, a, b, c=wood: rgba(np.clip(c[None, :] * (0.78 + 0.34 * (0.5 + 0.5 * np.sin(pos[:, 1] * 70 + np.sin(pos[:, 2] * 40))))[:, None], 0, 1), np.ones(len(pos))), sides=7, hard=False))
        tip = path[-1]
        tips.append(tip)
        cap = W_BRONZE if tier == 2 else W_SILVER if tier in (3, 4) else W_GOLD
        if tier >= 2:
            parts.append(w_rod(path[-4:], np.linspace(0.016, 0.011, 4) * 1.5, cap, sides=6, hard=True))
        if tier >= 3:
            band = path[9]
            parts.append(w_rod([band - np.array([0, 0.03 * side, 0]), band + np.array([0, 0.03 * side, 0])], 0.03, cap, sides=8, hard=True))
            glow.append(w_rod(path[6:17:1] + np.array([0, 0, 0.022]), 0.0055, (1, 1, 1), sides=4, hard=True))
        if tier >= 4:
            for k in (5, 9, 13, 17):
                root = path[k]
                fin = root + np.array([0, 0.03 * side, 0.1 - 0.003 * k])
                parts.append(w_rod(w_bezier(root, root + np.array([0, 0.0, 0.05]), fin, 6), np.linspace(0.016, 0.0015, 6), W_SILVER, sides=4, hard=True))
        if tier == 5:
            glow.append(w_gem(tip + np.array([0, 0.05 * side, 0]), 0.024, (1, 1, 1), stretch=2.0))
    # Рукоять с обмоткой и полка для стрелы.
    grip = np.linspace(-0.09, 0.09, 12)
    wrap = [W_LEATHER, W_LEATHER, np.array([0.14, 0.2, 0.42]), np.array([0.14, 0.2, 0.42]), np.array([0.34, 0.12, 0.14])][tier - 1]
    rings = [w_ring((0, y, -0.006), (1, 0, 0), (0, 0, 1), 0.034 * (1 + 0.1 * math.sin(y * 60)), 8) for y in grip]
    parts.append(w_loft(rings, lambda pos, a, b: rgba(np.clip(wrap[None, :] * (0.7 + 0.5 * (0.5 + 0.5 * np.sin(pos[:, 1] * 90)))[:, None], 0, 1), np.ones(len(pos))), hard=False))
    if tier >= 3:
        parts.append(w_gem((0, 0.12, 0.026), 0.015, W_SILVER))
        glow.append(w_gem((0, 0.12, 0.03), 0.016, (1, 1, 1)))
    # Тетива: две нити от концов к точке натяжения.
    nock = np.array([0, 0, -(belly * 0.8 + 0.03) - 0.56 * pull])
    string = glow if tier >= 4 else parts
    tone = (1, 1, 1) if tier >= 4 else np.array([0.82, 0.8, 0.72])
    for tip in tips:
        string.append(w_rod(np.linspace(tip, nock, 8), 0.0045, tone, sides=4, hard=False))
    if not glow:
        glow.append(w_rod([(0, 0.0, 0.03), (0, 0.001, 0.03)], 0.0004, (1, 1, 1), sides=3))
    return parts, glow


def weapon_bows():
    frames = 8
    for tier in range(1, 6):
        body, shine, body_quads, shine_quads = [], [], None, None
        hue = np.array(W_SUN if tier == 5 else W_RUNE)
        for f in range(frames):
            parts, glow = w_bow_tier(tier, f / (frames - 1))
            pos, quads, col = merged(parts)
            body.append((pos, col))
            body_quads = quads
            gpos, gquads, _ = merged(glow)
            shine.append((gpos, rgba(np.tile(hue, (len(gpos), 1)), np.ones(len(gpos)))))
            shine_quads = gquads
        save(f"weapon_bow_{tier}_body", body, body_quads)
        save(f"weapon_bow_{tier}_glow", shine, shine_quads)


# ---------------------------------------------------------------- перчатки

def w_finger(x, length, radius, curl, metal, seed):
    """Палец из трёх фаланг, согнут к ладони."""
    path = [np.array([x, -0.14, 0.0])]
    angle = 0.15
    for i, part in enumerate((0.45, 0.32, 0.23)):
        step = length * part
        path.append(path[-1] + np.array([0, -math.cos(angle) * step, -math.sin(angle) * step]))
        angle += curl
    points = []
    for a, b in zip(path, path[1:]):
        points += [a, a * 0.6 + b * 0.4, a * 0.2 + b * 0.8]
    points.append(path[-1])
    r = [radius * (1 - 0.3 * i / len(points)) * (1.08 if i % 3 == 0 else 0.97) for i in range(len(points))]
    return w_rod(points, r, metal, sides=7, seed=seed, hard=False), path[-1]


def w_glove(tier, cloth, trim, hue_name):
    parts, glow = [], []
    # Манжета расширяется к предплечью, ладонь плоская.
    sections = [(0.13, 0.178 + 0.004 * tier, 0.178 + 0.004 * tier), (0.07, 0.172, 0.172), (0.015, 0.168, 0.168), (-0.04, 0.17, 0.168), (-0.09, 0.172, 0.162), (-0.135, 0.158, 0.13), (-0.16, 0.12, 0.07)]
    rings = []
    for y, wide, deep in sections:
        angle = np.linspace(0, TAU, 12, endpoint=False)
        rings.append(np.stack([np.cos(angle) * wide, np.full(12, y), np.sin(angle) * deep], axis=1))
    parts.append(w_loft(rings, cloth, 20 + tier, hard=False))
    # Шов и отворот манжеты.
    angle = np.linspace(0, TAU, 28)
    edge = np.stack([np.cos(angle) * (0.182 + 0.004 * tier), np.full(28, 0.128), np.sin(angle) * (0.182 + 0.004 * tier)], axis=1)
    parts.append(w_rod(edge, 0.012 + 0.0015 * tier, trim, sides=6, hard=False))
    if tier >= 2:
        low = np.stack([np.cos(angle) * 0.172, np.full(28, 0.03), np.sin(angle) * 0.172], axis=1)
        parts.append(w_rod(low, 0.01, trim, sides=5, hard=False))
    tips = []
    for i, x in enumerate((-0.09, -0.03, 0.03, 0.09)):
        finger, tip = w_finger(x * 1.5, 0.2 + (0.03 if i in (1, 2) else 0), 0.036, 0.24, cloth, 30 + i)
        parts.append(finger)
        tips.append(tip)
        if tier >= 2:
            # Накладки на костяшки.
            parts.append(w_gem((x * 1.15, -0.12, 0.15), 0.022, trim, stretch=0.8))
    thumb = w_bezier((0.17, -0.04, -0.02), (0.235, -0.1, -0.05), (0.215, -0.2, -0.08), 9)
    parts.append(w_rod(thumb, np.linspace(0.036, 0.026, 9), cloth, sides=7, hard=False))
    tips.append(thumb[-1])
    # Тыльная пластина растёт от ступени к ступени.
    if tier >= 3:
        back = [w_ring((0, y, 0.165), (1, 0, 0), (0, 1, 0.1), r, 6) for y, r in ((-0.03, 0.03), (-0.07, 0.07), (-0.11, 0.05))]
        parts.append(w_loft(back, trim, 40))
        glow.append(w_gem((0, -0.07, 0.178), 0.03, (1, 1, 1), stretch=1.1))
    if hue_name == "dark":
        if tier >= 4:
            # Когти на пальцах.
            for tip in tips[:4]:
                far = tip + np.array([0, -0.05 - 0.02 * (tier - 3), -0.05])
                parts.append(w_rod(w_bezier(tip, tip * 0.5 + far * 0.5 + np.array([0, 0.0, 0.02]), far, 6), np.linspace(0.02, 0.002, 6), W_DARKSTEEL * 1.5, sides=5, hard=True))
        if tier >= 3:
            for x in (-0.06, 0.06):
                glow.append(w_rod([(x, 0.1, 0.184), (x * 1.2, 0.06, 0.18), (x * 0.8, 0.02, 0.176)], 0.006, (1, 1, 1), sides=4, hard=True))
    else:
        if tier >= 4:
            # Перья на манжете.
            for side in (-1, 1):
                for i in range(3):
                    root = np.array([side * 0.18, 0.12 - 0.03 * i, 0.04])
                    tip = root + np.array([side * (0.12 + 0.03 * i), 0.1 - 0.015 * i, -0.02])
                    parts.append(w_rod(w_bezier(root, root * 0.5 + tip * 0.5 + np.array([0, 0.03, 0]), tip, 7), np.array([0.008, 0.02, 0.026, 0.026, 0.02, 0.012, 0.002]), W_CLOTH, sides=5, hard=True))
        if tier >= 3:
            for k in range(8):
                angle = k / 8 * TAU
                inner = np.array([math.cos(angle) * 0.042, -0.07 + math.sin(angle) * 0.042, 0.176])
                outer = np.array([math.cos(angle) * 0.07, -0.07 + math.sin(angle) * 0.07, 0.176])
                glow.append(w_rod([inner, outer], 0.0055, (1, 1, 1), sides=4, hard=True))
    if tier == 5:
        halo = np.stack([np.cos(angle_ring := np.linspace(0, TAU, 32)) * 0.27, np.full(32, 0.07), np.sin(angle_ring) * 0.27], axis=1)
        glow.append(w_rod(halo, 0.008, (1, 1, 1), sides=4, hard=False))
    if not glow:
        glow.append(w_rod([(0, -0.07, 0.09), (0, -0.069, 0.09)], 0.0004, (1, 1, 1), sides=3))
    return parts, glow


def weapon_gloves():
    for name, cloth_by_tier, trim_by_tier, hue in (
            ("dark", [W_DARKLEATHER * 1.5, W_DARKLEATHER * 1.4, W_DARKLEATHER * 1.3, W_DARKLEATHER * 1.25, W_DARKLEATHER * 1.2],
             [W_IRON * 0.8, W_IRON, W_DARKSTEEL * 1.4, W_DARKSTEEL * 1.5, np.array([0.5, 0.36, 0.72])], W_VIOLET),
            ("light", [W_CLOTH * 0.94, W_CLOTH, W_CLOTH, W_CLOTH, W_CLOTH],
             [W_SILVER, W_GOLD * 0.9, W_GOLD, W_GOLD, W_GOLD * 1.05], W_SUN)):
        for tier in range(1, 6):
            parts, glow = w_glove(tier, cloth_by_tier[tier - 1], trim_by_tier[tier - 1], name)
            pos, quads, col = merged(parts)
            save(f"weapon_glove_{name}_{tier}_body", [(pos, col)], quads)
            frames, frame_quads = w_glow_frames(glow, hue, 12)
            save(f"weapon_glove_{name}_{tier}_glow", frames, frame_quads)


# ---------------------------------------------------------------- разрезы и стрела

def w_slash(name, radius, wide, frames=12):
    """Разрез: острый полумесяц пробегает дугой вперёд и тает с хвоста. Лезвие смотрит вдоль +Z, ход справа налево."""
    nu, nv = 56, 7
    u = np.tile(np.linspace(0, 1, nu), nv)
    v = np.repeat(np.linspace(-1, 1, nv), nu)
    quads = grid(nu, nv, wrap=False)
    both = np.concatenate([quads, quads[:, ::-1]])
    tear = Flow(731, freq=7.0, octaves=2, speed=0)
    body, core = [], []
    span = 2.2
    for f in range(frames):
        t = f / (frames - 1)
        head = 1 - (1 - min(1.0, t * 1.8)) ** 2
        tail = max(0.0, (t - 0.28) / 0.72) ** 1.3
        # Доля дуги, занятая разрезом в этом кадре.
        place = tail + (head - tail) * u
        angle = (place - 0.5) * span
        taper = np.sin(np.clip(u, 0, 1) * math.pi) ** 0.6
        thick = wide * taper * (1 + 0.14 * tear(np.stack([u * 3, v, u * 0], axis=1), 0.0))
        r = radius + v * thick * 0.5
        # Дуга стоит поперёк полёта и видна от первого лица целиком, концы отстают назад, как у серпа.
        x = np.sin(angle) * r
        y = np.cos(angle) * r - radius * 0.72
        z = -np.abs(np.sin(angle)) ** 1.5 * radius * 0.55 + 0.08 * v * thick + t * radius * 0.35
        pos = np.stack([x, y, z], axis=1)
        fade = 1.0 if t < 0.8 else 0.0
        edge = np.abs(v)
        rim = np.clip(edge * 1.2, 0, 1)[:, None]
        shell = np.array([0.55, 0.86, 1.0])[None, :] * (1 - rim) + np.array([0.06, 0.42, 0.98])[None, :] * rim
        body.append((pos * 1.0, rgba(shell, np.full(len(pos), 1.0 if t < 0.9 else 0.0))))
        inner = np.stack([x, y, z - 0.015], axis=1)
        heat = np.clip(1.3 - edge * 1.5, 0, 1)
        colour = np.array([0.5, 0.86, 1.0])[None, :] * (1 - heat[:, None]) + np.array([0.94, 0.99, 1.0])[None, :] * heat[:, None]
        core.append((inner, rgba(colour, ((edge < 0.4).astype(float)) * fade)))
    save(name + "_body", body, both)
    save(name + "_glow", core, both)


def slash_effects():
    w_slash("slash_arc", 1.3, 0.34)
    w_slash("slash_big", 2.6, 0.72)


def arrow_power():
    """Стрела силы: тонкое древко, гранёный наконечник и оперение из света. Летит вдоль +Z."""
    frames = 8
    head = [w_ring((0, 0, z), (1, 0, 0), (0, 1, 0), r, 6) for z, r in ((0.62, 0.002), (0.5, 0.05), (0.42, 0.06), (0.38, 0.02))]
    body_parts = [w_rod(np.linspace((0, 0, -0.55), (0, 0, 0.42), 8), 0.016, W_SILVER, sides=6, hard=False), w_loft(head, W_SILVER * 1.05, 9)]
    pos, quads, col = merged(body_parts)
    save("arrow_power_body", [(pos, col)] * frames, quads)
    fins = []
    for k in range(3):
        a = k / 3 * TAU
        out = np.array([math.cos(a), math.sin(a), 0])
        fins.append(w_rod(w_bezier(np.array([0, 0, -0.32]), out * 0.1 + np.array([0, 0, -0.46]), out * 0.04 + np.array([0, 0, -0.62]), 7), np.linspace(0.006, 0.03, 7), (1, 1, 1), sides=4, hard=True))
    fins.append(w_rod(np.linspace((0, 0, 0.0), (0, 0, 0.38), 5), 0.024, (1, 1, 1), sides=5, hard=False))
    glow, glow_quads = w_glow_frames(fins, W_RUNE, frames)
    save("arrow_power_glow", glow, glow_quads)


# ---------------------------------------------------------------- огромная волна

def great_wave():
    """Огромная волна: толща воды с закрученным гребнем, жилы света в глубине, пена по кромке и срывающиеся брызги. Катится вдоль +Z."""
    frames, nu, nv = 24, 110, 48
    x = np.tile(np.linspace(-1, 1, nu), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    sheet = grid(nu, nv, wrap=False)
    swell = Flow(811, freq=1.6, octaves=3, speed=1)
    chop = Flow(812, freq=5.0, octaves=3, gain=0.6, speed=1)
    light = Flow(813, freq=2.6, octaves=2, speed=1)
    lace = Flow(814, freq=8.0, octaves=2, speed=1)
    count = 60
    drop, drop_q = cube_sphere(2)
    rng = np.random.default_rng(815)
    plan = [(rng.uniform(-0.95, 0.95), rng.uniform(0, 1), rng.uniform(0.07, 0.17), int(rng.integers(1, 3))) for _ in range(count)]
    foam_quads = faces([(nu * 10, grid(nu, 10, wrap=False))] + [(len(drop), drop_q)] * count)
    body, foam = [], []
    for f in range(frames):
        t = f / frames
        flat = np.stack([x * 3, s * 2.4, s * 0], axis=1)
        n = swell(flat, t)
        m = chop(flat, t)
        ridge = 1 + 0.16 * swell(np.stack([x * 2.2, x * 0, x * 0], axis=1), t)
        curl = np.clip((s - 0.62) / 0.38, 0, 1)
        # Спина поднимается вверх, у гребня лист заворачивается вперёд и вниз.
        turn = curl ** 1.5 * 2.9
        y = 5.0 * ridge * (np.sin(np.minimum(s, 0.62) / 0.62 * math.pi / 2) ** 1.3 + 0.2 * np.sin(turn))
        z = -3.0 * (1 - s) ** 1.6 + 2.5 * curl ** 1.3 * np.cos(turn * 0.6) + 0.14 * n
        edge = 1 - np.abs(x) ** 7
        pos = np.stack([x * 4.6, (y + 0.14 * m) * edge, z * (0.4 + 0.6 * edge)], axis=1)
        lines = caustic(light, flat, t, sharp=8)
        depth = 0.34 + 0.34 * s + 0.16 * n + 0.42 * lines + 0.16 * m
        foam_mask = np.clip((s - 0.7) * 5 + 0.8 * m, 0, 1) + 0.5 * (np.abs(lace(flat * 0.5, t)) < 0.05)
        h = np.clip(depth + 0.6 * foam_mask, 0, 1)
        body.append((pos, rgba(ramp(h, DEEP), np.clip((1 - np.abs(x)) * 16, 0, 1))))
        # Пена живёт на верхних рядах гребня и чуть над ним.
        rows = pos.reshape(nv, nu, 3)[-10:].reshape(-1, 3) + np.array([0, 0.03, 0.03])
        net = lace(rows, t)
        keep = (np.abs(net) < 0.34).astype(float)
        parts_pos = [rows]
        parts_col = [rgba(np.tile(np.array([0.82, 0.95, 1.0]), (len(rows), 1)), keep)]
        for across, phase, size, turns in plan:
            k = (t * turns + phase) % 1.0
            spot = np.array([across * 4.4, 5.6 + 1.5 * k - 2.8 * k * k, 2.2 + 2.6 * k])
            parts_pos.append(drop * size * (1 - k ** 2) + spot)
            parts_col.append(rgba(np.tile(np.array([0.72, 0.92, 1.0]), (len(drop), 1)), np.ones(len(drop))))
        foam.append((np.concatenate(parts_pos), np.concatenate(parts_col)))
    save("great_wave_body", body, sheet)
    save("great_wave_glow", foam, foam_quads)
