# Звуки хоррора. Всё синтезируется здесь, чужих записей нет.
# Запуск после sounds_mix.py: python sounds_horror.py. Дописывает события в sounds.json.
import json
import math
import os
import subprocess

import numpy as np

SR = 44100
OUT = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements"
FOLDER = os.path.join(OUT, "sounds")


def time(seconds):
    return np.arange(int(seconds * SR)) / SR


def lowpass(x, cut):
    spectrum = np.fft.rfft(x)
    freq = np.fft.rfftfreq(len(x), 1 / SR)
    spectrum *= 1 / (1 + (freq / cut) ** 6)
    return np.fft.irfft(spectrum, len(x))


def band(x, low, high):
    spectrum = np.fft.rfft(x)
    freq = np.fft.rfftfreq(len(x), 1 / SR)
    spectrum *= ((freq > low) & (freq < high)).astype(float)
    return np.fft.irfft(spectrum, len(x))


def room(x, wet, seconds, rng):
    tail = rng.normal(size=int(seconds * SR)) * np.exp(-np.linspace(0, 7, int(seconds * SR)))
    size = len(x) + len(tail)
    out = np.fft.irfft(np.fft.rfft(x, size) * np.fft.rfft(tail, size), size)[: len(x) + len(tail) - 1]
    out /= np.abs(out).max() + 1e-9
    dry = np.pad(x, (0, len(out) - len(x)))
    return dry * (1 - wet) + out * wet * np.abs(x).max()


def finish(x, level):
    fade = min(len(x) // 8, int(0.25 * SR))
    x = x.copy()
    x[-fade:] *= np.linspace(1, 0, fade)
    return x / (np.abs(x).max() + 1e-9) * level


def step(seed):
    rng = np.random.default_rng(seed)
    t = time(2.6)
    thud = np.sin(math.tau * (30 + 26 * np.exp(-t * 9)) * t) * np.exp(-t * 3.2)
    crack = lowpass(rng.normal(size=len(t)), 420) * np.exp(-t * 16) * 2.5
    rumble = lowpass(rng.normal(size=len(t)), 75) * np.exp(-t * 1.5) * 7
    return finish(room(thud + crack + rumble, 0.35, 1.7, rng), 0.9)


def sting(seed):
    rng = np.random.default_rng(seed)
    t = time(2.4)
    swell = np.minimum(1, t / 0.16) * np.exp(-np.maximum(0, t - 0.25) * 2.2)
    x = np.zeros(len(t))
    for f in (196, 207.6, 293.7, 311.1, 415.3, 440):
        wobble = 1 + 0.006 * np.sin(math.tau * rng.uniform(4, 7) * t + rng.uniform(0, 6))
        x += sum(np.sin(math.tau * f * n * wobble * t) / n ** 1.4 for n in range(1, 7))
    return finish(room(lowpass(x, 2600) * swell, 0.42, 1.6, rng), 0.72)


def scream(seed):
    rng = np.random.default_rng(seed)
    t = time(1.9)
    pitch = 260 + 300 * np.minimum(1, t / 0.25) - 150 * t + 14 * np.sin(math.tau * 9 * t)
    phase = math.tau * np.cumsum(pitch) / SR
    x = sum(np.sin(phase * n) / n for n in range(1, 13))
    breath = rng.normal(size=len(t)) * 0.8
    voiced = sum(band(x + breath, f - w, f + w) * g for f, w, g in ((800, 170, 1.0), (1250, 230, 0.8), (2500, 340, 0.3)))
    envelope = np.minimum(1, t / 0.05) * np.exp(-t * 1.25)
    return finish(room(lowpass(voiced, 3300) * envelope, 0.4, 1.3, rng), 0.78)


def whisper(seed):
    rng = np.random.default_rng(seed)
    t = time(3.6)
    x = band(rng.normal(size=len(t)), 900, 6200)
    syllables = np.zeros(len(t))
    at = 0.15
    while at < 3.2:
        size = rng.uniform(0.09, 0.27)
        centre = at + size / 2
        syllables += np.exp(-((t - centre) / (size / 2.3)) ** 2) * rng.uniform(0.4, 1.0)
        at += size + rng.uniform(0.02, 0.28)
    shaped = sum(band(x, f - 340, f + 340) * (0.6 + 0.4 * np.sin(math.tau * rng.uniform(1.5, 4) * t + rng.uniform(0, 6))) for f in (1500, 2600, 3900))
    return finish(room(shaped * syllables, 0.46, 1.1, rng), 0.5)


def breath(seed):
    rng = np.random.default_rng(seed)
    t = time(3.0)
    inhale = np.exp(-((t - 0.65) / 0.42) ** 2)
    exhale = np.exp(-((t - 1.95) / 0.55) ** 2)
    x = band(rng.normal(size=len(t)), 240, 1500) * inhale * 0.7 + band(rng.normal(size=len(t)), 120, 780) * exhale
    rattle = 0.6 + 0.4 * np.sign(np.sin(math.tau * 31 * t))
    return finish(room(x * rattle, 0.22, 0.7, rng), 0.56)


def creak(seed):
    rng = np.random.default_rng(seed)
    t = time(2.2)
    rate = 34 - 16 * t / 2.2 + 3 * np.sin(math.tau * 1.3 * t)
    ticks = np.zeros(len(t))
    positions = np.cumsum(SR / rate[:: SR // 40])
    for p in positions:
        i = int(p)
        if i < len(t) - 400:
            ticks[i] = rng.uniform(0.5, 1)
    tone = np.convolve(ticks, np.sin(math.tau * 640 * np.arange(400) / SR) * np.exp(-np.arange(400) / 90), mode="same")
    envelope = np.sin(np.pi * np.minimum(1, t / 2.0)) ** 1.5
    return finish(room(band(tone, 180, 2400) * envelope, 0.26, 0.8, rng), 0.5)


EVENTS = {"horror_step": step, "horror_sting": sting, "horror_scream": scream, "horror_whisper": whisper, "horror_breath": breath, "horror_creak": creak}


def write(x, name):
    path = os.path.join(FOLDER, name + ".ogg")
    pcm = np.clip(x, -1, 1).astype("<f4").tobytes()
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "f32le", "-ar", str(SR), "-ac", "1", "-i", "-", "-c:a", "libvorbis", "-q:a", "4", path], input=pcm, check=True)


path = os.path.join(OUT, "sounds.json")
table = json.load(open(path, encoding="utf-8"))
for name, make in EVENTS.items():
    files = []
    for n in range(1, 4):
        write(make(sum(map(ord, name)) * 10 + n), f"{name}_{n}")
        files.append(f"minevia_elements:{name}_{n}")
    table[name] = {"sounds": files}
json.dump(table, open(path, "w", encoding="utf-8", newline="\n"), ensure_ascii=False, indent=2)
print("Звуки хоррора готовы:", len(EVENTS))
