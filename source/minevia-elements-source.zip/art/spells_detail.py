# Вторая волна графики: камень с настоящими сколами, магма с коркой, грязь, вода с пеной.
# Файл подключается после spells_more.py и заменяет собой старые функции с теми же именами.

LAVA = [(0.0, (0.22, 0.015, 0.005)), (0.35, (0.62, 0.06, 0.005)), (0.65, (0.92, 0.18, 0.01)), (0.86, (1.0, 0.36, 0.02)), (1.0, (1.0, 0.62, 0.08))]
BASALT = [(0.0, (0.05, 0.045, 0.045)), (0.5, (0.17, 0.15, 0.14)), (1.0, (0.36, 0.32, 0.29))]
MUD = [(0.0, (0.09, 0.055, 0.03)), (0.45, (0.21, 0.135, 0.075)), (0.8, (0.36, 0.25, 0.15)), (1.0, (0.52, 0.40, 0.27))]
DEEP = [(0.0, (0.0, 0.16, 0.50)), (0.4, (0.0, 0.34, 0.80)), (0.7, (0.04, 0.58, 0.96)), (0.88, (0.42, 0.86, 1.0)), (1.0, (0.96, 1.0, 1.0))]


def nearest_cells(points, seeds):
    """Ячейки Вороного: номер ближайшей точки и расстояние до границы с соседней ячейкой."""
    distance = np.linalg.norm(points[:, None, :] - seeds[None, :, :], axis=2)
    order = np.argsort(distance, axis=1)[:, :2]
    rows = np.arange(len(points))
    return order[:, 0], distance[rows, order[:, 1]] - distance[rows, order[:, 0]]


def ridges(flow, points):
    """Острые гребни вместо плавных волн шума."""
    return 1 - np.abs(flow(points, 0.0))


def crag(seed, cuts=20, planes=11, scale=(1, 1, 1), depth=0.62, shards=34, groove=0.055, jag=0.07):
    """Камень из отколотых блоков: у каждого свой наклон, между блоками глубокие трещины, по граням слои породы."""
    rng = np.random.default_rng(seed)
    pos, quads = cube_sphere(cuts)
    dirs = pos.copy()
    for _ in range(planes):
        n = rng.normal(size=3)
        n /= np.linalg.norm(n)
        over = np.maximum(pos @ n - rng.uniform(depth, 0.95), 0)
        pos = pos - np.outer(over, n) * 0.96
    seeds = rng.normal(size=(shards, 3))
    seeds /= np.linalg.norm(seeds, axis=1, keepdims=True)
    cell, gap = nearest_cells(dirs, seeds)
    tilts = rng.normal(size=(shards, 3)) * 0.1
    lift = rng.uniform(-0.03, 0.04, shards)[cell]
    lean = np.sum((dirs - seeds[cell]) * tilts[cell], axis=1)
    edge = np.clip(gap / 0.09, 0, 1) ** 0.6
    fine = Flow(seed + 1, freq=5.5, octaves=4, gain=0.6, speed=0)
    coarse = Flow(seed + 2, freq=2.4, octaves=3, gain=0.55, speed=0)
    crease = ridges(fine, dirs)
    pos = pos * (1 + lift + lean - groove * (1 - edge) + jag * (crease - 0.7) + 0.05 * coarse(dirs, 0.0))[:, None]
    pos = pos * np.array(scale)
    strata = np.sin(pos[:, 1] / max(scale[1], 0.1) * 19 + 2.6 * coarse(dirs, 0.0) + rng.uniform(0, 6))
    speck = fine(dirs * 3.1 + 5, 0.0)
    tone = rng.uniform(-0.09, 0.09, shards)[cell]
    grey = 0.66 + tone + 0.1 * strata + 0.13 * speck + 0.16 * (crease - 0.7)
    grey = grey * (0.3 + 0.7 * edge) + 0.14 * np.clip(edge - 0.82, 0, 1)
    grey = np.clip(grey, 0.05, 1)
    return pos, quads, rgba(np.stack([grey, grey * 0.97, grey * 0.92], axis=1), np.ones(len(pos)))


def boulder():
    pos, quads, col = crag(201, cuts=28, planes=15, scale=(0.86, 0.74, 0.92), shards=42)
    save("boulder", [(pos, col)], quads)


def earth_chunk():
    """Вырванный кусок земли: дёрн с травой, слои почвы с камнями, снизу рваные корни и комья."""
    pos, quads, _ = crag(205, cuts=26, planes=9, scale=(1.0, 0.8, 1.0), depth=0.7, shards=18, groove=0.05)
    top = 0.44
    lumps = Flow(206, freq=3.0, octaves=3, speed=0)
    blades = Flow(210, freq=17.0, octaves=2, speed=0)
    surface = top + 0.05 * lumps(pos * np.array([1, 0, 1]), 0.0)
    roof = pos[:, 1] >= surface
    pos[:, 1] = np.minimum(pos[:, 1], surface)
    pos[:, 1] += roof * np.clip(blades(pos * np.array([1, 0, 1]), 0.0), 0, 1) * 0.1
    under = np.clip(-pos[:, 1] / 0.8, 0, 1)
    ragged = Flow(207, freq=2.6, octaves=3, speed=0)
    pos[:, 1] -= 0.4 * under * (0.6 + ragged(pos, 0.0))
    pos[:, 0:2] *= (1 - 0.2 * under ** 2)[:, None]
    soil = Flow(208, freq=7.0, octaves=3, gain=0.65, speed=0)
    stones = Flow(209, freq=4.6, octaves=2, speed=0)
    n = soil(pos, 0.0)
    stone = np.clip((stones(pos, 0.0) - 0.3) * 10, 0, 1)
    band = 0.5 + 0.5 * np.sin(pos[:, 1] * 24 + 3 * n)
    dirt = np.array([0.36, 0.23, 0.13]) * (0.8 + 0.5 * n + 0.2 * band)[:, None]
    dark = np.array([0.19, 0.125, 0.08]) * (1 + 0.6 * n)[:, None]
    body = dirt * (1 - under[:, None]) + dark * under[:, None]
    grey = (0.46 + 0.24 * n)[:, None] * np.array([1.0, 0.98, 0.94])
    body = body * (1 - stone[:, None]) + grey * stone[:, None]
    depth = surface - pos[:, 1]
    turf = np.clip(1 - (depth - 0.02) / 0.1 + 0.6 * n, 0, 1)
    green = np.array([0.22, 0.40, 0.11]) * (0.75 + 0.7 * np.abs(n) + 0.5 * roof)[:, None]
    rgb = body * (1 - turf[:, None]) + green * turf[:, None]
    save("earth_chunk", [(pos, rgba(np.clip(rgb, 0, 1), np.ones(len(pos))))], quads)


def rock_burst():
    """Глыба рассыпается: крупные осколки и мелкая щебёнка разлетаются, кувыркаются и падают."""
    frames = 18
    shards = bits(30, 211, 3.4, 3.1, 9.0, 0.3)
    shapes = [crag(220 + i, cuts=5 if i < 12 else 3, planes=7, depth=0.5, shards=7, groove=0.12) for i in range(len(shards))]
    offsets = np.cumsum([0] + [len(s[0]) for s in shapes])
    quads = np.concatenate([s[1] + offsets[i] for i, s in enumerate(shapes)])
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        pos, col = [], []
        for i, (shard, shape) in enumerate(zip(shards, shapes)):
            turn = rotation(shard["axis"], shard["spin"] * t)
            center = shard["v"] * t * 0.62 - np.array([0, shard["gravity"] * t * t * 0.5 * 0.62, 0])
            shrink = (1 - max(0.0, (t - 0.6) / 0.4) ** 2) * (1.0 if i < 12 else 0.55)
            pos.append(shape[0] * shard["size"] * shrink @ turn.T + center)
            col.append(shape[2])
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("rock_burst", result, quads)


def ground_ring():
    """Кольцо вздыбленных плит земли вокруг точки удара."""
    rng = np.random.default_rng(241)
    parts = []
    for i in range(15):
        pos, quads, col = crag(250 + i, cuts=7, planes=8, scale=(0.3, 0.46, 0.2), depth=0.55, shards=9)
        angle = i / 15 * TAU + rng.uniform(-0.1, 0.1)
        out = np.array([math.cos(angle), 0, math.sin(angle)])
        tilt = rotation((-out[2], 0, out[0]), rng.uniform(0.25, 0.75))
        turn = rotation((0, 1, 0), -angle + math.pi / 2)
        placed = pos @ turn.T @ tilt.T + out * rng.uniform(0.9, 1.1) + np.array([0, rng.uniform(0.0, 0.14), 0])
        parts.append((placed, quads, col))
    pos, quads, col = merged(parts)
    save("ground_ring", [(pos, col)], quads)


def prism(seed, height, width, sides=6, taper=0.0, per_side=4, nv=20, point=False):
    """Каменный столб с плоскими гранями: у каждой грани свои вершины, поэтому рёбра острые. Поперёк идут разломы, вершина сколота."""
    rng = np.random.default_rng(seed)
    step = TAU / sides
    start = rng.uniform(0, step)
    breaks = Flow(seed + 1, freq=2.2, octaves=2, speed=0)
    grain = Flow(seed + 2, freq=6.0, octaves=3, gain=0.6, speed=0)
    bend = rng.uniform(-0.2, 0.2, 2) * height * 0.3
    nu = per_side + 1
    parts = []
    for side in range(sides):
        k = np.tile(np.linspace(0, 1, nu), nv)
        s = np.repeat(np.linspace(0, 1, nv), nu)
        a, b = start + side * step, start + (side + 1) * step
        corner_a = np.array([math.cos(a), math.sin(a)])
        corner_b = np.array([math.cos(b), math.sin(b)])
        rim = corner_a[None, :] * (1 - k)[:, None] + corner_b[None, :] * k[:, None]
        profile = (1 - s) ** 0.9 + 0.012 if point else 1 - taper * s
        ring = np.stack([rim[:, 0], s * height / max(width, 0.1) * 0.6, rim[:, 1]], axis=1)
        crease = ridges(grain, ring)
        fault = np.clip(1 - np.abs(np.sin(s * height * 3.6 + 1.6 * breaks(ring, 0.0))) * 7, 0, 1)
        radius = width * profile * (1 + 0.06 * (crease - 0.7) - 0.1 * fault)
        pos = np.stack([rim[:, 0] * radius, s * height, rim[:, 1] * radius], axis=1)
        pos[:, 0] += s ** 2 * bend[0]
        pos[:, 2] += s ** 2 * bend[1]
        if not point:
            top = np.clip((s - 0.93) / 0.07, 0, 1)
            pos[:, 0] *= 1 - 0.8 * top ** 2
            pos[:, 2] *= 1 - 0.8 * top ** 2
            pos[:, 1] -= 0.1 * height * top * (0.4 + 0.6 * math.sin(side * 2.4 + seed) ** 2)
        tone = 0.1 * math.sin(side * 12.9898 + seed)
        grey = np.clip(0.6 + tone + 0.2 * (crease - 0.7) + 0.13 * grain(ring * 2.3, 0.0) + 0.1 * s - 0.44 * fault, 0.05, 1)
        parts.append((pos, grid(nu, nv, wrap=False)[:, ::-1], rgba(np.stack([grey, grey * 0.98, grey * 0.93], axis=1), np.ones(len(pos)))))
    return merged(parts)


def rubble(seed, count, reach, size):
    """Щебень у основания: камень не торчит из идеально ровной земли."""
    rng = np.random.default_rng(seed)
    parts = []
    for i in range(count):
        pos, quads, col = crag(seed + 1 + i, cuts=4, planes=6, scale=(1, 0.6, 1), depth=0.5, shards=6, groove=0.12)
        angle = rng.uniform(0, TAU)
        spot = np.array([math.cos(angle), 0, math.sin(angle)]) * rng.uniform(0.35, 1) * reach
        parts.append((pos * rng.uniform(0.5, 1) * size @ rotation((0, 1, 0), rng.uniform(0, TAU)).T + spot, quads, col))
    return parts


def stone_spike():
    parts = []
    for seed, height, width, x, z in ((301, 2.7, 0.56, 0, 0), (305, 1.7, 0.36, 0.52, 0.26), (309, 1.3, 0.32, -0.46, 0.36), (313, 1.05, 0.28, 0.1, -0.52)):
        pos, quads, col = prism(seed, height, width, sides=5, per_side=3, nv=18, point=True)
        parts.append((pos + np.array([x, -0.2, z]), quads, col))
    parts += rubble(317, 7, 0.95, 0.17)
    pos, quads, col = merged(parts)
    save("stone_spike", [(pos, col)], quads)


def stone_plates():
    """Каменные пластины брони, кружащие вокруг игрока."""
    parts = []
    for i in range(6):
        pos, quads, col = crag(330 + i, cuts=8, planes=8, scale=(0.3, 0.38, 0.09), depth=0.55, shards=8, groove=0.08)
        angle = i / 6 * TAU
        out = np.array([math.cos(angle), 0, math.sin(angle)])
        turn = rotation((0, 1, 0), -angle + math.pi / 2)
        placed = pos @ turn.T + out * 0.92 + np.array([0, 0.5 + 0.48 * (i % 3), 0])
        parts.append((placed, quads, col))
    pos, quads, col = merged(parts)
    save("stone_plates", [(pos, col)], quads)


def stone_wall():
    """Стена из вставших из земли базальтовых столбов разной высоты."""
    rng = np.random.default_rng(351)
    parts = []
    spots = ((-0.72, 0.0), (-0.24, 0.16), (0.24, -0.1), (0.72, 0.12), (-0.46, -0.34), (0.48, -0.42), (0.0, 0.46), (-0.86, 0.5), (0.86, 0.5))
    for i, (x, z) in enumerate(spots):
        height = rng.uniform(4.6, 6.1)
        pos, quads, col = prism(352 + i * 3, height, rng.uniform(0.3, 0.42), sides=6, taper=0.1, per_side=2, nv=22)
        parts.append((pos + np.array([x, -1.1, z]), quads, col))
    parts += [(p + np.array([0, -0.0, 0.0]), q, c) for p, q, c in rubble(380, 8, 1.2, 0.2)]
    pos, quads, col = merged(parts)
    save("stone_wall", [(pos, col)], quads)


def ground_slab():
    """Плита земли, вставшая дыбом и наклонённая наружу."""
    pos, quads, col = crag(361, cuts=11, planes=8, scale=(0.5, 0.72, 0.28), depth=0.55, shards=10)
    pos = pos @ rotation((1, 0, 0), 0.5).T + np.array([0, 0.05, 0])
    save("ground_slab", [(pos, col)], quads)


def rock_fist():
    """Каменный кулак: предплечье с костяшками вырывается из земли, замирает и уходит обратно."""
    frames = 20
    bones = [(751, (0.72, 1.5, 0.72), (0, 0.9, 0)), (752, (0.9, 0.66, 0.74), (0, 2.5, 0)),
             (753, (0.26, 0.3, 0.3), (-0.6, 3.05, 0.34)), (754, (0.26, 0.32, 0.3), (-0.2, 3.12, 0.38)),
             (755, (0.26, 0.32, 0.3), (0.2, 3.12, 0.38)), (756, (0.26, 0.3, 0.3), (0.6, 3.05, 0.34)),
             (757, (0.3, 0.42, 0.3), (0.86, 2.5, 0.34))]
    shapes = [crag(seed, cuts=11 if i < 2 else 7, planes=10, scale=scale, depth=0.6, shards=12 if i < 2 else 6) for i, (seed, scale, _) in enumerate(bones)]
    quads = faces([(len(p), q) for p, q, _ in shapes])
    whole = np.concatenate([p + np.array(at) for (p, _, _), (_, _, at) in zip(shapes, bones)])
    colour = np.concatenate([c for _, _, c in shapes])
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        up = 1 - (1 - min(1.0, t * 5)) ** 3
        over = 0.35 * math.sin(min(1.0, t * 5) * math.pi)
        down = max(0.0, (t - 0.72) / 0.28) ** 2
        lean = rotation((1, 0, 0.4), 0.2 * math.sin(t * 5))
        result.append((whole @ lean.T + np.array([0, -4.2 * (1 - up) + over - 4.4 * down, 0]), colour))
    save("rock_fist", result, quads)


# ---------------------------------------------------------------- магма

def magma_boulder():
    """Раскалённая глыба: чёрная корка из блоков, а из трещин смотрит жидкий жар. Корка не светится, светится только нутро."""
    pos, quads, col = crag(441, cuts=28, planes=14, scale=(0.86, 0.74, 0.92), shards=36, groove=0.08, jag=0.06)
    grey = col[:, 0]
    rgb = ramp(np.clip(grey * 1.15, 0, 1), BASALT)
    # Края трещин подсвечены снизу жаром: тёмно-красный ободок, а не свечение всей глыбы.
    rgb = rgb + np.array([0.3, 0.05, 0.0]) * np.clip(0.3 - grey, 0, 0.3)[:, None] * 2.4
    save("magma_boulder", [(pos, rgba(np.clip(rgb, 0, 1), np.ones(len(pos))))], quads)
    # Жар лежит на той же форме чуть выше корки: от неё оставлены только грани трещин, поэтому края чистые, без точек прозрачности.
    frames = 8
    crack = grey < np.percentile(grey, 16)
    kept = quads[crack[quads].sum(axis=1) >= 3]
    used = np.unique(kept)
    remap = np.zeros(len(pos), dtype=np.int32)
    remap[used] = np.arange(len(used))
    pulse = Flow(443, freq=3.0, octaves=3, speed=1)
    glow_pos = pos[used] * 1.006
    result = []
    for f in range(frames):
        t = f / frames
        result.append((glow_pos, rgba(ramp(np.clip(0.72 + 0.45 * pulse(pos[used], t), 0, 1), LAVA), np.ones(len(used)))))
    save("magma_boulder_core", result, remap[kept])


def disc(nu, nv, seed, ragged=0.2):
    """Плоский круг с неровным краем: основа для луж."""
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    r = np.repeat(np.linspace(0, 1, nv) ** 0.8, nu)
    ring = np.stack([np.cos(theta), theta * 0, np.sin(theta)], axis=1)
    edge = 0.86 + ragged * Flow(seed, freq=1.7, octaves=3, speed=0)(ring, 0.0)
    flat = np.stack([r * edge * np.cos(theta), r * 0, r * edge * np.sin(theta)], axis=1)
    return flat, r, grid(nu, nv)


def domes(seed, count, reach, size, frames, shade):
    """Пузыри на поверхности лужи: вздуваются, лопаются и появляются в новом месте."""
    rng = np.random.default_rng(seed)
    ball, ball_q = cube_sphere(3)
    ball = ball * np.array([1, 0.72, 1])
    plan = [(rng.uniform(0, TAU), rng.uniform(0.1, reach), rng.uniform(0.5, 1) * size, rng.uniform(0, 1)) for _ in range(count)]
    quads = faces([(len(ball), ball_q)] * count)
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for angle, far, width, phase in plan:
            k = (t + phase) % 1.0
            swell = math.sin(min(1.0, k / 0.8) * math.pi / 2) ** 2 * (0.0 if k > 0.86 else 1.0)
            pos.append(ball * width * swell + np.array([math.cos(angle) * far, 0.06, math.sin(angle) * far]))
            col.append(shade(ball, k))
        result.append((np.concatenate(pos), np.concatenate(col)))
    return result, quads


def magma_pool():
    """Лавовое поле: чёрные плиты корки дрейфуют на жидком жаре, по швам течёт лава, лопаются пузыри."""
    flat, r, quads = disc(150, 44, 451)
    rng = np.random.default_rng(452)
    angle = rng.uniform(0, TAU, 46)
    far = np.sqrt(rng.uniform(0, 1.15, 46))
    seeds = np.stack([far * np.cos(angle), far * 0, far * np.sin(angle)], axis=1)
    cell, gap = nearest_cells(flat, seeds)
    edge = np.clip((gap - 0.012) / 0.05, 0, 1)
    grain = Flow(453, freq=9.0, octaves=3, gain=0.6, speed=0)
    crease = ridges(grain, flat)
    tops = rng.uniform(0.05, 0.11, 46)[cell]
    # Плиты тонут к краю, а щели между ними проваливаются ниже уровня лавы.
    y = (tops * edge ** 0.5 + 0.02 * (crease - 0.7) - 0.08 * (1 - edge)) * (1 - r ** 7) + 0.12 * (1 - r ** 4) * r ** 5 - 0.03 * r ** 9
    pos = flat + np.stack([r * 0, y, r * 0], axis=1)
    tone = 0.3 + 0.65 * (crease - 0.6) + 0.42 * grain(flat * 2.3, 0.0) + rng.uniform(-0.12, 0.12, 46)[cell]
    rgb = ramp(np.clip(tone, 0, 1), BASALT)
    heat = (1 - edge) ** 2 * (1 - r ** 6)
    rgb = rgb * (1 - heat[:, None]) + np.array([0.34, 0.05, 0.01]) * heat[:, None]
    save("magma_pool_crust", [(pos, rgba(rgb, np.ones(len(pos))))], quads)

    frames = 24
    under, ur, under_q = disc(110, 26, 451)
    flow = Flow(454, freq=4.4, octaves=3, gain=0.6, speed=1)
    veins = Flow(456, freq=5.2, octaves=2, speed=1)
    bubbles, bubble_q = domes(455, 10, 0.72, 0.055, frames, lambda ball, k: rgba(ramp(np.clip(0.85 - 0.8 * k + 0.2 * ball[:, 1], 0, 1), LAVA), np.ones(len(ball))))
    quads = faces([(len(under), under_q), (len(bubbles[0][0]), bubble_q)])
    result = []
    for f in range(frames):
        t = f / frames
        n = flow(under, t)
        lava = under * 0.84 + np.stack([ur * 0, 0.045 + 0.012 * n, ur * 0], axis=1)
        colour = rgba(ramp(np.clip(0.5 + 0.85 * n + 0.5 * caustic(veins, under, t, sharp=5), 0, 1), LAVA), np.ones(len(under)))
        pos, col = bubbles[f]
        result.append((np.concatenate([lava, pos]), np.concatenate([colour, col])))
    save("magma_pool", result, quads)


def magma_geyser():
    """Столб магмы: бьёт вверх, на лету покрывается чёрной коркой, разваливается и падает тяжёлыми каплями."""
    frames, nu, nv = 20, 34, 26
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    column = grid(nu, nv)
    blobs = bits(22, 491, 2.6, 7.0, 16.0, 0.26)
    blob_pos, blob_q = cube_sphere(3)
    quads = faces([(len(theta), column)] + [(len(blob_pos), blob_q)] * len(blobs))
    churn = Flow(492, freq=2.0, octaves=3, speed=2)
    plates = Flow(493, freq=3.4, octaves=3, gain=0.6, speed=2)
    lumps = Flow(494, freq=3.0, octaves=2, speed=0)
    crust = lumps(blob_pos, 0.0)
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        rise = 1 - (1 - min(1.0, t * 2.6)) ** 2
        fall = max(0.0, (t - 0.45) / 0.55)
        height = 6.2 * rise * (1 - fall ** 2)
        spot = np.stack([np.cos(theta), s * 6, np.sin(theta)], axis=1)
        n = churn(spot, t)
        m = plates(spot, t)
        radius = (0.72 - 0.42 * s + 0.1 * s ** 3) * (1 + 0.32 * n) * (1 - 0.6 * fall)
        pos = [np.stack([radius * np.cos(theta), s * height, radius * np.sin(theta)], axis=1)]
        cooled = np.clip((m + 0.1 + 0.8 * s + 0.9 * fall - 0.3) * 4, 0, 1)[:, None]
        hot = ramp(np.clip(0.95 - 0.5 * s + 0.3 * n, 0, 1), LAVA)
        rock_tone = ramp(np.clip(0.4 + 0.6 * n, 0, 1), BASALT)
        col = [rgba(hot * (1 - cooled) + rock_tone * cooled, np.clip((1.3 - fall * 1.4) * (1 - s ** 6), 0, 1))]
        for d in blobs:
            k = max(0.0, t - 0.12) / 0.88
            center = d["v"] * k * 0.8 - np.array([0, d["gravity"] * k * k * 0.5 * 0.8, 0])
            center[1] = max(center[1], 0.1)
            pos.append(blob_pos * (1 + 0.2 * crust)[:, None] * d["size"] * (1 - k ** 3) + center)
            shell = np.clip(crust * 2 + k * 2.2 - 0.3, 0, 1)[:, None]
            drop = ramp(np.full(len(blob_pos), 0.9 - 0.4 * k), LAVA) * (1 - shell) + ramp(np.full(len(blob_pos), 0.3), BASALT) * shell
            col.append(rgba(drop, np.full(len(blob_pos), 1.0 if k > 0 else 0.0)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("magma_geyser", result, quads)


# ---------------------------------------------------------------- грязь

def mud_pool():
    """Трясина: вязкая тёмная жижа с валиками на краю, камешками и пузырями, которые вздуваются и лопаются."""
    flat, r, quads = disc(150, 44, 461, ragged=0.26)
    slow = Flow(462, freq=3.4, octaves=4, gain=0.55, speed=0)
    fine = Flow(463, freq=11.0, octaves=2, speed=0)
    n = slow(flat, 0.0)
    ring = np.sin(r * 26 + 3.4 * n)
    bank = np.exp(-((r - 0.84) / 0.11) ** 2)
    y = 0.07 + 0.05 * n + 0.012 * ring + 0.07 * bank * (1 + 0.5 * n) - 0.09 * r ** 8
    pos = flat + np.stack([r * 0, y, r * 0], axis=1)
    # Мокрая середина тёмная, по валикам жижа подсыхает и светлеет.
    h = 0.26 + 0.34 * n + 0.1 * ring + 0.3 * bank + 0.14 * fine(flat, 0.0)
    rgb = ramp(np.clip(h, 0, 1), MUD)
    save("mud_pool", [(pos, rgba(rgb, np.ones(len(pos))))], quads)
    frames = 24
    result, bubble_q = domes(464, 12, 0.68, 0.06, frames, lambda ball, k: rgba(ramp(np.clip(0.22 + 0.3 * ball[:, 1] + 0.3 * k, 0, 1), MUD), np.ones(len(ball))))
    save("mud_bubbles", [(p + np.array([0, 0.07, 0]), c) for p, c in result], bubble_q)


# ---------------------------------------------------------------- вода

def caustic(flow, points, t, sharp=7):
    """Тонкие светлые линии, как свет в толще воды."""
    return (1 - np.abs(flow(points, t))) ** sharp


def water_blob():
    """Шар воды: тёмная глубина, бегущие блики, пена на складках, рядом кружат сорвавшиеся капли."""
    frames = 24
    dirs, quads, *_ = sphere(50, 34)
    wobble = Flow(81, freq=1.3, octaves=3, gain=0.45, speed=1)
    ripple = Flow(82, freq=4.2, octaves=3, gain=0.55, speed=2)
    light = Flow(83, freq=3.0, octaves=2, speed=1)
    drop, drop_q = cube_sphere(2)
    rng = np.random.default_rng(84)
    orbit = [(rng.uniform(0, TAU), rng.uniform(-0.6, 0.6), rng.uniform(0.8, 1.12), rng.uniform(0.03, 0.06), int(rng.integers(1, 3))) for _ in range(12)]
    all_quads = faces([(len(dirs), quads)] + [(len(drop), drop_q)] * len(orbit))
    result = []
    for f in range(frames):
        t = f / frames
        n = wobble(dirs, t)
        m = ripple(dirs, t)
        lines = caustic(light, dirs, t)
        pos = [dirs * (0.62 * (1 + 0.24 * n + 0.05 * m))[:, None]]
        foam = np.clip((m - 0.5) * 3.2, 0, 1)
        h = 0.26 + 0.28 * n + 0.2 * dirs[:, 1] + 0.42 * lines + 0.5 * foam
        col = [rgba(ramp(np.clip(h, 0, 1), DEEP), np.ones(len(dirs)))]
        for angle, height, far, size, turns in orbit:
            a = angle + TAU * turns * t
            spot = np.array([math.cos(a) * far * 0.68, height * 0.7 + 0.08 * math.sin(a * 2), math.sin(a) * far * 0.68])
            pos.append(drop * size * np.array([1, 1.3, 1]) + spot)
            col.append(rgba(ramp(np.full(len(drop), 0.82), DEEP), np.full(len(drop), 0.9)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("water_blob", result, all_quads)


def water_splash():
    """Брызги: рваная корона с пеной по кромке и вытянутые капли, которые летят и падают."""
    frames = 16
    nu, nv = 96, 13
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    crown = grid(nu, nv)
    teeth = Flow(91, freq=5.2, octaves=3, gain=0.7, speed=0)
    churn = Flow(93, freq=4.0, octaves=3, speed=1)
    drops = bits(40, 92, 3.2, 3.6, 7.0, 0.14)
    drop_pos, drop_quads = cube_sphere(2)
    per_drop = len(drop_pos)
    quads = np.concatenate([crown] + [drop_quads + len(theta) + i * per_drop for i in range(len(drops))])
    ring = np.stack([np.cos(theta), s * 0, np.sin(theta)], axis=1)
    jag = 0.45 + 1.2 * np.abs(teeth(ring, 0.0)) ** 1.5
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        spread = 0.25 + 1.5 * (1 - (1 - t) ** 2)
        lift = 1.5 * math.sin(min(1.0, t * 1.25) * math.pi) ** 0.8 * jag
        radius = spread * (0.5 + 0.5 * s + 0.26 * s * s)
        wave = churn(ring + np.stack([s * 0, s * 2, s * 0], axis=1), t)
        pos = np.stack([radius * np.cos(theta), lift * s ** 1.4 * (1 + 0.14 * wave), radius * np.sin(theta)], axis=1)
        foam = np.clip((s - 0.6) * 3 + 0.5 * wave, 0, 1)
        h = 0.34 + 0.36 * s + 0.2 * wave + 0.5 * foam
        col = rgba(ramp(np.clip(h, 0, 1), DEEP), np.clip((1.15 - t ** 1.6) * 1.6 - s * 0.3, 0, 1))
        parts_pos, parts_col = [pos], [col]
        for d in drops:
            k = min(1.0, t / d["life"])
            velocity = d["v"] * 0.55 - np.array([0, d["gravity"] * t * 0.55, 0])
            center = d["v"] * t * 0.55 - np.array([0, d["gravity"] * t * t * 0.5 * 0.55, 0])
            speed = max(1e-3, float(np.linalg.norm(velocity)))
            way = velocity / speed
            shape = drop_pos * d["size"] * (1 - k ** 3)
            shape = shape + np.outer(shape @ way, way) * 0.45 * min(3.0, speed)
            parts_pos.append(shape + center)
            parts_col.append(rgba(ramp(np.full(per_drop, 0.86), DEEP), np.full(per_drop, 0.9 * (1 - k ** 3))))
        result.append((np.concatenate(parts_pos), np.concatenate(parts_col)))
    save("water_splash", result, quads)


def water_wave():
    """Настоящая волна: тёмная толща, закрученный гребень с кружевной пеной и срывающиеся с него брызги."""
    frames, nu, nv = 24, 92, 40
    x = np.tile(np.linspace(-1, 1, nu), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    sheet = grid(nu, nv, wrap=False)
    chop = Flow(95, freq=2.2, octaves=3, speed=1)
    lace = Flow(96, freq=6.0, octaves=3, gain=0.65, speed=1)
    light = Flow(97, freq=3.4, octaves=2, speed=1)
    count = 34
    drop, drop_q = cube_sphere(1)
    rng = np.random.default_rng(98)
    plan = [(rng.uniform(-0.92, 0.92), rng.uniform(0, 1), rng.uniform(0.05, 0.12), int(rng.integers(1, 3))) for _ in range(count)]
    quads = faces([(nu * nv, sheet)] + [(len(drop), drop_q)] * count)
    result = []
    for f in range(frames):
        t = f / frames
        flat = np.stack([x * 3, s * 2, s * 0], axis=1)
        n = chop(flat, t)
        crest = 1 + 0.2 * chop(np.stack([x * 2, x * 0, x * 0], axis=1), t)
        curl = s ** 3
        y = (np.sin(s * 2.6) / math.sin(2.6 * 0.72)) * 2.3 * crest
        z = -1.1 * (1 - s) ** 1.5 + 1.6 * curl - 0.26 * np.maximum(s - 0.8, 0) * 5 + 0.08 * n
        edge = 1 - np.abs(x) ** 6
        sheet_pos = np.stack([x * 3.0, y * edge + 0.13 * n, z * edge], axis=1)
        net = lace(flat, t)
        foam = np.clip((s - 0.86) * 5 + 0.4 * n + 0.8 * (np.abs(net) < 0.1) * (s > 0.5), 0, 1)
        lines = caustic(light, flat, t, sharp=9)
        h = 0.22 + 0.36 * s + foam * 0.85 + 0.14 * n + 0.32 * lines
        a = np.clip(s * 10, 0, 1) * np.clip((1 - np.abs(x)) * 14, 0, 1)
        pos, col = [sheet_pos], [rgba(ramp(np.clip(h, 0, 1), DEEP), a)]
        for across, phase, size, turns in plan:
            k = (t * turns + phase) % 1.0
            spot = np.array([across * 3.0, 2.5 * (1 + 0.06 * math.sin(phase * 9)) + 0.9 * k - 1.5 * k * k, 1.0 + 1.5 * k])
            pos.append(drop * size * (1 - k ** 2) + spot)
            col.append(rgba(ramp(np.full(len(drop), 0.95), DEEP), np.full(len(drop), 0.92)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("water_wave", result, quads)


def water_stream():
    """Гибкая водяная плеть длиной в единицу: скрученная струя с пенными нитями, игра растягивает её до цели."""
    frames, nu, nv = 24, 20, 72
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    quads = grid(nu, nv)
    swell = Flow(85, freq=5.0, octaves=3, gain=0.6, speed=2)
    bend = Flow(86, freq=3.0, octaves=2, speed=1)
    result = []
    for f in range(frames):
        t = f / frames
        axis = np.stack([s * 3, s * 0, s * 0], axis=1)
        ends = np.sin(s * math.pi) ** 0.6
        n = swell(axis + np.stack([np.cos(theta), np.sin(theta), s * 0], axis=1) * 0.2, t)
        radius = (0.13 + 0.09 * (n + 1)) * (0.4 + 0.6 * ends)
        cx = bend(axis, t) * 0.2 * ends
        cy = bend(axis + 5, t) * 0.2 * ends
        pos = np.stack([np.cos(theta) * radius + cx, np.sin(theta) * radius + cy, s], axis=1)
        thread = np.clip(1 - np.abs(np.sin(theta * 1.5 + s * 26 - TAU * t * 3)) * 5, 0, 1)
        h = 0.3 + 0.3 * n + 0.75 * thread
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), DEEP), np.ones(len(pos)))))
    save("water_stream", result, quads)


def water_geyser():
    """Гейзер: столб бьёт вверх с пеной на гребне, у основания расходится воротник воды, потом всё падает каплями."""
    frames, nu, nv = 20, 40, 30
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    column = grid(nu, nv)
    collar_nu, collar_nv = 48, 8
    ctheta = np.tile(np.linspace(0, TAU, collar_nu, endpoint=False), collar_nv)
    cs = np.repeat(np.linspace(0, 1, collar_nv), collar_nu)
    collar = grid(collar_nu, collar_nv)
    blobs = bits(26, 741, 2.8, 7.2, 16.0, 0.24)
    blob_pos, blob_q = cube_sphere(2)
    quads = faces([(len(theta), column), (len(ctheta), collar)] + [(len(blob_pos), blob_q)] * len(blobs))
    churn = Flow(742, freq=2.2, octaves=3, speed=2)
    foam_noise = Flow(743, freq=5.0, octaves=3, gain=0.6, speed=2)
    teeth = Flow(744, freq=4.0, octaves=2, speed=0)
    jag = 0.5 + np.abs(teeth(np.stack([np.cos(ctheta), ctheta * 0, np.sin(ctheta)], axis=1), 0.0))
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        rise = 1 - (1 - min(1.0, t * 3.0)) ** 2
        fall = max(0.0, (t - 0.45) / 0.55)
        height = 6.4 * rise * (1 - fall ** 2)
        spot = np.stack([np.cos(theta), s * 6, np.sin(theta)], axis=1)
        n = churn(spot, t)
        m = foam_noise(spot, t)
        radius = (0.66 - 0.4 * s + 0.26 * s ** 4) * (1 + 0.26 * n) * (1 - 0.6 * fall)
        pos = [np.stack([radius * np.cos(theta), s * height, radius * np.sin(theta)], axis=1)]
        foam = np.clip((m - 0.1) * 3 + (s - 0.74) * 4, 0, 1)
        col = [rgba(ramp(np.clip(0.34 + 0.3 * s + 0.3 * n + 0.8 * foam, 0, 1), DEEP), np.clip((1.2 - fall * 1.3) * 1.4 * (1 - s ** 7), 0, 1))]
        spread = 0.7 + 1.5 * min(1.0, t * 1.6)
        cr = spread * (0.55 + 0.7 * cs)
        lift = 0.9 * math.sin(min(1.0, t * 1.5) * math.pi) * cs ** 1.2 * jag
        pos.append(np.stack([cr * np.cos(ctheta), lift, cr * np.sin(ctheta)], axis=1))
        col.append(rgba(ramp(np.clip(0.42 + 0.5 * cs, 0, 1), DEEP), np.full(len(ctheta), 1.0 if t < 0.66 else 0.0)))
        for d in blobs:
            k = max(0.0, t - 0.14) / 0.86
            center = d["v"] * k * 0.8 - np.array([0, d["gravity"] * k * k * 0.5 * 0.8, 0])
            center[1] = max(center[1], 0.1)
            pos.append(blob_pos * d["size"] * (1 - k ** 3) + center)
            col.append(rgba(ramp(np.full(len(blob_pos), 0.86), DEEP), np.full(len(blob_pos), 1.0 if k > 0 else 0.0)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("water_geyser", result, quads)


def puffs(name, seed, count, spread, flat, palette, alpha, nu=30, nv=20, ring=0.0, small=1.0):
    """Облако из клубов с кудрявой поверхностью, которые медленно перекатываются по кругу."""
    frames = 24
    rng = np.random.default_rng(seed)
    dirs, one, *_ = sphere(nu, nv, axis=1)
    quads = faces([(len(dirs), one)] * count)
    plan = [{"at": (np.array([math.cos(i / count * TAU) * ring, 0.16, math.sin(i / count * TAU) * ring]) if ring else np.zeros(3))
             + np.array([rng.normal() * spread, rng.normal() * spread * 0.22, rng.normal() * spread]),
             "size": rng.uniform(0.45, 0.8) * (0.5 if ring else 1) * small, "phase": rng.uniform(0, TAU),
             "noise": Flow(seed + 10 + i, freq=1.8, octaves=3, speed=1), "curl": Flow(seed + 40 + i, freq=4.6, octaves=3, gain=0.6, speed=1)} for i in range(count)]
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for g in plan:
            n = g["noise"](dirs, t)
            c = 1 - np.abs(g["curl"](dirs, t))
            drift = np.array([math.cos(TAU * t + g["phase"]), 0.4 * math.sin(TAU * t + g["phase"]), math.sin(TAU * t + g["phase"])]) * 0.09
            shape = dirs * (g["size"] * (1 + 0.28 * n + 0.2 * (c - 0.7)))[:, None]
            shape[:, 1] *= flat
            pos.append(shape + g["at"] + drift)
            h = 0.46 + 0.42 * dirs[:, 1] + 0.28 * n + 0.34 * (c - 0.7)
            col.append(rgba(ramp(np.clip(h, 0, 1), palette), np.full(len(dirs), alpha)))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save(name, result, quads)


def steam_cloud():
    puffs("steam_cloud", 421, 18, 0.62, 0.66, [(0.0, (0.62, 0.68, 0.74)), (0.6, (0.82, 0.86, 0.90)), (1.0, (0.98, 0.99, 1.0))], 0.34, nu=22, nv=15, small=0.5)


def sand_pit():
    """Зыбучий песок: воронка с бегущими по спирали грядами, песок оседает к тёмной середине."""
    frames = 24
    flat, r, quads = disc(120, 30, 471, ragged=0.1)
    angle = np.arctan2(flat[:, 2], flat[:, 0])
    grain = Flow(472, freq=9.0, octaves=2, speed=0)
    result = []
    for f in range(frames):
        t = f / frames
        ridge = np.sin(angle * 5 + r * 15 + TAU * t * 2)
        y = 0.02 + 0.06 * r ** 1.3 * (1 - r ** 7) + 0.018 * ridge * np.sin(r * math.pi) - 0.03 * r ** 9
        pos = flat * 1 + np.stack([r * 0, y, r * 0], axis=1)
        h = 0.16 + 0.34 * ridge + 0.42 * r ** 0.7 + 0.14 * grain(flat, 0.0) - 0.6 * (1 - r) ** 4
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), SANDY), np.ones(len(pos)))))
    save("sand_pit", result, quads)


_old_guardian = water_guardian


def water_guardian():
    """Страж воды: та же фигура, но плотная, с пенными потоками по телу и светлыми гребнями на руках."""
    global WATER
    keep = WATER
    WATER = [(0.0, (0.0, 0.15, 0.48)), (0.45, (0.0, 0.34, 0.8)), (0.75, (0.05, 0.6, 0.96)), (0.92, (0.5, 0.9, 1.0)), (1.0, (0.96, 1.0, 1.0))]
    _old_guardian()
    WATER = keep


_old_fire_burst = fire_burst


def fire_burst():
    """Взрыв: кудрявые клубы огня с сажей на гребнях, которые быстро чернеют и уходят дымом."""
    _old_fire_burst()
    frames = 18
    dirs, quads, *_ = sphere(60, 40, axis=1)
    for name, size, delay, heat, seed in (("fire_burst_core", 1.0, 0.0, 1.1, 51), ("fire_burst_outer", 1.55, 0.1, 0.8, 57)):
        lobes = Flow(seed, freq=2.0, octaves=2, speed=0)
        billow = Flow(seed + 1, freq=4.6, octaves=4, gain=0.62, speed=0)
        soot = Flow(seed + 2, freq=3.2, octaves=3, speed=0)
        result = []
        for f in range(frames):
            t = f / (frames - 1)
            grow = 1 - (1 - min(1.0, t * 1.5)) ** 3
            lobe = lobes(dirs, 0.0)
            n = billow(dirs * (1.0 + t * 0.6), t)
            curl = 1 - np.abs(n)
            radius = size * (0.15 + 0.85 * grow) * (1 + 0.5 * lobe + 0.3 * curl ** 2)
            pos = dirs * radius[:, None]
            pos[:, 1] += 0.55 * size * t * t
            h = heat - t * 1.1 + 0.55 * n + 0.25 * lobe
            smoke = np.clip((t - 0.26 + 0.4 * soot(dirs, 0.0) + 0.25 * n) / 0.3, 0, 1)
            rgb = ramp(np.clip(h, 0, 1), EMBER) * (1 - smoke[:, None]) + ramp(np.clip(0.5 + n, 0, 1), ASH) * smoke[:, None]
            a = np.clip((1.3 - max(0.0, t - delay) ** 1.7 * 1.5) * 1.8 + 0.5 * n, 0, 1)
            result.append((pos, rgba(rgb, a)))
        save(name, result, quads)


def ball_lightning():
    """Шаровая молния: плотное ядро, по которому бегут светлые жилы, и короткие дуги наружу."""
    frames, arcs, nodes, nu = 12, 9, 12, 5
    dirs, core, *_ = sphere(40, 26, axis=1)
    arc = grid(nu, nodes)
    quads = faces([(len(dirs), core)] + [(nodes * nu, arc)] * arcs)
    churn = Flow(711, freq=2.4, octaves=3, speed=2)
    veins = Flow(712, freq=3.6, octaves=2, speed=2)
    along = np.linspace(0, 1, nodes)
    result = []
    for f in range(frames):
        t = f / frames
        n = churn(dirs, t)
        lines = caustic(veins, dirs, t, sharp=6)
        body = dirs * (0.58 + 0.09 * n)[:, None]
        shade = np.clip(0.42 + 0.22 * n + 0.8 * lines, 0, 1)
        parts = [(body, rgba(np.repeat(shade[:, None], 3, axis=1), np.ones(len(dirs))))]
        for a in range(arcs):
            rng = np.random.default_rng(7100 + a * 97 + f)
            way = rng.normal(size=3)
            way /= np.linalg.norm(way)
            path = way * (0.5 + along[:, None] * 1.25) + rng.normal(size=(nodes, 3)) * 0.2 * along[:, None]
            strand = tube(path, 0.06 - 0.05 * along, nu)
            parts.append((strand, rgba(np.ones((len(strand), 3)), np.ones(len(strand)))))
        result.append(stack(parts))
    save("ball_lightning", result, quads)
