# Данные подземелий и переводы. Запуск из любой папки: python art/dungeon_data.py
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "elements-mod/src/main/resources"
DATA = ROOT / "data/minevia_elements"
ASSETS = ROOT / "assets/minevia_elements"


def load(path):
    return json.loads(path.read_text(encoding="utf-8"))


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


WEAPONS = {
    "cinderwing": ("Углекрыл", "Cinderwing", "Каждый третий удар выпускает дугу пламени.", "Every third hit releases a flame arc."),
    "tidal_trident": ("Приливный трезубец", "Tidal Trident", "ПКМ: рывок сквозь врагов, в воде вдвое дальше. Попадания понемногу лечат. Перезарядка: 3,5 с.", "Use: dash through foes, twice as far in water. Hits restore a little health. Cooldown: 3.5s."),
    "night_shard": ("Осколок ночи", "Night Shard", "Быстрые атаки. Удар сзади наносит тройной урон.", "Fast attacks. Striking from behind deals triple damage."),
    "chime_maul": ("Молот-колокол", "Chime Maul", "Удар в падении усиливается с высотой и пускает волну по земле.", "A falling strike grows stronger with fall distance and sends a ground wave."),
    "windcutter": ("Ветрорез", "Windcutter", "ПКМ в воздухе: второй прыжок, один до приземления. Перезарядка: 2 с.", "Use in midair: a second jump, once before landing. Cooldown: 2s."),
    "gravity_flail": ("Гравитационный кистень", "Gravity Flail", "ПКМ: притягивает врагов к точке перед вами. Перезарядка: 5 с.", "Use: pull foes toward a point ahead of you. Cooldown: 5s."),
    "storm_bow": ("Лук бури", "Storm Bow", "Полностью натянутая стрела поражает молнией следующего врага рядом с попаданием.", "A fully drawn arrow chains lightning to another foe near the impact."),
    "soul_scythe": ("Коса душ", "Soul Scythe", "Широкий удар задевает всех врагов впереди. Убийство даёт ускорение на 3,5 с.", "A wide strike cleaves all foes ahead. Kills grant speed for 3.5s."),
}
RELICS = {
    "cinder_heart": ("Угольное сердце", "Cinder Heart", "В инвентаре защищает от огня.", "Grants fire resistance while in your inventory."),
    "smith_tongs": ("Клещи Кузнеца", "Smith's Tongs", "ПКМ: сковывает и ослабляет видимую цель. Перезарядка: 7 с.", "Use: bind and weaken a visible target. Cooldown: 7s."),
    "bellows_relic": ("Древние меха", "Ancient Bellows", "ПКМ: выброс жара отбрасывает врагов. Перезарядка: 9 с.", "Use: a heat burst damages and repels foes. Cooldown: 9s."),
    "pearl_of_air": ("Жемчужина воздуха", "Air Pearl", "В инвентаре даёт дышать под водой.", "Grants water breathing while in your inventory."),
    "tidal_shell": ("Раковина прилива", "Tidal Shell", "ПКМ: лечит и защищает на 5 с. Перезарядка: 10 с.", "Use: heal and gain protection for 5s. Cooldown: 10s."),
    "deep_lantern": ("Светоч глубин", "Depth Lantern", "В инвентаре даёт ночное зрение под водой.", "Grants night vision underwater while in your inventory."),
    "star_lens": ("Звёздная линза", "Star Lens", "ПКМ: отмечает чудовищ сквозь стены. Перезарядка: 15 с.", "Use: reveal monsters through walls. Cooldown: 15s."),
    "orbit_stone": ("Орбитальный камень", "Orbit Stone", "ПКМ: поле замедляет врагов на 4 с. Перезарядка: 8 с.", "Use: leave a slowing field for 4s. Cooldown: 8s."),
    "sky_anchor": ("Небесный якорь", "Sky Anchor", "В инвентаре замедляет долгое падение.", "Slows long falls while in your inventory."),
}
DUNGEONS = {
    "forge": ("Заброшенная кузня", "Abandoned Forge"),
    "sanctuary": ("Затопленное святилище", "Drowned Sanctuary"),
    "observatory": ("Небесная обсерватория", "Sky Observatory"),
}
BOSSES = {"smith": ("Кузнец", "The Smith"), "keeper": ("Хранитель глубин", "Keeper of the Depths"), "astronomer": ("Звездочёт", "The Astronomer")}
PAIRS = {"crypt": ["night_shard", "soul_scythe"], "tower": ["windcutter", "storm_bow"], "maze": ["gravity_flail", "chime_maul"],
         "forge": ["cinderwing", "chime_maul"], "sanctuary": ["tidal_trident", "soul_scythe"], "observatory": ["windcutter", "storm_bow"]}


def item(name, count=None):
    entry = {"type": "minecraft:item", "name": name}
    if count:
        entry["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": count[0], "max": count[1]}}]
    return entry


def main():
    for language, index in (("ru_ru", 0), ("en_us", 1)):
        file = ASSETS / f"lang/{language}.json"
        lang = load(file)
        for name, values in (WEAPONS | RELICS).items():
            lang[f"item.minevia_elements.{name}"] = values[index]
            lang[f"item.minevia_elements.{name}.hint"] = values[index + 2]
        for name, values in DUNGEONS.items():
            lang[f"temple.minevia_elements.{name}"] = values[index]
            lang[f"structure.minevia_elements.dungeon_{name}"] = values[index]
        descriptions = {
            "forge": ("Подземные горны, лавовые мосты и Кузнец с раскалённым молотом.", "Underground furnaces, lava bridges and the Smith's searing hammer."),
            "sanctuary": ("Затопленные залы, воздушные карманы и сухая дорожка к Хранителю.", "Flooded halls, air pockets and a dry path to the Keeper."),
            "observatory": ("Высокая опора, мосты между площадками и падающие звёзды.", "A towering pillar, bridges between platforms and falling stars."),
        }
        for name, values in descriptions.items():
            lang[f"temple.minevia_elements.{name}.desc"] = values[index]
        for name, values in BOSSES.items():
            lang[f"boss.minevia_elements.{name}"] = values[index]
        lang["itemGroup.minevia_elements.elements"] = ("Minevia: Четыре начала", "Minevia: Four Origins")[index]
        lang["message.minevia_elements.keeper_healing"] = ("Хранитель отступил в воду. Ударьте его, чтобы прервать лечение!", "The Keeper retreats into water. Strike to interrupt healing!")[index]
        lang["message.minevia_elements.keeper_interrupted"] = ("Лечение Хранителя прервано!", "The Keeper's healing is interrupted!")[index]
        save(file, lang)
    placement = load(DATA / "worldgen/structure_set/dungeons.json")
    placement["structures"] = [{"structure": "minevia_elements:dungeon_" + name, "weight": 1} for name in PAIRS]
    save(DATA / "worldgen/structure_set/dungeons.json", placement)
    places = load(DATA / "tags/worldgen/structure/places.json")
    for name in DUNGEONS:
        identifier = "minevia_elements:dungeon_" + name
        if identifier not in places["values"]:
            places["values"].append(identifier)
        structure = load(DATA / "worldgen/structure/dungeon_crypt.json")
        structure["kind"] = name
        structure["step"] = "surface_structures" if name == "observatory" else "underground_structures"
        save(DATA / f"worldgen/structure/dungeon_{name}.json", structure)
        save(DATA / f"tags/worldgen/structure/dungeon_{name}.json", {"replace": False, "values": [identifier]})
    save(DATA / "tags/worldgen/structure/places.json", places)
    materials = {"forge": ["minecraft:netherite_scrap", "minecraft:raw_copper", "minecraft:blaze_rod", "minecraft:diamond"],
                 "sanctuary": ["minecraft:heart_of_the_sea", "minecraft:nautilus_shell", "minecraft:prismarine_crystals", "minecraft:diamond"],
                 "observatory": ["minecraft:phantom_membrane", "minecraft:amethyst_shard", "minecraft:ender_pearl", "minecraft:diamond"]}
    for name, pair in PAIRS.items():
        file = DATA / f"loot_table/chests/{name}.json"
        if name in materials:
            table = {"type": "minecraft:chest", "pools": [
                {"rolls": 3, "entries": [item(n, (1, 3)) for n in materials[name]]},
                {"rolls": 2, "entries": [item("minecraft:experience_bottle", (8, 16)), item("minecraft:golden_apple", (1, 3)), item("minevia_elements:element_core")]},
                {"rolls": 3, "entries": [item("minevia_elements:essence_" + e) for e in ("fire", "water", "earth", "air")]},
            ]}
        else:
            table = load(file)
        # Повторный запуск заменяет только наш пул, не размножая награды.
        table["pools"] = [p for p in table["pools"] if not any(e.get("name", "").removeprefix("minevia_elements:") in WEAPONS for e in p.get("entries", []))]
        table["pools"].append({"rolls": 1, "entries": [item("minevia_elements:" + weapon) for weapon in pair]})
        save(file, table)
    for name in WEAPONS | RELICS:
        parent = "minecraft:item/handheld" if name in WEAPONS else "minecraft:item/generated"
        model = {"parent": parent, "textures": {"layer0": "minevia_elements:item/" + name}}
        if name == "storm_bow":
            model["parent"] = "minecraft:item/bow"
            model["overrides"] = [{"predicate": {"pulling": 1, **({"pull": pull} if pull else {})}, "model": f"minevia_elements:item/storm_bow_pulling_{i}"} for i, pull in enumerate((0, 0.65, 0.9))]
            for i in range(3):
                save(ASSETS / f"models/item/storm_bow_pulling_{i}.json", {"parent": "minecraft:item/bow", "textures": {"layer0": f"minevia_elements:item/storm_bow_pulling_{i}"}})
        save(ASSETS / f"models/item/{name}.json", model)
    variants = load(ASSETS / "blockstates/dungeon_sigil.json")
    for i in range(3, 6):
        variants["variants"][f"kind={i}"] = {"model": f"minevia_elements:block/dungeon_sigil_{i}"}
        save(ASSETS / f"models/block/dungeon_sigil_{i}.json", {"parent": "minecraft:block/carpet", "textures": {"wool": f"minevia_elements:block/dungeon_sigil_{i}", "particle": f"minevia_elements:block/dungeon_sigil_{i}"}})
    save(ASSETS / "blockstates/dungeon_sigil.json", variants)
    melee = ["minevia_elements:" + w for w in WEAPONS if w != "storm_bow"]
    save(ROOT / "data/minecraft/tags/item/swords.json", {"replace": False, "values": melee})
    for tag, values in {"bow": ["minevia_elements:storm_bow"], "durability": ["minevia_elements:" + w for w in WEAPONS]}.items():
        save(ROOT / f"data/minecraft/tags/item/enchantable/{tag}.json", {"replace": False, "values": values})
    print("6 dungeons, 8 weapons, 18 relics: data and translations ready")


if __name__ == "__main__":
    main()
