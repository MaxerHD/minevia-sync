package local.minevia.elements.client;

import com.mojang.blaze3d.systems.RenderSystem;
import local.minevia.elements.Abilities;
import local.minevia.elements.Element;
import local.minevia.elements.ElementState;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.net.CastPayload;
import local.minevia.elements.net.PlayerSkinPayload;
import local.minevia.elements.net.StatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;
import net.minecraft.client.util.InputUtil;
import net.minecraft.resource.ResourceType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ElementsClient implements ClientModInitializer {
    private static final String CATEGORY = "category.minevia_elements";
    // В сборке заняты почти все буквы, а у клавиши работает только одно действие: эти свободны.
    private static final int[] DEFAULT_KEYS = {
            GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_N, GLFW.GLFW_KEY_UNKNOWN, GLFW.GLFW_KEY_UNKNOWN, GLFW.GLFW_KEY_UNKNOWN};
    /** Столько тиков надо держать первую клавишу, чтобы открылся круг, а не сработала способность. */
    private static final int WHEEL_DELAY = 4;
    private static final int SLOT = 11;
    private static final int ORB_FRAMES = 24;
    private static final int ORB_COLUMNS = 6;
    private static final int ORB_SIZE = 256;

    static final KeyBinding[] KEYS = new KeyBinding[Abilities.SLOTS];
    static KeyBinding menuKey;

    static Element element;
    static int level;
    static int xp;
    static int path;
    /** Способность на коротком нажатии первой клавиши: последняя выбранная в круге. */
    static int chosen;
    private static boolean holding;
    private static boolean heldWithShift;
    private static int heldTicks;
    static final int[] COOLDOWN = new int[Abilities.SLOTS];

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(MineviaElements.SPELL, SpellRenderer::new);
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SpellMesh.Loader());
        for (int i = 0; i < KEYS.length; i++) {
            KEYS[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.minevia_elements.ability" + (i + 1), InputUtil.Type.KEYSYM, DEFAULT_KEYS[i], CATEGORY));
        }
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.minevia_elements.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY));
        Zoom.key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.minevia_elements.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));
        ClientPlayNetworking.registerGlobalReceiver(StatePayload.ID, (payload, context) -> {
            element = Element.values()[payload.element()];
            level = payload.level();
            xp = payload.xp();
            path = payload.path();
            for (int i = 0; i < COOLDOWN.length; i++) {
                COOLDOWN[i] = payload.cooldowns().get(i);
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            element = null;
            chosen = 0;
            SkinClient.clear(client);
        });
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> SkinClient.upload());
        ClientPlayNetworking.registerGlobalReceiver(PlayerSkinPayload.ID,
                (payload, context) -> SkinClient.receive(context.client(), payload.player(), payload.png()));
        BlockEntityRendererFactories.register(MineviaElements.ALTAR_ENTITY, AltarRenderer::new);
        EntityRendererRegistry.register(MineviaElements.BOSS, BossRenderer::new);
        ClientTickEvents.END_CLIENT_TICK.register(ElementsClient::tick);
        HudRenderCallback.EVENT.register(ElementsClient::draw);
    }

    private static void tick(MinecraftClient client) {
        for (int i = 0; i < COOLDOWN.length; i++) {
            if (COOLDOWN[i] > 0) {
                COOLDOWN[i]--;
            }
        }
        tickFirstKey(client);
        for (int i = 1; i < KEYS.length; i++) {
            while (KEYS[i].wasPressed()) {
                // Shift + вторая клавиша даёт пятую способность.
                cast(i == 1 && client.options.sneakKey.isPressed() ? 4 : i);
            }
        }
        while (menuKey.wasPressed()) {
            if (element != null && client.currentScreen == null) {
                client.setScreen(new ElementScreen());
            }
        }
    }

    /**
     * Первая клавиша делает три вещи: короткое нажатие повторяет выбранную способность,
     * Shift с ней даёт четвёртую, а если её держать, открывается круг всех способностей.
     */
    private static void tickFirstKey(MinecraftClient client) {
        boolean pressed = false;
        while (KEYS[0].wasPressed()) {
            pressed = true;
        }
        if (client.currentScreen != null || element == null) {
            holding = false;
            AbilityWheel.close();
            return;
        }
        if (pressed && !holding) {
            holding = true;
            heldTicks = 0;
            heldWithShift = client.options.sneakKey.isPressed();
        }
        if (!holding) {
            return;
        }
        if (KEYS[0].isPressed()) {
            heldTicks++;
            if (heldTicks >= WHEEL_DELAY && !heldWithShift && !AbilityWheel.isOpen()) {
                AbilityWheel.open();
            }
            return;
        }
        holding = false;
        if (AbilityWheel.isOpen()) {
            int slot = AbilityWheel.close();
            if (slot >= 0) {
                chosen = slot;
                cast(slot);
            }
        } else {
            cast(heldWithShift ? 3 : chosen);
        }
    }

    private static void cast(int slot) {
        if (MinecraftClient.getInstance().player != null && ClientPlayNetworking.canSend(CastPayload.ID)) {
            ClientPlayNetworking.send(new CastPayload(slot));
        }
    }

    /** Название способности с учётом выбранного пути. */
    static Text abilityName(int slot) {
        if (slot == Abilities.PATH_SLOT) {
            return Text.translatable(element.pathKey(Math.max(1, path)));
        }
        return Text.translatable(element.abilityKey(slot));
    }

    /** Подпись клавиши латиницей: на русской раскладке игра показала бы другую букву. */
    static String keyLabel(KeyBinding key) {
        int code = KeyBindingHelper.getBoundKeyOf(key).getCode();
        if (code >= GLFW.GLFW_KEY_A && code <= GLFW.GLFW_KEY_Z) {
            return String.valueOf((char) code);
        }
        return key.getBoundKeyLocalizedText().getString();
    }

    static String slotLabel(int slot, boolean compact) {
        if (slot < 3 || !KEYS[slot].isUnbound()) {
            return keyLabel(KEYS[slot]);
        }
        if (slot == Abilities.PATH_SLOT) {
            return compact ? "" : Text.translatable("screen.minevia_elements.wheel_only").getString();
        }
        return (compact ? "S+" : "Shift+") + keyLabel(KEYS[slot - 3]);
    }

    static Identifier abilityIcon(int slot) {
        String suffix = slot == Abilities.PATH_SLOT ? "path" + Math.max(1, path) : String.valueOf(slot + 1);
        return Identifier.of(MineviaElements.MOD_ID, "textures/gui/ability/" + element.id() + "_" + suffix + ".png");
    }

    /** Кадр зацикленной 3D-анимации ядра, отрендеренной в Blender. */
    static void drawOrb(DrawContext context, int x, int y, int size) {
        String name = element.id();
        Identifier sheet = Identifier.of(MineviaElements.MOD_ID, "textures/gui/orb/" + name + ".png");
        int frame = (int) (System.currentTimeMillis() / 75 % ORB_FRAMES);
        int u = frame % ORB_COLUMNS * ORB_SIZE;
        int v = frame / ORB_COLUMNS * ORB_SIZE;
        int rows = ORB_FRAMES / ORB_COLUMNS;
        RenderSystem.enableBlend();
        context.setShaderColor(0.82F, 0.82F, 0.82F, 0.92F);
        context.drawTexture(sheet, x, y, size, size, u, v, ORB_SIZE, ORB_SIZE, ORB_SIZE * ORB_COLUMNS, ORB_SIZE * rows);
        context.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    static void drawIcon(DrawContext context, int slot, int x, int y, int size) {
        RenderSystem.enableBlend();
        context.setShaderColor(0.7F, 0.7F, 0.7F, 0.88F);
        context.drawTexture(abilityIcon(slot), x, y, size, size, 0, 0, 64, 64, 64, 64);
        context.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    static void drawPathIcon(DrawContext context, int path, int x, int y, int size) {
        Identifier icon = Identifier.of(MineviaElements.MOD_ID, "textures/gui/ability/" + element.id() + "_path" + path + ".png");
        RenderSystem.enableBlend();
        context.drawTexture(icon, x, y, size, size, 0, 0, 64, 64, 64, 64);
        RenderSystem.disableBlend();
    }

    static void drawSmallText(DrawContext context, String text, int x, int y, int color, float scale) {
        MinecraftClient client = MinecraftClient.getInstance();
        context.getMatrices().push();
        context.getMatrices().translate(x, y, 200);
        context.getMatrices().scale(scale, scale, 1);
        context.drawTextWithShadow(client.textRenderer, text, 0, 0, color);
        context.getMatrices().pop();
    }

    private static void draw(DrawContext context, RenderTickCounter counter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (element == null || client.options.hudHidden || client.getDebugHud().shouldShowDebugHud()) {
            return;
        }
        AbilityWheel.draw(context);
        int border = 0x70000000 | element.color;
        int x = context.getScaledWindowWidth() / 2 + 96;
        int y = context.getScaledWindowHeight() - 16;

        drawOrb(context, x - 1, y - 2, 15);
        drawSmallText(context, String.valueOf(level), x + 10, y + 8, 0xFFC8D0D6, 0.5F);
        x += 16;

        int shown = path > 0 ? Abilities.SLOTS : Abilities.SLOTS - 1;
        for (int i = 0; i < shown; i++) {
            int left = x + i * (SLOT + 1);
            boolean open = level >= Abilities.unlockLevel(i);
            context.fill(left - 1, y - 1, left + SLOT + 1, y + SLOT + 1, i == chosen ? 0xFF000000 | element.color : open ? border : 0x503A444E);
            context.fill(left, y, left + SLOT, y + SLOT, 0xB00D1620);
            drawIcon(context, i, left, y, SLOT);
            if (!open) {
                context.fill(left, y, left + SLOT, y + SLOT, 0xC00A1018);
            } else if (COOLDOWN[i] > 0) {
                int shade = SLOT * COOLDOWN[i] / Abilities.COOLDOWNS[i];
                context.fill(left, y + SLOT - shade, left + SLOT, y + SLOT, 0xB0000000);
                String seconds = String.valueOf(COOLDOWN[i] / 20 + 1);
                int width = client.textRenderer.getWidth(seconds);
                drawSmallText(context, seconds, left + (SLOT - width / 2) / 2, y + 3, 0xFFE8EDF0, 0.55F);
            }
            drawSmallText(context, slotLabel(i, true), left + 1, y + SLOT + 2, open ? 0xFFAEB9C1 : 0xFF66727B, 0.4F);
        }

        if (level == 1) {
            int width = Abilities.SLOTS * (SLOT + 1) - 1;
            int filled = width * xp / ElementState.XP_FOR_LEVEL_TWO;
            context.fill(x, y - 3, x + width, y - 2, 0x90000000);
            context.fill(x, y - 3, x + filled, y - 2, border);
        }
    }
}
