# Minevia: Четыре начала

Мод для Minecraft 1.21.1 (Fabric), лицензия GNU GPL версии 3 или новее, текст в файле `LICENSE`.

## Откуда взято

Поведение и параметры части способностей основаны на открытом проекте
[AvatarMod](https://github.com/ProjectKorra/AvatarMod) (GPL-3).
Авторы исходного мода: John Atkins, Luka Leer, CrowsOfWar, Mahtaran, FavouriteDragon, ProjectKorra.

## Что изменено

Код написан заново под новую версию игры. Способности показаны собственными анимированными 3D-моделями
(`SpellEntity.java`, `SpellRenderer.java`, файлы `.mesh`), сделанными скриптом для Blender `art/spells.py`.
Добавлены выдача уникальной стихии, уровни через Ядра стихий, новый интерфейс и иконки,
комбо двух стихий, вторая ступень с выбором пути, храмы со стражами и финальный босс Исток.
Модели стражей лежат в `art/spells_more.py`, текстуры в `art/textures.py`.
Все звуки синтезированы скриптом `art/sounds.py`, записей других людей в моде нет.

Проект не связан с авторами AvatarMod и с правообладателями сериала. Он сделан для игры с друзьями.

## Звуки

Записи для звуков навыков: rubberduck, наборы с OpenGameArt.org (80 CC0 RPG SFX, 100 CC0 SFX, 100 CC0 metal and wood SFX, 40 CC0 water, splash, slime SFX, 25 CC0 bang, firework SFX, 75 CC0 breaking, falling, hit SFX), лицензия CC0. Записи переработаны.
