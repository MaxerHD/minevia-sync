# Лепит и анимирует 3D-модели способностей и пишет их покадрово в файлы .mesh.
# Запуск: blender -b --factory-startup -P spells.py -- [имена моделей]
# Ось +Z смотрит вперёд по полёту, +Y вверх. Топология у всех кадров одна, поэтому игра плавно
# смешивает соседние кадры, и анимация не дёргается при любом FPS.
import gzip
import math
import os
import struct
import sys

import bmesh
import bpy
import numpy as np

OUT = r"D:\Rudnik\elements-mod\src\main\resources\assets\minevia_elements\mesh"
TAU = math.tau

FIRE = [(0.0, (0.22, 0.02, 0.0)), (0.30, (0.62, 0.08, 0.01)), (0.55, (0.90, 0.24, 0.02)),
        (0.78, (0.98, 0.46, 0.05)), (1.0, (1.0, 0.70, 0.22))]
WATER = [(0.0, (0.03, 0.20, 0.48)), (0.5, (0.08, 0.42, 0.76)), (0.8, (0.34, 0.72, 0.92)), (1.0, (0.92, 0.98, 1.0))]
WIND = [(0.0, (0.40, 0.50, 0.60)), (0.55, (0.70, 0.80, 0.86)), (1.0, (0.97, 1.0, 1.0))]


class Flow:
    """Плавный шум из синусоид: целое число оборотов по времени даёт идеальную петлю."""

    def __init__(self, seed, freq=1.6, octaves=4, gain=0.55, speed=1):
        rng = np.random.default_rng(seed)
        waves = []
        amp = 1.0
        for octave in range(octaves):
            for _ in range(3):
                k = rng.normal(size=3)
                k = k / np.linalg.norm(k) * freq * 1.9 ** octave
                cycles = int(rng.integers(1, 2 + octave)) * speed * (1 if rng.random() < 0.5 else -1)
                waves.append((k, rng.uniform(0, TAU), cycles, amp))
            amp *= gain
        self.waves = waves
        self.norm = sum(w[3] for w in waves) ** 0.5 * 1.4

    def __call__(self, p, t):
        total = np.zeros(len(p))
        for k, phase, cycles, amp in self.waves:
            total += amp * np.sin(p @ k + phase + TAU * cycles * t)
        return np.clip(total / self.norm, -1.0, 1.0)


def ramp(h, stops):
    xs = [s[0] for s in stops]
    return np.stack([np.interp(h, xs, [s[1][c] for s in stops]) for c in range(3)], axis=1)


def rgba(rgb, alpha):
    return np.concatenate([rgb, np.clip(alpha, 0, 1)[:, None]], axis=1)


def grid(nu, nv, wrap=True):
    """Сетка из nv рядов по nu вершин: возвращает четырёхугольники."""
    quads = []
    columns = nu if wrap else nu - 1
    for v in range(nv - 1):
        for u in range(columns):
            a = v * nu + u
            b = v * nu + (u + 1) % nu
            quads.append((a, b, b + nu, a + nu))
    return np.array(quads, dtype=np.int32)


def sphere(nu, nv, axis=2):
    """Единичная сфера с полюсами на выбранной оси."""
    theta = np.linspace(0, TAU, nu, endpoint=False)
    phi = np.linspace(0, math.pi, nv)
    t, f = np.meshgrid(theta, phi)
    a = (np.sin(f) * np.cos(t)).ravel()
    b = (np.sin(f) * np.sin(t)).ravel()
    c = np.cos(f).ravel()
    dirs = np.stack([a, b, c], axis=1) if axis == 2 else np.stack([a, c, b], axis=1)
    return dirs, grid(nu, nv), t.ravel(), f.ravel()


def cube_sphere(cuts):
    """Сфера из четырёхугольников: из неё лепятся камни."""
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=2.0)
    bmesh.ops.subdivide_edges(bm, edges=bm.edges[:], cuts=cuts, use_grid_fill=True)
    bm.verts.index_update()
    pos = np.array([v.co[:] for v in bm.verts])
    quads = np.array([[v.index for v in f.verts] for f in bm.faces if len(f.verts) == 4], dtype=np.int32)
    bm.free()
    return pos / np.linalg.norm(pos, axis=1, keepdims=True), quads


def normals(pos, quads):
    a, b, c, d = (pos[quads[:, i]] for i in range(4))
    face = np.cross(c - a, d - b)
    out = np.zeros_like(pos)
    for i in range(4):
        np.add.at(out, quads[:, i], face)
    length = np.linalg.norm(out, axis=1, keepdims=True)
    return out / np.maximum(length, 1e-9)


def save(name, frames, quads):
    """frames: список пар (позиции Nx3, цвет Nx4). Записывает сжатый файл для игры."""
    verts = len(frames[0][0])
    extent = max(float(np.abs(f[0]).max()) for f in frames) or 1.0
    body = bytearray(struct.pack(">iiiif", 0x4D4D5348, verts, len(quads), len(frames), extent))
    body += np.asarray(quads, dtype=">u2").tobytes()
    for pos, col in frames:
        body += np.round(pos / extent * 32767).astype(">i2").tobytes()
        body += np.round(normals(pos, quads) * 127).astype(np.int8).tobytes()
        body += np.round(np.clip(col, 0, 1) * 255).astype(np.uint8).tobytes()
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name + ".mesh")
    with gzip.GzipFile(path, "wb", compresslevel=9, mtime=0) as out:
        out.write(bytes(body))
    print(f"{name}: {verts} вершин, {len(quads)} граней, {len(frames)} кадров, {os.path.getsize(path) // 1024} КБ")


def merged(parts):
    """Склеивает статичные части (позиции, грани, цвет) в одну модель."""
    pos, col, quads, offset = [], [], [], 0
    for p, q, c in parts:
        pos.append(p)
        col.append(c)
        quads.append(q + offset)
        offset += len(p)
    return np.concatenate(pos), np.concatenate(quads), np.concatenate(col)


def rotation(axis, angle):
    axis = np.asarray(axis, dtype=float)
    axis = axis / np.linalg.norm(axis)
    x, y, z = axis
    c, s = math.cos(angle), math.sin(angle)
    k = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]])
    return np.eye(3) * c + s * k + (1 - c) * np.outer(axis, axis)


# ---------------------------------------------------------------- огонь

def comet(name, radius, tail, seed, heat, alpha, ragged, frames=24, nu=34, nv=26):
    """Слой фаербола: круглая голова и рваные языки, сдуваемые назад."""
    dirs, quads, theta, _ = sphere(nu, nv)
    big = Flow(seed, freq=1.5, octaves=3, speed=1)
    fine = Flow(seed + 1, freq=3.2, octaves=3, speed=2)
    side = Flow(seed + 2, freq=1.1, octaves=2, speed=1)
    side2 = Flow(seed + 3, freq=1.1, octaves=2, speed=1)
    result = []
    back = (1 - dirs[:, 2]) / 2
    for f in range(frames):
        t = f / frames
        n = big(dirs, t)
        m = fine(dirs, t)
        tongue = np.abs(fine(dirs * 1.7 + 3, t))
        swell = 1 + 0.2 * n + 0.1 * m
        pos = dirs * radius * swell[:, None]
        rear = back ** 2.4
        pos[:, 0:2] *= (1 - 0.72 * rear)[:, None]
        pos[:, 2] -= tail * rear * (0.45 + 1.5 * tongue)
        drift = rear * tail * 0.32
        pos[:, 0] += drift * side(dirs, t)
        pos[:, 1] += drift * side2(dirs, t)
        h = heat - back * 0.95 + 0.26 * n + 0.14 * m
        a = alpha * np.clip(1.5 - rear * 1.7 + 0.35 * m, 0, 1) * np.clip(ragged + 2.6 * tongue, 0, 1)
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), FIRE), a)))
    save(name, result, quads)


def fireball():
    comet("fireball_core", 0.40, 0.55, 11, 1.05, 1.0, 1.0)
    comet("fireball_mid", 0.56, 1.25, 23, 0.74, 0.86, 0.4)
    comet("fireball_outer", 0.74, 2.2, 37, 0.5, 0.6, 0.1)


def fire_burst():
    """Взрыв: клубы огня раздуваются неровными долями, остывают и становятся тающим дымом."""
    frames = 18
    dirs, quads, *_ = sphere(40, 28, axis=1)
    for name, size, delay, heat, seed in (("fire_burst_core", 1.0, 0.0, 1.1, 51), ("fire_burst_outer", 1.55, 0.1, 0.78, 57)):
        lobes = Flow(seed, freq=1.7, octaves=2, speed=0)
        billow = Flow(seed + 1, freq=4.2, octaves=3, gain=0.6, speed=0)
        result = []
        for f in range(frames):
            t = f / (frames - 1)
            grow = 1 - (1 - min(1.0, t * 1.5)) ** 3
            lobe = lobes(dirs, 0.0)
            n = billow(dirs * (1.0 + t * 0.6), t)
            puffs = np.abs(n) ** 0.7
            radius = size * (0.15 + 0.85 * grow) * (1 + 0.5 * lobe + 0.34 * puffs)
            pos = dirs * radius[:, None]
            pos[:, 1] += 0.55 * size * t * t
            h = heat - t * 1.2 + 0.5 * n + 0.25 * lobe
            smoke = np.clip((t - 0.42 + 0.25 * n) / 0.5, 0, 1)
            rgb = ramp(np.clip(h, 0, 1), FIRE) * (1 - smoke[:, None]) + np.array([0.16, 0.13, 0.12]) * smoke[:, None]
            a = np.clip(1.2 - max(0.0, t - delay) ** 1.7 * 1.3 + 0.35 * n, 0, 1)
            result.append((pos, rgba(rgb, a)))
        save(name, result, quads)
    # Ударная волна: тонкое расходящееся кольцо.
    nu, nv = 72, 5
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    ring = np.repeat(np.linspace(-1, 1, nv), nu)
    quads = grid(nu, nv)
    wob = Flow(53, freq=2.5, octaves=2, speed=0)
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        radius = 0.3 + 2.1 * (1 - (1 - t) ** 2.4)
        r = radius + ring * (0.1 + 0.32 * t)
        pos = np.stack([r * np.cos(theta), 0.06 * np.sin(ring * 2) * (1 - t), r * np.sin(theta)], axis=1)
        n = wob(pos, t)
        a = (1 - np.abs(ring)) ** 1.2 * (1 - t) ** 1.3 * (0.75 + 0.25 * n)
        result.append((pos, rgba(ramp(np.clip(0.9 - t * 0.7 + 0 * n, 0, 1), FIRE), a)))
    save("fire_shock", result, quads)


def flame_ring():
    """Стена живого огня по кругу: языки разной высоты бегут вверх."""
    frames, nu, nv = 24, 88, 11
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    quads = grid(nu, nv)
    base = np.stack([np.cos(theta), np.zeros_like(theta), np.sin(theta)], axis=1)
    tall = Flow(61, freq=5.0, octaves=2, speed=1)
    lick = Flow(62, freq=4.0, octaves=3, speed=2)
    result = []
    for f in range(frames):
        t = f / frames
        p = base * 1.0 + np.stack([np.zeros_like(s), s * 1.3, np.zeros_like(s)], axis=1)
        height = np.clip(0.3 + 3.4 * np.abs(tall(base, t)), 0, 1.7)
        n = lick(p, t)
        radius = 1 + (0.13 * n - 0.12 * s) * s
        pos = np.stack([np.cos(theta) * radius, s * height * 1.25, np.sin(theta) * radius], axis=1)
        h = 0.95 - s * 0.85 + 0.25 * n
        a = np.clip((1 - s) ** 0.7 * 1.8 + 0.3 * n, 0, 1) * np.clip(s * 7 + 0.15, 0, 1) * np.clip(0.75 - s * 0.6 + 2.2 * n, 0, 1)
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), FIRE), a)))
    save("flame_ring", result, quads)


# ---------------------------------------------------------------- вода

def water_blob():
    frames = 24
    dirs, quads, *_ = sphere(30, 22)
    wobble = Flow(81, freq=1.3, octaves=3, gain=0.45, speed=1)
    ripple = Flow(82, freq=3.0, octaves=2, speed=2)
    result = []
    for f in range(frames):
        t = f / frames
        n = wobble(dirs, t)
        m = ripple(dirs, t)
        pos = dirs * (0.62 * (1 + 0.26 * n + 0.05 * m))[:, None]
        h = 0.48 + 0.5 * m + 0.25 * dirs[:, 1]
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), WATER), np.full(len(pos), 0.62))))
    save("water_blob", result, quads)


def water_stream():
    """Гибкая водяная трубка длиной в единицу: игра растягивает её до цели."""
    frames, nu, nv = 24, 14, 40
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    quads = grid(nu, nv)
    swell = Flow(85, freq=5.0, octaves=2, speed=2)
    bend = Flow(86, freq=3.0, octaves=2, speed=1)
    result = []
    for f in range(frames):
        t = f / frames
        axis = np.stack([s * 3, s * 0, s * 0], axis=1)
        ends = np.sin(s * math.pi) ** 0.6
        radius = (0.11 + 0.1 * (swell(axis, t) + 1)) * (0.45 + 0.55 * ends)
        cx = bend(axis, t) * 0.2 * ends
        cy = bend(axis + 5, t) * 0.2 * ends
        pos = np.stack([np.cos(theta) * radius + cx, np.sin(theta) * radius + cy, s], axis=1)
        h = 0.5 + 0.45 * np.sin(theta * 2 + s * 18 - TAU * t * 3)
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), WATER), np.full(len(pos), 0.72))))
    save("water_stream", result, quads)


def bits(count, seed, spread, up, gravity, size, life=1.0):
    """Разлетающиеся куски: начальная скорость, вращение и падение по законам баллистики."""
    rng = np.random.default_rng(seed)
    out = []
    for _ in range(count):
        angle = rng.uniform(0, TAU)
        speed = rng.uniform(0.4, 1.0) * spread
        out.append({
            "v": np.array([math.cos(angle) * speed, rng.uniform(0.4, 1.0) * up, math.sin(angle) * speed]),
            "axis": rng.normal(size=3), "spin": rng.uniform(4, 14),
            "size": rng.uniform(0.45, 1.0) * size, "gravity": gravity, "life": life * rng.uniform(0.7, 1.0),
        })
    return out


def water_splash():
    """Брызги: водяная корона и капли, которые летят и падают."""
    frames = 16
    nu, nv = 52, 9
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    crown = grid(nu, nv)
    teeth = Flow(91, freq=3.2, octaves=2, speed=0)
    drops = bits(26, 92, 3.2, 3.6, 7.0, 0.14)
    drop_pos, drop_quads = cube_sphere(1)
    per_drop = len(drop_pos)
    quads = np.concatenate([crown] + [drop_quads + len(theta) + i * per_drop for i in range(len(drops))])
    ring = np.stack([np.cos(theta), s * 0, np.sin(theta)], axis=1)
    jag = 0.6 + 0.8 * np.abs(teeth(ring, 0.0))
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        spread = 0.25 + 1.5 * (1 - (1 - t) ** 2)
        lift = 1.3 * math.sin(min(1.0, t * 1.25) * math.pi) ** 0.8 * jag
        radius = spread * (0.5 + 0.5 * s + 0.2 * s * s)
        pos = np.stack([radius * np.cos(theta), lift * s ** 1.4, radius * np.sin(theta)], axis=1)
        col = rgba(ramp(np.clip(0.42 + 0.58 * s, 0, 1), WATER), (1 - s * 0.35) * (1 - t ** 2.2) * 0.8)
        parts_pos, parts_col = [pos], [col]
        for d in drops:
            k = min(1.0, t / d["life"])
            center = d["v"] * t * 0.55 - np.array([0, d["gravity"] * t * t * 0.5 * 0.55, 0])
            shape = drop_pos * d["size"] * (1 - k ** 3)
            parts_pos.append(shape + center)
            parts_col.append(rgba(ramp(np.full(per_drop, 0.8), WATER), np.full(per_drop, 0.85 * (1 - k ** 3))))
        result.append((np.concatenate(parts_pos), np.concatenate(parts_col)))
    save("water_splash", result, quads)


def water_wave():
    """Настоящая волна: стена воды с закрученным гребнем и белой пеной."""
    frames, nu, nv = 24, 46, 22
    x = np.tile(np.linspace(-1, 1, nu), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    quads = grid(nu, nv, wrap=False)
    chop = Flow(95, freq=2.2, octaves=3, speed=1)
    result = []
    for f in range(frames):
        t = f / frames
        flat = np.stack([x * 3, s * 2, s * 0], axis=1)
        n = chop(flat, t)
        crest = 1 + 0.2 * chop(np.stack([x * 2, x * 0, x * 0], axis=1), t)
        curl = s ** 3
        y = (math.pi * 0 + np.sin(s * 2.6) / math.sin(2.6 * 0.72)) * 2.3 * crest
        y = np.where(s > 0.72, y, y)
        z = -1.1 * (1 - s) ** 1.5 + 1.6 * curl - 0.65 * np.maximum(s - 0.8, 0) * 5 * 0.4 + 0.08 * n
        edge = 1 - np.abs(x) ** 6
        pos = np.stack([x * 3.0, y * edge + 0.11 * n, z * edge], axis=1)
        foam = np.clip((s - 0.68) * 3.4 + 0.35 * n, 0, 1)
        h = 0.3 + 0.35 * s + foam * 0.65 + 0.14 * n
        a = 0.74 * np.clip(s * 8, 0, 1) + foam * 0.2
        result.append((pos, rgba(ramp(np.clip(h, 0, 1), WATER), a)))
    save("water_wave", result, quads)


def helix():
    """Три ленты, бегущие вверх по спирали. Белая: цвет задаёт игра."""
    frames, nu, nv = 24, 3, 76
    across = np.tile(np.linspace(-1, 1, nu), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    one = grid(nu, nv, wrap=False)
    count = nu * nv
    quads = np.concatenate([one + i * count for i in range(3)])
    result = []
    for f in range(frames):
        t = f / frames
        all_pos, all_col = [], []
        for ribbon in range(3):
            offset = ribbon * TAU / 3
            theta = s * TAU * 2.1 + offset + TAU * t
            radius = 0.82 - 0.22 * s + across * 0.12
            pos = np.stack([radius * np.cos(theta), s * 2.2 + across * 0.05, radius * np.sin(theta)], axis=1)
            pulse = 0.25 + 0.75 * np.maximum(0, np.sin(TAU * (2 * s - 2 * t) + offset)) ** 2
            a = pulse * np.sin(s * math.pi) ** 0.7 * (1 - np.abs(across) ** 2)
            all_pos.append(pos)
            all_col.append(rgba(np.ones((count, 3)), a))
        result.append((np.concatenate(all_pos), np.concatenate(all_col)))
    save("helix", result, quads)


def crystal(height, width, sides=6):
    """Ледяной кристалл с плоскими гранями: у каждой грани свои вершины."""
    ring = [(math.cos(i / sides * TAU) * width, math.sin(i / sides * TAU) * width) for i in range(sides)]
    pos, quads = [], []
    for i in range(sides):
        a, b = ring[i], ring[(i + 1) % sides]
        shoulder = height * 0.72
        base = len(pos)
        pos += [(a[0], 0, a[1]), (b[0], 0, b[1]), (b[0] * 0.92, shoulder, b[1] * 0.92), (a[0] * 0.92, shoulder, a[1] * 0.92)]
        quads.append((base, base + 3, base + 2, base + 1))
        base = len(pos)
        tip = (0, height, 0)
        pos += [(a[0] * 0.92, shoulder, a[1] * 0.92), (b[0] * 0.92, shoulder, b[1] * 0.92), tip, tip]
        quads.append((base, base + 3, base + 2, base + 1))
    return np.array(pos, dtype=float), np.array(quads, dtype=np.int32)


def ice_shard():
    """Группа кристаллов льда, наклонённых наружу. Из таких групп складывается кольцо."""
    rng = np.random.default_rng(101)
    parts = []
    for i in range(4):
        pos, quads = crystal(rng.uniform(1.1, 2.1), rng.uniform(0.15, 0.27))
        angle = rng.uniform(0, TAU)
        tilt = rotation((1, 0, 0), rng.uniform(0.1, 0.5)) @ rotation((0, 1, 0), rng.uniform(0, TAU))
        placed = pos @ tilt.T + np.array([math.cos(angle), -0.2, math.sin(angle)]) * 0.3 * (i > 0)
        h = np.clip(placed[:, 1] / 2.0, 0, 1)
        rgb = np.array([0.12, 0.42, 0.78]) * (1 - h[:, None]) + np.array([0.55, 0.82, 0.98]) * h[:, None]
        parts.append((placed, quads, rgba(rgb, np.full(len(pos), 0.7))))
    pos, quads, col = merged(parts)
    save("ice_shard", [(pos, col)], quads)


# ---------------------------------------------------------------- земля

def rock(seed, cuts=11, planes=13, scale=(1, 1, 1), depth=0.62):
    """Камень: шар, обрубленный случайными плоскостями. Сколы плоские и острые, по ним бегут трещины."""
    rng = np.random.default_rng(seed)
    pos, quads = cube_sphere(cuts)
    for _ in range(planes):
        n = rng.normal(size=3)
        n /= np.linalg.norm(n)
        limit = rng.uniform(depth, 0.95)
        over = np.maximum(pos @ n - limit, 0)
        pos = pos - np.outer(over, n) * 0.96
    grain = Flow(seed + 1, freq=4.5, octaves=4, gain=0.62, speed=0)
    veins = Flow(seed + 2, freq=3.0, octaves=3, gain=0.6, speed=0)
    pos = pos * (1 + 0.05 * grain(pos, 0.0))[:, None]
    tone = grain(pos * 1.9 + 4, 0.0)
    crack = np.clip(1 - np.abs(veins(pos, 0.0)) * 9, 0, 1) ** 1.5
    pos = pos * (1 - 0.035 * crack)[:, None]
    pos = pos * np.array(scale)
    strata = 0.5 + 0.5 * np.sin(pos[:, 1] * 15 + 2.2 * tone)
    grey = np.clip(0.72 + 0.32 * tone + 0.1 * strata - 0.5 * crack, 0.1, 1)
    return pos, quads, rgba(np.stack([grey, grey * 0.97, grey * 0.92], axis=1), np.ones(len(pos)))


def boulder():
    pos, quads, col = rock(201, cuts=14, planes=15, scale=(0.86, 0.74, 0.92))
    save("boulder", [(pos, col)], quads)


def earth_chunk():
    """Вырванный кусок земли: дёрн сверху, под ним почва с камнями, снизу рваные корни и комья."""
    pos, quads, _ = rock(205, cuts=14, planes=9, scale=(1.0, 0.8, 1.0), depth=0.7)
    top = 0.44
    lumps = Flow(206, freq=3.0, octaves=3, speed=0)
    surface = top + 0.05 * lumps(pos * np.array([1, 0, 1]), 0.0)
    pos[:, 1] = np.minimum(pos[:, 1], surface)
    under = np.clip(-pos[:, 1] / 0.8, 0, 1)
    ragged = Flow(207, freq=2.6, octaves=3, speed=0)
    pos[:, 1] -= 0.34 * under * (0.6 + ragged(pos, 0.0))
    pos[:, 0:2] *= (1 - 0.2 * under ** 2)[:, None]
    soil = Flow(208, freq=6.0, octaves=3, gain=0.65, speed=0)
    stones = Flow(209, freq=4.0, octaves=2, speed=0)
    n = soil(pos, 0.0)
    stone = np.clip((stones(pos, 0.0) - 0.34) * 9, 0, 1)
    depth = surface - pos[:, 1]
    dirt = np.array([0.40, 0.27, 0.17]) * (1 + 0.55 * n)[:, None]
    dark = np.array([0.27, 0.19, 0.13]) * (1 + 0.5 * n)[:, None]
    body = dirt * (1 - under[:, None]) + dark * under[:, None]
    grey = (0.5 + 0.2 * n)[:, None] * np.array([1.0, 0.98, 0.94])
    body = body * (1 - stone[:, None]) + grey * stone[:, None]
    turf = np.clip(1 - (depth - 0.03) / 0.09 + 0.5 * n, 0, 1)
    green = np.array([0.30, 0.46, 0.15]) * (1 + 0.5 * n)[:, None]
    rgb = body * (1 - turf[:, None]) + green * turf[:, None]
    save("earth_chunk", [(pos, rgba(np.clip(rgb, 0, 1), np.ones(len(pos))))], quads)


def rock_burst():
    """Глыба рассыпается: осколки разлетаются, кувыркаются и падают."""
    frames = 18
    shards = bits(22, 211, 3.4, 3.1, 9.0, 0.3)
    shapes = [rock(220 + i, cuts=2, planes=6, depth=0.5) for i in range(len(shards))]
    offsets = np.cumsum([0] + [len(s[0]) for s in shapes])
    quads = np.concatenate([s[1] + offsets[i] for i, s in enumerate(shapes)])
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        pos, col = [], []
        for shard, shape in zip(shards, shapes):
            turn = rotation(shard["axis"], shard["spin"] * t)
            center = shard["v"] * t * 0.62 - np.array([0, shard["gravity"] * t * t * 0.5 * 0.62, 0])
            shrink = 1 - max(0.0, (t - 0.6) / 0.4) ** 2
            pos.append(shape[0] * shard["size"] * shrink @ turn.T + center)
            col.append(shape[2])
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("rock_burst", result, quads)


def dust_puff():
    """Клубящаяся пыль из-под камня: мягкие объёмные клубы, тающие в воздухе."""
    frames = 18
    dirs, quads, *_ = sphere(26, 16, axis=1)
    billow = Flow(231, freq=2.2, octaves=3, speed=0)
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        n = billow(dirs * (1 + t * 0.4), t)
        pos = dirs * ((0.3 + 1.2 * (1 - (1 - t) ** 2)) * (1 + 0.32 * n))[:, None]
        pos[:, 1] *= 0.58
        pos[:, 1] += 0.5 * t
        g = 0.74 + 0.14 * n
        a = np.clip(0.62 * (1 - t) ** 1.2 + 0.1 * n * (1 - t), 0, 1)
        result.append((pos, rgba(np.stack([g, g * 0.97, g * 0.92], axis=1), a)))
    save("dust_puff", result, quads)


def ground_ring():
    """Кольцо вздыбленных плит земли вокруг точки удара."""
    rng = np.random.default_rng(241)
    parts = []
    for i in range(13):
        pos, quads, col = rock(250 + i, cuts=4, planes=8, scale=(0.3, 0.46, 0.2), depth=0.55)
        angle = i / 13 * TAU + rng.uniform(-0.1, 0.1)
        out = np.array([math.cos(angle), 0, math.sin(angle)])
        tilt = rotation((-out[2], 0, out[0]), rng.uniform(0.25, 0.75))
        turn = rotation((0, 1, 0), -angle + math.pi / 2)
        placed = pos @ turn.T @ tilt.T + out * rng.uniform(0.9, 1.1) + np.array([0, rng.uniform(0.0, 0.14), 0])
        parts.append((placed, quads, col))
    pos, quads, col = merged(parts)
    save("ground_ring", [(pos, col)], quads)


def spike_shape(seed, height, width):
    rng = np.random.default_rng(seed)
    nu, nv = 10, 13
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    radius = width * (1 - s) ** 0.85 + 0.01
    lumps = 1 + 0.2 * np.sin(theta * 3 + rng.uniform(0, 6)) + 0.13 * np.sin(theta * 5 + s * 5 + rng.uniform(0, 6))
    pos = np.stack([np.cos(theta) * radius * lumps, s * height, np.sin(theta) * radius * lumps], axis=1)
    pos[:, 0] += s ** 2 * rng.uniform(-0.2, 0.2) * height * 0.3
    pos[:, 2] += s ** 2 * rng.uniform(-0.2, 0.2) * height * 0.3
    grain = Flow(seed + 1, freq=4.0, octaves=3, speed=0)
    tone = grain(pos, 0.0)
    pos = pos + np.stack([np.cos(theta), s * 0, np.sin(theta)], axis=1) * (0.05 * tone * (1 - s))[:, None]
    grey = np.clip(0.62 + 0.2 * tone + 0.14 * s, 0, 1)
    return pos, grid(nu, nv)[:, ::-1], rgba(np.stack([grey, grey * 0.98, grey * 0.94], axis=1), np.ones(len(pos)))


def stone_spike():
    parts = []
    for seed, height, width, x, z in ((301, 2.5, 0.52, 0, 0), (305, 1.5, 0.34, 0.5, 0.26), (309, 1.2, 0.3, -0.42, 0.36), (313, 1.0, 0.27, 0.08, -0.5)):
        pos, quads, col = spike_shape(seed, height, width)
        parts.append((pos + np.array([x, -0.2, z]), quads, col))
    pos, quads, col = merged(parts)
    save("stone_spike", [(pos, col)], quads)


def stone_plates():
    """Каменные пластины брони, кружащие вокруг игрока."""
    parts = []
    for i in range(6):
        pos, quads, col = rock(330 + i, cuts=4, planes=8, scale=(0.3, 0.38, 0.09), depth=0.55)
        angle = i / 6 * TAU
        out = np.array([math.cos(angle), 0, math.sin(angle)])
        turn = rotation((0, 1, 0), -angle + math.pi / 2)
        placed = pos @ turn.T + out * 0.92 + np.array([0, 0.5 + 0.48 * (i % 3), 0])
        parts.append((placed, quads, col))
    pos, quads, col = merged(parts)
    save("stone_plates", [(pos, col)], quads)


def stone_wall():
    pos, quads, col = rock(351, cuts=11, planes=9, scale=(1.08, 3.1, 1.0), depth=0.84)
    pos = pos + np.array([0, 2.0, 0])
    save("stone_wall", [(pos, col)], quads)


def ground_slab():
    """Плита земли, вставшая дыбом и наклонённая наружу."""
    pos, quads, col = rock(361, cuts=5, planes=8, scale=(0.5, 0.72, 0.28), depth=0.55)
    pos = pos @ rotation((1, 0, 0), 0.5).T + np.array([0, 0.05, 0])
    save("ground_slab", [(pos, col)], quads)


# ---------------------------------------------------------------- воздух

def streak(angle, s, t, arms, twist, sharp, spin=1):
    """Узор воздушных струй на поверхности: острые светлые полосы, бегущие по кругу."""
    wave = np.sin(angle * arms + s * twist - TAU * t * spin)
    return np.maximum(wave, 0) ** sharp


def wind_saw():
    """Воздушная пила: серповидные лезвия, тонкий обод и размытие от вращения."""
    frames = 12
    blades, segments, across = 7, 20, 3
    parts_q, count = [], segments * across
    for i in range(blades):
        parts_q.append(grid(across, segments, wrap=False) + i * count)
    disc_nu, disc_nv = 56, 4
    disc_q = grid(disc_nu, disc_nv) + blades * count
    quads = np.concatenate(parts_q + [disc_q])
    s = np.repeat(np.linspace(0, 1, segments), across)
    c = np.tile(np.linspace(-1, 1, across), segments)
    dt = np.tile(np.linspace(0, TAU, disc_nu, endpoint=False), disc_nv)
    dr = np.repeat(np.linspace(0.16, 0.92, disc_nv), disc_nu)
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for i in range(blades):
            angle = i / blades * TAU + s * 1.5
            radius = 0.2 + 0.98 * s
            width = 0.2 * np.sin(np.clip(s, 0.02, 1) * math.pi) ** 0.6 * (1 - 0.65 * s)
            r = radius + c * width
            a = angle + c * width * 0.8
            shimmer = 0.1 * math.sin(TAU * (t + i / blades))
            y = 0.035 * np.sin(s * 9 + TAU * t) * (1 - np.abs(c))
            pos.append(np.stack([r * np.cos(a), y, r * np.sin(a)], axis=1))
            edge = np.clip(c * 0.5 + 0.5, 0, 1) ** 2
            rgb = ramp(0.25 + 0.75 * edge, WIND)
            col.append(rgba(rgb, np.clip(0.62 + 0.4 * edge + shimmer, 0, 1) * (1 - s ** 6)))
        pos.append(np.stack([dr * np.cos(dt), dr * 0, dr * np.sin(dt)], axis=1))
        blur = streak(dt, dr * 3, t, 7, 6, 3) * 0.3 + 0.16
        col.append(rgba(ramp(np.full(len(dt), 0.6), WIND), blur * np.sin((dr - 0.16) / 0.76 * math.pi) ** 0.7))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("wind_saw", result, quads)


def wind_burst():
    """Хлопок воздуха: три расходящихся кольца с рваными струями."""
    frames, nu, nv = 14, 72, 4
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    ring = np.repeat(np.linspace(-1, 1, nv), nu)
    one = grid(nu, nv)
    count = nu * nv
    quads = np.concatenate([one + i * count for i in range(3)])
    result = []
    for f in range(frames):
        t = f / (frames - 1)
        pos, col = [], []
        for i in range(3):
            local = np.clip(t * 1.25 - i * 0.12, 0, 1)
            radius = 0.25 + (1.05 - i * 0.16) * (1 - (1 - local) ** 2.3)
            r = radius + ring * (0.05 + 0.2 * local)
            pos.append(np.stack([r * np.cos(theta), np.full(count, i * 0.2 - 0.2) + ring * 0.03, r * np.sin(theta)], axis=1))
            a = (1 - np.abs(ring)) * (1 - local) ** 1.2 * (0.28 + 0.72 * streak(theta, ring, t, 9, 1, 2)) * (local > 0)
            col.append(rgba(ramp(np.full(count, 0.85), WIND), a))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("wind_burst", result, quads)


def wind_tunnel():
    """Воздушный конус вокруг тела в рывке, острый спереди."""
    frames, nu, nv = 16, 48, 18
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    quads = grid(nu, nv)
    result = []
    for f in range(frames):
        t = f / frames
        radius = 0.12 + 1.02 * s ** 0.75
        z = 1.5 - s * 4.2
        pos = np.stack([radius * np.cos(theta), radius * np.sin(theta), z], axis=1)
        a = (0.16 + 0.84 * streak(theta, s, t, 6, 5, 3, 2)) * np.sin(np.clip(s, 0, 1) ** 0.6 * math.pi) ** 0.9
        result.append((pos, rgba(ramp(0.5 + 0.5 * s, WIND), a)))
    save("wind_tunnel", result, quads)


def tornado():
    """Смерч: закрученная воронка с плавающей осью и двумя слоями струй."""
    frames, nu, nv = 24, 58, 30
    theta = np.tile(np.linspace(0, TAU, nu, endpoint=False), nv)
    s = np.repeat(np.linspace(0, 1, nv), nu)
    one = grid(nu, nv)
    count = nu * nv
    quads = np.concatenate([one, one + count])
    result = []
    for f in range(frames):
        t = f / frames
        pos, col = [], []
        for layer, width, power, arms in ((0, 1.0, 0.95, 6), (1, 0.66, 0.8, 5)):
            sway = 0.22 * s * np.sin(s * 4.2 - TAU * t)
            sway2 = 0.22 * s * np.cos(s * 3.4 - TAU * t)
            radius = (0.22 + 2.1 * s ** 1.5) * width * (1 + 0.07 * np.sin(s * 19 - TAU * t * 3))
            pos.append(np.stack([radius * np.cos(theta) + sway, s * 5.0, radius * np.sin(theta) + sway2], axis=1))
            lines = streak(theta, s, t, arms, 11, 3, 3 + layer)
            bands = 0.55 + 0.45 * np.sin(s * 31 - TAU * t * 4)
            a = power * (0.3 + 0.7 * lines * bands) * np.clip(s * 9, 0, 1) * np.clip((1 - s) * 6, 0, 1)
            shade = 0.25 + 0.75 * lines
            col.append(rgba(ramp(shade, WIND) * (0.88 + 0.12 * layer), a))
        result.append((np.concatenate(pos), np.concatenate(col)))
    save("tornado", result, quads)


def wind_dome():
    """Купол из струй воздуха вокруг игрока."""
    frames = 20
    dirs, quads, theta, phi = sphere(52, 26, axis=1)
    result = []
    for f in range(frames):
        t = f / frames
        s = phi / math.pi
        lines = streak(theta, s, t, 5, 6, 4, 2)
        lines2 = streak(-theta, s, t, 3, 4, 5, 1)
        pulse = 1 + 0.015 * np.sin(s * 14 - TAU * t * 2)
        a = 0.1 + 0.6 * np.maximum(lines, lines2 * 0.8)
        result.append((dirs * pulse[:, None], rgba(ramp(0.4 + 0.6 * lines, WIND), a)))
    save("wind_dome", result, quads)


# Вторая часть моделей лежит рядом и заменяет собой старую струю огнемёта.
exec(compile(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "spells_more.py"), encoding="utf-8").read(), "spells_more.py", "exec"))

MODELS = [fireball, fire_burst, flame_ring, flame_jet, water_blob, water_stream, water_splash, water_wave, helix,
          ice_shard, boulder, earth_chunk, ground_slab, rock_burst, dust_puff, ground_ring, stone_spike, stone_plates, stone_wall,
          wind_saw, wind_burst, wind_tunnel, tornado, wind_dome,
          fire_tornado, rock_tornado, steam_cloud, mist_ring, storm_cloud, magma_boulder, magma_pool, mud_pool, element_mark,
          ice_bolt, lightning, magma_geyser, sand_pit, metal_blade, vacuum, danger_ring,
          altar_core, seal_orb, boss_fire, boss_water, boss_earth, boss_air, boss_primal]

wanted = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
for model in MODELS:
    if not wanted or model.__name__ in wanted:
        model()
print("Модели готовы")
