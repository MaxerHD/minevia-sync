package local.minevia.elements;

import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Старый подбор природных стихий для служебных сценариев. Игрок выбирает сам. */
public final class ElementAssigner {
    private ElementAssigner() {
    }

    public static Element pick(Collection<Element> taken, Random random) {
        Map<Element, Integer> counts = new EnumMap<>(Element.class);
        for (Element element : Element.natural()) {
            counts.put(element, 0);
        }
        for (Element element : taken) {
            counts.merge(element, 1, Integer::sum);
        }
        int fewest = counts.values().stream().min(Integer::compare).orElse(0);
        List<Element> options = new ArrayList<>();
        for (Map.Entry<Element, Integer> entry : counts.entrySet()) {
            if (entry.getValue() == fewest) {
                options.add(entry.getKey());
            }
        }
        return options.get(random.nextInt(options.size()));
    }
}
