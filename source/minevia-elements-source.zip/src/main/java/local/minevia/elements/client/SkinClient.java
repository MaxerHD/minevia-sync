package local.minevia.elements.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.net.UploadSkinPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.util.Identifier;

/** Скины игроков: свой файл из лаунчера уходит на сервер, чужие приходят оттуда и подменяют обычный скин. */
public final class SkinClient {
    private record Skin(Identifier texture, SkinTextures.Model model) {
    }

    private static final Map<UUID, Skin> SKINS = new HashMap<>();

    private SkinClient() {
    }

    /** Файл кладёт лаунчер при запуске. Если персонаж не выбран, файла нет и скин остаётся обычным. */
    static void upload() {
        Path file = FabricLoader.getInstance().getGameDir().resolve("minevia").resolve("skin.png");
        if (!Files.isRegularFile(file) || !ClientPlayNetworking.canSend(UploadSkinPayload.ID)) {
            return;
        }
        try {
            ClientPlayNetworking.send(new UploadSkinPayload(Files.readAllBytes(file)));
        } catch (IOException problem) {
            MineviaElements.LOGGER.warn("Не читается файл скина {}", file, problem);
        }
    }

    static void receive(MinecraftClient client, UUID player, byte[] png) {
        remove(client, player);
        if (png.length == 0) {
            return;
        }
        try {
            NativeImage image = NativeImage.read(png);
            // В узких руках столбец за рукой пустой: так игра и отличает узкую модель от широкой.
            boolean slim = image.getOpacity(54, 20) == 0;
            Identifier id = Identifier.of(MineviaElements.MOD_ID, "skins/" + player.toString().toLowerCase(Locale.ROOT));
            client.getTextureManager().registerTexture(id, new NativeImageBackedTexture(image));
            SKINS.put(player, new Skin(id, slim ? SkinTextures.Model.SLIM : SkinTextures.Model.WIDE));
        } catch (IOException | IllegalArgumentException problem) {
            MineviaElements.LOGGER.warn("Пришёл неправильный скин игрока {}", player, problem);
        }
    }

    private static void remove(MinecraftClient client, UUID player) {
        Skin old = SKINS.remove(player);
        if (old != null) {
            client.getTextureManager().destroyTexture(old.texture());
        }
    }

    static void clear(MinecraftClient client) {
        client.execute(() -> {
            for (Skin skin : SKINS.values()) {
                client.getTextureManager().destroyTexture(skin.texture());
            }
            SKINS.clear();
        });
    }

    /** Подменяет только сам скин и модель: плащ и надкрылья остаются прежними. */
    public static SkinTextures apply(UUID player, SkinTextures original) {
        Skin skin = SKINS.get(player);
        if (skin == null) {
            return original;
        }
        return new SkinTextures(skin.texture(), null, original.capeTexture(), original.elytraTexture(), skin.model(), false);
    }
}
