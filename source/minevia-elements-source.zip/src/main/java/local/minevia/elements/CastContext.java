package local.minevia.elements;

import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/** Старый навык не продолжает бой и прокачку после смены стиля. */
final class CastContext {
    record Token(MinecraftServer server, ServerWorld world, UUID player, Element element, long stamp, int slot, boolean[] hitRewarded) {
        boolean valid() {
            ServerPlayerEntity online = server.getPlayerManager().getPlayer(player);
            ElementState.Data data = ElementState.get(server).find(player);
            return online != null && online.isAlive() && online.getWorld() == world
                    && data != null && data.element == element && data.changedAt == stamp && StyleGear.equipped(online, element);
        }
    }

    private static final ThreadLocal<Token> CURRENT = new ThreadLocal<>();

    private CastContext() { }

    static Token capture() { return CURRENT.get(); }

    static void cast(ServerPlayerEntity p, int slot, Runnable action) {
        ElementState.Data d = ElementState.get(p.getServer()).getOrAssign(p.getUuid());
        run(new Token(p.getServer(), p.getServerWorld(), p.getUuid(), d.element, d.changedAt, slot, new boolean[1]), action);
    }

    static void run(Token token, Runnable action) {
        if (token != null && !token.valid()) return;
        Token previous = CURRENT.get();
        CURRENT.set(token);
        try { action.run(); }
        finally {
            if (previous == null) CURRENT.remove();
            else CURRENT.set(previous);
        }
    }
}
