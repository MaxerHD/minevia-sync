package local.minevia.elements.mixin;

import local.minevia.elements.client.ElementsClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Открытая панель навыков заменяет хотбар: иначе предметы и рамка рисовались бы поверх значков и цифр. */
@Mixin(InGameHud.class)
abstract class InGameHudMixin {
    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    private void minevia$hideHotbar(DrawContext context, RenderTickCounter counter, CallbackInfo info) {
        if (ElementsClient.barOpen()) {
            info.cancel();
        }
    }
}
