package local.minevia.elements.client;

import static local.minevia.elements.Gesture.CHANNELS;
import static local.minevia.elements.Gesture.HEAD;
import static local.minevia.elements.Gesture.LA;
import static local.minevia.elements.Gesture.LEAN;
import static local.minevia.elements.Gesture.LL;
import static local.minevia.elements.Gesture.LO;
import static local.minevia.elements.Gesture.LW;
import static local.minevia.elements.Gesture.RA;
import static local.minevia.elements.Gesture.RL;
import static local.minevia.elements.Gesture.RO;
import static local.minevia.elements.Gesture.RW;
import static local.minevia.elements.Gesture.TURN;

import java.util.Map;
import java.util.WeakHashMap;
import local.minevia.elements.Gesture;
import local.minevia.elements.net.GesturePayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Показывает движения навыков: на модели игрока для всех вокруг и на руках в кадре от первого лица. */
public final class GestureClient {
    private static final float FADE_IN = 2;
    private static final float FADE_OUT = 5;
    private static final float SWITCH = 3;
    private static final int LONGEST_HOLD = 260;
    private static final float HAND_LIMIT = 0.5F;
    private static final float HELD_HAND_LIMIT = 0.12F;
    private static final float LEG_LENGTH = 12;
    private static final float RAD = MathHelper.RADIANS_PER_DEGREE;

    /** Движение на модели: значения каналов, доля каждого в итоговой позе и сама поза, с которой оно перехватило предыдущую. */
    private static final class Active {
        Gesture gesture;
        float start;
        float end;
        float[] fromPose;
        float[] fromWeight;
        final float[] pose = new float[CHANNELS];
        final float[] weight = new float[CHANNELS];
    }

    private static final Map<Entity, Active> ACTIVE = new WeakHashMap<>();

    private GestureClient() {
    }

    static void receive(GesturePayload payload) {
        MinecraftClient client = MinecraftClient.getInstance();
        Entity entity = client.world == null ? null : client.world.getEntityById(payload.entity());
        if (entity == null) {
            return;
        }
        Active old = ACTIVE.get(entity);
        if (payload.gesture() == GesturePayload.STOP) {
            if (old != null) {
                old.end = Math.min(old.end, entity.age - old.start + FADE_OUT);
            }
            return;
        }
        Active next = new Active();
        next.gesture = Gesture.values()[payload.gesture()];
        next.start = entity.age;
        next.end = next.gesture.held() ? LONGEST_HOLD : payload.ticks();
        if (old != null) {
            update(old, entity.age);
            next.fromPose = old.pose.clone();
            next.fromWeight = old.weight.clone();
        }
        ACTIVE.put(entity, next);
    }

    /** Считает позу на этот момент. Если движение перехватило предыдущее, руки плавно идут из той позы, а не из опущенных. */
    private static boolean update(Active active, float age) {
        float time = age - active.start;
        if (time >= active.end) {
            return false;
        }
        active.gesture.pose(time, active.pose);
        float out = MathHelper.clamp((active.end - time) / FADE_OUT, 0, 1);
        float in = Math.min(1, time / FADE_IN);
        float shift = active.fromPose == null ? 1 : Math.min(1, time / SWITCH);
        for (int i = 0; i < CHANNELS; i++) {
            boolean used = active.gesture.uses(i);
            float from = active.fromWeight == null ? 0 : active.fromWeight[i];
            if (used && from > 0) {
                active.pose[i] = MathHelper.lerp(shift, active.fromPose[i], active.pose[i]);
                active.weight[i] = MathHelper.lerp(shift, from, 1) * out;
            } else if (used) {
                active.weight[i] = in * out;
            } else if (from > 0) {
                active.pose[i] = active.fromPose[i];
                active.weight[i] = from * (1 - shift);
            } else {
                active.weight[i] = 0;
            }
        }
        return true;
    }

    private static Active current(LivingEntity entity, float age) {
        Active active = ACTIVE.get(entity);
        if (active != null && !update(active, age)) {
            ACTIVE.remove(entity);
            return null;
        }
        return active;
    }

    /** Голову и торс игра сама на место не возвращает, а модель одна на всех игроков: иначе наклон копился бы от кадра к кадру. */
    public static void straighten(PlayerEntityModel<?> model) {
        model.head.pivotX = 0;
        model.head.pivotZ = 0;
        model.body.pivotX = 0;
        model.body.pivotZ = 0;
    }

    /** Вызывается после обычной анимации игрока и ложится поверх неё. Для руки в кадре игра передаёт нулевое время: там работает hand(). */
    public static void pose(PlayerEntityModel<?> model, LivingEntity entity, float age, float limbDistance) {
        if (ACTIVE.isEmpty() || age <= 0 || entity.isSleeping() || entity.isFallFlying() || entity.isInSwimmingPose()) {
            return;
        }
        Active active = current(entity, age);
        if (active == null) {
            return;
        }
        bowPose(entity, active, age - entity.age);
        boolean aimed = active.gesture.aim == Gesture.Aim.LOOK;
        float lookPitch = aimed ? model.head.pitch : 0;
        float lookYaw = aimed ? model.head.yaw : 0;
        float[] pose = active.pose;
        float[] weight = active.weight;
        arm(model.rightArm, pose[RA], weight[RA], lookPitch, lookYaw);
        arm(model.leftArm, pose[LA], weight[LA], lookPitch, lookYaw);
        model.rightArm.roll = MathHelper.lerp(weight[RO], model.rightArm.roll, pose[RO] * RAD);
        model.leftArm.roll = MathHelper.lerp(weight[LO], model.leftArm.roll, -pose[LO] * RAD);
        model.rightArm.yaw -= pose[RW] * RAD * weight[RW];
        model.leftArm.yaw += pose[LW] * RAD * weight[LW];

        // На бегу ноги важнее: иначе персонаж скользил бы по земле в застывшей стойке.
        float legs = entity.hasVehicle() ? 0 : 1 - MathHelper.clamp(limbDistance * 2.5F, 0, 1);
        float right = weight[RL] * legs;
        float left = weight[LL] * legs;
        model.rightLeg.pitch = MathHelper.lerp(right, model.rightLeg.pitch, -pose[RL] * RAD);
        model.leftLeg.pitch = MathHelper.lerp(left, model.leftLeg.pitch, -pose[LL] * RAD);

        float lean = pose[LEAN] * weight[LEAN] * RAD;
        float turn = pose[TURN] * weight[TURN] * RAD;
        bend(model.body, model, lean, turn);
        bend(model.head, model, lean, turn);
        bend(model.rightArm, model, lean, turn);
        bend(model.leftArm, model, lean, turn);
        model.body.pitch += lean;
        model.body.yaw -= turn;
        model.head.pitch += pose[HEAD] * weight[HEAD] * RAD;
        if (!aimed) {
            model.rightArm.pitch += lean;
            model.leftArm.pitch += lean;
            model.rightArm.yaw -= turn;
            model.leftArm.yaw -= turn;
        }

        // Ноги жёсткие, поэтому в широкой стойке корпус опускается, чтобы ступни оставались на земле.
        float stance = Math.min(Math.abs(pose[RL] * right), Math.abs(pose[LL] * left));
        float drop = LEG_LENGTH * (1 - MathHelper.cos(stance * RAD));
        for (ModelPart part : new ModelPart[] {model.head, model.body, model.rightArm, model.leftArm, model.rightLeg, model.leftLeg}) {
            part.pivotY += drop;
        }
        model.hat.copyTransform(model.head);
        model.jacket.copyTransform(model.body);
        model.rightSleeve.copyTransform(model.rightArm);
        model.leftSleeve.copyTransform(model.leftArm);
        model.rightPants.copyTransform(model.rightLeg);
        model.leftPants.copyTransform(model.leftLeg);
    }

    private static void bowPose(LivingEntity player, Active active, float delta) {
        if (active.gesture != Gesture.STYLE_BOW_AIMED || !player.getMainHandStack().isOf(local.minevia.elements.StyleGear.BOW)) return;
        float draw = StyleGearRenderer.drawProgress(player.getMainHandStack(), player, delta);
        active.pose[RA] = 92;
        active.pose[LA] = 60 + draw * 30;
        active.pose[LW] = 20 + draw * 55;
    }

    private static void arm(ModelPart arm, float forward, float weight, float lookPitch, float lookYaw) {
        arm.pitch = MathHelper.lerp(weight, arm.pitch, -forward * RAD + lookPitch);
        arm.yaw = MathHelper.lerp(weight, arm.yaw, lookYaw);
    }

    /** Корпус гнётся в поясе: всё, что выше него, поворачивается вокруг бёдер. */
    private static void bend(ModelPart part, PlayerEntityModel<?> model, float lean, float turn) {
        float hipY = model.rightLeg.pivotY;
        float hipZ = model.rightLeg.pivotZ;
        float x = part.pivotX;
        float y = part.pivotY - hipY;
        float z = part.pivotZ - hipZ;
        float cos = MathHelper.cos(lean);
        float sin = MathHelper.sin(lean);
        float bentY = y * cos - z * sin;
        float bentZ = y * sin + z * cos;
        cos = MathHelper.cos(-turn);
        sin = MathHelper.sin(-turn);
        part.pivotX = x * cos + bentZ * sin;
        part.pivotY = bentY + hipY;
        part.pivotZ = bentZ * cos - x * sin + hipZ;
    }

    /** Нужно ли дорисовать в кадре вторую руку: игра показывает её только с предметом. */
    public static boolean showsOffHand(LivingEntity player, float tickDelta) {
        Active active = ACTIVE.isEmpty() ? null : current(player, player.age + tickDelta);
        return local.minevia.elements.StyleGear.gloves(player.getMainHandStack()) || player.getMainHandStack().isOf(local.minevia.elements.StyleGear.BOW) && (player.isUsingItem() || local.minevia.elements.StyleGear.data(player.getMainHandStack()).contains("style_draw_start")) || active != null && active.weight[LA] > 0.02F;
    }

    /** Переносит движение модели на руку в кадре: поднятая рука уходит вверх и вперёд, опущенная скрывается вниз. */
    public static void hand(LivingEntity player, Arm arm, boolean mainHand, float tickDelta, MatrixStack matrices) {
        if (mainHand && player.getMainHandStack().isOf(local.minevia.elements.StyleGear.BOW) && (player.isUsingItem() || local.minevia.elements.StyleGear.data(player.getMainHandStack()).contains("style_draw_start"))) {
            float draw = StyleGearRenderer.drawProgress(player.getMainHandStack(), player, tickDelta);
            matrices.translate(0, 0.08 + draw * 0.06, -draw * 0.15);
            if (draw >= 0.99F) matrices.translate(Math.sin((player.age + tickDelta) * 2.4) * 0.005, 0, 0);
        }
        Active active = ACTIVE.isEmpty() ? null : current(player, player.age + tickDelta);
        if (active == null) return;
        if (mainHand && player.getMainHandStack().isOf(local.minevia.elements.StyleGear.SWORD)) {
            float weight = active.weight[RA];
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(active.pose[RW] * weight * 0.9F));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((active.pose[TURN] * 0.8F + active.pose[RO]) * weight));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees((active.pose[RA] - 65) * weight));
            matrices.translate(0, 0, -Math.sin(active.pose[RA] * RAD) * 0.12F * weight);
        }
        bowPose(player, active, tickDelta);
        if (!mainHand && player.getMainHandStack().isOf(local.minevia.elements.StyleGear.BOW)) {
            float draw = StyleGearRenderer.drawProgress(player.getMainHandStack(), player, tickDelta);
            matrices.translate(0, draw * 0.09, draw * 0.26);
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((arm == Arm.LEFT ? 1 : -1) * draw * 25));
        }
        int forward = mainHand ? RA : LA;
        int out = mainHand ? RO : LO;
        int across = mainHand ? RW : LW;
        float weight = active.weight[forward];
        if (weight <= 0) {
            return;
        }
        float raised = active.pose[forward];
        // Рука не закрывает прицел, особенно когда снаряд держат долго и им надо целиться.
        boolean drawing = !mainHand && player.getMainHandStack().isOf(local.minevia.elements.StyleGear.BOW);
        float highest = active.gesture.held() || drawing ? HELD_HAND_LIMIT : HAND_LIMIT;
        float up = MathHelper.clamp((raised - 60) / 100, -0.9F, highest) * weight;
        float side = arm == Arm.RIGHT ? 1 : -1;
        float wide = (active.pose[out] * active.weight[out] - active.pose[across] * active.weight[across]) / 90;
        matrices.translate(side * wide * 0.25F, up * 0.32F, -MathHelper.sin(MathHelper.clamp(raised, 0, 180) * RAD) * 0.14F * weight);
        matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(MathHelper.clamp(raised - 60, -60, highest * 100) * 0.35F * weight));
    }

    /** Вторая рука выезжает снизу кадра, а не появляется из воздуха. */
    public static void offHandEntry(LivingEntity player, float tickDelta, MatrixStack matrices) {
        Active active = current(player, player.age + tickDelta);
        if (active != null) {
            matrices.translate(0, (active.weight[LA] - 1) * 0.6F, 0);
        }
    }
}
