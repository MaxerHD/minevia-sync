package local.minevia.elements;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Падает с боссов. Использование поднимает уровень стихии на один. */
public class ElementCoreItem extends Item {
    public ElementCoreItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (!(user instanceof ServerPlayerEntity player)) {
            return TypedActionResult.success(stack);
        }
        ElementState state = ElementState.get(player.getServer());
        ElementState.Data data = state.getOrAssign(player.getUuid());
        if (data.element == null) return TypedActionResult.fail(stack);
        if (data.level >= ElementState.MAX_LEVEL) {
            player.sendMessage(Text.translatable("message.minevia_elements.max_level"), true);
            return TypedActionResult.fail(stack);
        }
        data.level++;
        state.markDirty();
        stack.decrementUnlessCreative(1, player);
        world.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 1.0F, 1.0F);
        boolean second = data.level == ElementState.MAX_LEVEL;
        player.sendMessage(Text.translatable(second ? "message.minevia_elements.choose_path" : "message.minevia_elements.level_up", data.level), true);
        MineviaElements.sync(player);
        return TypedActionResult.success(stack);
    }
}
