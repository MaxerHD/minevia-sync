package local.minevia.elements;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Способности работают только на сервере и не ломают блоки, поэтому базу случайно не сжечь.
 * По питомцам они не бьют, а по другим игрокам только с правилом mineviaFriendlyFire.
 */
public final class Abilities {
    public static final int SLOTS = 10;
    public static final int[] COOLDOWNS = {60, 200, 500, 300, 600, 400, 500, 300, 360, 2400};

    /** Шестой и седьмой слоты открывает вторая ступень стихии. */
    public static final int PATH_SLOT = 5;
    public static final int PATH_SECOND_SLOT = 6;
    public static final int ULTIMATE_SLOT = 9;

    private static final int[] UNLOCK = {1, 2, 3, 4, 5, 6, 6, 2, 4, 6};

    private static final Map<UUID, long[]> READY_AT = new HashMap<>();

    private Abilities() {
    }

    /** Косинус половины конуса помощи в прицеливании, примерно 9 градусов. */
    private static final double AIM_CONE = 0.988;

    public static int unlockLevel(int slot) {
        return UNLOCK[slot];
    }

    public static boolean isPathSlot(int slot) {
        return slot == PATH_SLOT || slot == PATH_SECOND_SLOT;
    }

    public static int[] remaining(ServerPlayerEntity player) {
        long now = player.getServer().getTicks();
        long[] ready = READY_AT.getOrDefault(player.getUuid(), new long[SLOTS]);
        int[] left = new int[SLOTS];
        for (int i = 0; i < SLOTS; i++) {
            left[i] = (int) Math.max(0, ready[i] - now);
        }
        return left;
    }

    public static void forget(UUID id) {
        READY_AT.remove(id);
        Control.forget(id);
        Mastery.forget(id);
    }

    public static void cast(ServerPlayerEntity player, int slot) {
        if (slot < 0 || slot >= SLOTS || !player.isAlive() || player.isSpectator()) {
            return;
        }
        if (Control.releaseSlot(player, slot)) {
            return;
        }
        ElementState.Data data = ElementState.get(player.getServer()).getOrAssign(player.getUuid());
        if (data.level < unlockLevel(slot)) {
            player.sendMessage(Text.translatable("message.minevia_elements.locked", unlockLevel(slot)), true);
            return;
        }
        long now = player.getServer().getTicks();
        long[] ready = READY_AT.computeIfAbsent(player.getUuid(), id -> new long[SLOTS]);
        if (now < ready[slot]) {
            return;
        }
        if (isPathSlot(slot) && data.path == 0) {
            player.sendMessage(Text.translatable("message.minevia_elements.choose_path"), true);
            return;
        }
        // Под водой огонь не загорается: перезарядка не тратится, остаётся только облачко пара.
        if (data.element == Element.FIRE && slot != ULTIMATE_SLOT && player.isSubmergedInWater()) {
            Nature.steam(player.getServerWorld(), player.getEyePos().add(player.getRotationVector().multiply(1.5)), 0.6F);
            player.sendMessage(Text.translatable("message.minevia_elements.no_fire_underwater"), true);
            return;
        }
        player.swingHand(Hand.MAIN_HAND, true);
        // Слот запоминается раньше навыка: его первый удар уже должен знать, чем он нанесён.
        Combos.casting(player, slot);
        Mastery.cast(player, data, slot);
        int power = Mastery.power(data, slot);
        if (slot == PATH_SLOT) {
            Paths.cast(player, data.element, data.path, power);
        } else if (slot == PATH_SECOND_SLOT) {
            Skills.pathSecond(player, data.element, data.path, power);
        } else if (slot == ULTIMATE_SLOT) {
            Skills.ultimate(player, data.element, power);
        } else if (slot > PATH_SECOND_SLOT) {
            Skills.extra(player, data.element, slot, power);
        } else {
            switch (data.element) {
                case FIRE -> fire(player, slot, power);
                case WATER -> water(player, slot, power);
                case EARTH -> earth(player, slot, power);
                case AIR -> air(player, slot, power);
            }
        }
        Flourish.cast(player, data.element, slot);
        ready[slot] = now + COOLDOWNS[slot];
        MineviaElements.sync(player);
        Combos.chain(player, data.element, slot);
    }

    /** У каждой стихии пять разных приёмов: снаряд, область, усиление, особый удар и высшая техника. */
    private static void fire(ServerPlayerEntity player, int slot, int level) {
        switch (slot) {
            case 0 -> Spells.fireball(player, level);
            case 1 -> Spells.flameRing(player, level);
            case 2 -> Spells.flameArmor(player, level);
            case 3 -> Spells.greatFireball(player, level);
            default -> Spells.flamethrower(player, level);
        }
    }

    private static void water(ServerPlayerEntity player, int slot, int level) {
        switch (slot) {
            case 0 -> Spells.waterFlow(player, level);
            case 1 -> Spells.healing(player, level);
            case 2 -> Spells.iceRing(player, level);
            case 3 -> Spells.whip(player, level);
            default -> Spells.wave(player, level);
        }
    }

    private static void earth(ServerPlayerEntity player, int slot, int level) {
        switch (slot) {
            case 0 -> Spells.boulder(player, level);
            case 1 -> Spells.quake(player, level);
            case 2 -> Spells.stoneArmor(player, level);
            case 3 -> Spells.spikes(player, level);
            default -> Spells.wall(player, level);
        }
    }

    private static void air(ServerPlayerEntity player, int slot, int level) {
        switch (slot) {
            case 0 -> Spells.windOrb(player, level);
            case 1 -> Spells.airSaw(player, level);
            case 2 -> Spells.dash(player, level);
            case 3 -> Spells.tornado(player, level);
            default -> Spells.dome(player, level);
        }
    }

    static boolean canHit(Entity entity, ServerPlayerEntity player) {
        if (!(entity instanceof LivingEntity living) || entity == player || !living.isAlive()) {
            return false;
        }
        if (entity instanceof PlayerEntity other) {
            return player.getServerWorld().getGameRules().getBoolean(Nature.FRIENDLY_FIRE) && player.shouldDamagePlayer(other);
        }
        if (entity instanceof ArmorStandEntity) {
            return false;
        }
        return !(entity instanceof TameableEntity pet && pet.isTamed());
    }

    /**
     * Цель способности: первый враг на линии взгляда, а если прицел чуть промахнулся, то ближайший
     * к прицелу видимый монстр. Так в него легко попасть на бегу. Сквозь блоки способность не проходит.
     */
    static LivingEntity aim(ServerPlayerEntity player, double reach) {
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVector();
        Vec3d end = eye.add(look.multiply(reach));
        Box box = player.getBoundingBox().stretch(look.multiply(reach)).expand(1.0);
        EntityHitResult hit = ProjectileUtil.raycast(player, eye, end, box, entity -> canHit(entity, player), reach * reach);
        if (hit != null && hit.getEntity() instanceof LivingEntity living) {
            return living;
        }
        LivingEntity best = null;
        double bestDot = AIM_CONE;
        for (LivingEntity near : monstersAt(player, eye.add(look.multiply(reach / 2)), reach / 2 + 2)) {
            Vec3d to = near.getBoundingBox().getCenter().subtract(eye);
            double dot = to.normalize().dotProduct(look);
            if (dot > bestDot && to.length() <= reach && player.canSee(near)) {
                best = near;
                bestDot = dot;
            }
        }
        return best;
    }

    /** Эффект без вихря частиц вокруг цели: вся анимация способностей своя. */
    static void buff(LivingEntity target, RegistryEntry<StatusEffect> effect, int ticks, int amplifier) {
        target.addStatusEffect(new StatusEffectInstance(effect, ticks, amplifier, false, false, true));
    }

    static void debuff(LivingEntity target, RegistryEntry<StatusEffect> effect, int ticks, int amplifier) {
        target.addStatusEffect(new StatusEffectInstance(effect, ticks, amplifier, false, false, false));
    }

    /** Удар способностью: оставляет на цели метку стихии, из которой получаются комбо. */
    static void hurt(ServerPlayerEntity player, LivingEntity target, float amount) {
        ElementState.Data data = ElementState.get(player.getServer()).find(player.getUuid());
        float scaled = data != null ? Nature.scale(player, target, data.element, amount) : amount;
        target.damage(player.getDamageSources().playerAttack(player), scaled);
        if (data != null) {
            Mastery.hit(player, data);
            Flourish.hit(player.getServerWorld(), target, data.element.color);
            Combos.hit(player, target, data.element);
        }
    }

    /** Удар залпа: обычная защита от частых ударов съела бы все снаряды, кроме первого. */
    static void pierce(ServerPlayerEntity player, LivingEntity target, float amount) {
        target.timeUntilRegen = 0;
        hurt(player, target, amount);
    }

    /** Удар без метки: им бьют сами комбо, иначе они запускали бы друг друга. Проходит сразу после обычного удара. */
    static void strike(ServerPlayerEntity player, LivingEntity target, float amount) {
        target.timeUntilRegen = 0;
        target.damage(player.getDamageSources().playerAttack(player), amount);
    }

    static void push(Entity entity, Vec3d velocity) {
        // Хозяина подземелья нельзя унести вихрем или сдуть с его арены.
        if (entity instanceof DungeonBoss) {
            return;
        }
        entity.setVelocity(velocity);
        entity.velocityModified = true;
    }

    static List<LivingEntity> monstersAt(ServerPlayerEntity player, Vec3d center, double radius) {
        return player.getServerWorld().getEntitiesByClass(LivingEntity.class, new Box(center, center).expand(radius),
                entity -> entity instanceof Monster && canHit(entity, player));
    }

    static List<LivingEntity> livingAt(ServerPlayerEntity player, Vec3d center, double radius) {
        return player.getServerWorld().getEntitiesByClass(LivingEntity.class, new Box(center, center).expand(radius),
                entity -> canHit(entity, player));
    }

    /** Высота немного плавает, чтобы одна и та же способность не звучала как заезженная запись. */
    static void soundAt(ServerWorld world, Vec3d at, SoundEvent sound, float pitch) {
        float varied = pitch * (0.95F + world.random.nextFloat() * 0.1F);
        world.playSound(null, at.x, at.y, at.z, sound, SoundCategory.PLAYERS, 1.0F, varied);
    }

    static void sound(ServerPlayerEntity player, SoundEvent sound, float pitch) {
        soundAt(player.getServerWorld(), player.getPos(), sound, pitch);
    }
}
