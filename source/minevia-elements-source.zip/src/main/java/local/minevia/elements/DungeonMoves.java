package local.minevia.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Приёмы хозяев подземелий. Каждый сначала показывает, что будет: закрутом силы или кругом на земле. Возвращает паузу до следующего. */
final class DungeonMoves {
    private static final int SOUL = 0x7FD8FF;
    private static final int BONE = 0xE0D6BE;
    private static final int BRONZE = 0xFFD27A;
    private static final int STONE = 0xB89A6A;
    private static final int LIGHTNING = 0xBFD8FF;

    private DungeonMoves() {
    }

    static int use(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        int move = world.random.nextInt(3);
        return switch (boss.kind()) {
            case DungeonBoss.ABBOT -> {
                if (boss.shouldRaise()) {
                    yield raise(boss, world);
                }
                yield move == 0 ? soulVolley(boss, world, target) : move == 1 ? boneField(boss, world, target) : blink(boss, world, target);
            }
            case DungeonBoss.BELL -> move == 0 ? toll(boss, world) : move == 1 ? storm(boss, world, target) : gale(boss, world);
            default -> move == 0 ? stomp(boss, world) : move == 1 ? hurl(boss, world, target) : rush(boss, world, target);
        };
    }

    private static Vec3d ground(ServerWorld world, Vec3d at) {
        double ground = Spells.groundAt(world, at.add(0, 2, 0));
        return Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
    }

    private static void warn(ServerWorld world, Vec3d base, float radius, int ticks, int color, Runnable hit) {
        SpellEntity.spawn(world, SpellKind.DANGER_RING, base.add(0, 0.06, 0), radius, ticks).tint(color);
        Effects.later(world, ticks, hit);
    }

    // ------------------------------------------------------------------ Настоятель

    /** Три огня души: летят медленно и доворачивают за целью, от них можно уйти за колонну. */
    private static int soulVolley(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d hand = boss.getPos().add(0, 2.2, 0);
        Flourish.charge(world, hand, 1.6F, 16, SOUL);
        Abilities.soundAt(world, hand, Sounds.VACUUM, 1.5F);
        int count = boss.angry() ? 5 : 3;
        Effects.repeat(world, count, 7, step -> {
            if (!boss.isAlive() || !target.isAlive()) {
                return false;
            }
            Abilities.soundAt(world, hand, Sounds.LIGHTNING, 1.7F);
            Vec3d[] speed = {target.getEyePos().subtract(hand).normalize().multiply(0.42)};
            SpellEntity shot = SpellEntity.spawn(world, SpellKind.SOUL_FLAME, hand, 0.42F, 80);
            shot.setVelocity(speed[0]);
            shot.logic(self -> {
                if (target.isAlive()) {
                    speed[0] = speed[0].lerp(target.getEyePos().subtract(self.getPos()).normalize().multiply(0.42), 0.06);
                }
                self.setVelocity(speed[0]);
                Vec3d next = self.getPos().add(speed[0]);
                BlockPos pos = BlockPos.ofFloored(next);
                boolean blocked = !world.getBlockState(pos).getCollisionShape(world, pos).isEmpty();
                self.setPosition(next);
                boolean hit = false;
                for (PlayerEntity player : ElementBoss.playersAt(world, next, 1.1)) {
                    boss.strike(world, player, 5);
                    Flourish.hit(world, player, SOUL);
                    hit = true;
                }
                if (blocked || hit || self.age >= self.life() - 1) {
                    Flourish.blast(world, next, 1.6F, SOUL);
                    self.discard();
                }
            });
            return true;
        }, 16);
        return 62;
    }

    /** Из пола вырастают кости: круги показывают где, и на отход есть почти секунда. */
    private static int boneField(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Abilities.soundAt(world, target.getPos(), Sounds.EARTH_RISE, 0.6F);
        int count = boss.angry() ? 6 : 4;
        for (int i = 0; i < count; i++) {
            Vec3d at = i == 0 ? target.getPos() : target.getPos().add(world.random.nextDouble() * 8 - 4, 0, world.random.nextDouble() * 8 - 4);
            Vec3d base = ground(world, at);
            warn(world, base, 1.9F, 18 + i * 3, SOUL, () -> {
                if (!boss.isAlive()) {
                    return;
                }
                Spells.ring(world, SpellKind.STONE_SPIKE, base, 0.7, 5, 34, 1.0F, BONE);
                SpellEntity.spawn(world, SpellKind.STONE_SPIKE, base, 1.3F, 34).tint(BONE);
                Abilities.soundAt(world, base, Sounds.EARTH_SPIKE, 0.8F);
                for (PlayerEntity player : ElementBoss.playersAt(world, base.add(0, 0.8, 0), 2.1)) {
                    boss.strike(world, player, 7);
                    Abilities.push(player, new Vec3d(0, 0.7, 0));
                }
            });
        }
        return 60;
    }

    /** Настоятель растворяется и появляется за спиной цели, а на месте остаётся вспышка душ. */
    private static int blink(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d from = boss.getPos();
        Vec3d back = target.getRotationVector();
        Vec3d flat = new Vec3d(back.x, 0, back.z);
        Vec3d spot = target.getPos().subtract((flat.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : flat.normalize()).multiply(3.2)).add(0, 1.2, 0);
        BlockPos pos = BlockPos.ofFloored(spot);
        if (!world.getBlockState(pos).getCollisionShape(world, pos).isEmpty()) {
            return soulVolley(boss, world, target);
        }
        Flourish.blast(world, from.add(0, 1.4, 0), 3.4F, SOUL);
        SpellEntity.spawn(world, SpellKind.SOUL_FLAME, from, 1.5F, 20);
        boss.setPosition(spot);
        Flourish.blast(world, spot.add(0, 1.4, 0), 3.4F, SOUL);
        Abilities.soundAt(world, spot, Sounds.VACUUM, 0.8F);
        Effects.later(world, 14, () -> {
            if (boss.isAlive()) {
                SpellEntity.spawn(world, SpellKind.WIND_BURST, boss.getPos().add(0, 1, 0), 3.6F, 14);
                for (PlayerEntity player : ElementBoss.playersAt(world, boss.getPos().add(0, 1, 0), 4.2)) {
                    boss.strike(world, player, 6);
                    Abilities.push(player, player.getPos().subtract(boss.getPos()).normalize().multiply(0.9).add(0, 0.4, 0));
                }
            }
        });
        return 44;
    }

    private static int raise(DungeonBoss boss, ServerWorld world) {
        boss.say(world, "message.minevia_elements.abbot_raise");
        Abilities.soundAt(world, boss.getPos(), Sounds.ALTAR, 0.6F);
        Flourish.charge(world, boss.getPos().add(0, 2, 0), 2.4F, 26, SOUL);
        for (int i = 0; i < 3; i++) {
            double angle = i / 3.0 * Math.PI * 2;
            Vec3d base = ground(world, Vec3d.ofBottomCenter(boss.home()).add(Math.cos(angle) * 3.4, 0, Math.sin(angle) * 3.4));
            SpellEntity.spawn(world, SpellKind.SIGIL, base.add(0, 0.05, 0), 1.3F, 28).tint(SOUL);
            Effects.later(world, 26, () -> {
                if (boss.isAlive()) {
                    SpellEntity.spawn(world, SpellKind.SOUL_FLAME, base, 1.2F, 26);
                    EntityType.SKELETON.spawn(world, BlockPos.ofFloored(base), SpawnReason.MOB_SUMMONED);
                }
            });
        }
        return 70;
    }

    // ------------------------------------------------------------------ Звонарь

    /** Удар колокола: волна идёт по крыше, и её надо перепрыгнуть. В ярости за первой идёт вторая. */
    private static int toll(DungeonBoss boss, ServerWorld world) {
        Vec3d center = ground(world, boss.getPos().add(0, -1, 0));
        Flourish.charge(world, boss.getPos().add(0, 1.4, 0), 2.6F, 18, BRONZE);
        Effects.repeat(world, boss.angry() ? 2 : 1, 24, step -> {
            if (!boss.isAlive()) {
                return false;
            }
            world.playSound(null, center.x, center.y, center.z, SoundEvents.BLOCK_BELL_USE, boss.getSoundCategory(), 3.0F, 0.5F);
            Abilities.soundAt(world, center, Sounds.EARTH_QUAKE, 1.2F);
            Set<UUID> struck = new HashSet<>();
            SpellEntity.spawn(world, SpellKind.SHOCK_RING, center.add(0, 0.1, 0), 11, 22).tint(BRONZE).logic(self -> {
                double radius = 11 * (0.25 + 0.75 * (1 - Math.pow(1 - Math.min(1, self.age / 21.0), 2.2)));
                for (PlayerEntity player : ElementBoss.playersAt(world, center.add(0, 1, 0), radius + 1)) {
                    double distance = new Vec3d(player.getX() - center.x, 0, player.getZ() - center.z).length();
                    if (distance > radius - 1.5 && player.getY() < center.y + 1.1 && struck.add(player.getUuid())) {
                        boss.strike(world, player, 8);
                        Abilities.push(player, new Vec3d(player.getX() - center.x, 0, player.getZ() - center.z).normalize().multiply(0.5).add(0, 0.5, 0));
                    }
                }
            });
            return true;
        }, 18);
        return boss.angry() ? 80 : 58;
    }

    /** С неба бьют молнии: круги загораются один за другим и догоняют цель. */
    private static int storm(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Abilities.soundAt(world, boss.getPos(), Sounds.THUNDER, 0.9F);
        int count = boss.angry() ? 7 : 5;
        Effects.repeat(world, count, 9, step -> {
            if (!boss.isAlive() || !target.isAlive()) {
                return false;
            }
            Vec3d base = ground(world, target.getPos().add(target.getVelocity().multiply(10)));
            warn(world, base, 2.2F, 18, LIGHTNING, () -> {
                if (!boss.isAlive()) {
                    return;
                }
                Paths.bolt(world, base.add(0, 14, 0), base, LIGHTNING);
                Flourish.blast(world, base.add(0, 0.2, 0), 3, LIGHTNING);
                Abilities.soundAt(world, base, Sounds.LIGHTNING, 0.8F);
                for (PlayerEntity player : ElementBoss.playersAt(world, base.add(0, 1, 0), 2.6)) {
                    boss.strike(world, player, 7);
                }
            });
            return true;
        });
        return 40 + count * 9;
    }

    /** Порыв сносит к краю крыши: надо упереться за зубцы или отойти к середине. */
    private static int gale(DungeonBoss boss, ServerWorld world) {
        Vec3d at = boss.getPos().add(0, 1, 0);
        Flourish.charge(world, at, 3.2F, 22, 0xE4F0F6);
        Abilities.soundAt(world, at, Sounds.AIR_TORNADO, 0.8F);
        Effects.later(world, 22, () -> {
            if (!boss.isAlive()) {
                return;
            }
            Flourish.blast(world, at, 9, 0xE4F0F6);
            SpellEntity.spawn(world, SpellKind.WIND_BURST, at, 8.0F, 14);
            Abilities.soundAt(world, at, Sounds.AIR_GUST, 0.6F);
            for (PlayerEntity player : ElementBoss.playersAt(world, at, 10)) {
                Vec3d away = new Vec3d(player.getX() - at.x, 0, player.getZ() - at.z);
                Abilities.push(player, (away.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : away.normalize()).multiply(1.25).add(0, 0.42, 0));
                boss.strike(world, player, 3);
            }
        });
        return 58;
    }

    // ------------------------------------------------------------------ Рогач

    private static int stomp(DungeonBoss boss, ServerWorld world) {
        Vec3d at = ground(world, boss.getPos());
        float radius = boss.angry() ? 6.5F : 5;
        warn(world, at, radius, 20, STONE, () -> {
            if (!boss.isAlive()) {
                return;
            }
            Flourish.blast(world, at.add(0, 0.2, 0), radius * 1.3F, STONE);
            Spells.ring(world, SpellKind.GROUND_SLAB, at, radius * 0.7, 12, 24, 1.1F, 0x8A7F70);
            Abilities.soundAt(world, at, Sounds.EARTH_QUAKE, 0.8F);
            for (PlayerEntity player : ElementBoss.playersAt(world, at.add(0, 0.9, 0), radius)) {
                boss.strike(world, player, 8);
                Abilities.push(player, player.getPos().subtract(at).normalize().multiply(0.7).add(0, 0.6, 0));
            }
        });
        return 50;
    }

    private static int hurl(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d hand = boss.getPos().add(0, 2.4, 0);
        Abilities.soundAt(world, hand, Sounds.EARTH_THROW, 0.7F);
        Vec3d[] speed = {target.getPos().add(0, 1, 0).subtract(hand).normalize().multiply(0.8).add(0, 0.2, 0)};
        SpellEntity rock = SpellEntity.spawn(world, SpellKind.MAGMA_BOULDER, hand, 0.9F, 60);
        rock.setVelocity(speed[0]);
        rock.logic(self -> {
            speed[0] = speed[0].add(0, -0.03, 0);
            self.setVelocity(speed[0]);
            Vec3d next = self.getPos().add(speed[0]);
            BlockPos pos = BlockPos.ofFloored(next);
            boolean blocked = !world.getBlockState(pos).getCollisionShape(world, pos).isEmpty();
            self.setPosition(next);
            boolean hit = !ElementBoss.playersAt(world, next, 1.5).isEmpty();
            if (blocked || hit || self.age >= self.life() - 1) {
                Flourish.blast(world, next, 3.4F, 0xFF7A3A);
                SpellEntity.spawn(world, SpellKind.ROCK_BURST, next, 1.0F, 18).tint(0x8A7F70);
                Abilities.soundAt(world, next, Sounds.EARTH_HIT, 0.8F);
                for (PlayerEntity player : ElementBoss.playersAt(world, next, 2.8)) {
                    boss.strike(world, player, 7);
                }
                self.discard();
            }
        });
        return 44;
    }

    /** Разбег: дорожка кругов показывает линию. Отойди к стене и увернись, и Рогач врежется в неё и оглушится. */
    private static int rush(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d to = target.getPos().subtract(boss.getPos());
        Vec3d way = new Vec3d(to.x, 0, to.z).normalize();
        int windup = boss.angry() ? 20 : 28;
        for (int i = 1; i <= 7; i++) {
            Vec3d spot = ground(world, boss.getPos().add(way.multiply(i * 2.2)));
            SpellEntity.spawn(world, SpellKind.DANGER_RING, spot.add(0, 0.06, 0), 1.4F, windup).tint(0xFF7A3A);
        }
        Flourish.charge(world, boss.getPos().add(way.multiply(1.5)).add(0, 1.4, 0), 2.0F, windup, 0xFF7A3A);
        Abilities.soundAt(world, boss.getPos(), Sounds.BOSS_AWAKE, 1.6F);
        boss.startRush(world, way, windup);
        return windup + 70;
    }
}
