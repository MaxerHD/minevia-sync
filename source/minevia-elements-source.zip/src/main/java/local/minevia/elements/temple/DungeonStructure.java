package local.minevia.elements.temple;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Locale;
import java.util.Optional;
import local.minevia.elements.MineviaElements;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureType;

/** Подземелья без стража: склеп уходит под землю, башня стоит на поверхности, лабиринт стелется по ней. */
public final class DungeonStructure extends Structure {
    public static final MapCodec<DungeonStructure> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            configCodecBuilder(instance),
            Codec.STRING.fieldOf("kind").forGetter(dungeon -> dungeon.kind.name().toLowerCase(Locale.ROOT))
    ).apply(instance, DungeonStructure::new));

    private static final int MAX_SLOPE = 7;

    private final DungeonPiece.Kind kind;

    private DungeonStructure(Config config, String kind) {
        super(config);
        this.kind = DungeonPiece.Kind.valueOf(kind.toUpperCase(Locale.ROOT));
    }

    @Override
    protected Optional<StructurePosition> getStructurePosition(Context context) {
        // Соседи считаются быстро, а высоты земли дорого: сначала дешёвая проверка.
        if (Apart.crowded(context, true)) {
            return Optional.empty();
        }
        int x = context.chunkPos().getStartX();
        int z = context.chunkPos().getStartZ();
        int size = kind.size;
        int middleX = x + size / 2;
        int middleZ = z + size / 2;
        int sea = context.chunkGenerator().getSeaLevel();
        int floor = context.chunkGenerator().getHeightInGround(middleX, middleZ, Heightmap.Type.OCEAN_FLOOR_WG,
                context.world(), context.noiseConfig());
        if (floor < sea) {
            return Optional.empty();
        }
        // На склоне комнаты вылезли бы из холма, а лабиринт ушёл бы в него, поэтому место должно быть ровным.
        int low = Integer.MAX_VALUE;
        int high = Integer.MIN_VALUE;
        for (int[] corner : new int[][] {{x, z}, {x + size, z}, {x, z + size}, {x + size, z + size}, {middleX, middleZ}}) {
            int height = context.chunkGenerator().getHeightInGround(corner[0], corner[1], Heightmap.Type.OCEAN_FLOOR_WG,
                    context.world(), context.noiseConfig());
            low = Math.min(low, height);
            high = Math.max(high, height);
        }
        if (high - low > MAX_SLOPE) {
            return Optional.empty();
        }
        // Вход склепа стоит в середине плана, поэтому высота берётся там: поворот на неё не влияет.
        int base = kind == DungeonPiece.Kind.CRYPT ? floor - DungeonPiece.CRYPT_DEPTH : low;
        Direction facing = Direction.Type.HORIZONTAL.random(context.random());
        BlockPos origin = new BlockPos(x, base, z);
        return Optional.of(new StructurePosition(origin, collector -> collector.addPiece(new DungeonPiece(kind, origin, facing))));
    }

    @Override
    public StructureType<?> getType() {
        return MineviaElements.DUNGEON;
    }
}
