package local.minevia.elements;

import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Печать падает со стража храма. Четыре разные Печати вызывают Исток. */
public final class SealItem extends Item {
    public SealItem(Settings settings) {
        super(settings);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.minevia_elements.seal.hint").formatted(Formatting.GRAY));
    }
}
