package local.minevia.elements.temple;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import local.minevia.elements.DungeonBoss;
import local.minevia.elements.DungeonSigilBlock;
import local.minevia.elements.Element;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.TrapBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.loot.LootTable;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.structure.StructureContext;
import net.minecraft.structure.StructurePiece;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.StructureAccessor;
import net.minecraft.world.gen.chunk.ChunkGenerator;

/**
 * Подземелье одним куском. Кусок строится по чанкам, поэтому план должен быть одинаковым в каждом из них:
 * он выводится из положения подземелья, а случайность игры идёт только на содержимое сундуков.
 */
public final class DungeonPiece extends StructurePiece {
    public enum Kind {
        CRYPT(37, 30), TOWER(19, 56), MAZE(41, 8), FORGE(41, 36), SANCTUARY(41, 72), OBSERVATORY(41, 80);

        final int size;
        final int height;

        Kind(int size, int height) {
            this.size = size;
            this.height = height;
        }
    }

    /** На сколько блоков пол склепа лежит ниже поверхности. */
    static final int CRYPT_DEPTH = 20;
    private static final int CRYPT_FLOOR = 2;
    private static final int CELL = 12;
    private static final int TOWER_FLOORS = 6;
    private static final int STOREY = 8;
    private static final int TOWER_RADIUS = 8;
    private static final int TOWER_CENTER = 9;
    private static final int MAZE_CELLS = 13;
    private static final int MAZE_STEP = 3;
    /** Наградные сундуки по хозяевам: у каждого подземелья своя добыча. */
    public static final List<RegistryKey<LootTable>> REWARDS = List.of(table("crypt"), table("tower"), table("maze"), table("forge"), table("sanctuary"), table("observatory"));
    private static final RegistryKey<LootTable> SMALL = table("small");
    private static final EntityType<?>[] CRYPT_MOBS = {EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER, EntityType.STRAY};
    private static final EntityType<?>[] TOWER_MOBS = {EntityType.ZOMBIE, EntityType.SKELETON, MineviaElements.SPIRITS[2], MineviaElements.SPIRITS[1],
            MineviaElements.SPIRITS[3], MineviaElements.SPIRITS[0]};
    private static final BlockState WALL = Blocks.DEEPSLATE_BRICKS.getDefaultState();
    private static final BlockState CRACKED = Blocks.CRACKED_DEEPSLATE_BRICKS.getDefaultState();
    private static final BlockState TILES = Blocks.DEEPSLATE_TILES.getDefaultState();
    private static final BlockState LIGHT = Blocks.SOUL_LANTERN.getDefaultState();
    private static final BlockState STONE = Blocks.STONE_BRICKS.getDefaultState();
    private static final BlockState MOSSY = Blocks.MOSSY_STONE_BRICKS.getDefaultState();
    private static final BlockState LAMP = Blocks.OCHRE_FROGLIGHT.getDefaultState();

    private final Kind kind;
    final int entryHeight;

    private static RegistryKey<LootTable> table(String name) {
        return RegistryKey.of(RegistryKeys.LOOT_TABLE, Identifier.of(MineviaElements.MOD_ID, "chests/" + name));
    }

    DungeonPiece(Kind kind, BlockPos origin, Direction facing, int entryHeight) {
        super(MineviaElements.DUNGEON_PIECE, 0, createBox(origin.getX(), origin.getY(), origin.getZ(), facing, kind.size, kind.height, kind.size));
        this.kind = kind;
        this.entryHeight = entryHeight;
        setOrientation(facing);
    }

    public DungeonPiece(NbtCompound nbt) {
        super(MineviaElements.DUNGEON_PIECE, nbt);
        kind = Kind.values()[Math.floorMod(nbt.getInt("Kind"), Kind.values().length)];
        entryHeight = nbt.getInt("EntryHeight");
    }

    @Override
    protected void writeNbt(StructureContext context, NbtCompound nbt) {
        nbt.putInt("Kind", kind.ordinal());
        nbt.putInt("EntryHeight", entryHeight);
    }

    /** Один и тот же для всех чанков подземелья. */
    private java.util.Random plan() {
        BlockBox whole = getBoundingBox();
        return new java.util.Random(whole.getMinX() * 341873128712L + whole.getMinZ() * 132897987541L + kind.ordinal());
    }

    @Override
    public void generate(StructureWorldAccess world, StructureAccessor accessor, ChunkGenerator generator, Random random,
            BlockBox box, ChunkPos chunk, BlockPos pivot) {
        switch (kind) {
            case CRYPT -> crypt(world, box, random);
            case TOWER -> tower(world, box, random);
            case MAZE -> maze(world, box, random);
            default -> new DungeonPlans(this, kind, world, box, random, plan()).generate();
        }
    }

    void place(StructureWorldAccess world, BlockBox box, BlockState state, int x, int y, int z) {
        addBlock(world, state, x, y, z, box);
    }

    void cache(StructureWorldAccess world, BlockBox box, Random random, int x, int y, int z) {
        addChest(world, box, random, x, y, z, SMALL);
    }

    void spawner(StructureWorldAccess world, BlockBox box, Random random, int x, int y, int z, EntityType<?> mob) {
        BlockPos pos = offsetPos(x, y, z);
        if (!box.contains(pos)) {
            return;
        }
        world.setBlockState(pos, Blocks.SPAWNER.getDefaultState(), 2);
        if (world.getBlockEntity(pos) instanceof MobSpawnerBlockEntity spawner) {
            spawner.setEntityType(mob, random);
        }
    }

    /** Печать хозяина: он проснётся, когда игрок подойдёт, а награда появится только после победы. */
    void sigil(StructureWorldAccess world, BlockBox box, int x, int y, int z, int kind) {
        addBlock(world, MineviaElements.SIGIL.getDefaultState().with(DungeonSigilBlock.KIND, kind), x, y, z, box);
    }

    private static BlockState trap(Element element) {
        return MineviaElements.TRAP.getDefaultState().with(TrapBlock.ELEMENT, element.ordinal());
    }

    // ------------------------------------------------------------------ склеп

    /** Девять комнат три на три. Вход сверху в средней, награда в дальнем углу, и туда надо пройти через другие. */
    private void crypt(StructureWorldAccess world, BlockBox box, Random random) {
        java.util.Random plan = plan();
        int reward = new int[] {0, 2, 6, 8}[plan.nextInt(4)];
        int top = CRYPT_FLOOR + 8;
        for (int x = 0; x < kind.size; x++) {
            for (int z = 0; z < kind.size; z++) {
                addBlock(world, TILES, x, CRYPT_FLOOR, z, box);
                addBlock(world, WALL, x, top, z, box);
                boolean wall = x % CELL == 0 || z % CELL == 0;
                for (int y = CRYPT_FLOOR + 1; y < top; y++) {
                    addBlock(world, wall ? (x * 7 + z * 3 + y) % 5 == 0 ? CRACKED : WALL : AIR, x, y, z, box);
                }
            }
        }
        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                int x = column * CELL;
                int z = row * CELL;
                if (column < 2) {
                    door(world, box, x + CELL, z + 6, true);
                }
                if (row < 2) {
                    door(world, box, x + 6, z + CELL, false);
                }
                int room = row * 3 + column;
                int kindOfRoom = plan.nextInt(4);
                for (int dx : new int[] {2, 10}) {
                    for (int dz : new int[] {2, 10}) {
                        addBlock(world, LIGHT, x + dx, CRYPT_FLOOR + 1, z + dz, box);
                    }
                }
                if (room == 4) {
                    continue;
                }
                if (room == reward) {
                    sigil(world, box, x + 6, CRYPT_FLOOR + 1, z + 6, DungeonBoss.ABBOT);
                    addBlock(world, Blocks.GOLD_BLOCK.getDefaultState(), x + 5, CRYPT_FLOOR, z + 6, box);
                    addBlock(world, Blocks.GOLD_BLOCK.getDefaultState(), x + 7, CRYPT_FLOOR, z + 6, box);
                } else if (kindOfRoom == 0) {
                    spawner(world, box, random, x + 6, CRYPT_FLOOR + 1, z + 6, CRYPT_MOBS[plan.nextInt(CRYPT_MOBS.length)]);
                } else if (kindOfRoom == 1) {
                    trapFloor(world, box, x, z, Element.natural()[plan.nextInt(4)]);
                } else if (kindOfRoom == 2) {
                    columns(world, box, x, z);
                    addChest(world, box, random, x + 6, CRYPT_FLOOR + 1, z + 6, SMALL);
                } else {
                    webs(world, box, x, z, plan);
                    spawner(world, box, random, x + 6, CRYPT_FLOOR + 1, z + 6, EntityType.SPIDER);
                }
            }
        }
        cryptEntrance(world, box);
    }

    private void door(StructureWorldAccess world, BlockBox box, int x, int z, boolean alongZ) {
        for (int side = -1; side <= 1; side++) {
            for (int y = CRYPT_FLOOR + 1; y <= CRYPT_FLOOR + 3; y++) {
                addBlock(world, AIR, alongZ ? x : x + side, y, alongZ ? z + side : z, box);
            }
        }
    }

    /** Пол из ловушек с безопасной дорожкой посередине. */
    private void trapFloor(StructureWorldAccess world, BlockBox box, int x, int z, Element element) {
        for (int dx = 2; dx <= 10; dx++) {
            for (int dz = 2; dz <= 10; dz++) {
                if (dx != 6 && dz != 6 && (dx + dz) % 2 == 0) {
                    addBlock(world, trap(element), x + dx, CRYPT_FLOOR, z + dz, box);
                }
            }
        }
    }

    private void columns(StructureWorldAccess world, BlockBox box, int x, int z) {
        for (int dx : new int[] {3, 9}) {
            for (int dz : new int[] {3, 9}) {
                for (int y = CRYPT_FLOOR + 2; y < CRYPT_FLOOR + 8; y++) {
                    addBlock(world, Blocks.CHISELED_DEEPSLATE.getDefaultState(), x + dx, y, z + dz, box);
                }
            }
        }
    }

    private void webs(StructureWorldAccess world, BlockBox box, int x, int z, java.util.Random plan) {
        for (int i = 0; i < 26; i++) {
            addBlock(world, Blocks.COBWEB.getDefaultState(), x + 1 + plan.nextInt(11), CRYPT_FLOOR + 3 + plan.nextInt(5), z + 1 + plan.nextInt(11), box);
        }
    }

    /** Шахта с лестницей из средней комнаты и маленький склеп на поверхности. */
    private void cryptEntrance(StructureWorldAccess world, BlockBox box) {
        int center = kind.size / 2;
        int surface = CRYPT_DEPTH;
        for (int y = CRYPT_FLOOR + 8; y <= surface + 4; y++) {
            for (int dx = -2; dx <= 2; dx++) {
                for (int dz = -2; dz <= 2; dz++) {
                    boolean side = Math.abs(dx) == 2 || Math.abs(dz) == 2;
                    addBlock(world, side ? WALL : AIR, center + dx, y, center + dz, box);
                }
            }
        }
        BlockState ladder = Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.SOUTH);
        for (int y = CRYPT_FLOOR + 1; y <= surface; y++) {
            addBlock(world, WALL, center, y, center - 2, box);
            addBlock(world, ladder, center, y, center - 1, box);
        }
        // Пол склепа наверху: без него за дверью сразу начиналась бы шахта.
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx != 0 || dz != -1) {
                    addBlock(world, TILES, center + dx, surface, center + dz, box);
                }
            }
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                addBlock(world, TILES, center + dx, surface + 5, center + dz, box);
            }
        }
        for (int y = surface + 1; y <= surface + 3; y++) {
            for (int dx = -1; dx <= 1; dx++) {
                addBlock(world, AIR, center + dx, y, center + 2, box);
            }
        }
        addBlock(world, LIGHT, center, surface + 4, center, box);
    }

    // ------------------------------------------------------------------ башня

    /** Шесть круглых этажей: чем выше, тем опаснее чудовища. Наверху открытая площадка с наградой. */
    private void tower(StructureWorldAccess world, BlockBox box, Random random) {
        java.util.Random plan = plan();
        int roof = TOWER_FLOORS * STOREY;
        for (int x = 0; x < kind.size; x++) {
            for (int z = 0; z < kind.size; z++) {
                double distance = Math.hypot(x - TOWER_CENTER, z - TOWER_CENTER);
                if (distance > TOWER_RADIUS + 0.5) {
                    continue;
                }
                boolean wall = distance > TOWER_RADIUS - 0.6;
                fillDownwards(world, STONE, x, -1, z, box);
                for (int y = 0; y <= roof; y++) {
                    boolean floor = y % STOREY == 0;
                    boolean hole = floor && y > 0 && x == TOWER_CENTER && z == TOWER_CENTER + 1;
                    BlockState block;
                    if (hole) {
                        block = AIR;
                    } else if (floor) {
                        block = distance < 2 ? LAMP : (x + z) % 3 == 0 ? MOSSY : STONE;
                    } else if (wall) {
                        boolean window = y % STOREY == 4 && (x + z) % 4 == 0;
                        block = window ? Blocks.IRON_BARS.getDefaultState() : (x * 5 + z + y) % 4 == 0 ? MOSSY : STONE;
                    } else {
                        block = AIR;
                    }
                    addBlock(world, block, x, y, z, box);
                }
                if (wall) {
                    addBlock(world, STONE, x, roof + 1, z, box);
                    if ((x + z) % 2 == 0) {
                        addBlock(world, MOSSY, x, roof + 2, z, box);
                    }
                }
            }
        }
        BlockState ladder = Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.SOUTH);
        for (int y = 1; y < roof; y++) {
            addBlock(world, STONE, TOWER_CENTER, y, TOWER_CENTER, box);
            addBlock(world, ladder, TOWER_CENTER, y, TOWER_CENTER + 1, box);
        }
        addBlock(world, ladder, TOWER_CENTER, roof, TOWER_CENTER + 1, box);
        for (int y = 1; y <= 3; y++) {
            for (int x = TOWER_CENTER - 1; x <= TOWER_CENTER + 1; x++) {
                addBlock(world, AIR, x, y, 1, box);
                addBlock(world, AIR, x, y, 2, box);
            }
        }
        for (int floor = 0; floor < TOWER_FLOORS; floor++) {
            int y = floor * STOREY + 1;
            EntityType<?> mob = TOWER_MOBS[floor];
            spawner(world, box, random, TOWER_CENTER + 5, y, TOWER_CENTER, mob);
            spawner(world, box, random, TOWER_CENTER - 5, y, TOWER_CENTER, mob);
            addBlock(world, Blocks.LANTERN.getDefaultState(), TOWER_CENTER + 4, y, TOWER_CENTER + 4, box);
            addBlock(world, Blocks.LANTERN.getDefaultState(), TOWER_CENTER - 4, y, TOWER_CENTER - 4, box);
            if (floor % 2 == 1) {
                addChest(world, box, random, TOWER_CENTER - 4, y, TOWER_CENTER + 4, SMALL);
            }
            if (floor >= 2 && plan.nextBoolean()) {
                for (int dx = -3; dx <= 3; dx += 2) {
                    addBlock(world, trap(Element.natural()[floor % 4]), TOWER_CENTER + dx, y - 1, TOWER_CENTER + 3, box);
                }
            }
        }
        sigil(world, box, TOWER_CENTER, roof + 1, TOWER_CENTER - 3, DungeonBoss.BELL);
    }

    // ------------------------------------------------------------------ лабиринт

    /** Настоящий лабиринт под крышей: ходы прорезаны обходом в глубину, в тупиках сундуки и чудовища, в центре награда. */
    private void maze(StructureWorldAccess world, BlockBox box, Random random) {
        java.util.Random plan = plan();
        boolean[][] seen = new boolean[MAZE_CELLS][MAZE_CELLS];
        boolean[][] openEast = new boolean[MAZE_CELLS][MAZE_CELLS];
        boolean[][] openSouth = new boolean[MAZE_CELLS][MAZE_CELLS];
        int[] exits = new int[MAZE_CELLS * MAZE_CELLS];
        carve(plan, seen, openEast, openSouth, exits);

        int width = MAZE_CELLS * MAZE_STEP + 1;
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < width; z++) {
                fillDownwards(world, STONE, x, -1, z, box);
                addBlock(world, (x + z) % 5 == 0 ? MOSSY : STONE, x, 0, z, box);
                addBlock(world, (x * 3 + z) % 11 == 0 ? LAMP : STONE, x, 5, z, box);
                boolean wall = x % MAZE_STEP == 0 || z % MAZE_STEP == 0;
                for (int y = 1; y <= 4; y++) {
                    addBlock(world, wall ? (x + y + z) % 4 == 0 ? MOSSY : STONE : AIR, x, y, z, box);
                }
            }
        }
        for (int cx = 0; cx < MAZE_CELLS; cx++) {
            for (int cz = 0; cz < MAZE_CELLS; cz++) {
                int x = cx * MAZE_STEP;
                int z = cz * MAZE_STEP;
                if (openEast[cx][cz]) {
                    clear(world, box, x + 3, z + 1, x + 3, z + 2);
                }
                if (openSouth[cx][cz]) {
                    clear(world, box, x + 1, z + 3, x + 2, z + 3);
                }
                if (exits[cx * MAZE_CELLS + cz] == 1 && !central(cx, cz)) {
                    int roll = plan.nextInt(10);
                    if (roll < 4) {
                        spawner(world, box, random, x + 1, 1, z + 1, CRYPT_MOBS[plan.nextInt(CRYPT_MOBS.length)]);
                    } else if (roll < 7) {
                        addChest(world, box, random, x + 1, 1, z + 1, SMALL);
                    }
                } else if (exits[cx * MAZE_CELLS + cz] == 2 && plan.nextInt(9) == 0) {
                    addBlock(world, trap(Element.natural()[plan.nextInt(4)]), x + 1, 0, z + 1, box);
                    addBlock(world, trap(Element.natural()[plan.nextInt(4)]), x + 2, 0, z + 2, box);
                }
            }
        }
        int low = (MAZE_CELLS / 2 - 2) * MAZE_STEP;
        int high = (MAZE_CELLS / 2 + 3) * MAZE_STEP;
        clear(world, box, low + 1, low + 1, high - 1, high - 1);
        int middle = (low + high) / 2;
        sigil(world, box, middle, 1, middle, DungeonBoss.BULL);
        // Вход в середине ближней стены.
        int entry = MAZE_CELLS / 2 * MAZE_STEP;
        clear(world, box, entry + 1, 0, entry + 2, 0);
    }

    private static boolean central(int cx, int cz) {
        int half = MAZE_CELLS / 2;
        return Math.abs(cx - half) <= 2 && Math.abs(cz - half) <= 2;
    }

    private void clear(StructureWorldAccess world, BlockBox box, int fromX, int fromZ, int toX, int toZ) {
        for (int x = fromX; x <= toX; x++) {
            for (int z = fromZ; z <= toZ; z++) {
                for (int y = 1; y <= 4; y++) {
                    addBlock(world, AIR, x, y, z, box);
                }
            }
        }
    }

    /** Обход в глубину: из любой клетки есть ровно один путь в любую другую. exits считает выходы из клетки. */
    private static void carve(java.util.Random plan, boolean[][] seen, boolean[][] openEast, boolean[][] openSouth, int[] exits) {
        Deque<int[]> path = new ArrayDeque<>();
        path.push(new int[] {MAZE_CELLS / 2, 0});
        seen[MAZE_CELLS / 2][0] = true;
        while (!path.isEmpty()) {
            int[] at = path.peek();
            List<int[]> next = new ArrayList<>();
            for (int[] step : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
                int x = at[0] + step[0];
                int z = at[1] + step[1];
                if (x >= 0 && z >= 0 && x < MAZE_CELLS && z < MAZE_CELLS && !seen[x][z]) {
                    next.add(new int[] {x, z});
                }
            }
            if (next.isEmpty()) {
                path.pop();
                continue;
            }
            Collections.shuffle(next, plan);
            int[] to = next.get(0);
            seen[to[0]][to[1]] = true;
            if (to[0] != at[0]) {
                openEast[Math.min(at[0], to[0])][at[1]] = true;
            } else {
                openSouth[at[0]][Math.min(at[1], to[1])] = true;
            }
            exits[at[0] * MAZE_CELLS + at[1]]++;
            exits[to[0] * MAZE_CELLS + to[1]]++;
            path.push(to);
        }
    }
}
