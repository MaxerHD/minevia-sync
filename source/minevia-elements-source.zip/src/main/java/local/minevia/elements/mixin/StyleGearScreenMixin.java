package local.minevia.elements.mixin;
import local.minevia.elements.StyleGear;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.PlayerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Оружие можно переставлять только между своими ячейками. */
@Mixin(ScreenHandler.class)
abstract class StyleGearScreenMixin {
    @Inject(method = "onSlotClick", at = @At("HEAD"), cancellable = true)
    private void minevia$bound(int slotId, int button, SlotActionType action, PlayerEntity player, CallbackInfo ci) {
        ScreenHandler self = (ScreenHandler) (Object) this;
        boolean cursor = StyleGear.isGear(self.getCursorStack());
        boolean target = slotId >= 0 && slotId < self.slots.size() && StyleGear.isGear(self.slots.get(slotId).getStack());
        boolean swap = action == SlotActionType.SWAP && StyleGear.isGear(player.getInventory().getStack(button == 40 ? 40 : Math.clamp(button, 0, 8)));
        if (!(cursor || target || swap)) return;
        boolean bundle = self.getCursorStack().getItem() instanceof net.minecraft.item.BundleItem
                || slotId >= 0 && slotId < self.slots.size() && self.slots.get(slotId).getStack().getItem() instanceof net.minecraft.item.BundleItem;
        if (bundle) { ci.cancel(); return; }
        // Курсор не используется, чтобы закрытие меню не выбросило оружие.
        boolean ownSwap = self instanceof PlayerScreenHandler && (action == SlotActionType.SWAP || action == SlotActionType.PICKUP || action == SlotActionType.QUICK_MOVE)
                && slotId >= 9 && slotId <= 44;
        if (!ownSwap) ci.cancel();
    }
}
