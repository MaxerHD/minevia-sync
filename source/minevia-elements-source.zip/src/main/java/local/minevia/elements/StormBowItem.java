package local.minevia.elements;

import java.util.List;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.world.World;

/** Обычная стрела сохраняет зачарования, полный натяг добавляет цепную молнию. */
public final class StormBowItem extends BowItem {
    public StormBowItem(Settings settings) {
        super(settings);
    }

    @Override
    protected ProjectileEntity createArrowEntity(World world, LivingEntity shooter, ItemStack weapon, ItemStack ammo, boolean critical) {
        ProjectileEntity arrow = super.createArrowEntity(world, shooter, weapon, ammo, critical);
        if (arrow instanceof PersistentProjectileEntity persistent) {
            ((StormArrow) persistent).mineviaStorm(critical);
        }
        return arrow;
    }

    @Override
    public boolean canRepair(ItemStack stack, ItemStack ingredient) {
        return ingredient.isOf(Items.NETHERITE_INGOT) || super.canRepair(stack, ingredient);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.minevia_elements.storm_bow.hint").formatted(Formatting.GRAY));
    }
}
