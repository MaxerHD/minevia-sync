package local.minevia.elements.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import local.minevia.elements.client.SkinClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Отсюда скин берут и модель игрока, и рука от первого лица, и список игроков на Tab. */
@Mixin(PlayerListEntry.class)
abstract class PlayerListEntryMixin {
    @ModifyReturnValue(method = "getSkinTextures", at = @At("RETURN"))
    private SkinTextures minevia$playerSkin(SkinTextures original) {
        return SkinClient.apply(((PlayerListEntry) (Object) this).getProfile().getId(), original);
    }
}
