package local.minevia.elements;

/** Выбор и пауза смены проверяются сервером. */
public final class SelectionRules {
    public static final long COOLDOWN_MS = 20 * 60 * 1000L;

    private SelectionRules() { }

    public static Element choice(int id) {
        return id >= 0 && id < Element.values().length ? Element.values()[id] : null;
    }

    public static long remaining(long changedAt, long now) {
        if (changedAt <= 0) return 0;
        if (now < changedAt) return COOLDOWN_MS;
        return Math.max(0, COOLDOWN_MS - (now - changedAt));
    }

    public static boolean allowed(Element current, Element next, long changedAt, long now) {
        return next != null && current != next && (current == null || remaining(changedAt, now) == 0);
    }
}
