package local.minevia.elements.mixin;
import local.minevia.elements.client.StyleGearRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/** Перчатка следует за рукой от первого лица. */
@Mixin(PlayerEntityRenderer.class)
abstract class StyleGloveArmMixin {
    @Inject(method = "renderRightArm", at = @At("TAIL"))
    private void minevia$right(MatrixStack matrices, VertexConsumerProvider out, int light, AbstractClientPlayerEntity player, CallbackInfo ci) {
        StyleGearRenderer.glove(player, Arm.RIGHT, ((PlayerEntityRenderer)(Object)this).getModel(), matrices, out, light, 0);
    }
    @Inject(method = "renderLeftArm", at = @At("TAIL"))
    private void minevia$left(MatrixStack matrices, VertexConsumerProvider out, int light, AbstractClientPlayerEntity player, CallbackInfo ci) {
        StyleGearRenderer.glove(player, Arm.LEFT, ((PlayerEntityRenderer)(Object)this).getModel(), matrices, out, light, 0);
    }
}
