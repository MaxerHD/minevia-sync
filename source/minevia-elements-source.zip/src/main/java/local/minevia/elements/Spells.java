package local.minevia.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Способности стихий. Всё видимое здесь является 3D-моделями из {@link SpellEntity}.
 * Часть поведения и скоростей взята из открытого AvatarMod (GPL-3, авторы в CREDITS.md),
 * код написан заново под 1.21.1.
 */
final class Spells {
    private static final int DIRT = 0x8A6A48;

    /** Что делает снаряд при попадании. Вернуть true, если снаряд закончил полёт. */
    interface Hit {
        boolean at(Vec3d position, LivingEntity target);
    }

    private Spells() {
    }

    /** Во сколько раз снаряд крупнее от силы навыка: от 0.7 на первом уровне до 1.3 у мастера. */
    static float big(int level) {
        return 0.7F + 0.1F * (level - 1);
    }

    /** Сколько секунд горит цель: новичок только подпаливает. */
    static int burnTime(int level) {
        return 2 + level / 2;
    }

    // ------------------------------------------------------------------ огонь

    /** Шар висит перед игроком и разгорается, пока его держат: чем выше уровень, тем больше он набирает. ЛКМ стреляет. */
    static void fireball(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_CHARGE, 1.5F);
        float scale = big(level);
        SpellEntity ball = SpellEntity.spawn(world, SpellKind.FIREBALL, muzzle(player, 3.0), 0.7F * scale, 340).charged(Element.FIRE, player);
        Set<UUID> struck = new HashSet<>();
        boolean[] flying = {false};
        float[] charge = {0};
        LivingEntity[] locked = {null};
        ball.logic(self -> {
            if (!flying[0]) {
                if (!Control.holding(player, self)) {
                    self.discard();
                    return;
                }
                charge[0] = Math.min(1, self.age / 40.0F);
                self.setSize((0.7F + 0.9F * charge[0]) * scale);
                self.facing(player.getRotationVector());
                hover(self, Control.spot(player));
                return;
            }
            // Помощь в прицеливании: шар слегка доворачивает за врагом, на которого смотрел игрок.
            if (locked[0] != null && locked[0].isAlive()) {
                Vec3d to = locked[0].getBoundingBox().getCenter().subtract(self.getPos()).normalize().multiply(0.9);
                self.setVelocity(self.getVelocity().lerp(to, 0.14));
            }
            float power = 1 + charge[0] * Math.min(1, 0.3F + level * 0.12F);
            flyFire(self, player, struck, 0.7, 2.6 * scale * (1 + charge[0] * 0.5), (6 + level * 1.5F) * power, power * 0.8F * scale, burnTime(level));
        });
        Control.hold(player, 0, ball, 3.5, () -> {
            flying[0] = true;
            locked[0] = Abilities.aim(player, 40);
            Abilities.sound(player, Sounds.FIRE_CAST, 1.0F);
            ball.setVelocity(crosshair(player, 40).subtract(ball.getPos()).normalize().multiply(0.9));
            ball.setLife(ball.age + 70);
        });
    }

    /** Большой шар: разгорается перед игроком, держится сколько нужно и летит туда, куда смотрит игрок. */
    static void greatFireball(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_CHARGE, 1.0F);
        SpellEntity ball = SpellEntity.spawn(world, SpellKind.FIREBALL, muzzle(player, 4.0), 0.3F, 340).charged(Element.FIRE, player);
        Flourish.charge(world, muzzle(player, 4.0), 2.2F * big(level), 20, 0xFF8A3D);
        Set<UUID> struck = new HashSet<>();
        boolean[] flying = {false};
        float grown = 2.3F * big(level);
        ball.logic(self -> {
            if (!flying[0]) {
                if (!Control.holding(player, self)) {
                    self.discard();
                    return;
                }
                self.setSize(0.3F + (grown - 0.3F) * Math.min(1, self.age / 20.0F));
                self.facing(player.getRotationVector());
                hover(self, Control.spot(player));
                return;
            }
            flyFire(self, player, struck, 1.2, 3.0 + level * 0.5, 10 + level * 2, 2.1F * big(level), burnTime(level));
        });
        Control.hold(player, 3, ball, 5.0, () -> {
            flying[0] = true;
            Abilities.sound(player, Sounds.FIRE_CAST, 0.7F);
            ball.setVelocity(crosshair(player, 40).subtract(ball.getPos()).normalize().multiply(0.7));
            ball.setLife(ball.age + 80);
        });
    }

    private static void flyFire(SpellEntity self, ServerPlayerEntity owner, Set<UUID> struck, double radius,
            double blast, float damage, float size, int burning) {
        boolean ended = fly(self, owner, radius, true, struck, (at, target) -> true);
        if (!ended && self.age < self.life() - 1) {
            return;
        }
        ServerWorld world = (ServerWorld) self.getWorld();
        Vec3d at = self.getPos();
        SpellEntity.spawn(world, SpellKind.FIRE_BURST, at, size * 1.3F, 17);
        Abilities.soundAt(world, at, Sounds.FIRE_BLAST, 1.0F);
        Nature.burn(world, owner, at, Math.min(blast, 3.0));
        Flourish.blast(world, at, size * 2.4F, 0xFF8A3D);
        for (LivingEntity near : Abilities.livingAt(owner, at, blast)) {
            Abilities.hurt(owner, near, damage);
            near.setOnFireFor(burning);
        }
        self.discard();
    }

    static void flameRing(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_RING, 1.0F);
        Vec3d center = player.getPos();
        Set<UUID> struck = new HashSet<>();
        SpellEntity.spawn(world, SpellKind.FLAME_RING, center, 1.0F, 20).charged(Element.FIRE, player).logic(self -> {
            double radius = 1 + (2.2 + level * 0.65) * Math.min(1.0, self.age / 16.0);
            self.setSize((float) radius);
            if (self.age == 8 || self.age == 16) {
                Nature.burn(world, player, center.add(0, 0.5, 0), radius);
            }
            for (LivingEntity target : Abilities.monstersAt(player, center, radius)) {
                if (target.getPos().distanceTo(center) <= radius + 0.5 && struck.add(target.getUuid())) {
                    Abilities.hurt(player, target, 4 + level);
                    target.setOnFireFor(burnTime(level));
                }
            }
        });
    }

    /** Пламенная броня: сила на 15 секунд, и всё, что подошло вплотную, загорается. */
    static void flameArmor(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_ARMOR, 1.0F);
        Abilities.buff(player, StatusEffects.STRENGTH, 300, level >= 4 ? 1 : 0);
        Abilities.buff(player, StatusEffects.FIRE_RESISTANCE, 300, 0);
        SpellEntity.spawn(world, SpellKind.FLAME_AURA, player.getPos(), 0.8F, 300).owner(player).logic(self -> {
            self.setPosition(player.getPos());
            if (!player.isAlive()) {
                self.discard();
            } else if (self.age % 20 == 0) {
                for (LivingEntity target : Abilities.monstersAt(player, player.getPos().add(0, 1, 0), 2.6)) {
                    Abilities.hurt(player, target, 1 + level * 0.5F);
                    target.setOnFireFor(burnTime(level));
                }
            }
        });
    }

    static void flamethrower(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        SpellEntity.spawn(world, SpellKind.FLAME_JET, player.getEyePos(), big(level), 24 + level * 6).owner(player).charged(Element.FIRE, player).logic(self -> {
            self.setPosition(player.getEyePos());
            if (!player.isAlive()) {
                self.discard();
                return;
            }
            if (self.age % 12 == 0) {
                Abilities.sound(player, Sounds.FLAME_LOOP, 1.0F);
            }
            if (self.age % 2 != 0) {
                return;
            }
            Vec3d look = player.getRotationVector();
            Vec3d eye = player.getEyePos();
            if (self.age % 6 == 0) {
                Nature.burn(world, player, player.raycast(8, 1.0F, false).getPos(), 1.6);
            }
            double reach = 3 + level * 0.4;
            for (LivingEntity target : Abilities.livingAt(player, eye.add(look.multiply(reach)), reach + 0.5)) {
                Vec3d toTarget = target.getBoundingBox().getCenter().subtract(eye).normalize();
                if (toTarget.dotProduct(look) > 0.82) {
                    Abilities.hurt(player, target, 1.0F + level * 0.4F);
                    target.setOnFireFor(burnTime(level));
                }
            }
        });
    }

    // ------------------------------------------------------------------ вода

    /**
     * Поток: игрок забирает воду из ближайшего водоёма, а если его нет, вытягивает из земли.
     * Пока вода в руках, ею можно водить и таскать врагов, а ЛКМ выстреливает её в прицел.
     * Из настоящего водоёма поток крупнее и бьёт сильнее.
     */
    static void waterFlow(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d pool = nearestWater(player);
        Vec3d source = pool != null ? pool : groundAhead(player, 2.5);
        float size = (pool != null ? 1.2F : 0.95F) * big(level);
        float damage = (pool != null ? 8 : 6) + level * 1.5F;
        Abilities.soundAt(world, source, Sounds.WATER_RISE, 1.0F);
        SpellEntity.spawn(world, SpellKind.WATER_SPLASH, source, 0.7F, 15);
        Set<UUID> struck = new HashSet<>();
        boolean[] flying = {false};
        SpellEntity blob = SpellEntity.spawn(world, SpellKind.WATER_BLOB, source, size, 340).charged(Element.WATER, player);
        blob.logic(self -> {
            if (!player.isAlive() || player.isRemoved()) {
                self.discard();
                return;
            }
            if (!flying[0]) {
                if (!Control.holding(player, self)) {
                    self.discard();
                    return;
                }
                Vec3d to = Control.spot(player).subtract(self.getPos());
                double distance = to.length();
                Vec3d want = distance < 0.3 ? Vec3d.ZERO : to.multiply(Math.min(1.9, distance * 0.5) / distance);
                self.setVelocity(self.getVelocity().lerp(want, 0.5));
                if (self.age % 14 == 0) {
                    struck.clear();
                }
                fly(self, player, 0.8 * size, false, struck, (at, target) -> {
                    Abilities.hurt(player, target, damage * 0.35F);
                    Abilities.debuff(target, StatusEffects.SLOWNESS, 40, 2);
                    Abilities.push(target, self.getVelocity().multiply(0.9).add(0, 0.2, 0));
                    return false;
                });
                return;
            }
            boolean ended = fly(self, player, 0.75 * size, true, struck, (at, target) -> {
                Abilities.pierce(player, target, damage);
                Abilities.debuff(target, StatusEffects.SLOWNESS, 80, 2);
                Abilities.push(target, self.getVelocity().multiply(0.7).add(0, 0.25, 0));
                return true;
            });
            if (ended || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, self.getPos(), 1.15F * size, 15);
                Abilities.soundAt(world, self.getPos(), Sounds.WATER_HIT, 1.0F);
                Nature.douse(world, player, self.getPos(), 2.8);
                Flourish.blast(world, self.getPos(), size * 3, 0x7FD0FF);
                self.discard();
            }
        });
        Control.hold(player, 0, blob, 4.5, () -> {
            flying[0] = true;
            struck.clear();
            Abilities.sound(player, Sounds.WATER_WHIP, 1.1F);
            blob.setVelocity(crosshair(player, 40).subtract(blob.getPos()).normalize().multiply(1.5));
            blob.setLife(blob.age + 45);
        });
    }

    static void healing(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        float amount = 4 + level * 2;
        Abilities.sound(player, Sounds.WATER_HEAL, 1.0F);
        for (PlayerEntity ally : world.getEntitiesByClass(PlayerEntity.class, player.getBoundingBox().expand(8), PlayerEntity::isAlive)) {
            ally.heal(amount);
            ally.extinguish();
            SpellEntity.spawn(world, SpellKind.HEAL_SPIRAL, ally.getPos(), 1.0F, 34).owner(ally).tint(0x6FE3D2)
                    .logic(self -> self.setPosition(ally.getPos()));
        }
    }

    static void iceRing(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.ICE_FORM, 1.0F);
        Vec3d feet = player.getPos();
        double ground = groundAt(world, feet);
        Vec3d center = Double.isNaN(ground) ? feet : new Vec3d(feet.x, ground, feet.z);
        double far = 3.4 + level * 0.5;
        ring(world, SpellKind.ICE_SHARD, center, far * 0.52, 9, 70, big(level), 0xFFFFFF);
        Nature.freeze(world, player, center.add(0, -0.5, 0), 6.5);
        Effects.later(world, 5, () -> {
            ring(world, SpellKind.ICE_SHARD, center, far, 16, 66, 1.15F * big(level), 0xFFFFFF);
            Abilities.soundAt(world, center, Sounds.ICE_FORM, 0.8F);
        });
        for (LivingEntity target : Abilities.monstersAt(player, center, far + 1)) {
            Abilities.hurt(player, target, 3 + level);
            Abilities.debuff(target, StatusEffects.SLOWNESS, 120, 3);
            target.setFrozenTicks(160);
        }
    }

    /** Водяная плеть: хлещет цель на линии взгляда и подтаскивает её к игроку. */
    static void whip(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.WATER_WHIP, 1.0F);
        LivingEntity target = Abilities.aim(player, 20);
        Vec3d look = player.getRotationVector();
        SpellEntity whip = SpellEntity.spawn(world, SpellKind.WATER_WHIP, player.getPos(), 12.0F, 11).owner(player);
        whip.facing(look);
        if (target != null) {
            whip.target(target);
        }
        whip.logic(self -> {
            self.setPosition(player.getPos());
            if (self.age == 3 && target != null && target.isAlive()) {
                Abilities.hurt(player, target, 8 + level * 2);
                Abilities.debuff(target, StatusEffects.SLOWNESS, 60, 1);
                Vec3d pull = player.getPos().subtract(target.getPos());
                Abilities.push(target, pull.normalize().multiply(Math.min(2.0, pull.length() * 0.22)).add(0, 0.32, 0));
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, target.getBoundingBox().getCenter(), 0.6F, 15);
            }
        });
    }

    static void wave(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.WATER_WAVE, 1.0F);
        Vec3d forward = flatLook(player);
        Vec3d start = player.getPos().add(forward.multiply(2.0));
        Set<UUID> struck = new HashSet<>();
        double half = 2.6 + level * 0.4;
        float size = (float) (half / 3.0);
        SpellEntity wave = SpellEntity.spawn(world, SpellKind.WATER_WAVE, start, size, 36).facing(forward).charged(Element.WATER, player);
        wave.setVelocity(forward.multiply(0.6));
        wave.logic(self -> {
            Vec3d at = self.getPos();
            double ground = groundAt(world, at.add(0, 1, 0));
            double dy = Double.isNaN(ground) ? 0 : MathHelper.clamp(ground - at.y, -0.5, 0.5);
            self.setVelocity(forward.multiply(0.6).add(0, dy, 0));
            self.setPosition(at.add(self.getVelocity()));
            for (LivingEntity target : Abilities.monstersAt(player, self.getPos().add(0, 1, 0), half)) {
                Abilities.push(target, forward.multiply(0.8).add(0, 0.28, 0));
                if (struck.add(target.getUuid())) {
                    Abilities.hurt(player, target, 5 + level);
                }
            }
        });
    }

    // ------------------------------------------------------------------ земля

    /** Глыба: кусок земли вырывается из-под ног и висит там, куда смотрит игрок. Ею можно таранить, а ЛКМ бросает её. */
    static void boulder(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d ground = groundAhead(player, 2.8);
        int tint = groundColor(world, ground);
        Abilities.soundAt(world, ground, Sounds.EARTH_RISE, 1.0F);
        SpellEntity.spawn(world, SpellKind.GROUND_RING, ground, 1.15F, 34).tint(tint);
        SpellEntity.spawn(world, SpellKind.DUST_PUFF, ground, 1.0F, 18).tint(tint);
        float size = big(level) * 1.05F;
        Set<UUID> struck = new HashSet<>();
        boolean[] flying = {false};
        int rise = 13;
        SpellKind kind = tint == DIRT ? SpellKind.EARTH_CHUNK : SpellKind.BOULDER;
        SpellEntity rock = SpellEntity.spawn(world, kind, ground.add(0, -1.1, 0), size, 340).tint(tint).charged(Element.EARTH, player);
        rock.logic(self -> {
            if (!player.isAlive() || player.isRemoved()) {
                self.discard();
                return;
            }
            if (!flying[0]) {
                if (!Control.holding(player, self)) {
                    self.discard();
                    return;
                }
                Vec3d aim = Control.spot(player).add(0, -0.4, 0);
                if (self.age < rise) {
                    float eased = 1 - (1 - self.age / (float) rise) * (1 - self.age / (float) rise);
                    aim = ground.add(0, -1.1, 0).lerp(aim, eased);
                }
                hover(self, aim);
                if (self.age % 16 == 0) {
                    struck.clear();
                }
                for (LivingEntity near : Abilities.livingAt(player, self.getPos(), 1.1 * size + 0.4)) {
                    if (struck.add(near.getUuid())) {
                        Abilities.hurt(player, near, 3 + level);
                        Abilities.push(near, self.getVelocity().multiply(0.8).add(0, 0.35, 0));
                    }
                }
                return;
            }
            self.setVelocity(self.getVelocity().add(0, -0.008, 0));
            boolean ended = fly(self, player, 0.9 * size, true, struck, (at, target) -> {
                Abilities.pierce(player, target, 7 + level * 2);
                Abilities.push(target, self.getVelocity().normalize().multiply(1.3).add(0, 0.4, 0));
                return true;
            });
            if (ended || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.ROCK_BURST, self.getPos(), size * 1.25F, 18).tint(tint);
                SpellEntity.spawn(world, SpellKind.DUST_PUFF, self.getPos(), size * 1.3F, 18).tint(tint);
                Abilities.soundAt(world, self.getPos(), Sounds.EARTH_HIT, 1.0F);
                Nature.crush(world, player, self.getPos(), 2.2);
                Flourish.blast(world, self.getPos(), size * 3, 0xB89A6A);
                if (self.infused() == Element.FIRE) {
                    Nature.burn(world, player, self.getPos(), 2.0);
                    Combos.magmaPool(player, self.getPos(), 7 + level);
                }
                for (LivingEntity near : Abilities.monstersAt(player, self.getPos(), 2.4)) {
                    if (struck.add(near.getUuid())) {
                        Abilities.hurt(player, near, 3 + level);
                    }
                }
                self.discard();
            }
        });
        Control.hold(player, 0, rock, 4.5, () -> {
            flying[0] = true;
            struck.clear();
            Abilities.sound(player, Sounds.EARTH_THROW, 1.0F);
            // Глыба висит ниже прицела, поэтому летит не вдоль взгляда, а прямо в точку прицела.
            rock.setVelocity(crosshair(player, 40).subtract(rock.getPos()).normalize().multiply(1.25));
            rock.setLife(rock.age + 70);
        });
    }

    static void quake(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.EARTH_QUAKE, 1.0F);
        Vec3d feet = player.getPos();
        double ground = groundAt(world, feet.add(0, 0.5, 0));
        Vec3d center = Double.isNaN(ground) ? feet : new Vec3d(feet.x, ground, feet.z);
        int tint = groundColor(world, center);
        Set<UUID> struck = new HashSet<>();
        int rings = Math.min(5, 2 + level / 2);
        for (int ring = 0; ring < rings; ring++) {
            double radius = 2.0 + ring * 2.0;
            int count = 8 + ring * 6;
            Effects.later(world, ring * 3, () -> {
                ring(world, SpellKind.GROUND_SLAB, center, radius, count, 30, 1.0F + (float) radius * 0.06F, tint);
                SpellEntity.spawn(world, SpellKind.DUST_PUFF, center, (float) radius * 0.7F, 18).tint(tint);
                Abilities.soundAt(world, center, Sounds.EARTH_HIT, 0.7F);
                // Удар приходит вместе с волной, а не в миг нажатия.
                for (LivingEntity target : Abilities.monstersAt(player, center, radius + 1)) {
                    if (struck.add(target.getUuid())) {
                        Abilities.hurt(player, target, 6 + level * 1.5F);
                        Vec3d away = target.getPos().subtract(center).normalize().multiply(0.9);
                        Abilities.push(target, away.add(0, 0.8, 0));
                    }
                }
            });
        }
    }

    static void stoneArmor(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.EARTH_ARMOR, 1.0F);
        Abilities.buff(player, StatusEffects.RESISTANCE, 300, level >= 4 ? 2 : 1);
        Abilities.buff(player, StatusEffects.ABSORPTION, 300, level >= 4 ? 2 : 1);
        int tint = groundColor(world, player.getPos());
        SpellEntity.spawn(world, SpellKind.STONE_PLATES, player.getPos(), 1.0F, 300).owner(player).tint(tint).logic(self -> {
            self.setPosition(player.getPos());
            if (!player.isAlive()) {
                self.discard();
            }
        });
    }

    /** Шипы расходятся от игрока веером из трёх рядов. */
    static void spikes(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d forward = flatLook(player);
        Vec3d across = new Vec3d(-forward.z, 0, forward.x);
        Vec3d start = player.getPos();
        Set<UUID> struck = new HashSet<>();
        Effects.repeat(world, 7 + level, 2, step -> {
            for (int row = -1; row <= 1; row++) {
                Vec3d at = start.add(forward.multiply(2 + step * 1.25)).add(across.multiply(row * step * 0.32));
                double ground = groundAt(world, at);
                if (Double.isNaN(ground)) {
                    continue;
                }
                Vec3d point = new Vec3d(at.x, ground, at.z);
                int tint = groundColor(world, point);
                SpellEntity.spawn(world, SpellKind.STONE_SPIKE, point, (row == 0 ? 1.15F : 0.9F) + world.random.nextFloat() * 0.3F, 34).tint(tint);
                for (LivingEntity target : Abilities.livingAt(player, point.add(0, 0.8, 0), 1.7)) {
                    if (struck.add(target.getUuid())) {
                        Abilities.hurt(player, target, 7 + level * 2);
                        Abilities.push(target, new Vec3d(0, 0.9, 0));
                    }
                }
            }
            Abilities.soundAt(world, start.add(forward.multiply(2 + step * 1.25)), Sounds.EARTH_SPIKE, 1.0F);
            return true;
        });
    }

    /** Стена: видимые столбы поднимаются из земли, а внутри них появляются настоящие блоки. */
    static void wall(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.EARTH_WALL, 1.0F);
        Direction facing = player.getHorizontalFacing();
        Direction across = facing.rotateYClockwise();
        BlockPos center = player.getBlockPos().offset(facing, 3);
        int half = 2 + (level >= 5 ? 1 : 0);
        BlockState stone = Blocks.MOSSY_COBBLESTONE.getDefaultState();
        for (int s = -half; s <= half; s++) {
            BlockPos column = center.offset(across, s);
            int delay = Math.abs(s) * 2;
            Vec3d base = Vec3d.ofBottomCenter(column);
            int tint = groundColor(world, base);
            Effects.later(world, delay, () -> SpellEntity.spawn(world, SpellKind.STONE_WALL, base, 1.0F, 214).tint(tint));
            for (int y = 0; y < 4; y++) {
                Effects.temporaryBlock(world, column.up(y), stone, delay + 8 + y, 200);
            }
        }
    }

    // ------------------------------------------------------------------ воздух

    /** Вихрь: сжатый воздух висит перед игроком и затягивает врагов. Их можно носить, а ЛКМ швыряет всё вперёд. */
    static void windOrb(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_GUST, 1.4F);
        float scale = big(level);
        SpellEntity orb = SpellEntity.spawn(world, SpellKind.WIND_ORB, muzzle(player, 3.0), 1.1F * scale, 340).charged(Element.AIR, player);
        Set<LivingEntity> carried = new HashSet<>();
        Set<UUID> struck = new HashSet<>();
        boolean[] flying = {false};
        orb.logic(self -> {
            if (!player.isAlive() || player.isRemoved()) {
                self.discard();
                return;
            }
            if (!flying[0]) {
                if (!Control.holding(player, self)) {
                    self.discard();
                    return;
                }
                hover(self, Control.spot(player));
                if (self.age % 16 == 0) {
                    Abilities.soundAt(world, self.getPos(), Sounds.AIR_SAW, 0.7F);
                }
                carried.addAll(Abilities.livingAt(player, self.getPos(), 2.6 * scale));
                carried.removeIf(near -> !near.isAlive());
                for (LivingEntity near : carried) {
                    Vec3d to = self.getPos().subtract(near.getBoundingBox().getCenter());
                    Abilities.push(near, to.multiply(0.35).add(0, 0.08, 0));
                    near.fallDistance = 0;
                    if (self.age % 20 == 0) {
                        Abilities.hurt(player, near, 1 + level * 0.5F);
                    }
                }
                return;
            }
            boolean ended = fly(self, player, 1.2, true, struck, (at, target) -> {
                Abilities.pierce(player, target, 6 + level * 1.5F);
                Abilities.push(target, self.getVelocity().multiply(1.2).add(0, 0.5, 0));
                return false;
            });
            if (ended || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.WIND_BURST, self.getPos(), 3.0F, 14);
                Flourish.blast(world, self.getPos(), 3.6F * scale, 0xE4F0F6);
                Abilities.soundAt(world, self.getPos(), Sounds.AIR_GUST, 0.8F);
                for (LivingEntity near : Abilities.livingAt(player, self.getPos(), 3.5)) {
                    Vec3d away = near.getPos().subtract(self.getPos()).normalize();
                    Abilities.push(near, away.multiply(1.2).add(0, 0.5, 0));
                }
                self.discard();
            }
        });
        Control.hold(player, 0, orb, 5.0, () -> {
            flying[0] = true;
            Abilities.sound(player, Sounds.AIR_DASH, 1.2F);
            Vec3d out = crosshair(player, 40).subtract(orb.getPos()).normalize().multiply(1.3);
            orb.setVelocity(out);
            orb.setLife(orb.age + 40);
            for (LivingEntity near : carried) {
                struck.add(near.getUuid());
                Abilities.pierce(player, near, 6 + level * 1.5F);
                Abilities.push(near, out.multiply(1.7).add(0, 0.35, 0));
            }
        });
    }

    /** Рывок: игрок вихрем пролетает вперёд и бьёт всех, кого задел. Пока он летит, направление можно менять взглядом. */
    static void dash(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_DASH, 1.0F);
        double speed = 1.75 + level * 0.1;
        Vec3d first = player.getRotationVector().multiply(speed).add(0, 0.08, 0);
        SpellEntity.spawn(world, SpellKind.WIND_BURST, player.getPos().add(0, 0.9, 0), 2.2F, 14);
        SpellEntity tunnel = SpellEntity.spawn(world, SpellKind.WIND_TUNNEL, player.getPos(), 1.0F, 12).owner(player).facing(first);
        tunnel.logic(self -> self.setPosition(player.getPos()));
        Set<UUID> struck = new HashSet<>();
        Effects.repeat(world, 10, 1, step -> {
            if (!player.isAlive()) {
                return false;
            }
            Vec3d velocity = player.getRotationVector().multiply(speed).add(0, 0.08, 0);
            Abilities.push(player, velocity);
            player.fallDistance = 0;
            Nature.blow(world, player, player.getPos().add(0, 1, 0), 2.5, velocity.multiply(0.3));
            for (LivingEntity target : Abilities.livingAt(player, player.getPos().add(0, 1, 0), 2.1)) {
                if (struck.add(target.getUuid())) {
                    Abilities.hurt(player, target, 5 + level * 1.5F);
                    Vec3d aside = target.getPos().subtract(player.getPos()).normalize().multiply(0.7);
                    Abilities.push(target, velocity.multiply(0.45).add(aside).add(0, 0.45, 0));
                }
            }
            return true;
        });
    }

    /** Воздушная пила: диск вращается перед игроком и режет всё, куда его подвели. ЛКМ бросает его, и он возвращается. */
    static void airSaw(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        float damage = 5 + level * 1.5F;
        int turn = 18;
        Set<UUID> outward = new HashSet<>();
        Set<UUID> back = new HashSet<>();
        int[] thrownAt = {-1};
        Vec3d[] out = {player.getRotationVector()};
        SpellEntity saw = SpellEntity.spawn(world, SpellKind.WIND_SAW, muzzle(player, 2.0), 1.5F * big(level), 340).facing(out[0]).charged(Element.AIR, player);
        saw.logic(self -> {
            if (self.age % 10 == 0) {
                Abilities.soundAt(world, self.getPos(), Sounds.AIR_SAW, 1.0F);
            }
            if (thrownAt[0] < 0) {
                if (!Control.holding(player, self)) {
                    self.discard();
                    return;
                }
                self.setVelocity(Control.spot(player).subtract(self.getPos()).multiply(0.5));
                if (self.age % 10 == 0) {
                    outward.clear();
                }
                fly(self, player, 1.3, false, outward, (at, target) -> {
                    Abilities.hurt(player, target, damage * 0.4F);
                    return false;
                });
                return;
            }
            int flown = self.age - thrownAt[0];
            boolean returning = flown > turn;
            if (returning) {
                Vec3d home = player.getEyePos().subtract(self.getPos());
                if (home.length() < 1.6 || !player.isAlive()) {
                    self.discard();
                    return;
                }
                self.setVelocity(self.getVelocity().lerp(home.normalize().multiply(1.4), 0.3));
            } else {
                self.setVelocity(out[0].multiply(1 - 0.75 * flown / turn));
            }
            boolean ended = fly(self, player, 1.3, !returning, returning ? back : outward, (at, target) -> {
                Abilities.pierce(player, target, damage);
                return false;
            });
            if (ended || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.WIND_BURST, self.getPos(), 1.4F, 14);
                self.discard();
            }
        });
        Control.hold(player, 1, saw, 3.5, () -> {
            thrownAt[0] = saw.age;
            outward.clear();
            Abilities.sound(player, Sounds.AIR_DASH, 1.3F);
            out[0] = crosshair(player, 30).subtract(saw.getPos()).normalize().multiply(1.25);
            saw.facing(out[0]);
            saw.setLife(saw.age + 80);
        });
    }

    /** Смерч: идёт за взглядом игрока, затягивает монстров и крутит их в воздухе. ЛКМ отпускает его вперёд. */
    static void tornado(ServerPlayerEntity player, int level) {
        Vec3d start = groundAhead(player, 3.0);
        SpellEntity storm = SpellEntity.spawn(player.getServerWorld(), SpellKind.TORNADO, start, big(level) * 1.1F, 240).charged(Element.AIR, player);
        Vec3d[] drift = {flatLook(player).multiply(0.2)};
        driveTornado(storm, player, () -> {
            if (Control.holding(player, storm)) {
                Vec3d goal = Skills.aimGround(player, 28);
                Vec3d to = new Vec3d(goal.x - storm.getX(), 0, goal.z - storm.getZ());
                drift[0] = to.lengthSquared() < 0.2 ? Vec3d.ZERO : to.normalize().multiply(Math.min(0.4, to.length() * 0.12));
            }
            return drift[0];
        }, level);
        Control.hold(player, 3, storm, 10, () -> {
            drift[0] = flatLook(player).multiply(0.32);
            storm.setLife(storm.age + 80);
        });
    }

    /** Смерч идёт по земле и крутит монстров. Зажжённый комбо жжёт их, а с камнями бьёт и ослепляет. */
    static void driveTornado(SpellEntity storm, ServerPlayerEntity player, Supplier<Vec3d> step, int level) {
        ServerWorld world = player.getServerWorld();
        storm.setVelocity(step.get());
        storm.logic(self -> {
            Vec3d at = self.getPos();
            double ground = groundAt(world, at.add(0, 1.5, 0));
            double dy = Double.isNaN(ground) ? 0 : MathHelper.clamp(ground - at.y, -0.4, 0.4);
            self.setVelocity(step.get().add(0, dy, 0));
            self.setPosition(at.add(self.getVelocity()));
            if (self.age % 30 == 0) {
                Abilities.soundAt(world, at, Sounds.AIR_TORNADO, 1.0F);
            }
            Element infused = self.infused();
            for (LivingEntity target : Abilities.monstersAt(player, at.add(0, 2, 0), 6)) {
                Vec3d toCore = at.subtract(target.getPos());
                Vec3d flat = new Vec3d(toCore.x, 0, toCore.z);
                double distance = Math.max(0.5, flat.length());
                Vec3d around = new Vec3d(-flat.z, 0, flat.x).normalize().multiply(0.34);
                Abilities.push(target, flat.normalize().multiply(0.3).add(around).add(0, distance < 2.5 ? 0.36 : 0.08, 0));
                if (self.age % 10 == 0 && distance < 3) {
                    float damage = 2 + level * 0.8F;
                    if (infused == null) {
                        Abilities.hurt(player, target, damage);
                    } else {
                        Abilities.strike(player, target, damage * 2);
                        if (infused == Element.FIRE) {
                            target.setOnFireFor(5);
                        } else {
                            Abilities.debuff(target, StatusEffects.BLINDNESS, 60, 0);
                        }
                    }
                }
            }
        });
    }

    static void dome(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_DOME, 1.0F);
        double radius = 2.8 + level * 0.3;
        SpellEntity.spawn(world, SpellKind.WIND_DOME, player.getPos(), (float) radius, 160).owner(player).charged(Element.AIR, player).logic(self -> {
            self.setPosition(player.getPos());
            if (!player.isAlive()) {
                self.discard();
                return;
            }
            Vec3d center = player.getPos().add(0, 1, 0);
            for (LivingEntity target : Abilities.monstersAt(player, center, radius)) {
                Abilities.push(target, target.getPos().subtract(player.getPos()).normalize().multiply(0.8).add(0, 0.2, 0));
            }
            if (self.age % 10 == 0) {
                Nature.blow(world, player, center, radius, Vec3d.ZERO);
            }
            Box area = new Box(center, center).expand(radius);
            for (ProjectileEntity shot : world.getEntitiesByClass(ProjectileEntity.class, area, shot -> shot.getOwner() != player)) {
                Abilities.push(shot, shot.getVelocity().multiply(-0.6));
            }
        });
    }

    // ------------------------------------------------------------------ общее

    /** Двигает снаряд на шаг. Вернёт true, если он упёрся в блок или обработчик попадания закончил полёт. */
    static boolean fly(SpellEntity self, ServerPlayerEntity owner, double radius, boolean solid, Set<UUID> struck, Hit hit) {
        ServerWorld world = (ServerWorld) self.getWorld();
        Vec3d from = self.getPos();
        Vec3d next = from.add(self.getVelocity());
        BlockHitResult block = world.raycast(new RaycastContext(from, next,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, self));
        boolean blocked = solid && block.getType() != HitResult.Type.MISS;
        Vec3d end = blocked ? block.getPos() : next;

        Box sweep = new Box(from, end).expand(radius);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, sweep, entity -> Abilities.canHit(entity, owner))) {
            if (struck.add(target.getUuid()) && hit.at(target.getBoundingBox().getCenter(), target)) {
                self.setPosition(end);
                return true;
            }
        }
        self.setPosition(end);
        return blocked;
    }

    /** Круг из отдельных моделей: каждая стоит на своей земле и смотрит наружу. */
    static void ring(ServerWorld world, SpellKind kind, Vec3d center, double radius, int count, int life, float size, int tint) {
        double start = world.random.nextDouble() * Math.PI * 2;
        for (int i = 0; i < count; i++) {
            double angle = start + Math.PI * 2 * (i + world.random.nextDouble() * 0.5) / count;
            Vec3d out = new Vec3d(Math.cos(angle), 0, Math.sin(angle));
            Vec3d at = center.add(out.multiply(radius));
            double ground = groundAt(world, at.add(0, 1, 0));
            if (!Double.isNaN(ground)) {
                float scale = size * (0.8F + world.random.nextFloat() * 0.45F);
                SpellEntity.spawn(world, kind, new Vec3d(at.x, ground, at.z), scale, life).facing(out).tint(tint);
            }
        }
    }

    /** Подтягивает модель к точке, сообщая клиенту скорость, чтобы движение было плавным. */
    static void hover(SpellEntity self, Vec3d point) {
        Vec3d step = point.subtract(self.getPos()).multiply(0.5);
        self.setVelocity(step);
        self.setPosition(self.getPos().add(step));
    }

    /** Точка перед глазами игрока: модель у самых глаз закрыла бы весь экран. */
    static Vec3d muzzle(ServerPlayerEntity player, double distance) {
        return player.getEyePos().add(player.getRotationVector().multiply(distance));
    }

    static Vec3d flatLook(ServerPlayerEntity player) {
        Vec3d look = player.getRotationVector();
        Vec3d flat = new Vec3d(look.x, 0, look.z);
        return flat.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : flat.normalize();
    }

    /** Куда направлен прицел: первый враг на линии взгляда или блок, с небольшим отступом от него. */
    static Vec3d crosshair(ServerPlayerEntity player, double range) {
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVector();
        HitResult block = player.raycast(range, 1.0F, false);
        double reach = block.getType() == HitResult.Type.MISS ? range : block.getPos().distanceTo(eye) - 0.9;
        LivingEntity target = Abilities.aim(player, Math.max(1, reach));
        return target != null ? target.getBoundingBox().getCenter() : eye.add(look.multiply(Math.max(1, reach)));
    }

    private static Vec3d nearestWater(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        for (BlockPos pos : BlockPos.iterateOutwards(player.getBlockPos(), 8, 4, 8)) {
            if (world.getFluidState(pos).isIn(FluidTags.WATER)) {
                return Vec3d.ofCenter(pos);
            }
        }
        return null;
    }

    static Vec3d groundAhead(ServerPlayerEntity player, double distance) {
        Vec3d at = player.getPos().add(flatLook(player).multiply(distance));
        double ground = groundAt(player.getServerWorld(), at.add(0, 1, 0));
        return Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
    }

    static double groundAt(ServerWorld world, Vec3d at) {
        BlockPos.Mutable pos = BlockPos.ofFloored(at).mutableCopy().move(Direction.UP, 2);
        for (int i = 0; i < 8; i++) {
            pos.move(Direction.DOWN);
            if (world.getBlockState(pos).isSolidBlock(world, pos)) {
                return pos.getY() + 1.0;
            }
        }
        return Double.NaN;
    }

    /** Цвет грунта под точкой: глыба с песка песчаная, с камня серая, с травы становится куском дёрна. */
    static int groundColor(ServerWorld world, Vec3d at) {
        BlockPos pos = BlockPos.ofFloored(at).down();
        BlockState state = world.getBlockState(pos);
        int color = state.getMapColor(world, pos).color;
        return state.isAir() || state.isIn(BlockTags.DIRT) || color == 0 ? DIRT : color;
    }
}
