package local.minevia.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;

/** Общая физика стилей, без изменения блоков. */
final class StyleSupport {
    private StyleSupport() { }

    static boolean valid(ServerPlayerEntity p, Element element, long stamp) {
        if (!p.isAlive() || p.isRemoved() || p.getServer() == null) return false;
        ElementState.Data d = ElementState.get(p.getServer()).find(p.getUuid());
        return d != null && d.element == element && d.changedAt == stamp && StyleGear.equipped(p, element);
    }

    static SpellEntity model(ServerPlayerEntity p, SpellKind kind, Vec3d at, float size, int life, SpellEntity.Logic logic) {
        ElementState.Data d = ElementState.get(p.getServer()).getOrAssign(p.getUuid());
        Element element = d.element;
        long stamp = d.changedAt;
        var world = p.getServerWorld();
        return SpellEntity.spawn(world, kind, at, size, life).charged(element, p).logic(self -> {
            if (p.getWorld() != world || !valid(p, element, stamp)) { self.discard(); return; }
            if (logic != null) logic.tick(self);
        });
    }

    static void hit(ServerPlayerEntity p, LivingEntity target, float damage) {
        if (Abilities.canHit(target, p) && p.canSee(target)) Abilities.pierce(p, target, damage);
    }

    static void area(ServerPlayerEntity p, Vec3d at, double radius, float damage, Consumer<LivingEntity> effect) {
        for (LivingEntity e : Abilities.livingAt(p, at, radius)) {
            if (e.getBoundingBox().getCenter().distanceTo(at) > radius + e.getWidth() || !p.canSee(e)) continue;
            if (damage > 0) hit(p, e, damage);
            if (effect != null && e.isAlive()) effect.accept(e);
        }
    }

    static void shot(ServerPlayerEntity p, SpellKind kind, Vec3d at, Vec3d velocity, float size, int life,
            boolean pierces, BiConsumer<SpellEntity, LivingEntity> impact, Consumer<Vec3d> end) {
        Set<UUID> struck = new HashSet<>();
        SpellEntity shot = model(p, kind, at, size, life, self -> {
            boolean done = Spells.fly(self, p, 0.35 * size + 0.15, true, struck, (point, target) -> {
                impact.accept(self, target);
                return !pierces;
            });
            if (done || self.age >= self.life() - 1) {
                if (end != null) end.accept(self.getPos());
                self.discard();
            }
        }).facing(velocity);
        shot.setVelocity(velocity);
    }

    static void held(ServerPlayerEntity p, int slot, SpellKind kind, int level, SoundEvent sound,
            boolean pierces, BiConsumer<SpellEntity, LivingEntity> impact, Consumer<Vec3d> end) {
        boolean[] released = {false};
        Set<UUID> struck = new HashSet<>();
        SpellEntity shot = model(p, kind, Spells.muzzle(p, 2.5), 0.8F, 340, self -> {
            if (!released[0]) {
                if (!Control.holding(p, self)) { self.discard(); return; }
                Spells.hover(self, Control.spot(p));
                self.facing(p.getRotationVector());
                self.setSize(0.7F + Math.min(0.55F, self.age / 70F));
                return;
            }
            boolean done = Spells.fly(self, p, 0.4, true, struck, (at, target) -> {
                impact.accept(self, target);
                return !pierces;
            });
            if (done || self.age >= self.life() - 1) {
                if (end != null) end.accept(self.getPos());
                self.discard();
            }
        });
        Control.hold(p, slot, shot, 3, () -> {
            released[0] = true;
            shot.setVelocity(Spells.crosshair(p, 80).subtract(shot.getPos()).normalize().multiply(2.5 + level * 0.12));
            shot.setLife(shot.age + 60);
            Abilities.sound(p, sound, 1);
        });
    }

    static SpellEntity field(ServerPlayerEntity p, SpellKind kind, Vec3d at, float size, int life,
            int interval, Consumer<SpellEntity> pulse) {
        return model(p, kind, at, size, life, self -> {
            if (self.age % interval == 0) pulse.accept(self);
        });
    }

    static void follow(ServerPlayerEntity p, SpellKind kind, int life, Consumer<SpellEntity> pulse) {
        model(p, kind, p.getPos(), 1, life, self -> {
            self.setPosition(p.getPos());
            self.facing(Spells.flatLook(p));
            if (pulse != null) pulse.accept(self);
        });
    }

    static void fall(ServerPlayerEntity p, SpellKind kind, Vec3d target, float size, int delay, Consumer<Vec3d> impact) {
        Vec3d velocity = new Vec3d(0, -1.2, 0);
        model(p, kind, target.add(0, delay * 1.2, 0), size, delay + 15, self -> {
            if (self.age <= delay) {
                self.setVelocity(velocity);
                self.setPosition(self.getPos().add(velocity));
            }
            if (self.age == delay) { self.setPosition(target); self.setVelocity(Vec3d.ZERO); impact.accept(target); }
        }).facing(velocity);
    }

    static void dash(ServerPlayerEntity p, SpellKind kind, int ticks, double speed, float damage) {
        Vec3d direction = Spells.flatLook(p);
        Set<UUID> struck = new HashSet<>();
        model(p, kind, p.getPos(), 1, ticks, self -> {
            Abilities.push(p, direction.multiply(speed).add(0, 0.08, 0));
            p.fallDistance = 0;
            self.setPosition(p.getPos());
            self.facing(direction);
            for (LivingEntity e : Abilities.livingAt(p, p.getPos().add(0, 1, 0), 2)) {
                if (damage > 0 && struck.add(e.getUuid())) hit(p, e, damage);
            }
        });
    }

    static LivingEntity ally(ServerPlayerEntity p, double reach) {
        return p.getServerWorld().getEntitiesByClass(PlayerEntity.class, p.getBoundingBox().expand(reach),
                e -> e != p && e.isAlive() && !e.isSpectator() && p.canSee(e)
                        && e.getEyePos().subtract(p.getEyePos()).normalize().dotProduct(p.getRotationVector()) > 0.97)
                .stream().min(java.util.Comparator.comparingDouble(p::squaredDistanceTo)).orElse(p);
    }

    static void cleanse(LivingEntity ally) {
        for (var effect : java.util.List.copyOf(ally.getStatusEffects())) {
            if (!effect.getEffectType().value().isBeneficial()) ally.removeStatusEffect(effect.getEffectType());
        }
        ally.extinguish();
    }

    static void root(LivingEntity e, int ticks) {
        Abilities.debuff(e, StatusEffects.SLOWNESS, ticks, 5);
        Abilities.push(e, new Vec3d(0, Math.min(0, e.getVelocity().y), 0));
    }
}
