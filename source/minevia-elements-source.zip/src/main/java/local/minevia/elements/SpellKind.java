package local.minevia.elements;

/** Какую 3D-модель показывает сущность способности. */
public enum SpellKind {
    FIREBALL, FIRE_BURST, FLAME_RING, FLAME_AURA, FLAME_JET,
    WATER_BLOB, WATER_SPLASH, WATER_WHIP, HEAL_SPIRAL, WATER_WAVE, ICE_SHARD,
    BOULDER, EARTH_CHUNK, ROCK_BURST, DUST_PUFF, GROUND_RING, GROUND_SLAB, STONE_SPIKE, STONE_PLATES, STONE_WALL,
    WIND_SAW, WIND_BURST, WIND_TUNNEL, TORNADO, WIND_DOME,
    // комбо
    ELEMENT_MARK, FIRE_TORNADO, ROCK_TORNADO, STEAM_CLOUD, MAGMA_BOULDER, MAGMA_POOL, MUD_POOL,
    // вторая ступень
    ICE_BOLT, MIST, LIGHTNING, MAGMA_GEYSER, SAND_PIT, METAL_BLADE, STORM_CLOUD, VACUUM,
    // храмы
    DANGER_RING,
    // управляемые и супер-навыки
    WIND_ORB, ORB, METEOR, WATER_GEYSER, WATER_GUARDIAN, ROCK_FIST, GREAT_TORNADO, RAIN;

    private static final SpellKind[] ALL = values();

    public static SpellKind of(int id) {
        return ALL[Math.floorMod(id, ALL.length)];
    }
}
