package local.minevia.elements.mixin;

import local.minevia.elements.client.GestureClient;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Движения навыков ложатся поверх обычной анимации игрока. */
@Mixin(PlayerEntityModel.class)
abstract class PlayerEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("HEAD"))
    private void minevia$straighten(LivingEntity entity, float limbAngle, float limbDistance, float animationProgress,
            float headYaw, float headPitch, CallbackInfo info) {
        GestureClient.straighten((PlayerEntityModel<?>) (Object) this);
    }

    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void minevia$gesture(LivingEntity entity, float limbAngle, float limbDistance, float animationProgress,
            float headYaw, float headPitch, CallbackInfo info) {
        GestureClient.pose((PlayerEntityModel<?>) (Object) this, entity, animationProgress, limbDistance);
    }
}
