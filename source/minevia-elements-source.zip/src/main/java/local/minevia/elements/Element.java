package local.minevia.elements;

public enum Element {
    FIRE(0xFF8A3D),
    WATER(0x5CC8FF),
    EARTH(0xA8D468),
    AIR(0xE4F0F6),
    SWORD(0xAABED4),
    BOW(0x7ABF91),
    DARK(0x9362D4),
    LIGHT(0xE8B84D);

    public static Element[] natural() {
        return new Element[] {FIRE, WATER, EARTH, AIR};
    }

    public boolean isNatural() {
        return ordinal() < 4;
    }

    public final int color;

    Element(int color) {
        this.color = color;
    }

    public String id() {
        return name().toLowerCase(java.util.Locale.ROOT);
    }

    public String key() {
        return "element.minevia_elements." + id();
    }

    public String abilityKey(int slot) {
        return key() + ".ability" + (slot + 1);
    }

    /** Название пути второй ступени: 1 или 2. */
    public String pathTitleKey(int path) {
        return pathKey(path) + (isNatural() ? "" : ".title");
    }

    public String pathKey(int path) {
        return key() + ".path" + path;
    }
}
