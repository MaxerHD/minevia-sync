package local.minevia.elements;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Супер-навыки воды и земли: «Цунами» и «Каменный титан». Блоков в мире они не трогают. */
final class Ultimates {
    private static final Identifier TITAN_SCALE = Identifier.of(MineviaElements.MOD_ID, "titan_scale");
    private static final Identifier TITAN_WEIGHT = Identifier.of(MineviaElements.MOD_ID, "titan_weight");
    private static final int TITAN_TICKS = 300;
    /** Кто сейчас титан: по этой таблице размер возвращается, как бы ни кончилась способность. */
    private static final Map<UUID, SpellEntity> TITANS = new HashMap<>();

    private Ultimates() {
    }

    // ------------------------------------------------------------------ вода

    /**
     * Цунами: за спиной встаёт огромная волна, игрок стоит на её гребне и ведёт её взглядом.
     * Задетых врагов волна несёт с собой без урона, а по ЛКМ или по времени рушится вперёд и бьёт их об землю.
     */
    static void tsunami(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        float size = 1.0F + 0.05F * level;
        double crest = 5.9 * size;
        double half = 6.2 * size;
        int ride = 120 + level * 12;
        Vec3d[] forward = {Spells.flatLook(player)};
        Vec3d feet = player.getPos();
        double ground = Spells.groundAt(world, feet.add(0, 1, 0));
        Vec3d start = Double.isNaN(ground) ? feet : new Vec3d(feet.x, ground, feet.z);
        SpellEntity wave = SpellEntity.spawn(world, SpellKind.TSUNAMI, start, size, ride + 60).facing(forward[0]).charged(Element.WATER, player);
        Set<LivingEntity> carried = new HashSet<>();
        boolean[] done = {false};
        Abilities.soundAt(world, start, Sounds.TSUNAMI_RISE, 1.0F);
        SpellEntity.spawn(world, SpellKind.WATER_SPLASH, start, 3.0F * size, 16);
        wave.logic(self -> {
            if (done[0]) {
                return;
            }
            if (!player.isAlive() || player.isRemoved() || !Control.holding(player, self) || player.squaredDistanceTo(self) > 900) {
                self.discard();
                return;
            }
            // Волна поворачивает за взглядом плавно: такую массу воды рывком не развернуть.
            Vec3d turned = forward[0].add(Spells.flatLook(player).subtract(forward[0]).multiply(0.12));
            if (turned.lengthSquared() > 1.0E-4) {
                forward[0] = turned.normalize();
            }
            Vec3d way = forward[0];
            Vec3d across = new Vec3d(-way.z, 0, way.x);
            double risen = Math.min(1.0, self.age / 14.0);
            risen = 1 - (1 - risen) * (1 - risen);
            Vec3d at = self.getPos();
            Vec3d chest = at.add(0, 3.4 * size, 0);
            if (self.age > 14 && world.raycast(new RaycastContext(chest, chest.add(way.multiply(3.4 * size)), RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, self)).getType() != HitResult.Type.MISS) {
                Control.release(player);
                return;
            }
            Vec3d next = at.add(way.multiply(0.2 + 0.4 * risen));
            double floor = Spells.groundAt(world, next.add(0, 1, 0));
            if (!Double.isNaN(floor)) {
                next = new Vec3d(next.x, at.y + MathHelper.clamp(floor - at.y, -0.4, 0.4), next.z);
            }
            Vec3d step = next.subtract(at);
            self.setVelocity(step);
            self.setPosition(next);
            self.facing(way);

            // Игрок стоит на гребне: его подтягивает к месту, а падение не копится.
            Vec3d seat = next.add(way.multiply(-0.3 * size)).add(0, crest * risen + 0.1, 0);
            Vec3d pull = seat.subtract(player.getPos());
            if (pull.lengthSquared() > 2.25) {
                pull = pull.normalize().multiply(1.5);
            }
            Abilities.push(player, pull.multiply(0.7).add(step));
            player.fallDistance = 0;

            Vec3d face = next.add(way.multiply(2.2 * size)).add(0, 2.4 * size * risen, 0);
            if (self.age % 3 == 0) {
                for (LivingEntity near : Abilities.livingAt(player, face, half)) {
                    Vec3d offset = near.getPos().subtract(next);
                    if (Math.abs(offset.dotProduct(across)) > half || Math.abs(offset.dotProduct(way) - 2.0 * size) > 3.0 * size
                            || offset.y > crest || offset.y < -3) {
                        continue;
                    }
                    if (carried.add(near)) {
                        Abilities.soundAt(world, near.getPos(), Sounds.WATER_HIT, 0.8F);
                        near.extinguish();
                    }
                }
                carried.removeIf(caught -> !caught.isAlive() || caught.isRemoved());
                Nature.douse(world, player, next.add(way.multiply(2)).add(0, 0.6, 0), 3);
            }
            if (self.age % 34 == 20) {
                Abilities.soundAt(world, next, Sounds.WATER_WAVE, 0.7F);
            }
            for (LivingEntity caught : carried) {
                double side = MathHelper.clamp(caught.getPos().subtract(next).dotProduct(across), -half + 1, half - 1);
                Vec3d to = face.add(across.multiply(side)).subtract(caught.getPos());
                if (to.lengthSquared() > 4) {
                    to = to.normalize().multiply(2);
                }
                Abilities.push(caught, to.multiply(0.5).add(step));
                caught.fallDistance = 0;
            }
            if (self.age >= ride) {
                Control.release(player);
            }
        });
        Control.hold(player, Abilities.ULTIMATE_SLOT, wave, 3, () -> {
            done[0] = true;
            crash(player, world, wave, carried, forward[0], size, level);
        });
    }

    private static void crash(ServerPlayerEntity player, ServerWorld world, SpellEntity wave, Set<LivingEntity> carried, Vec3d way, float size, int level) {
        Vec3d at = wave.getPos();
        wave.discard();
        Vec3d reach = at.add(way.multiply(5.5 * size));
        double floor = Spells.groundAt(world, reach.add(0, 2, 0));
        Vec3d impact = Double.isNaN(floor) ? reach : new Vec3d(reach.x, floor, reach.z);
        SpellEntity.spawn(world, SpellKind.TSUNAMI_CRASH, at, size, 22).facing(way);
        Abilities.soundAt(world, impact, Sounds.TSUNAMI_CRASH, 1.0F);
        for (LivingEntity caught : carried) {
            if (caught.isAlive()) {
                Abilities.push(caught, new Vec3d(way.x * 1.0, -0.9, way.z * 1.0));
            }
        }
        // Игрока волна мягко ставит на землю: ни урона от падения, ни резкого рывка.
        Abilities.push(player, way.multiply(0.5).add(0, 0.3, 0));
        Abilities.buff(player, StatusEffects.SLOW_FALLING, 70, 0);
        Effects.repeat(world, 70, 1, tick -> {
            player.fallDistance = 0;
            return player.isAlive();
        });
        Effects.later(world, 6, () -> {
            SpellEntity.spawn(world, SpellKind.WATER_SPLASH, impact.add(0, 0.5, 0), 4.5F * size, 18);
            Flourish.blast(world, impact, 6 * size, Element.WATER.color);
            Nature.douse(world, player, impact.add(0, 1, 0), 6);
            Set<UUID> slammed = new HashSet<>();
            for (LivingEntity caught : carried) {
                if (caught.isAlive() && Abilities.canHit(caught, player)) {
                    slammed.add(caught.getUuid());
                    Abilities.pierce(player, caught, 20 + level * 3);
                    Abilities.debuff(caught, StatusEffects.SLOWNESS, 60, 2);
                }
            }
            for (LivingEntity near : Abilities.livingAt(player, impact.add(0, 1, 0), 6.5 * size)) {
                if (slammed.contains(near.getUuid())) {
                    continue;
                }
                Abilities.pierce(player, near, 12 + level * 2.5F);
                Vec3d away = near.getPos().subtract(impact);
                Vec3d flat = new Vec3d(away.x, 0, away.z);
                Abilities.push(near, (flat.lengthSquared() < 0.01 ? way : flat.normalize()).multiply(0.6).add(0, 0.55, 0));
                near.extinguish();
            }
        });
    }

    // ------------------------------------------------------------------ земля

    /**
     * Каменный титан: на пятнадцать секунд игрока покрывают плиты, он в полтора раза больше и почти не отлетает от ударов.
     * От шагов дрожит земля, ЛКМ пускает по земле гряду шипов, приземление после прыжка бьёт по кругу.
     */
    static void titan(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        SpellEntity old = TITANS.remove(player.getUuid());
        if (old != null) {
            old.discard();
        }
        clear(player);
        modify(player, EntityAttributes.GENERIC_SCALE, TITAN_SCALE, 0.5, EntityAttributeModifier.Operation.ADD_MULTIPLIED_BASE);
        modify(player, EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, TITAN_WEIGHT, 0.9, EntityAttributeModifier.Operation.ADD_VALUE);
        int tint = Spells.groundColor(world, player.getPos());
        SpellEntity armor = SpellEntity.spawn(world, SpellKind.TITAN_PLATES, player.getPos(), 1.5F, TITAN_TICKS).owner(player).tint(tint);
        armor.setYaw(player.getBodyYaw());
        TITANS.put(player.getUuid(), armor);
        Abilities.sound(player, Sounds.TITAN_FORM, 1.0F);
        SpellEntity.spawn(world, SpellKind.DUST_PUFF, player.getPos(), 2.4F, 18).tint(tint);
        Spells.ring(world, SpellKind.GROUND_SLAB, player.getPos(), 2.2, 8, 24, 1.0F, tint);

        double[] walked = {0};
        Vec3d[] last = {player.getPos()};
        int[] airborne = {0};
        long[] punched = {-100};
        Runnable punch = () -> punch(player, world, level, punched);
        armor.logic(self -> {
            if (!player.isAlive() || player.isRemoved() || player.getWorld() != world) {
                self.discard();
                return;
            }
            Vec3d at = player.getPos();
            self.setPosition(at);
            self.setYaw(player.getBodyYaw());
            player.fallDistance = 0;
            if (self.age >= TITAN_TICKS - 1) {
                SpellEntity fall = SpellEntity.spawn(world, SpellKind.TITAN_CRUMBLE, at, 1.5F, 18).tint(tint);
                fall.setYaw(player.getBodyYaw());
                SpellEntity.spawn(world, SpellKind.DUST_PUFF, at, 2.0F, 18).tint(tint);
                Abilities.soundAt(world, at, Sounds.EARTH_ARMOR, 0.7F);
                self.discard();
                return;
            }
            // Удар повторяется, пока титан жив: после каждого ЛКМ способность снова берётся в руки.
            if (!Control.active(player)) {
                Control.hold(player, Abilities.ULTIMATE_SLOT, self, 3, punch);
            }
            Vec3d moved = at.subtract(last[0]);
            last[0] = at;
            if (player.isOnGround()) {
                if (airborne[0] >= 7) {
                    int color = Spells.groundColor(world, at);
                    Spells.ring(world, SpellKind.GROUND_SLAB, at, 3.2, 10, 28, 1.2F, color);
                    SpellEntity.spawn(world, SpellKind.DUST_PUFF, at, 2.8F, 18).tint(color);
                    Abilities.soundAt(world, at, Sounds.EARTH_QUAKE, 1.1F);
                    Skills.blast(player, at.add(0, 1, 0), 5.5, 8 + level * 2, 0.75);
                    walked[0] = 0;
                }
                airborne[0] = 0;
                walked[0] += Math.min(1.0, Math.sqrt(moved.x * moved.x + moved.z * moved.z));
                if (walked[0] >= 3.0) {
                    walked[0] = 0;
                    Abilities.soundAt(world, at, Sounds.TITAN_STEP, 1.0F);
                    SpellEntity.spawn(world, SpellKind.DUST_PUFF, at, 1.5F, 14).tint(Spells.groundColor(world, at));
                    for (LivingEntity near : Abilities.livingAt(player, at.add(0, 1, 0), 3.5)) {
                        Abilities.pierce(player, near, 2 + level * 0.5F);
                        Vec3d away = near.getPos().subtract(at);
                        Vec3d flat = new Vec3d(away.x, 0, away.z);
                        Abilities.push(near, (flat.lengthSquared() < 0.01 ? Vec3d.ZERO : flat.normalize().multiply(0.45)).add(0, 0.25, 0));
                    }
                }
            } else {
                airborne[0]++;
            }
        });
        Control.hold(player, Abilities.ULTIMATE_SLOT, armor, 3, punch);
    }

    /** Удар кулаком в землю: гряда каменных шипов бежит туда, куда смотрит титан. */
    private static void punch(ServerPlayerEntity player, ServerWorld world, int level, long[] punched) {
        long now = world.getServer().getTicks();
        if (now - punched[0] < 14) {
            return;
        }
        punched[0] = now;
        Vec3d forward = Spells.flatLook(player);
        Vec3d start = player.getPos();
        Set<UUID> struck = new HashSet<>();
        Abilities.sound(player, Sounds.TITAN_STEP, 0.8F);
        Effects.repeat(world, 8 + level / 2, 1, step -> {
            Vec3d at = start.add(forward.multiply(2.2 + step * 1.5));
            double ground = Spells.groundAt(world, at.add(0, 2, 0));
            if (Double.isNaN(ground)) {
                return true;
            }
            Vec3d base = new Vec3d(at.x, ground, at.z);
            int tint = Spells.groundColor(world, base);
            SpellEntity.spawn(world, SpellKind.STONE_SPIKE, base, 1.6F + step * 0.05F, 36).tint(tint);
            if (step % 3 == 0) {
                SpellEntity.spawn(world, SpellKind.DUST_PUFF, base, 1.6F, 16).tint(tint);
            }
            if (step % 2 == 0) {
                Abilities.soundAt(world, base, Sounds.EARTH_SPIKE, 0.9F);
            }
            for (LivingEntity near : Abilities.livingAt(player, base.add(0, 1, 0), 2.4)) {
                if (struck.add(near.getUuid())) {
                    Abilities.pierce(player, near, 10 + level * 2);
                    Abilities.push(near, forward.multiply(0.35).add(0, 0.85, 0));
                }
            }
            return true;
        });
    }

    private static void modify(ServerPlayerEntity player, RegistryEntry<EntityAttribute> attribute, Identifier id, double value, EntityAttributeModifier.Operation operation) {
        EntityAttributeInstance instance = player.getAttributeInstance(attribute);
        if (instance != null) {
            instance.removeModifier(id);
            instance.addTemporaryModifier(new EntityAttributeModifier(id, value, operation));
        }
    }

    /** Возвращает игроку обычный размер и вес. Вызывается в конце способности, при входе в игру и после возрождения. */
    static void clear(ServerPlayerEntity player) {
        EntityAttributeInstance scale = player.getAttributeInstance(EntityAttributes.GENERIC_SCALE);
        if (scale != null) {
            scale.removeModifier(TITAN_SCALE);
        }
        EntityAttributeInstance weight = player.getAttributeInstance(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE);
        if (weight != null) {
            weight.removeModifier(TITAN_WEIGHT);
        }
    }

    /** Плиты могли пропасть как угодно: время вышло, игрок погиб или сменил стихию. Размер возвращается в любом случае. */
    static void tick(MinecraftServer server) {
        if (TITANS.isEmpty()) {
            return;
        }
        TITANS.entrySet().removeIf(entry -> {
            if (!entry.getValue().isRemoved()) {
                return false;
            }
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(entry.getKey());
            if (player != null) {
                clear(player);
            }
            return true;
        });
    }
}
