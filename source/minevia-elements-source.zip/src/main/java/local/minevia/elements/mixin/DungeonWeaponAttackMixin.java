package local.minevia.elements.mixin;

import local.minevia.elements.Weapons;
import net.minecraft.entity.Entity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.world.ServerWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Базовый удар сохраняет зачарования, особый эффект рисуется только нашей моделью. */
@Mixin(PlayerEntity.class)
abstract class DungeonWeaponAttackMixin {
    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void mineviaBegin(Entity target, CallbackInfo ci) {
        if (!Weapons.begin((PlayerEntity) (Object) this, target)) {
            ci.cancel();
        }
    }

    @Inject(method = "attack", at = @At("RETURN"))
    private void mineviaEnd(Entity target, CallbackInfo ci) {
        Weapons.end((PlayerEntity) (Object) this);
    }

    @Redirect(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z", ordinal = 0))
    private boolean mineviaDamage(Entity target, DamageSource source, float amount) {
        return target.damage(source, Weapons.damage((PlayerEntity) (Object) this, target, amount));
    }

    @Redirect(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;addCritParticles(Lnet/minecraft/entity/Entity;)V"))
    private void mineviaCritical(PlayerEntity player, Entity target) {
        if (!Weapons.isSpecial(player.getMainHandStack())) {
            player.addCritParticles(target);
        }
    }

    @Redirect(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;addEnchantedHitParticles(Lnet/minecraft/entity/Entity;)V"))
    private void mineviaEnchanted(PlayerEntity player, Entity target) {
        if (!Weapons.isSpecial(player.getMainHandStack())) {
            player.addEnchantedHitParticles(target);
        }
    }

    @Redirect(method = "attack", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/world/ServerWorld;spawnParticles(Lnet/minecraft/particle/ParticleEffect;DDDIDDDD)I"))
    private int mineviaDamageModel(ServerWorld world, ParticleEffect effect, double x, double y, double z, int count, double dx, double dy, double dz, double speed) {
        return Weapons.isSpecial(((PlayerEntity) (Object) this).getMainHandStack()) ? 0 : world.spawnParticles(effect, x, y, z, count, dx, dy, dz, speed);
    }
}
