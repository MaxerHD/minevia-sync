package local.minevia.elements.mixin;
import local.minevia.elements.StyleGear;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/** Личное оружие никогда не становится предметом на земле. */
@Mixin(PlayerEntity.class)
abstract class StyleGearDropMixin {
    @Inject(method = "dropItem(Lnet/minecraft/item/ItemStack;ZZ)Lnet/minecraft/entity/ItemEntity;", at = @At("HEAD"), cancellable = true)
    private void minevia$keep(ItemStack stack, boolean scatter, boolean retain, CallbackInfoReturnable<ItemEntity> ci) {
        if (StyleGear.isGear(stack)) ci.setReturnValue(null);
    }
}
