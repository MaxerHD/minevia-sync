package local.minevia.elements;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Движение персонажа при навыке. У каждого навыка оно своё и видно всем игрокам.
 * Запись "3 ra92 lean9 | 8 ra40": на третьем тике правая рука поднята на 92 градуса, корпус наклонён на 9,
 * к восьмому тику рука опускается до 40, а наклон сохраняется. Канал, которого нет ни в одном кадре, остаётся за обычной анимацией игры.
 * ra, la: рука вперёд; ro, lo: рука в сторону; rw, lw: рука поперёк груди; rl, ll: нога вперёд; lean: наклон; turn: правое плечо вперёд; head: кивок.
 * Навык срабатывает сразу, поэтому главный момент движения приходится на первые тики.
 * Длительность 0 значит, что снаряд держат в руках: поза стоит, пока его не выпустят.
 */
public enum Gesture {
    // Огонь
    FIREBALL(Aim.LOOK, 0, Wobble.TENSE, "4 ra74 ro14 rw-6 turn-6"),
    FIREBALL_THROW(Aim.LOOK, 13, "2 ra128 ro8 turn-20 lean-6 | 5 ra90 ro0 turn24 lean12"),
    FLAME_RING(Aim.FREE, 17, "3 ra70 rw34 la70 lw34 lean10 | 8 ra62 rw-74 la62 lw-74 lean-5"),
    FLAME_ARMOR(Aim.FREE, 19, "4 ra40 ro16 rw50 la40 lo16 lw50 lean8 head10 | 9 ra8 ro46 rw0 la8 lo46 lw0 lean-9 head-9"),
    GREAT_FIREBALL(Aim.FREE, 0, Wobble.TENSE, "7 ra142 ro20 la142 lo20 lean-9 head-8"),
    GREAT_FIREBALL_THROW(Aim.FREE, 15, "3 ra182 ro10 la182 lo10 lean-14 | 7 ra82 ro0 la82 lo0 lean22 rl14 ll-12"),
    FLAMETHROWER(Aim.LOOK, 24, 6, Wobble.SHAKE, "3 ra92 ro-4 la62 lo22 lw30 lean9 turn16 rl-12 ll16"),
    FIRE_STEP(Aim.FREE, 13, "2 ra-42 la-42 lean34 rl30 ll-40 | 8"),
    SPARK_SWARM(Aim.FREE, 15, "3 ra40 ro5 la40 lo5 lean6 | 7 ra122 ro40 la122 lo40 lean-6 head-10"),
    METEOR(Aim.FREE, 46, "10 ra170 ro18 la170 lo18 lean-12 head-28 | 30 | 34 ra18 ro6 la18 lo6 lean40 head14 rl-8 ll14"),
    CHAIN_LIGHTNING(Aim.LOOK, 15, "2 ra132 turn-20 | 5 ra90 turn22 lean10 | 7 ra97 | 9 ra90"),
    ERUPTION(Aim.FREE, 19, "3 ra-10 la-10 lean20 rl-16 ll20 | 8 ra124 ro12 la124 lo12 lean-10 head-14 rl0 ll0"),
    BALL_LIGHTNING(Aim.FREE, 15, "4 ra62 rw34 la62 lw34 turn-24 | 8 ra92 rw0 la92 lw0 turn16 lean10"),
    LAVA_SHIELD(Aim.FREE, 17, "3 ra82 rw56 la82 lw56 lean7 head7 rl-10 ll14"),
    // Вода
    WATER_FLOW(Aim.FREE, 0, Wobble.SWAY, "5 ra62 ro14 la48 lo18 lw20 turn8"),
    WATER_FLOW_THROW(Aim.LOOK, 14, "3 ra104 ro0 la104 lo0 lw0 turn-14 lean-5 | 7 ra86 la86 turn14 lean10"),
    HEALING(Aim.FREE, 25, "5 ra62 ro30 la62 lo30 lean-6 head-20 | 19"),
    ICE_RING(Aim.FREE, 17, "3 ra112 la112 lean-5 | 7 ra20 ro22 la20 lo22 lean22 rl-14 ll18"),
    WHIP(Aim.FREE, 14, "3 ra152 ro10 turn-22 lean-6 | 6 ra42 ro-8 rw20 turn20 lean12 | 8 ra62"),
    WAVE(Aim.FREE, 21, "3 ra-20 la-20 lean15 rl-14 ll18 | 9 ra112 la112 lean-4 | 12 ra90 la90 lean10"),
    GEYSER(Aim.FREE, 21, "4 ra30 la30 lean24 rl-12 ll16 | 10 ra170 ro10 la170 lo10 lean-12 head-18 rl0 ll0"),
    BUBBLE(Aim.FREE, 21, "5 ra82 ro25 rw40 la82 lo25 lw40 | 14 ra70 ro46 rw14 la70 lo46 lw14"),
    GUARDIAN(Aim.FREE, 38, "8 ra102 rw30 la102 lw30 lean6 | 22 ra152 ro40 rw0 la152 lo40 lw0 lean-10 head-22 | 32"),
    ICE_VOLLEY(Aim.LOOK, 23, "2 ra95 la20 turn14 | 6 ra20 la95 turn-14 | 10 ra95 la20 turn14 | 14 ra20 la95 turn-14 | 18 ra95 la20 turn14"),
    MIST(Aim.FREE, 23, "6 ra102 ro60 la102 lo60 | 14 ra40 ro40 la40 lo40 lean4 head8"),
    ICE_PRISON(Aim.LOOK, 17, "3 ra90 ro25 la90 lo25 | 7 ro0 rw30 lo0 lw30 lean8"),
    HEALING_RAIN(Aim.FREE, 31, "6 ra166 ro30 la166 lo30 lean-8 head-30 | 24"),
    // Земля
    BOULDER(Aim.FREE, 0, Wobble.TENSE, "3 ra30 la30 lean24 rl-14 ll20 | 9 ra158 ro12 la158 lo12 lean-10 head-8 rl0 ll0"),
    BOULDER_THROW(Aim.FREE, 17, "3 ra185 ro10 la185 lo10 lean-14 | 7 ra84 ro0 la84 lo0 lean22 rl16 ll-12"),
    QUAKE(Aim.FREE, 15, "3 ra20 ro56 la-10 lo56 lean-8 rl76 | 5 ra-18 ro38 la-18 lo38 lean26 head4 rl20 ll-8"),
    STONE_ARMOR(Aim.FREE, 19, "4 ra72 ro22 la72 lo22 lean-3 | 7 ra80 ro0 rw46 la80 lo0 lw46 lean7 head6"),
    SPIKES(Aim.FREE, 17, "3 ra152 turn-14 lean-6 | 6 ra20 ro-4 turn0 lean32 rl-16 ll20"),
    WALL(Aim.FREE, 17, "3 ra10 la10 lean18 | 8 ra96 ro14 la96 lo14 lean-2"),
    EARTH_FIST(Aim.FREE, 17, "3 ra-22 turn-24 lean12 | 6 ra170 turn20 lean-8 head-10"),
    STONE_LEAP(Aim.FREE, 23, "2 ra-30 la-30 lean24 rl-20 ll24 | 6 ra122 la122 lean-6 rl10 ll-10 | 14 ra60 ro30 la60 lo30 rl30 ll-24"),
    FISSURE(Aim.FREE, 40, "6 ra170 la170 lean-14 head-12 | 11 ra10 la10 lean46 head10 rl-22 ll26 | 32"),
    QUICKSAND(Aim.FREE, 23, "4 ra50 ro22 la50 lo22 lean14 | 10 ra62 rw30 la40 lw-30 | 16 ra40 rw-30 la62 lw30"),
    BLADES(Aim.FREE, 15, "3 ra122 ro10 rw-40 la122 lo10 lw-40 | 7 ra60 ro0 rw56 la60 lo0 lw56 lean12"),
    SAND_BLAST(Aim.LOOK, 15, Wobble.SHAKE, "2 ra22 turn-20 | 5 ra100 turn16 lean8"),
    STEEL_STORM(Aim.FREE, 24, "4 ra90 rw-60 la90 lw-60 turn-30 | 10 turn30 | 16 turn-30 | 22 turn0"),
    // Воздух
    WIND_ORB(Aim.FREE, 0, Wobble.SWAY, "4 ra76 ro10 la56 lo10 lw30"),
    WIND_ORB_THROW(Aim.LOOK, 13, "3 ra62 ro0 la20 lo0 lw0 turn-18 | 6 ra92 turn22 lean10"),
    AIR_SAW(Aim.FREE, 0, Wobble.SWAY, "4 ra132 ro6 head-4"),
    AIR_SAW_THROW(Aim.LOOK, 14, "3 ra86 ro0 rw70 turn-30 | 7 ra90 rw-40 turn26"),
    DASH(Aim.FREE, 15, "2 ra-50 la-50 lean36 head-18 rl25 ll-35 | 10"),
    TORNADO(Aim.FREE, 0, Wobble.SWAY, "5 ra150 ro22 la40 lo18"),
    TORNADO_THROW(Aim.LOOK, 13, "3 ra172 ro0 la20 lo0 | 7 ra82 lean10"),
    DOME(Aim.FREE, 25, "4 ra20 ro10 la20 lo10 | 10 ra166 ro40 la166 lo40 head-10 | 16 ra90 ro86 la90 lo86"),
    FLIGHT(Aim.FREE, 60, 8, Wobble.TENSE, "4 ra176 la-28 lean62 head-46 rl-62 ll-74"),
    GUST(Aim.LOOK, 15, "3 ra70 ro10 la70 lo10 lean-6 | 6 ra100 ro0 la100 lo0 lean14"),
    GREAT_TORNADO(Aim.FREE, 0, Wobble.SWAY, "8 ra166 ro30 la166 lo30 lean-6 head-20"),
    GREAT_TORNADO_THROW(Aim.LOOK, 15, "4 ra184 ro10 la184 lo10 | 9 ra86 ro0 la86 lo0 lean14"),
    STORM(Aim.FREE, 25, "4 ra176 ro8 head-20 | 18 | 22 ra62"),
    VACUUM(Aim.FREE, 19, "3 ra90 ro50 la90 lo50 | 10 ra70 ro0 rw56 la70 lo0 lw56 lean4"),
    SKY_WRATH(Aim.FREE, 19, "5 ra170 ro18 la170 lo18 head-14 | 9 ra62 ro0 rw34 la62 lo0 lw34 lean20 head8"),
    THIN_AIR(Aim.LOOK, 27, Wobble.SHAKE, "5 ra92 la30 lo20 | 20 ra97 lean6");

    public static final int RA = 0, RO = 1, RW = 2, LA = 3, LO = 4, LW = 5, RL = 6, LL = 7, LEAN = 8, TURN = 9, HEAD = 10, CHANNELS = 11;

    private static final int WOBBLE_FADE = 6;

    private static final Gesture[][] BASE = {
            {FIREBALL, FLAME_RING, FLAME_ARMOR, GREAT_FIREBALL, FLAMETHROWER},
            {WATER_FLOW, HEALING, ICE_RING, WHIP, WAVE},
            {BOULDER, QUAKE, STONE_ARMOR, SPIKES, WALL},
            {WIND_ORB, AIR_SAW, DASH, TORNADO, DOME}};
    private static final Gesture[][] EXTRA = {
            {FIRE_STEP, SPARK_SWARM, METEOR},
            {GEYSER, BUBBLE, GUARDIAN},
            {EARTH_FIST, STONE_LEAP, FISSURE},
            {FLIGHT, GUST, GREAT_TORNADO}};
    /** Навыки путей: сначала основной и второй навык первого пути, потом то же у второго. */
    private static final Gesture[][] PATHS = {
            {CHAIN_LIGHTNING, BALL_LIGHTNING, ERUPTION, LAVA_SHIELD},
            {ICE_VOLLEY, ICE_PRISON, MIST, HEALING_RAIN},
            {QUICKSAND, SAND_BLAST, BLADES, STEEL_STORM},
            {STORM, SKY_WRATH, VACUUM, THIN_AIR}};

    /** Конструктор перечисления не видит его статические поля, поэтому разбор записи живёт отдельно. */
    private static final class Notation {
        static final List<String> NAMES = List.of("ra", "ro", "rw", "la", "lo", "lw", "rl", "ll", "lean", "turn", "head");
        static final Pattern VALUE = Pattern.compile("([a-z]+)(-?\\d+)");
    }

    /** Куда смотрят руки: FREE ставит их относительно корпуса, LOOK ведёт за взглядом, как лук в руках. */
    public enum Aim {
        FREE, LOOK
    }

    /** Чем живёт поза, когда кадры закончились: иначе удержание выглядело бы застывшей статуей. */
    private enum Wobble {
        NONE, SHAKE, SWAY, TENSE
    }

    public final Aim aim;
    private final int ticks;
    private final int perLevel;
    private final Wobble wobble;
    private final int[] times;
    private final float[][] frames;
    private final boolean[] used = new boolean[CHANNELS];

    Gesture(Aim aim, int ticks, String keys) {
        this(aim, ticks, 0, Wobble.NONE, keys);
    }

    Gesture(Aim aim, int ticks, Wobble wobble, String keys) {
        this(aim, ticks, 0, wobble, keys);
    }

    Gesture(Aim aim, int ticks, int perLevel, Wobble wobble, String keys) {
        this.aim = aim;
        this.ticks = ticks;
        this.perLevel = perLevel;
        this.wobble = wobble;
        List<float[]> poses = new ArrayList<>();
        String[] parts = keys.split("\\|");
        times = new int[parts.length];
        float[] pose = new float[CHANNELS];
        for (int i = 0; i < parts.length; i++) {
            String[] words = parts[i].trim().split(" ");
            times[i] = Integer.parseInt(words[0]);
            pose = pose.clone();
            for (int w = 1; w < words.length; w++) {
                Matcher value = Notation.VALUE.matcher(words[w]);
                int channel = value.matches() ? Notation.NAMES.indexOf(value.group(1)) : -1;
                if (channel < 0) {
                    throw new IllegalArgumentException(name() + ": " + words[w]);
                }
                pose[channel] = Integer.parseInt(value.group(2));
                used[channel] = true;
            }
            poses.add(pose);
        }
        frames = poses.toArray(new float[0][]);
    }

    public static Gesture of(Element element, int slot, int path) {
        int row = element.ordinal();
        if (slot == Abilities.PATH_SLOT || slot == Abilities.PATH_SECOND_SLOT) {
            return PATHS[row][(path - 1) * 2 + (slot == Abilities.PATH_SLOT ? 0 : 1)];
        }
        if (slot == Abilities.ULTIMATE_SLOT) {
            return EXTRA[row][2];
        }
        return slot < BASE[row].length ? BASE[row][slot] : EXTRA[row][slot - 7];
    }

    /** Что делает персонаж, когда выпускает снаряд из рук. Без снаряда в руках ответ null. */
    public Gesture release() {
        return switch (this) {
            case FIREBALL -> FIREBALL_THROW;
            case GREAT_FIREBALL -> GREAT_FIREBALL_THROW;
            case WATER_FLOW -> WATER_FLOW_THROW;
            case BOULDER -> BOULDER_THROW;
            case WIND_ORB -> WIND_ORB_THROW;
            case AIR_SAW -> AIR_SAW_THROW;
            case TORNADO -> TORNADO_THROW;
            case GREAT_TORNADO -> GREAT_TORNADO_THROW;
            default -> null;
        };
    }

    public boolean held() {
        return ticks == 0;
    }

    public int ticks(int level) {
        return ticks + perLevel * level;
    }

    public boolean uses(int channel) {
        return used[channel];
    }

    /** Поза в момент времени, углы в градусах. */
    public void pose(float time, float[] out) {
        int next = 0;
        while (next < times.length && times[next] <= time) {
            next++;
        }
        if (next == times.length) {
            System.arraycopy(frames[next - 1], 0, out, 0, CHANNELS);
            wobble(time, Math.min(1, (time - times[next - 1]) / WOBBLE_FADE), out);
            return;
        }
        float[] from = next == 0 ? new float[CHANNELS] : frames[next - 1];
        int start = next == 0 ? 0 : times[next - 1];
        float k = (time - start) / (times[next] - start);
        k = k * k * (3 - 2 * k);
        for (int i = 0; i < CHANNELS; i++) {
            out[i] = from[i] + (frames[next][i] - from[i]) * k;
        }
    }

    private void wobble(float time, float amount, float[] out) {
        switch (wobble) {
            case SHAKE -> {
                float shake = (float) Math.sin(time * 2.6) * 2.2F * amount;
                out[RA] += shake;
                out[LA] -= shake;
            }
            case SWAY -> {
                float wave = (float) Math.sin(time * 0.22) * amount;
                float side = (float) Math.cos(time * 0.22) * amount;
                out[RA] += wave * 9;
                out[RO] += side * 6;
                out[LA] -= wave * 9;
                out[LO] -= side * 6;
            }
            case TENSE -> {
                float breath = (float) Math.sin(time * 0.16) * amount;
                out[RA] += breath * 2.5F;
                out[LA] += breath * 2.5F;
                out[LEAN] += breath * 1.2F;
            }
            default -> {
            }
        }
    }
}
