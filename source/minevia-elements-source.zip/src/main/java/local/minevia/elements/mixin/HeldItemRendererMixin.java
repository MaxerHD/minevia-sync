package local.minevia.elements.mixin;

import local.minevia.elements.client.GestureClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** От первого лица движения навыков видны на руках: двигается и рука с предметом, и пустая вторая. */
@Mixin(HeldItemRenderer.class)
abstract class HeldItemRendererMixin {
    @Shadow
    private void renderArmHoldingItem(MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light,
            float equipProgress, float swingProgress, Arm arm) {
    }

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void minevia$moveHand(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand, float swingProgress,
            ItemStack item, float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo info) {
        boolean main = hand == Hand.MAIN_HAND;
        matrices.push();
        GestureClient.hand(player, main ? player.getMainArm() : player.getMainArm().getOpposite(), main, tickDelta, matrices);
    }

    @Inject(method = "renderFirstPersonItem", at = @At("RETURN"))
    private void minevia$restoreHand(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand, float swingProgress,
            ItemStack item, float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo info) {
        matrices.pop();
    }

    @Inject(method = "renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;draw()V"))
    private void minevia$offHand(float tickDelta, MatrixStack matrices, VertexConsumerProvider.Immediate vertexConsumers,
            ClientPlayerEntity player, int light, CallbackInfo info) {
        if (player.isInvisible() || !player.getOffHandStack().isEmpty() || !GestureClient.showsOffHand(player, tickDelta)) {
            return;
        }
        Arm arm = player.getMainArm().getOpposite();
        matrices.push();
        GestureClient.offHandEntry(player, tickDelta, matrices);
        GestureClient.hand(player, arm, false, tickDelta, matrices);
        renderArmHoldingItem(matrices, vertexConsumers, light, 0, 0, arm);
        matrices.pop();
    }
}
