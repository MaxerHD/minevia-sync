package local.minevia.elements;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Приёмы духов. Каждый приём возвращает, сколько тиков ждать до следующего. */
final class MobMoves {
    private static final int WARN = 18;
    private static final int STONE = 0x8A7F70;

    /** Что происходит, когда снаряд попал в цель. */
    private interface Hit {
        void on(LivingEntity target);
    }

    private MobMoves() {
    }

    static int use(ElementMob mob, ServerWorld world, LivingEntity target) {
        double distance = mob.distanceTo(target);
        return switch (mob.element()) {
            case FIRE -> distance < 20 ? fire(mob, world, target) : 20;
            case WATER -> distance > 3 && distance < 15 ? water(mob, world, target) : 20;
            case EARTH -> distance < 3.6 ? stomp(mob, world) : distance < 16 ? hurl(mob, world, target) : 20;
            case AIR -> distance < 14 ? air(mob, world, target) : 20;
        };
    }

    private static float power(ElementMob mob, float damage) {
        return mob.elder() ? damage * 1.5F : damage;
    }

    /** Снаряд духа: летит по прямой или дуге и гаснет о блок. Игроков задевает, других монстров нет. */
    private static void shot(ElementMob mob, ServerWorld world, SpellKind kind, float size, Vec3d velocity, double fall, int tint, Runnable end, Hit hit) {
        Vec3d from = mob.getBoundingBox().getCenter().add(velocity.normalize().multiply(0.8));
        Vec3d[] speed = {velocity};
        SpellEntity spell = SpellEntity.spawn(world, kind, from, size, 70).facing(velocity).tint(tint);
        spell.setVelocity(velocity);
        spell.logic(self -> {
            speed[0] = speed[0].add(0, -fall, 0);
            self.setVelocity(speed[0]);
            Vec3d at = self.getPos();
            Vec3d next = at.add(speed[0]);
            var block = world.raycast(new RaycastContext(at, next, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, self));
            boolean blocked = block.getType() != HitResult.Type.MISS;
            self.setPosition(blocked ? block.getPos() : next);
            for (PlayerEntity player : ElementBoss.playersAt(world, self.getPos(), 1.1)) {
                hit.on(player);
                blocked = true;
                break;
            }
            if (blocked || self.age >= self.life() - 1) {
                end.run();
                self.discard();
            }
        });
    }

    private static Vec3d aim(ElementMob mob, LivingEntity target, double speed) {
        return target.getBoundingBox().getCenter().subtract(mob.getBoundingBox().getCenter()).normalize().multiply(speed);
    }

    private static int fire(ElementMob mob, ServerWorld world, LivingEntity target) {
        int count = mob.elder() ? 3 : 1;
        Abilities.soundAt(world, mob.getPos(), Sounds.FIRE_CAST, 1.4F);
        for (int i = 0; i < count; i++) {
            Effects.later(world, i * 7, () -> {
                if (!mob.isAlive() || !target.isAlive()) {
                    return;
                }
                Vec3d[] where = {mob.getPos()};
                shot(mob, world, SpellKind.FIREBALL, 0.45F, aim(mob, target, 0.62), 0, 0xFFFFFF,
                        () -> SpellEntity.spawn(world, SpellKind.FIRE_BURST, where[0], 0.4F, 17),
                        player -> {
                            where[0] = player.getBoundingBox().getCenter();
                            player.damage(world.getDamageSources().mobAttack(mob), power(mob, 4));
                            player.setOnFireFor(3);
                        });
            });
        }
        return 54 + world.random.nextInt(20);
    }

    private static int water(ElementMob mob, ServerWorld world, LivingEntity target) {
        Abilities.soundAt(world, mob.getPos(), Sounds.WATER_WHIP, 1.3F);
        Vec3d[] where = {target.getPos()};
        shot(mob, world, SpellKind.WATER_BLOB, 0.5F, aim(mob, target, 0.7).add(0, 0.1, 0), 0.015, 0xFFFFFF,
                () -> SpellEntity.spawn(world, SpellKind.WATER_SPLASH, where[0], 0.5F, 15),
                player -> {
                    where[0] = player.getBoundingBox().getCenter();
                    player.damage(world.getDamageSources().mobAttack(mob), power(mob, 3));
                    player.extinguish();
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 50, 1, false, false, true));
                });
        return 60 + world.random.nextInt(20);
    }

    /** Топот сначала показывает круг на земле, поэтому от него можно отбежать. */
    private static int stomp(ElementMob mob, ServerWorld world) {
        Vec3d at = mob.getPos();
        float radius = mob.elder() ? 5 : 3.6F;
        SpellEntity.spawn(world, SpellKind.DANGER_RING, at.add(0, 0.06, 0), radius, WARN).tint(0xB89A6A);
        Effects.later(world, WARN, () -> {
            if (!mob.isAlive()) {
                return;
            }
            Spells.ring(world, SpellKind.GROUND_SLAB, at, radius * 0.7, 10, 24, 0.9F, STONE);
            Abilities.soundAt(world, at, Sounds.EARTH_QUAKE, 1.3F);
            for (PlayerEntity player : ElementBoss.playersAt(world, at.add(0, 0.8, 0), radius)) {
                player.damage(world.getDamageSources().mobAttack(mob), power(mob, 6));
                Abilities.push(player, player.getPos().subtract(at).normalize().multiply(0.6).add(0, 0.55, 0));
            }
        });
        return 70;
    }

    private static int hurl(ElementMob mob, ServerWorld world, LivingEntity target) {
        Abilities.soundAt(world, mob.getPos(), Sounds.EARTH_THROW, 1.3F);
        double distance = mob.distanceTo(target);
        Vec3d[] where = {target.getPos()};
        Vec3d velocity = aim(mob, target, 0.7).add(0, 0.05 + distance * 0.022, 0);
        shot(mob, world, SpellKind.BOULDER, 0.5F, velocity, 0.03, STONE,
                () -> SpellEntity.spawn(world, SpellKind.ROCK_BURST, where[0], 0.5F, 18).tint(STONE),
                player -> {
                    where[0] = player.getBoundingBox().getCenter();
                    player.damage(world.getDamageSources().mobAttack(mob), power(mob, 5));
                });
        return 80 + world.random.nextInt(30);
    }

    /** Птица пикирует на цель, а если не долетит, сверху бьёт порывом. */
    private static int air(ElementMob mob, ServerWorld world, LivingEntity target) {
        Abilities.soundAt(world, mob.getPos(), Sounds.AIR_DASH, 1.3F);
        mob.startDive();
        return 80 + world.random.nextInt(30);
    }

    static void diveHit(ElementMob mob, ServerWorld world, LivingEntity target) {
        Vec3d at = target.getBoundingBox().getCenter();
        SpellEntity.spawn(world, SpellKind.WIND_BURST, at, 1.6F, 14);
        Abilities.soundAt(world, at, Sounds.AIR_GUST, 1.2F);
        target.damage(world.getDamageSources().mobAttack(mob), power(mob, 4));
        Abilities.push(target, target.getPos().subtract(mob.getPos()).normalize().multiply(1.1).add(0, 0.5, 0));
    }

    /** Дух разлетается своим веществом. */
    static void burst(ElementMob mob, ServerWorld world) {
        Vec3d at = mob.getBoundingBox().getCenter();
        float size = mob.elder() ? 1.4F : 0.9F;
        Flourish.blast(world, at, size * 3, mob.element().color);
        switch (mob.element()) {
            case FIRE -> SpellEntity.spawn(world, SpellKind.FIRE_BURST, at, size, 17);
            case WATER -> SpellEntity.spawn(world, SpellKind.WATER_SPLASH, at, size, 15);
            case EARTH -> SpellEntity.spawn(world, SpellKind.ROCK_BURST, at, size, 18).tint(STONE);
            case AIR -> SpellEntity.spawn(world, SpellKind.WIND_BURST, at, size * 2, 14);
        }
    }
}
