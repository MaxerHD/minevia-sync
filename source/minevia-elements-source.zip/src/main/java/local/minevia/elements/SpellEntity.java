package local.minevia.elements;

import java.util.ArrayDeque;
import java.util.Deque;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Видимая часть способности: летящая, растущая или прикреплённая к игроку 3D-модель.
 * Логику задаёт сервер, а клиент сам плавно ведёт модель между пакетами. В сохранение мира не попадает.
 */
public final class SpellEntity extends Entity {
    private static final TrackedData<Integer> KIND = DataTracker.registerData(SpellEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> LIFE = DataTracker.registerData(SpellEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> OWNER = DataTracker.registerData(SpellEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TARGET = DataTracker.registerData(SpellEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> TINT = DataTracker.registerData(SpellEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Float> SIZE = DataTracker.registerData(SpellEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final int TRAIL = 9;

    /** Поведение способности на сервере, вызывается каждый тик. */
    public interface Logic {
        void tick(SpellEntity self);
    }

    private Logic logic;
    private CastContext.Token castContext;
    private Element charge;
    private Element infused;
    private ServerPlayerEntity caster;
    private Vec3d corrected;
    private final Deque<Vec3d> trail = new ArrayDeque<>();
    private Vec3d heading;
    private Vec3d prevHeading;
    private float shownSize = -1;
    private float prevShownSize;

    public SpellEntity(EntityType<?> type, World world) {
        super(type, world);
        noClip = true;
        ignoreCameraFrustum = true;
        setNoGravity(true);
    }

    public static SpellEntity spawn(ServerWorld world, SpellKind kind, Vec3d at, float size, int life) {
        SpellEntity spell = new SpellEntity(MineviaElements.SPELL, world);
        spell.dataTracker.set(KIND, kind.ordinal());
        spell.dataTracker.set(LIFE, life);
        spell.dataTracker.set(SIZE, size);
        spell.castContext = CastContext.capture();
        spell.setPosition(at);
        world.spawnEntity(spell);
        return spell;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(KIND, 0);
        builder.add(LIFE, 20);
        builder.add(OWNER, -1);
        builder.add(TARGET, -1);
        builder.add(TINT, 0xFFFFFF);
        builder.add(SIZE, 1.0F);
    }

    public SpellEntity logic(Logic value) {
        logic = value;
        return this;
    }

    /** Помечает способность стихией: две разные стихии рядом дают комбо. */
    public SpellEntity charged(Element element, ServerPlayerEntity player) {
        charge = element;
        caster = player;
        Combos.track(this);
        return this;
    }

    public Element charge() {
        return charge;
    }

    public ServerPlayerEntity caster() {
        return caster;
    }

    /** Стихия, которую способность приняла от комбо: глыба раскаляется, смерч загорается. */
    public Element infused() {
        return infused;
    }

    public void infuse(Element element, SpellKind look) {
        infused = element;
        dataTracker.set(KIND, look.ordinal());
    }

    public SpellEntity owner(Entity entity) {
        dataTracker.set(OWNER, entity.getId());
        return this;
    }

    public SpellEntity target(Entity entity) {
        dataTracker.set(TARGET, entity.getId());
        return this;
    }

    public SpellEntity tint(int color) {
        dataTracker.set(TINT, color);
        return this;
    }

    public SpellEntity facing(Vec3d direction) {
        double flat = Math.sqrt(direction.x * direction.x + direction.z * direction.z);
        setYaw((float) Math.toDegrees(Math.atan2(-direction.x, direction.z)));
        setPitch((float) Math.toDegrees(Math.atan2(-direction.y, flat)));
        return this;
    }

    public void setSize(float size) {
        dataTracker.set(SIZE, size);
    }

    public void setLife(int ticks) {
        dataTracker.set(LIFE, ticks);
    }

    public SpellKind kind() {
        return SpellKind.of(dataTracker.get(KIND));
    }

    public int life() {
        return dataTracker.get(LIFE);
    }

    public float size() {
        return dataTracker.get(SIZE);
    }

    public int tintColor() {
        return dataTracker.get(TINT);
    }

    public Entity ownerEntity() {
        return getWorld().getEntityById(dataTracker.get(OWNER));
    }

    public Entity targetEntity() {
        return getWorld().getEntityById(dataTracker.get(TARGET));
    }

    public float shownSize(float delta) {
        if (shownSize < 0) {
            return size();
        }
        return prevShownSize + (shownSize - prevShownSize) * delta;
    }

    public Vec3d heading(float delta) {
        if (heading == null) {
            return getRotationVector();
        }
        return prevHeading.lerp(heading, delta);
    }

    public Iterable<Vec3d> trail() {
        return trail;
    }

    @Override
    public void tick() {
        if (getWorld().isClient) {
            tickClient();
            return;
        }
        if (castContext != null && !castContext.valid()) { discard(); return; }
        CastContext.run(castContext, () -> {
            if (logic != null) logic.tick(this);
            if (charge != null && !isRemoved()) Nature.tick(this);
        });
        if (age >= life()) {
            discard();
        }
    }

    private void tickClient() {
        if (shownSize < 0) {
            shownSize = 0;
        }
        prevShownSize = shownSize;
        shownSize += (size() - shownSize) * 0.4F;

        Vec3d velocity = getVelocity();
        Vec3d next = getPos().add(velocity);
        if (corrected != null) {
            next = next.add(corrected.subtract(next).multiply(0.3));
        }
        setPosition(next);

        Vec3d want = velocity.lengthSquared() > 0.0025 ? velocity.normalize() : getRotationVector();
        prevHeading = heading == null ? want : heading;
        heading = prevHeading.lerp(want, 0.45).normalize();

        trail.addFirst(next);
        while (trail.size() > TRAIL) {
            trail.removeLast();
        }
    }

    /** Пакеты приходят неровно: они только подправляют путь, иначе снаряд дёргался бы на лету. */
    @Override
    public void updateTrackedPositionAndAngles(double x, double y, double z, float yaw, float pitch, int steps) {
        corrected = new Vec3d(x, y, z);
        setRotation(yaw, pitch);
    }

    @Override
    public boolean shouldRender(double distance) {
        return distance < 128 * 128;
    }

    /** Подсказки других модов не должны показывать способность как существо. */
    @Override
    public boolean isInvisibleTo(PlayerEntity player) {
        return true;
    }

    @Override
    public boolean isAttackable() {
        return false;
    }

    @Override
    public boolean canHit() {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean doesRenderOnFire() {
        return false;
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
    }
}
