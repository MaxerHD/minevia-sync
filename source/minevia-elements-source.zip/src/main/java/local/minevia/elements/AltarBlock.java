package local.minevia.elements;

import com.mojang.serialization.MapCodec;
import java.util.EnumSet;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * Алтарь в сердце храма. Первое касание будит стража. С четырьмя Печатями в инвентаре любой алтарь
 * вызывает Исток: для него рядом нужны игроки хотя бы двух разных стихий, потому что его берут только комбо.
 */
public final class AltarBlock extends BlockWithEntity {
    public static final MapCodec<AltarBlock> CODEC = createCodec(AltarBlock::new);
    public static final IntProperty ELEMENT = IntProperty.of("element", 0, 3);
    public static final BooleanProperty AWAKE = BooleanProperty.of("awake");
    private static final VoxelShape SHAPE = Block.createCuboidShape(1, 0, 1, 15, 14, 15);
    private static final int RITUAL_TICKS = 50;

    public AltarBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(ELEMENT, 0).with(AWAKE, true));
    }

    @Override
    protected MapCodec<AltarBlock> getCodec() {
        return CODEC;
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(ELEMENT, AWAKE);
    }

    @Override
    protected BlockRenderType getRenderType(BlockState state) {
        return BlockRenderType.MODEL;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return SHAPE;
    }

    @Override
    public BlockEntity createBlockEntity(BlockPos pos, BlockState state) {
        return new AltarBlockEntity(pos, state);
    }

    @Override
    protected ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player, BlockHitResult hit) {
        if (!(world instanceof ServerWorld server) || !(player instanceof ServerPlayerEntity user)) {
            return ActionResult.SUCCESS;
        }
        if (hasAllSeals(user)) {
            callPrimal(server, pos, user);
            return ActionResult.CONSUME;
        }
        if (!state.get(AWAKE)) {
            user.sendMessage(Text.translatable("message.minevia_elements.altar_asleep"), true);
            return ActionResult.CONSUME;
        }
        world.setBlockState(pos, state.with(AWAKE, false));
        Abilities.soundAt(server, Vec3d.ofCenter(pos), Sounds.ALTAR, 1.0F);
        int kind = state.get(ELEMENT);
        Effects.later(server, RITUAL_TICKS, () -> ElementBoss.summon(server, pos, kind, 0));
        return ActionResult.CONSUME;
    }

    private static boolean hasAllSeals(ServerPlayerEntity player) {
        for (var seal : MineviaElements.SEALS) {
            if (!player.getInventory().containsAny(stack -> stack.isOf(seal))) {
                return false;
            }
        }
        return true;
    }

    private static void callPrimal(ServerWorld world, BlockPos pos, ServerPlayerEntity user) {
        Set<Element> present = EnumSet.noneOf(Element.class);
        ElementState state = ElementState.get(world.getServer());
        for (PlayerEntity near : world.getEntitiesByClass(PlayerEntity.class, new Box(pos).expand(40), PlayerEntity::isAlive)) {
            ElementState.Data data = state.find(near.getUuid());
            if (data != null && data.element != null && data.element.isNatural()) {
                present.add(data.element);
            }
        }
        if (present.size() < 2) {
            user.sendMessage(Text.translatable("message.minevia_elements.primal_alone"), true);
            return;
        }
        for (var seal : MineviaElements.SEALS) {
            for (int i = 0; i < user.getInventory().size(); i++) {
                ItemStack stack = user.getInventory().getStack(i);
                if (stack.isOf(seal)) {
                    stack.decrement(1);
                    break;
                }
            }
        }
        int mask = 0;
        for (Element element : present) {
            mask |= 1 << element.ordinal();
        }
        int seals = mask;
        Abilities.soundAt(world, Vec3d.ofCenter(pos), Sounds.ALTAR, 0.7F);
        Effects.later(world, RITUAL_TICKS, () -> ElementBoss.summon(world, pos, ElementBoss.PRIMAL, seals));
    }
}
