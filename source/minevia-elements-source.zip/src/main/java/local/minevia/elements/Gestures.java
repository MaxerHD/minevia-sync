package local.minevia.elements;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import local.minevia.elements.net.GesturePayload;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

/** Рассылает движения персонажа всем, кто его видит, и помнит, кто что держит в руках. */
final class Gestures {
    private static final Map<UUID, Gesture> HELD = new HashMap<>();

    private Gestures() {
    }

    static void play(ServerPlayerEntity player, Gesture gesture, int level) {
        if (gesture.held()) {
            HELD.put(player.getUuid(), gesture);
        } else {
            HELD.remove(player.getUuid());
        }
        send(player, new GesturePayload(player.getId(), gesture.ordinal(), gesture.ticks(level)));
    }

    /** Снаряд вышел из рук: поза удержания сменяется броском. */
    static void release(ServerPlayerEntity player) {
        Gesture held = HELD.get(player.getUuid());
        if (held != null) {
            play(player, held.release(), 0);
        }
    }

    /** Снаряд пропал сам: руки просто опускаются. */
    static void stop(ServerPlayerEntity player) {
        if (HELD.remove(player.getUuid()) != null) {
            send(player, new GesturePayload(player.getId(), GesturePayload.STOP, 0));
        }
    }

    static void forget(UUID id) {
        HELD.remove(id);
    }

    private static void send(ServerPlayerEntity player, GesturePayload payload) {
        List<ServerPlayerEntity> viewers = new ArrayList<>(PlayerLookup.tracking(player));
        viewers.add(player);
        for (ServerPlayerEntity viewer : viewers) {
            if (ServerPlayNetworking.canSend(viewer, GesturePayload.ID)) {
                ServerPlayNetworking.send(viewer, payload);
            }
        }
    }
}
