package local.minevia.elements;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.TagKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.gen.structure.Structure;

/** Что умеют реликвии. Часть работает по правой кнопке, часть просто лежит в инвентаре. */
final class Relics {
    private static final int SOUL = 0x7FD8FF;
    private static final int BRONZE = 0xFFD27A;
    private static final int HORN = 0xFF7A3A;
    private static final int CHARM_PAUSE = 12000;
    private static final Identifier HEART = Identifier.of(MineviaElements.MOD_ID, "stone_heart");
    private static final Identifier HEART_WEIGHT = Identifier.of(MineviaElements.MOD_ID, "stone_heart_weight");
    private static final TagKey<Structure> PLACES = TagKey.of(RegistryKeys.STRUCTURE, Identifier.of(MineviaElements.MOD_ID, "places"));

    private Relics() {
    }

    static void init() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity player && has(player, RelicItem.Kind.BONE_CHARM)
                    && !player.getItemCooldownManager().isCoolingDown(item(RelicItem.Kind.BONE_CHARM))) {
                saveFromDeath(player);
                return false;
            }
            return true;
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) ->
                !(entity instanceof ServerPlayerEntity player && source.isOf(DamageTypes.FALL) && has(player, RelicItem.Kind.STORM_FEATHER)));
    }

    private static Item item(RelicItem.Kind kind) {
        return MineviaElements.RELICS[kind.ordinal()];
    }

    private static boolean has(ServerPlayerEntity player, RelicItem.Kind kind) {
        Item wanted = item(kind);
        return player.getInventory().containsAny(stack -> stack.isOf(wanted));
    }

    /** Костяной оберег: смерть отменяется, вокруг вспыхивают кости, а оберег остывает десять минут. */
    private static void saveFromDeath(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        player.setHealth(10);
        player.clearStatusEffects();
        player.extinguish();
        Abilities.buff(player, StatusEffects.RESISTANCE, 80, 3);
        player.getItemCooldownManager().set(item(RelicItem.Kind.BONE_CHARM), CHARM_PAUSE);
        Flourish.rise(world, player.getPos().add(0, 0.05, 0), 2.6F, 0xE0D6BE);
        Spells.ring(world, SpellKind.STONE_SPIKE, player.getPos(), 2.4, 10, 34, 1.0F, 0xE0D6BE);
        Abilities.sound(player, Sounds.SEAL_BREAK, 0.8F);
        player.sendMessage(Text.translatable("message.minevia_elements.charm_saved"), true);
    }

    /** Раз в секунду: Каменное сердце добавляет здоровье, Фонарь в левой руке даёт видеть в темноте. */
    static void tick(MinecraftServer server) {
        if (server.getTicks() % 20 != 0) {
            return;
        }
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (has(player, RelicItem.Kind.CINDER_HEART)) {
                Abilities.buff(player, StatusEffects.FIRE_RESISTANCE, 45, 0);
            }
            if (has(player, RelicItem.Kind.PEARL_OF_AIR)) {
                Abilities.buff(player, StatusEffects.WATER_BREATHING, 45, 0);
            }
            if (has(player, RelicItem.Kind.DEEP_LANTERN) && player.isSubmergedInWater()) {
                Abilities.buff(player, StatusEffects.NIGHT_VISION, 320, 0);
            }
            if (has(player, RelicItem.Kind.SKY_ANCHOR) && player.fallDistance > 3) {
                Abilities.buff(player, StatusEffects.SLOW_FALLING, 35, 0);
            }
            boolean heart = has(player, RelicItem.Kind.STONE_HEART);
            modifier(player.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH), HEART, heart, 6);
            modifier(player.getAttributeInstance(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE), HEART_WEIGHT, heart, 0.3);
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
            if (player.getOffHandStack().isOf(item(RelicItem.Kind.ABBOT_LANTERN))) {
                Abilities.buff(player, StatusEffects.NIGHT_VISION, 320, 0);
            }
        }
    }

    private static void modifier(EntityAttributeInstance attribute, Identifier id, boolean wanted, double amount) {
        if (attribute == null) {
            return;
        }
        if (wanted && !attribute.hasModifier(id)) {
            attribute.addTemporaryModifier(new EntityAttributeModifier(id, amount, EntityAttributeModifier.Operation.ADD_VALUE));
        } else if (!wanted && attribute.hasModifier(id)) {
            attribute.removeModifier(id);
        }
    }

    static void use(RelicItem.Kind kind, ServerPlayerEntity player) {
        switch (kind) {
            case SOUL_STAFF -> soulShot(player);
            case BELL_HAMMER -> hammer(player);
            case HAND_BELL -> bell(player);
            case STORM_FEATHER -> leap(player);
            case RAM_HORN -> ram(player);
            case MAZE_THREAD -> thread(player);
            case SMITH_TONGS -> {
                LivingEntity target = Abilities.aim(player, 12);
                if (target != null) {
                    Abilities.debuff(target, StatusEffects.SLOWNESS, 70, 3);
                    Abilities.debuff(target, StatusEffects.WEAKNESS, 100, 1);
                    SpellEntity.spawn(player.getServerWorld(), SpellKind.GRAVITY_KNOT, target.getPos().add(0, 0.8, 0), 1, 35).tint(0xFF9138);
                }
            }
            case BELLOWS_RELIC -> {
                SpellEntity.spawn(player.getServerWorld(), SpellKind.HEAT_BURST, player.getPos(), 5, 22);
                for (LivingEntity near : Abilities.livingAt(player, player.getPos(), 5)) {
                    if (player.canSee(near)) {
                        Abilities.hurt(player, near, 7);
                        Abilities.push(near, near.getPos().subtract(player.getPos()).normalize().multiply(0.9).add(0, 0.2, 0));
                    }
                }
            }
            case TIDAL_SHELL -> {
                player.heal(5);
                Abilities.buff(player, StatusEffects.RESISTANCE, 100, 1);
                SpellEntity.spawn(player.getServerWorld(), SpellKind.DEPTH_HEAL, player.getPos(), 2, 40);
            }
            case STAR_LENS -> {
                SpellEntity.spawn(player.getServerWorld(), SpellKind.STAR_FIELD, player.getPos(), 8, 35);
                for (LivingEntity near : Abilities.monstersAt(player, player.getPos(), 32)) {
                    Abilities.debuff(near, StatusEffects.GLOWING, 200, 0);
                }
            }
            case ORBIT_STONE -> {
                ServerWorld world = player.getServerWorld();
                Vec3d at = player.getPos();
                SpellEntity.spawn(world, SpellKind.STAR_FIELD, at, 5, 80);
                Effects.repeat(world, 16, 5, step -> {
                    if (!player.isAlive() || player.getWorld() != world) {
                        return false;
                    }
                    for (LivingEntity near : Abilities.livingAt(player, at, 5)) {
                        if (player.canSee(near)) {
                            Abilities.debuff(near, StatusEffects.SLOWNESS, 16, 2);
                        }
                    }
                    return true;
                });
            }
            default -> {
            }
        }
    }

    /** Посох выпускает огонь души: он сам доворачивает к ближайшему врагу. */
    private static void soulShot(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d[] speed = {player.getRotationVector().multiply(0.7)};
        Abilities.sound(player, Sounds.VACUUM, 1.6F);
        SpellEntity flame = SpellEntity.spawn(world, SpellKind.SOUL_FLAME, Spells.muzzle(player, 1.6), 0.4F, 70);
        flame.setVelocity(speed[0]);
        flame.logic(self -> {
            LivingEntity near = Abilities.monstersAt(player, self.getPos(), 10).stream()
                    .min(java.util.Comparator.comparingDouble(target -> target.squaredDistanceTo(self))).orElse(null);
            if (near != null) {
                speed[0] = speed[0].lerp(near.getBoundingBox().getCenter().subtract(self.getPos()).normalize().multiply(0.7), 0.16);
            }
            self.setVelocity(speed[0]);
            Vec3d next = self.getPos().add(speed[0]);
            BlockPos pos = BlockPos.ofFloored(next);
            boolean blocked = !world.getBlockState(pos).getCollisionShape(world, pos).isEmpty();
            self.setPosition(next);
            List<LivingEntity> hit = Abilities.livingAt(player, next, 1.2);
            if (blocked || !hit.isEmpty() || self.age >= self.life() - 1) {
                for (LivingEntity target : hit) {
                    Abilities.strike(player, target, 9);
                }
                Flourish.blast(world, next, 2.2F, SOUL);
                self.discard();
            }
        });
    }

    /** Молот бьёт в землю: волна подбрасывает всех вокруг. */
    private static void hammer(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d at = player.getPos();
        world.playSound(null, at.x, at.y, at.z, SoundEvents.BLOCK_BELL_USE, player.getSoundCategory(), 2.0F, 0.6F);
        Abilities.sound(player, Sounds.EARTH_QUAKE, 1.1F);
        Flourish.blast(world, at.add(0, 0.2, 0), 8, BRONZE);
        for (LivingEntity near : Abilities.livingAt(player, at.add(0, 1, 0), 6)) {
            Abilities.strike(player, near, 12);
            Vec3d away = near.getPos().subtract(at);
            Abilities.push(near, new Vec3d(away.x, 0, away.z).normalize().multiply(0.8).add(0, 0.7, 0));
        }
    }

    /** Малый колокол: монстры вокруг светятся сквозь стены и слабеют. */
    private static void bell(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d at = player.getPos();
        world.playSound(null, at.x, at.y, at.z, SoundEvents.BLOCK_BELL_USE, player.getSoundCategory(), 2.0F, 1.4F);
        SpellEntity.spawn(world, SpellKind.SHOCK_RING, at.add(0, 0.6, 0), 12, 14).tint(BRONZE);
        for (LivingEntity near : Abilities.monstersAt(player, at, 28)) {
            Abilities.debuff(near, StatusEffects.GLOWING, 240, 0);
            Abilities.debuff(near, StatusEffects.WEAKNESS, 240, 0);
        }
    }

    /** Перо бури: прыжок прямо в воздухе. */
    private static void leap(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_GUST, 1.5F);
        SpellEntity.spawn(world, SpellKind.WIND_BURST, player.getPos(), 1.8F, 14);
        Abilities.push(player, player.getRotationVector().multiply(0.5).add(0, 1.0, 0));
        player.fallDistance = 0;
    }

    /** Рог Рогача: игрок несётся вперёд и сносит всех, кто попался. */
    private static void ram(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d way = Spells.flatLook(player);
        Abilities.sound(player, Sounds.BOSS_AWAKE, 1.7F);
        Flourish.charge(world, player.getPos().add(0, 1, 0), 1.4F, 8, HORN);
        java.util.Set<java.util.UUID> struck = new java.util.HashSet<>();
        Effects.repeat(world, 14, 1, step -> {
            if (!player.isAlive()) {
                return false;
            }
            Abilities.push(player, way.multiply(1.25).add(0, player.getVelocity().y, 0));
            player.fallDistance = 0;
            if (step % 3 == 0) {
                SpellEntity.spawn(world, SpellKind.DUST_PUFF, player.getPos(), 0.9F, 18).tint(0x9A8468);
            }
            for (LivingEntity near : Abilities.livingAt(player, player.getPos().add(0, 1, 0), 2.2)) {
                if (struck.add(near.getUuid())) {
                    Abilities.strike(player, near, 11);
                    Abilities.push(near, way.multiply(1.4).add(0, 0.6, 0));
                    Flourish.hit(world, near, HORN);
                }
            }
            return true;
        });
    }

    /** Нить лабиринта: тянется к ближайшему храму или подземелью и подсказывает, куда идти. */
    private static void thread(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        BlockPos found = world.locateStructure(PLACES, player.getBlockPos(), 24, false);
        if (found == null) {
            player.sendMessage(Text.translatable("message.minevia_elements.temple_none"), false);
            return;
        }
        int dx = found.getX() - player.getBlockX();
        int dz = found.getZ() - player.getBlockZ();
        int side = Math.floorMod((int) Math.round(Math.toDegrees(Math.atan2(dx, -dz)) / 45), 8);
        Vec3d way = new Vec3d(dx, 0, dz).normalize();
        Effects.repeat(world, 7, 2, step -> {
            SpellEntity.spawn(world, SpellKind.SIGIL, player.getPos().add(way.multiply(2 + step * 2)).add(0, 0.1, 0), 0.7F, 20).tint(0xE8D8A0);
            return true;
        });
        Abilities.sound(player, Sounds.WHEEL, 1.2F);
        player.sendMessage(Text.translatable("message.minevia_elements.thread", (int) Math.hypot(dx, dz),
                Text.translatable("direction.minevia_elements." + side)), false);
    }

    /** Награда хозяина: каждому игроку рядом своя реликвия, причём сначала те, которых у него ещё не было. */
    static void reward(ServerWorld world, Vec3d at, int boss) {
        ElementState state = ElementState.get(world.getServer());
        Box area = new Box(at, at).expand(32);
        for (ServerPlayerEntity player : world.getEntitiesByClass(ServerPlayerEntity.class, area, ServerPlayerEntity::isAlive)) {
            ElementState.Data data = state.getOrAssign(player.getUuid());
            List<Integer> fresh = new ArrayList<>();
            for (int i = boss * 3; i < boss * 3 + 3; i++) {
                if ((data.relics >> i & 1) == 0) {
                    fresh.add(i);
                }
            }
            if (fresh.isEmpty()) {
                player.giveItemStack(new ItemStack(MineviaElements.ELEMENT_CORE));
                player.sendMessage(Text.translatable("message.minevia_elements.relics_done"), false);
                continue;
            }
            int chosen = fresh.get(world.random.nextInt(fresh.size()));
            data.relics |= 1 << chosen;
            state.markDirty();
            ItemStack relic = new ItemStack(MineviaElements.RELICS[chosen]);
            player.sendMessage(Text.translatable("message.minevia_elements.relic", relic.getName().copy().formatted(Formatting.GOLD)), false);
            player.giveItemStack(relic);
        }
    }
}
