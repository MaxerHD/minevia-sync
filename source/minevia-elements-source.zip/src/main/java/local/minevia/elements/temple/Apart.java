package local.minevia.elements.temple;

import java.util.Set;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.structure.StructureSet;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.biome.source.BiomeSource;
import net.minecraft.world.gen.chunk.placement.StructurePlacementCalculator;
import net.minecraft.world.gen.structure.Structure;

/**
 * Держит наши строения подальше от деревень, крепостей и больших подземелий других модов.
 * Проверка стоит внутри самого строения, поэтому и /locate, и поиск в меню показывают только то, что действительно есть.
 */
final class Apart {
    private static final Identifier TEMPLES = Identifier.of("minevia_elements", "temples");
    /**
     * Только то, что стоит на поверхности и большое. В сборке ещё десятки наборов могил и руин: если обходить и их,
     * свободного места почти не остаётся, и подземелий не будет совсем.
     */
    private static final Set<String> NEIGHBOURS = Set.of("minecraft:villages", "minecraft:pillager_outposts", "minecraft:woodland_mansions",
            "minecraft:desert_pyramids", "minecraft:jungle_temples", "towns_and_towers:towns", "towns_and_towers:towers",
            "dungeons_arise:major_structures", "dungeons_arise:minor_structures");
    private static final int KEEP_AWAY_CHUNKS = 4;

    private static volatile StructurePlacementCalculator calculator;
    private static volatile BiomeSource source;
    private static volatile long seed;

    private Apart() {
    }

    private static StructurePlacementCalculator calculator(Structure.Context context) {
        StructurePlacementCalculator known = calculator;
        if (known == null || source != context.biomeSource() || seed != context.seed()) {
            known = StructurePlacementCalculator.create(context.noiseConfig(), context.seed(), context.biomeSource(),
                    context.dynamicRegistryManager().getWrapperOrThrow(RegistryKeys.STRUCTURE_SET));
            calculator = known;
            source = context.biomeSource();
            seed = context.seed();
        }
        return known;
    }

    /** Есть ли рядом большое чужое строение. Подземелье обходит и храмы, а храм подземелья не проверяет, иначе они убирали бы друг друга. */
    static boolean crowded(Structure.Context context, boolean dungeon) {
        StructurePlacementCalculator placements = calculator(context);
        ChunkPos at = context.chunkPos();
        for (RegistryEntry<StructureSet> set : placements.getStructureSets()) {
            boolean neighbour = dungeon && set.matchesId(TEMPLES)
                    || set.getKey().map(key -> NEIGHBOURS.contains(key.getValue().toString())).orElse(false);
            if (neighbour && placements.canGenerate(set, at.x, at.z, KEEP_AWAY_CHUNKS)) {
                return true;
            }
        }
        return false;
    }
}
