package local.minevia.elements;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Поддержка союзников и оружие света. */
final class StyleLight {
    private StyleLight() { }

    static void cast(ServerPlayerEntity p, int slot, int path, int level) {
        Abilities.sound(p, Sounds.LIGHT_CAST, slot == 9 ? 0.7F : 1);
        switch (slot) {
            case 4 -> ray(p, level);
            case 1 -> {
                LivingEntity ally = StyleSupport.ally(p, 22);
                ally.heal(5 + level * 2);
                if (level >= 3) StyleSupport.cleanse(ally);
                if (level >= 5) { Abilities.buff(ally, StatusEffects.REGENERATION, 100, 1); Abilities.buff(ally, StatusEffects.ABSORPTION, 100, 0); }
                StyleSupport.model(p, SpellKind.LIGHT_HEAL, ally.getPos(), 1, 45, self -> self.setPosition(ally.getPos()));
            }
            case 2 -> {
                LivingEntity ally = StyleSupport.ally(p, 18);
                Abilities.buff(ally, StatusEffects.ABSORPTION, 200, 1);
                Abilities.buff(ally, StatusEffects.RESISTANCE, 100, 1);
                if (level >= 3) Abilities.buff(ally, StatusEffects.FIRE_RESISTANCE, 200, 0);
                if (level >= 5) StyleSupport.model(p, SpellKind.LIGHT_FAITH, ally.getPos(), 2, 100, self -> {
                    self.setPosition(ally.getPos());
                    if (self.age % 20 == 0) StyleSupport.area(p, ally.getPos(), 3, 4, null);
                });
                StyleSupport.model(p, SpellKind.LIGHT_FAITH, ally.getPos(), 1.3F, 100, self -> self.setPosition(ally.getPos()));
            }
            case 3 -> {
                for (PlayerEntity ally : allies(p, p.getPos(), 7)) {
                    StyleSupport.cleanse(ally);
                    Abilities.buff(ally, StatusEffects.FIRE_RESISTANCE, 80, 0);
                    if (level >= 3) ally.heal(4);
                    if (level >= 5) Abilities.buff(ally, StatusEffects.RESISTANCE, 120, 1);
                }
                StyleSupport.model(p, SpellKind.LIGHT_CLEANSE, p.getPos(), 6, 28, null);
            }
            case 0 -> {
                Vec3d at = Skills.aimGround(p, 32);
                column(p, at, level);
            }
            case 5 -> {
                if (path == 1) SkillVariants.hammerCharge(p, level);
                else sanctuary(p, level);
            }
            case 6 -> {
                if (path == 1) {
                    Abilities.buff(p, StatusEffects.RESISTANCE, 220, 1);
                    StyleSupport.follow(p, SpellKind.LIGHT_ARMOR, 220, self -> {
                        if (self.age % 20 == 0) StyleSupport.area(p, p.getPos().add(0, 1, 0), 3, 2 + level * 0.5F,
                                e -> Abilities.push(e, e.getPos().subtract(p.getPos()).normalize().multiply(0.5)));
                    });
                } else SkillVariants.blessingShields(p, level);
            }
            case 7 -> SkillVariants.rescue(p, level);
            case 8 -> {
                LivingEntity ally = StyleSupport.ally(p, 25);
                StyleSupport.model(p, SpellKind.LIGHT_SPARK, ally.getPos(), 0.85F, 180, self -> {
                    self.setPosition(ally.getPos().add(0, 1.4, 0));
                    if (!ally.isAlive()) { self.discard(); return; }
                    if (ally.getHealth() <= ally.getMaxHealth() * 0.4F) {
                        ally.heal(8 + level * 2);
                        Abilities.buff(ally, StatusEffects.RESISTANCE, 50, 1);
                        self.discard();
                    }
                });
            }
            case 9 -> SkillVariants.judgmentShield(p, level);
        }
    }

    private static void column(ServerPlayerEntity p, Vec3d at, int level) {
        float radius = 1.5F * (level >= 2 ? 2.8F : 1.8F);
        StyleSupport.model(p, SpellKind.DANGER_RING, at, radius, 16, null).tint(Element.LIGHT.color);
        StyleSupport.model(p, SpellKind.LIGHT_COLUMN, at, radius, 40, self -> {
            if (self.age == 16 || level >= 3 && self.age == 24) {
                StyleSupport.area(p, at.add(0, 1.5, 0), radius + 1.5, 7 + level, e -> {
                    if (level >= 4) Abilities.debuff(e, StatusEffects.WEAKNESS, 100, 1);
                });
                Flourish.blast(p.getServerWorld(), at, radius * 1.6F, Element.LIGHT.color);
                Abilities.soundAt(p.getServerWorld(), at, Sounds.LIGHT_HIT, 1);
            }
            if (level >= 5 && self.age == 32) {
                StyleSupport.model(p, SpellKind.LIGHT_JUDGMENT, at, radius * 1.5F, 14, null);
                StyleSupport.area(p, at.add(0, 1, 0), radius * 1.7, 10 + level, null);
                for (PlayerEntity ally : allies(p, at, radius * 1.7)) { ally.heal(4); StyleSupport.cleanse(ally); }
            }
        });
    }

    static java.util.List<PlayerEntity> allies(ServerPlayerEntity p, Vec3d at, double radius) {
        return p.getServerWorld().getEntitiesByClass(PlayerEntity.class,
                new net.minecraft.util.math.Box(at, at).expand(radius), e -> e.isAlive() && !e.isSpectator() && p.canSee(e));
    }

    private static void ray(ServerPlayerEntity p, int level) {
        Vec3d from = p.getEyePos();
        Vec3d end = p.raycast(36, 1, false).getPos();
        Vec3d span = end.subtract(from);
        StyleSupport.model(p, SpellKind.LIGHT_RAY, from, (float) span.length(), 12, null).facing(span);
        var struck = new java.util.HashSet<java.util.UUID>();
        StyleSupport.shot(p, SpellKind.LIGHT_RAY, from, span.normalize().multiply(3), 0.35F, 12, true,
                (self, e) -> {
                    if (struck.add(e.getUuid())) StyleSupport.hit(p, e, 6 + level * 1.5F);
                    if (level >= 3) Abilities.debuff(e, StatusEffects.WEAKNESS, 80, 1);
                    if (level >= 5) StyleSupport.area(p, e.getPos(), 2.5, 4, null);
                    Abilities.soundAt(p.getServerWorld(), e.getPos(), Sounds.LIGHT_HIT, 1.2F);
                }, null);
    }

    private static void sanctuary(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 24);
        for (PlayerEntity ally : allies(p, at, 5)) Abilities.buff(ally, StatusEffects.ABSORPTION, 200, 1);
        StyleSupport.field(p, SpellKind.LIGHT_SANCTUARY, at, 5, 200, 20, self -> {
            for (PlayerEntity ally : allies(p, at, 5)) {
                Abilities.buff(ally, StatusEffects.FIRE_RESISTANCE, 35, 0);
                Abilities.buff(ally, StatusEffects.RESISTANCE, 35, 0);
            }
            for (net.minecraft.entity.projectile.ProjectileEntity shot : p.getServerWorld().getEntitiesByClass(net.minecraft.entity.projectile.ProjectileEntity.class,
                    new net.minecraft.util.math.Box(at, at).expand(5), shot -> shot.getOwner() instanceof LivingEntity owner && Abilities.canHit(owner, p))) shot.discard();
            for (LivingEntity e : Abilities.monstersAt(p, at, 5)) {
                if (p.canSee(e)) Abilities.push(e, e.getPos().subtract(at).normalize().multiply(0.5));
            }
        });
    }
}
