package local.minevia.elements;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Поддержка союзников и оружие света. */
final class StyleLight {
    private StyleLight() { }

    static void cast(ServerPlayerEntity p, int slot, int path, int level) {
        Abilities.sound(p, Sounds.LIGHT_CAST, slot == 9 ? 0.7F : 1);
        switch (slot) {
            case 0 -> ray(p, level);
            case 1 -> {
                LivingEntity ally = StyleSupport.ally(p, 22);
                ally.heal(5 + level * 2);
                StyleSupport.model(p, SpellKind.LIGHT_HEAL, ally.getPos(), 1, 45, self -> self.setPosition(ally.getPos()));
            }
            case 2 -> {
                LivingEntity ally = StyleSupport.ally(p, 18);
                Abilities.buff(ally, StatusEffects.ABSORPTION, 200, 1);
                Abilities.buff(ally, StatusEffects.RESISTANCE, 100, 1);
                StyleSupport.model(p, SpellKind.LIGHT_FAITH, ally.getPos(), 1.3F, 100, self -> self.setPosition(ally.getPos()));
            }
            case 3 -> {
                for (PlayerEntity ally : allies(p, p.getPos(), 7)) {
                    StyleSupport.cleanse(ally);
                    Abilities.buff(ally, StatusEffects.FIRE_RESISTANCE, 80, 0);
                }
                StyleSupport.model(p, SpellKind.LIGHT_CLEANSE, p.getPos(), 6, 28, null);
            }
            case 4 -> {
                Vec3d at = Skills.aimGround(p, 32);
                StyleSupport.field(p, SpellKind.LIGHT_COLUMN, at, 3, 70, 10, self -> {
                    StyleSupport.area(p, at.add(0, 2, 0), 3.8, 4 + level, null);
                    if (self.age % 20 == 0) Abilities.soundAt(p.getServerWorld(), at, Sounds.LIGHT_HIT, 1);
                });
            }
            case 5 -> {
                if (path == 1) {
                    Vec3d at = Skills.aimGround(p, 20);
                    StyleSupport.fall(p, SpellKind.LIGHT_HAMMER, at, 2.8F, 16, point ->
                            StyleSupport.area(p, point.add(0, 1, 0), 4.5, 12 + level * 2,
                                    e -> { StyleSupport.root(e, 35); Abilities.debuff(e, StatusEffects.WEAKNESS, 80, 1); }));
                } else sanctuary(p, level);
            }
            case 6 -> {
                if (path == 1) {
                    Abilities.buff(p, StatusEffects.RESISTANCE, 220, 1);
                    StyleSupport.follow(p, SpellKind.LIGHT_ARMOR, 220, self -> {
                        if (self.age % 20 == 0) StyleSupport.area(p, p.getPos().add(0, 1, 0), 3, 2 + level * 0.5F,
                                e -> Abilities.push(e, e.getPos().subtract(p.getPos()).normalize().multiply(0.5)));
                    });
                } else {
                    for (PlayerEntity ally : allies(p, p.getPos(), 10)) {
                        Abilities.buff(ally, StatusEffects.REGENERATION, 200, 1);
                        Abilities.buff(ally, StatusEffects.SPEED, 200, 0);
                        Abilities.buff(ally, StatusEffects.ABSORPTION, 200, 0);
                        StyleSupport.model(p, SpellKind.LIGHT_BLESSING, ally.getPos(), 1, 200, self -> self.setPosition(ally.getPos()));
                    }
                }
            }
            case 7 -> {
                Abilities.buff(p, StatusEffects.SLOW_FALLING, 180, 0);
                StyleSupport.follow(p, SpellKind.LIGHT_WINGS, 100, self -> {
                    if (self.age < 45) Abilities.push(p, Spells.flatLook(p).multiply(0.6).add(0, p.isSneaking() ? -0.1 : 0.28, 0));
                    p.fallDistance = 0;
                });
            }
            case 8 -> {
                LivingEntity ally = StyleSupport.ally(p, 25);
                StyleSupport.model(p, SpellKind.LIGHT_SPARK, ally.getPos(), 0.85F, 180, self -> {
                    self.setPosition(ally.getPos().add(0, 1.4, 0));
                    if (!ally.isAlive()) { self.discard(); return; }
                    if (ally.getHealth() <= ally.getMaxHealth() * 0.4F) {
                        ally.heal(8 + level * 2);
                        Abilities.buff(ally, StatusEffects.RESISTANCE, 50, 1);
                        self.discard();
                    }
                });
            }
            case 9 -> {
                Vec3d at = Skills.aimGround(p, 42);
                StyleSupport.field(p, SpellKind.LIGHT_JUDGMENT, at, 7, 90, 15, self -> {
                    StyleSupport.area(p, at.add(0, 2, 0), 7, 7 + level * 1.2F, e -> Abilities.debuff(e, StatusEffects.WEAKNESS, 40, 0));
                    for (PlayerEntity ally : allies(p, at, 7)) { ally.heal(2 + level * 0.3F); StyleSupport.cleanse(ally); }
                    Abilities.soundAt(p.getServerWorld(), at, Sounds.LIGHT_HIT, 0.7F);
                });
            }
        }
    }

    static java.util.List<PlayerEntity> allies(ServerPlayerEntity p, Vec3d at, double radius) {
        return p.getServerWorld().getEntitiesByClass(PlayerEntity.class,
                new net.minecraft.util.math.Box(at, at).expand(radius), e -> e.isAlive() && !e.isSpectator() && p.canSee(e));
    }

    private static void ray(ServerPlayerEntity p, int level) {
        Vec3d from = p.getEyePos();
        Vec3d end = p.raycast(36, 1, false).getPos();
        Vec3d span = end.subtract(from);
        StyleSupport.model(p, SpellKind.LIGHT_RAY, from, (float) span.length(), 12, null).facing(span);
        var struck = new java.util.HashSet<java.util.UUID>();
        StyleSupport.shot(p, SpellKind.LIGHT_RAY, from, span.normalize().multiply(3), 0.35F, 12, true,
                (self, e) -> {
                    if (struck.add(e.getUuid())) StyleSupport.hit(p, e, 6 + level * 1.5F);
                    Abilities.soundAt(p.getServerWorld(), e.getPos(), Sounds.LIGHT_HIT, 1.2F);
                }, null);
    }

    private static void sanctuary(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 24);
        StyleSupport.field(p, SpellKind.LIGHT_SANCTUARY, at, 5, 200, 20, self -> {
            for (PlayerEntity ally : allies(p, at, 5)) {
                ally.heal(2 + level * 0.5F);
                Abilities.buff(ally, StatusEffects.RESISTANCE, 35, 0);
            }
            for (LivingEntity e : Abilities.monstersAt(p, at, 5)) {
                if (p.canSee(e)) Abilities.push(e, e.getPos().subtract(at).normalize().multiply(0.5));
            }
        });
    }
}
