package local.minevia.elements;

import java.util.List;
import java.util.Optional;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.block.AbstractCandleBlock;
import net.minecraft.block.BellBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.ConcretePowderBlock;
import net.minecraft.block.CropBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FarmlandBlock;
import net.minecraft.block.LeveledCauldronBlock;
import net.minecraft.block.SaplingBlock;
import net.minecraft.block.TntBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.FlyingEntity;
import net.minecraft.entity.mob.MagmaCubeEntity;
import net.minecraft.entity.mob.StrayEntity;
import net.minecraft.entity.passive.BatEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.state.property.Properties;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.dimension.NetherPortal;

/**
 * Стихии ведут себя как настоящие: огонь гаснет в воде и поджигает, вода тушит и застужает лаву,
 * воздух задувает и разносит лёгкое, камень бьёт стекло. Менять блоки можно только там, где игроку
 * разрешено строить. Правило mineviaElementsWorld выключает все изменения блоков разом.
 */
public final class Nature {
    public static final GameRules.Key<GameRules.BooleanRule> CHANGE_WORLD = GameRuleRegistry.register(
            "mineviaElementsWorld", GameRules.Category.MISC, GameRuleFactory.createBooleanRule(true));

    /** Правило mineviaFriendlyFire: навыки задевают других игроков, только если его включили. */
    public static final GameRules.Key<GameRules.BooleanRule> FRIENDLY_FIRE = GameRuleRegistry.register(
            "mineviaFriendlyFire", GameRules.Category.PLAYER, GameRuleFactory.createBooleanRule(false));

    private static final int MOST_BROKEN = 12;
    private static final int WATER_LIFE_IN_HEAT = 60;

    private Nature() {
    }

    static void init() {
    }

    private static boolean allowed(ServerWorld world, ServerPlayerEntity player, BlockPos pos) {
        return player != null && world.getGameRules().getBoolean(CHANGE_WORLD) && world.isChunkLoaded(pos) && player.canModifyAt(world, pos);
    }

    private static Iterable<BlockPos> around(Vec3d center, double radius) {
        int reach = (int) Math.ceil(radius);
        BlockPos middle = BlockPos.ofFloored(center);
        return BlockPos.iterate(middle.add(-reach, -reach, -reach), middle.add(reach, reach, reach));
    }

    private static boolean inside(BlockPos pos, Vec3d center, double radius) {
        return pos.toCenterPos().squaredDistanceTo(center) <= radius * radius;
    }

    /** Маленькое облачко пара: шипит вода на огне, гаснет шар. Вреда не наносит. */
    static void steam(ServerWorld world, Vec3d at, float size) {
        SpellEntity.spawn(world, SpellKind.STEAM_CLOUD, at.add(0, -0.3, 0), size, 30);
        Abilities.soundAt(world, at, Sounds.STEAM, 1.4F);
    }

    // ------------------------------------------------------------------ каждый тик

    /** Снаряд со стихией встретил что-то на лету. Вызывается из самой способности каждый тик. */
    static void tick(SpellEntity self) {
        ServerWorld world = (ServerWorld) self.getWorld();
        ServerPlayerEntity player = self.caster();
        BlockPos pos = self.getBlockPos();
        boolean inWater = world.getFluidState(pos).isIn(FluidTags.WATER);
        boolean inLava = world.getFluidState(pos).isIn(FluidTags.LAVA);
        SpellKind kind = self.kind();
        switch (self.charge()) {
            case FIRE -> {
                if (kind == SpellKind.FIREBALL && inWater) {
                    steam(world, self.getPos(), 0.8F);
                    self.discard();
                } else if (kind == SpellKind.FIREBALL && world.getBlockState(pos).isOf(Blocks.COBWEB) && allowed(world, player, pos)) {
                    // Паутина не останавливает шар, поэтому сгорает на пролёте, а не от взрыва.
                    world.breakBlock(pos, false);
                } else if (kind == SpellKind.FIREBALL && world.getBlockState(pos).isAir() && touchesObsidian(world, pos) && allowed(world, player, pos)) {
                    // Шар, пролетевший через рамку, зажигает портал: прицельно попадать в обсидиан не нужно.
                    lightPortal(world, pos);
                }
            }
            case WATER -> {
                if (kind == SpellKind.WATER_BLOB) {
                    if (world.getDimension().ultrawarm() && self.age > WATER_LIFE_IN_HEAT) {
                        steam(world, self.getPos(), 0.9F);
                        self.discard();
                    } else if (inLava) {
                        douse(world, player, self.getPos(), 2.6);
                        self.discard();
                    } else if (self.age % 3 == 0) {
                        douse(world, player, self.getPos(), 1.8);
                    }
                } else if (kind == SpellKind.WATER_WAVE && self.age % 4 == 0) {
                    douse(world, player, self.getPos().add(0, 0.5, 0), 3.0);
                }
            }
            case EARTH -> {
                if ((kind == SpellKind.BOULDER || kind == SpellKind.EARTH_CHUNK) && inLava) {
                    self.infuse(Element.FIRE, SpellKind.MAGMA_BOULDER);
                    Abilities.soundAt(world, self.getPos(), Sounds.MAGMA, 1.2F);
                } else if ((kind == SpellKind.BOULDER || kind == SpellKind.EARTH_CHUNK || kind == SpellKind.MAGMA_BOULDER) && inWater) {
                    self.setVelocity(self.getVelocity().multiply(0.8));
                    if (kind == SpellKind.MAGMA_BOULDER) {
                        self.infuse(null, SpellKind.BOULDER);
                        steam(world, self.getPos(), 0.9F);
                    }
                }
            }
            case AIR -> {
                if (self.age % 4 == 0) {
                    if (kind == SpellKind.WIND_ORB) {
                        pull(world, self.getPos(), 5);
                    } else if (kind == SpellKind.TORNADO) {
                        pull(world, self.getPos().add(0, 1, 0), 6);
                        blow(world, player, self.getPos().add(0, 1, 0), 3.5, Vec3d.ZERO);
                    } else if (kind == SpellKind.GREAT_TORNADO) {
                        pull(world, self.getPos().add(0, 2, 0), 15);
                        blow(world, player, self.getPos().add(0, 1, 0), 9, Vec3d.ZERO);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ огонь

    /**
     * Огонь: зажигает TNT, костры, свечи и портал, топит лёд и снег, сжигает паутину, жарит предметы на земле.
     * Настоящего пламени не ставит: пожар в лесу убил бы кадры, а игрокам он не нужен.
     */
    static void burn(ServerWorld world, ServerPlayerEntity player, Vec3d center, double radius) {
        for (ItemEntity item : world.getEntitiesByClass(ItemEntity.class, new Box(center, center).expand(radius), Entity::isAlive)) {
            cook(world, item);
        }
        for (BlockPos pos : around(center, radius)) {
            if (inside(pos, center, radius) && allowed(world, player, pos)) {
                burnBlock(world, pos.toImmutable());
            }
        }
    }

    private static void burnBlock(ServerWorld world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        Block block = state.getBlock();
        if (block instanceof TntBlock) {
            TntBlock.primeTnt(world, pos);
            world.removeBlock(pos, false);
        } else if ((block instanceof CampfireBlock && CampfireBlock.canBeLit(state)) || (block instanceof AbstractCandleBlock && !state.get(Properties.LIT)
                && !state.get(Properties.WATERLOGGED))) {
            world.setBlockState(pos, state.with(Properties.LIT, true));
        } else if (state.isOf(Blocks.COBWEB)) {
            world.breakBlock(pos, false);
        } else if (state.isOf(Blocks.ICE) || state.isOf(Blocks.FROSTED_ICE)) {
            world.setBlockState(pos, Blocks.WATER.getDefaultState());
        } else if (state.isOf(Blocks.SNOW) || state.isOf(Blocks.SNOW_BLOCK) || state.isOf(Blocks.POWDER_SNOW)) {
            world.removeBlock(pos, false);
        } else if (state.isOf(Blocks.WET_SPONGE)) {
            world.setBlockState(pos, Blocks.SPONGE.getDefaultState());
        } else if (state.isAir() && touchesObsidian(world, pos)) {
            lightPortal(world, pos);
        }
    }

    private static boolean touchesObsidian(ServerWorld world, BlockPos pos) {
        for (Direction side : Direction.values()) {
            if (world.getBlockState(pos.offset(side)).isOf(Blocks.OBSIDIAN)) {
                return true;
            }
        }
        return false;
    }

    /** Портал зажигается сразу, без блока огня: только если рамка действительно собрана. */
    private static void lightPortal(ServerWorld world, BlockPos pos) {
        for (Direction.Axis axis : new Direction.Axis[] {Direction.Axis.X, Direction.Axis.Z}) {
            Optional<NetherPortal> portal = NetherPortal.getNewPortal(world, pos, axis);
            if (portal.isPresent()) {
                portal.get().createPortal();
                return;
            }
        }
    }

    /** Предметы на земле жарятся как в печи: сырое мясо становится готовым, руда слитком. */
    private static void cook(ServerWorld world, ItemEntity item) {
        ItemStack stack = item.getStack();
        world.getRecipeManager().getFirstMatch(RecipeType.SMELTING, new SingleStackRecipeInput(stack), world).ifPresent(recipe -> {
            ItemStack result = recipe.value().getResult(world.getRegistryManager()).copy();
            result.setCount(result.getCount() * stack.getCount());
            item.setStack(result);
            item.setInvulnerable(true);
        });
    }

    // ------------------------------------------------------------------ вода

    /** Вода: тушит огонь и людей, застужает лаву, поливает грядки, наполняет котёл. Сама на месте не остаётся. */
    static void douse(ServerWorld world, ServerPlayerEntity player, Vec3d center, double radius) {
        boolean hissed = false;
        for (BlockPos pos : around(center, radius)) {
            if (inside(pos, center, radius) && allowed(world, player, pos)) {
                hissed |= douseBlock(world, pos.toImmutable());
            }
        }
        Box area = new Box(center, center).expand(radius);
        for (LivingEntity near : world.getEntitiesByClass(LivingEntity.class, area, LivingEntity::isOnFire)) {
            near.extinguish();
            hissed = true;
        }
        // Вода гасит запал: шашка снова становится предметом и не взрывается.
        for (TntEntity tnt : world.getEntitiesByClass(TntEntity.class, area, Entity::isAlive)) {
            tnt.dropStack(new ItemStack(Items.TNT));
            tnt.discard();
            hissed = true;
        }
        if (hissed) {
            steam(world, center, 1.0F);
        }
    }

    private static boolean douseBlock(ServerWorld world, BlockPos pos) {
        BlockState state = world.getBlockState(pos);
        Block block = state.getBlock();
        if (world.getFluidState(pos).isIn(FluidTags.LAVA)) {
            world.setBlockState(pos, (world.getFluidState(pos).isStill() ? Blocks.OBSIDIAN : Blocks.COBBLESTONE).getDefaultState());
            return true;
        }
        if (state.isOf(Blocks.FIRE) || state.isOf(Blocks.SOUL_FIRE)) {
            world.removeBlock(pos, false);
            return true;
        }
        if ((block instanceof CampfireBlock || block instanceof AbstractCandleBlock) && state.get(Properties.LIT)) {
            world.setBlockState(pos, state.with(Properties.LIT, false));
            return true;
        }
        if (block instanceof FarmlandBlock) {
            world.setBlockState(pos, state.with(FarmlandBlock.MOISTURE, FarmlandBlock.MAX_MOISTURE));
        } else if (state.isOf(Blocks.SPONGE)) {
            world.setBlockState(pos, Blocks.WET_SPONGE.getDefaultState());
        } else if (state.isOf(Blocks.CAULDRON)) {
            world.setBlockState(pos, Blocks.WATER_CAULDRON.getDefaultState().with(LeveledCauldronBlock.LEVEL, LeveledCauldronBlock.MAX_LEVEL));
        } else if (block instanceof ConcretePowderBlock) {
            Identifier id = Registries.BLOCK.getId(block);
            Block hard = Registries.BLOCK.get(Identifier.of(id.getNamespace(), id.getPath().replace("_powder", "")));
            world.setBlockState(pos, hard.getDefaultState());
        }
        return false;
    }

    /** Лёд: вода под ногами застывает, и по ней можно пройти, пока она не растает. */
    static void freeze(ServerWorld world, ServerPlayerEntity player, Vec3d center, double radius) {
        for (BlockPos found : around(center, radius)) {
            BlockPos pos = found.toImmutable();
            if (!inside(pos, center, radius) || !allowed(world, player, pos)) {
                continue;
            }
            BlockState state = world.getBlockState(pos);
            if (state.isOf(Blocks.FIRE) || state.isOf(Blocks.SOUL_FIRE)) {
                world.removeBlock(pos, false);
            } else if (world.getFluidState(pos).isIn(FluidTags.LAVA) && world.getFluidState(pos).isStill()) {
                world.setBlockState(pos, Blocks.OBSIDIAN.getDefaultState());
            } else if (state.isOf(Blocks.WATER) && world.getFluidState(pos).isStill() && world.getBlockState(pos.up()).isAir()) {
                world.setBlockState(pos, Blocks.FROSTED_ICE.getDefaultState());
                world.scheduleBlockTick(pos, Blocks.FROSTED_ICE, 100 + world.random.nextInt(80));
            }
        }
    }

    /** Дождь растит посевы и саженцы под тучей. */
    static void grow(ServerWorld world, ServerPlayerEntity player, Vec3d center, double radius) {
        for (BlockPos found : around(center, radius)) {
            BlockPos pos = found.toImmutable();
            BlockState state = world.getBlockState(pos);
            if ((state.getBlock() instanceof CropBlock || state.getBlock() instanceof SaplingBlock) && allowed(world, player, pos)) {
                state.randomTick(world, pos, world.random);
            }
        }
    }

    // ------------------------------------------------------------------ воздух

    /** Воздух: задувает пламя и свечи, распахивает двери, разносит предметы, запалы и лодки. */
    static void blow(ServerWorld world, ServerPlayerEntity player, Vec3d center, double radius, Vec3d push) {
        for (BlockPos found : around(center, radius)) {
            BlockPos pos = found.toImmutable();
            if (!inside(pos, center, radius) || !allowed(world, player, pos)) {
                continue;
            }
            BlockState state = world.getBlockState(pos);
            if (state.isOf(Blocks.FIRE) || state.isOf(Blocks.SOUL_FIRE)) {
                world.removeBlock(pos, false);
            } else if (state.getBlock() instanceof AbstractCandleBlock && state.get(Properties.LIT)) {
                world.setBlockState(pos, state.with(Properties.LIT, false));
            } else if (push != Vec3d.ZERO && state.getBlock() instanceof DoorBlock door && door.getBlockSetType().canOpenByHand() && !state.get(DoorBlock.OPEN)) {
                door.setOpen(player, world, state, pos, true);
            }
        }
        if (push == Vec3d.ZERO) {
            return;
        }
        List<Entity> light = world.getOtherEntities(player, new Box(center, center).expand(radius),
                entity -> !(entity instanceof LivingEntity) && !(entity instanceof SpellEntity));
        for (Entity entity : light) {
            Abilities.push(entity, entity.getVelocity().add(push));
        }
    }

    /** Смерч и вихрь подбирают предметы и опыт: их можно собрать, не бегая по всему полю. */
    static void pull(ServerWorld world, Vec3d center, double radius) {
        Box area = new Box(center, center).expand(radius);
        List<Entity> loose = world.getEntitiesByClass(Entity.class, area, entity -> entity instanceof ItemEntity || entity instanceof ExperienceOrbEntity);
        for (Entity entity : loose) {
            Abilities.push(entity, center.subtract(entity.getPos()).multiply(0.14).add(0, 0.06, 0));
        }
    }

    // ------------------------------------------------------------------ камень

    /** Камень: бьёт стекло и лёд, сносит цветочные горшки и заставляет звонить колокол. */
    static void crush(ServerWorld world, ServerPlayerEntity player, Vec3d center, double radius) {
        int broken = 0;
        for (BlockPos found : around(center, radius)) {
            BlockPos pos = found.toImmutable();
            if (!inside(pos, center, radius) || !allowed(world, player, pos)) {
                continue;
            }
            BlockState state = world.getBlockState(pos);
            if (state.getBlock() instanceof BellBlock bell) {
                bell.ring(player, world, pos, Direction.NORTH);
            } else if (broken < MOST_BROKEN && !state.hasBlockEntity() && state.getHardness(world, pos) >= 0 && state.getHardness(world, pos) <= 0.6F
                    && state.getSoundGroup() == BlockSoundGroup.GLASS) {
                world.breakBlock(pos, true, player);
                broken++;
            }
        }
    }

    // ------------------------------------------------------------------ молния

    /** Молния: бежит по воде на всех, кто в ней стоит, поджигает шашки и заряжает криперов. */
    static void shock(ServerWorld world, ServerPlayerEntity player, LivingEntity target, float damage, int color) {
        Vec3d at = target.getBoundingBox().getCenter();
        if (target instanceof CreeperEntity creeper) {
            charge(creeper);
        }
        if (target.isTouchingWater()) {
            for (LivingEntity near : Abilities.livingAt(player, at, 9)) {
                if (near != target && near.isTouchingWater()) {
                    Paths.bolt(world, at, near.getBoundingBox().getCenter(), color);
                    Abilities.strike(player, near, damage * 0.6F);
                }
            }
        }
    }

    /** Удар молнии в землю: то, что от неё загорается, загорается. */
    static void lightningAt(ServerWorld world, ServerPlayerEntity player, Vec3d at) {
        for (BlockPos found : around(at, 2)) {
            BlockPos pos = found.toImmutable();
            if (world.getBlockState(pos).getBlock() instanceof TntBlock && allowed(world, player, pos)) {
                TntBlock.primeTnt(world, pos);
                world.removeBlock(pos, false);
            }
        }
    }

    private static void charge(CreeperEntity creeper) {
        NbtCompound data = new NbtCompound();
        creeper.writeCustomDataToNbt(data);
        data.putBoolean("powered", true);
        creeper.readCustomDataFromNbt(data);
    }

    // ------------------------------------------------------------------ урон

    /** Сила удара зависит от того, чем бьёшь и кого: вода против блейза, огонь в дождь, ветер против летунов. */
    static float scale(ServerPlayerEntity player, LivingEntity target, Element element, float amount) {
        if (target instanceof ElementBoss) {
            return amount;
        }
        if (target instanceof ElementMob spirit) {
            return amount * spirit.factor(element);
        }
        ServerWorld world = player.getServerWorld();
        boolean rain = world.hasRain(target.getBlockPos());
        boolean hot = world.getDimension().ultrawarm();
        boolean flyer = target instanceof FlyingEntity || target instanceof BatEntity;
        float scaled = amount;
        switch (element) {
            case FIRE -> {
                if (target.isFireImmune()) {
                    scaled *= 0.3F;
                }
                if (target.isSubmergedInWater()) {
                    scaled *= 0.5F;
                } else if (rain) {
                    scaled *= 0.75F;
                }
                if (target instanceof StrayEntity) {
                    scaled *= 1.4F;
                }
                if (hot) {
                    scaled *= 1.25F;
                }
                if (target instanceof CreeperEntity creeper) {
                    creeper.ignite();
                }
            }
            case WATER -> {
                if (target.hurtByWater()) {
                    scaled *= 2;
                }
                if (target instanceof MagmaCubeEntity) {
                    scaled *= 1.5F;
                }
                if (rain) {
                    scaled *= 1.25F;
                }
                if (hot) {
                    scaled *= 0.6F;
                }
                target.extinguish();
            }
            case EARTH -> {
                if (target instanceof AbstractSkeletonEntity) {
                    scaled *= 1.3F;
                }
                if (flyer) {
                    scaled *= 0.7F;
                }
            }
            case AIR -> {
                if (flyer) {
                    scaled *= 1.4F;
                }
            }
        }
        return scaled;
    }
}
