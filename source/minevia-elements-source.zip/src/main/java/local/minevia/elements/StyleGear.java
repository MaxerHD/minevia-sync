package local.minevia.elements;

import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.AttributeModifierSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/** Личное оружие восстанавливается сервером. */
public final class StyleGear {
    public static final Item SWORD = register("style_sword", Element.SWORD);
    public static final Item BOW = register("style_bow", Element.BOW);
    public static final Item DARK = register("dark_gloves", Element.DARK);
    public static final Item LIGHT = register("light_gloves", Element.LIGHT);
    private StyleGear() { }

    private static Item register(String id, Element element) {
        return Registry.register(Registries.ITEM, Identifier.of(MineviaElements.MOD_ID, id),
                new StyleGearItem(element, new Item.Settings().maxCount(1)));
    }

    public static Item item(Element element) {
        if (element == null || element.isNatural()) return null;
        return switch (element) { case SWORD -> SWORD; case BOW -> BOW; case DARK -> DARK; case LIGHT -> LIGHT; default -> null; };
    }
    public static boolean isGear(ItemStack stack) { return stack.getItem() instanceof StyleGearItem; }
    public static boolean gloves(ItemStack stack) { return stack.isOf(DARK) || stack.isOf(LIGHT); }
    public static int level(ItemStack stack) { return Math.clamp(data(stack).getInt("style_level"), 1, 5); }
    public static NbtCompound data(ItemStack stack) { return stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT).copyNbt(); }
    public static boolean equipped(PlayerEntity p, Element element) {
        if (element == null || element.isNatural()) return true;
        ItemStack stack = p.getMainHandStack();
        return stack.isOf(item(element)) && data(stack).containsUuid("style_owner") && data(stack).getUuid("style_owner").equals(p.getUuid());
    }
    static boolean require(ServerPlayerEntity p, Element element) {
        if (equipped(p, element)) return true;
        p.sendMessage(Text.translatable("message.minevia_elements.hold_style_weapon"), true);
        return false;
    }
    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) if (p.isAlive()) reconcile(p);
        });
        net.fabricmc.fabric.api.event.player.AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (isGear(player.getMainHandStack()) && player instanceof ServerPlayerEntity p) {
                var d = ElementState.get(p.getServer()).getOrAssign(p.getUuid());
                if (d.element == null || d.element.isNatural() || !equipped(p, d.element) || !Abilities.canHit(entity, p)) return net.minecraft.util.ActionResult.FAIL;
            }
            return net.minecraft.util.ActionResult.PASS;
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> reconcile(newPlayer));
    }
    public static void reconcile(ServerPlayerEntity p) {
        var d = ElementState.get(p.getServer()).getOrAssign(p.getUuid());
        Item wanted = item(d.element);
        ItemStack found = ItemStack.EMPTY;
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (!isGear(s)) continue;
            NbtCompound tag = data(s);
            if (wanted != null && s.isOf(wanted) && found.isEmpty()
                    && (!tag.containsUuid("style_owner") || tag.getUuid("style_owner").equals(p.getUuid()))) {
                found = s; s.setCount(1);
            } else inv.setStack(i, ItemStack.EMPTY);
        }
        ItemStack cursor = p.currentScreenHandler.getCursorStack();
        if (isGear(cursor)) {
            NbtCompound cursorTag = data(cursor);
            if (found.isEmpty() && wanted != null && cursor.isOf(wanted)
                    && cursorTag.containsUuid("style_owner") && cursorTag.getUuid("style_owner").equals(p.getUuid())
                    && p.currentScreenHandler instanceof net.minecraft.screen.PlayerScreenHandler) { found = cursor; found.setCount(1); }
            else p.currentScreenHandler.setCursorStack(ItemStack.EMPTY);
        }
        for (var slot : p.currentScreenHandler.slots)
            if (slot.inventory != inv && isGear(slot.getStack())) slot.setStack(ItemStack.EMPTY);
        for (int i = 0; i < p.getEnderChestInventory().size(); i++)
            if (isGear(p.getEnderChestInventory().getStack(i))) p.getEnderChestInventory().setStack(i, ItemStack.EMPTY);
        if (wanted == null) return;
        if (!Control.active(p) && data(found).contains("style_draw_start")) {
            NbtCompound clean = data(found); clean.remove("style_draw_start");
            found.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(clean));
        }
        int targetLevel = Mastery.level(d.skills[0]);
        boolean created = found.isEmpty();
        int before = created ? targetLevel : level(found);
        if (created) found = new ItemStack(wanted);
        NbtCompound tag = data(found);
        if (created || !tag.containsUuid("style_owner") || level(found) != targetLevel) {
            tag.putUuid("style_owner", p.getUuid());
            tag.putInt("style_level", targetLevel);
            if (targetLevel > before) tag.putLong("style_flash", p.getWorld().getTime());
            found.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(tag));
            double damage = d.element == Element.SWORD ? 4 + targetLevel * 1.4 : d.element == Element.BOW ? 1 : 1 + targetLevel * 0.65;
            found.set(DataComponentTypes.ATTRIBUTE_MODIFIERS, AttributeModifiersComponent.builder()
                    .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, new EntityAttributeModifier(Item.BASE_ATTACK_DAMAGE_MODIFIER_ID, damage, EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.MAINHAND)
                    .add(EntityAttributes.GENERIC_ATTACK_SPEED, new EntityAttributeModifier(Item.BASE_ATTACK_SPEED_MODIFIER_ID, d.element == Element.SWORD ? -2.4 : -1.5, EntityAttributeModifier.Operation.ADD_VALUE), AttributeModifierSlot.MAINHAND).build());
        }
        if (created) {
            int empty = inv.getEmptySlot();
            if (empty < 0) {
                empty = inv.selectedSlot;
                ItemStack displaced = inv.removeStack(empty);
                p.dropItem(displaced, false);
            }
            inv.setStack(empty, found);
        }
        if (targetLevel > before) {
            Abilities.sound(p, Sounds.SEAL_BREAK, 1.6F);
            Flourish.levelUp(p, d.element.color);
            p.sendMessage(Text.translatable("message.minevia_elements.weapon_up", targetLevel,
                    Text.translatable(d.element.abilityKey(0) + ".rank" + targetLevel)), true);
        }
        inv.markDirty();
    }
}
