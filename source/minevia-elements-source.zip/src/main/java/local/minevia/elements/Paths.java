package local.minevia.elements;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Вторая ступень: на шестом уровне игрок выбирает один из двух путей своей стихии, и шестая способность
 * зависит от этого выбора. Поэтому два игрока с одной стихией играют по-разному.
 */
final class Paths {
    private static final int LIGHTNING_COLOR = 0xBFD8FF;

    private Paths() {
    }

    static void cast(ServerPlayerEntity player, Element element, int path, int level) {
        switch (element) {
            case FIRE -> {
                if (path == 1) {
                    chainLightning(player, level);
                } else {
                    eruption(player, level);
                }
            }
            case WATER -> {
                if (path == 1) {
                    iceVolley(player, level);
                } else {
                    mist(player, level);
                }
            }
            case EARTH -> {
                if (path == 1) {
                    quicksand(player, level);
                } else {
                    blades(player, level);
                }
            }
            case AIR -> {
                if (path == 1) {
                    storm(player, level);
                } else {
                    vacuum(player, level);
                }
            }
        }
    }

    /** Луч между двумя точками: модель длиной в единицу растягивается на всё расстояние. */
    static void bolt(ServerWorld world, Vec3d from, Vec3d to, int color) {
        Vec3d span = to.subtract(from);
        SpellEntity.spawn(world, SpellKind.LIGHTNING, from, (float) span.length(), 8).facing(span).tint(color);
    }

    /** Молния бьёт в цель и перескакивает на соседних врагов, слабея с каждым прыжком. */
    private static void chainLightning(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.LIGHTNING, 1.0F);
        LivingEntity first = Abilities.aim(player, 26);
        Vec3d from = Spells.muzzle(player, 1.0).add(0, -0.3, 0);
        if (first == null) {
            Vec3d miss = Spells.crosshair(player, 26);
            bolt(world, from, miss, LIGHTNING_COLOR);
            Nature.lightningAt(world, player, miss);
            return;
        }
        Set<UUID> struck = new HashSet<>();
        LivingEntity target = first;
        float damage = 12 + level * 2;
        int jumps = Math.min(7, 2 + level / 2);
        for (int jump = 0; jump < jumps && target != null; jump++) {
            Vec3d at = target.getBoundingBox().getCenter();
            bolt(world, from, at, LIGHTNING_COLOR);
            struck.add(target.getUuid());
            Abilities.hurt(player, target, damage);
            Nature.shock(world, player, target, damage, LIGHTNING_COLOR);
            damage *= 0.78F;
            from = at;
            Vec3d origin = at;
            target = Abilities.livingAt(player, at, 9).stream()
                    .filter(near -> !struck.contains(near.getUuid()))
                    .min(Comparator.comparingDouble(near -> near.getPos().squaredDistanceTo(origin)))
                    .orElse(null);
        }
    }

    /** Извержение: из земли в точке прицела бьёт столб магмы и оставляет лужу. */
    private static void eruption(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d aim = Spells.crosshair(player, 26);
        double ground = Spells.groundAt(world, aim.add(0, 1, 0));
        Vec3d base = Double.isNaN(ground) ? aim : new Vec3d(aim.x, ground, aim.z);
        Abilities.soundAt(world, base, Sounds.MAGMA, 0.8F);
        SpellEntity.spawn(world, SpellKind.MAGMA_GEYSER, base, 1.6F * Spells.big(level), 30);
        Nature.burn(world, player, base.add(0, 1, 0), 3);
        for (LivingEntity near : Abilities.livingAt(player, base.add(0, 1.5, 0), 3.6)) {
            Abilities.hurt(player, near, 12 + level * 2);
            Abilities.push(near, new Vec3d(0, 1.0, 0));
            near.setOnFireFor(7);
        }
        Combos.magmaPool(player, base, level + 4);
    }

    /** Залп пяти ледяных копий: каждое летит в прицел на момент выстрела. */
    private static void iceVolley(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        int spears = Math.min(7, 3 + level / 2);
        Effects.repeat(world, spears, 4, step -> {
            if (!player.isAlive()) {
                return false;
            }
            Abilities.sound(player, Sounds.ICE_FORM, 1.3F);
            double side = (step - (spears - 1) / 2.0) * 0.55;
            Vec3d look = player.getRotationVector();
            Vec3d across = look.crossProduct(new Vec3d(0, 1, 0)).normalize();
            Vec3d start = Spells.muzzle(player, 1.6).add(across.multiply(side));
            Vec3d velocity = Spells.crosshair(player, 34).subtract(start).normalize().multiply(1.5);
            SpellEntity spear = SpellEntity.spawn(world, SpellKind.ICE_BOLT, start, 1.0F, 40).facing(velocity).charged(Element.WATER, player);
            spear.setVelocity(velocity);
            Set<UUID> struck = new HashSet<>();
            spear.logic(self -> {
                boolean ended = Spells.fly(self, player, 0.6, true, struck, (at, target) -> {
                    Abilities.pierce(player, target, 6 + level);
                    Abilities.debuff(target, StatusEffects.SLOWNESS, 80, 2);
                    target.setFrozenTicks(140);
                    return true;
                });
                if (ended) {
                    SpellEntity.spawn(world, SpellKind.WATER_SPLASH, self.getPos(), 0.5F, 15);
                    self.discard();
                }
            });
            return true;
        });
    }

    /** Туман вокруг игрока: друзья внутри лечатся, а враги слепнут и слабеют. */
    private static void mist(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = player.getPos();
        Abilities.soundAt(world, center, Sounds.STEAM, 0.8F);
        SpellEntity.spawn(world, SpellKind.MIST, center, 6.0F, 200).logic(self -> {
            if (self.age % 20 != 0) {
                return;
            }
            Box area = new Box(center, center).expand(8);
            for (PlayerEntity ally : world.getEntitiesByClass(PlayerEntity.class, area, PlayerEntity::isAlive)) {
                ally.heal(1 + level * 0.25F);
            }
            for (LivingEntity near : Abilities.monstersAt(player, center, 8)) {
                Abilities.debuff(near, StatusEffects.BLINDNESS, 40, 0);
                Abilities.debuff(near, StatusEffects.WEAKNESS, 40, 1);
            }
        });
    }

    /** Зыбучий песок: воронка в точке прицела затягивает врагов к центру. */
    private static void quicksand(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d aim = Spells.crosshair(player, 26);
        double ground = Spells.groundAt(world, aim.add(0, 1, 0));
        Vec3d base = Double.isNaN(ground) ? aim : new Vec3d(aim.x, ground, aim.z);
        Abilities.soundAt(world, base, Sounds.SAND, 1.0F);
        SpellEntity.spawn(world, SpellKind.SAND_PIT, base, 5.0F, 130).logic(self -> {
            for (LivingEntity near : Abilities.monstersAt(player, base.add(0, 1, 0), 5.5)) {
                Vec3d in = base.subtract(near.getPos());
                Abilities.push(near, new Vec3d(in.x, 0, in.z).multiply(0.09).add(0, -0.1, 0));
                Abilities.debuff(near, StatusEffects.SLOWNESS, 20, 3);
                if (self.age % 20 == 0) {
                    Abilities.hurt(player, near, 2 + level * 0.6F);
                    Abilities.debuff(near, StatusEffects.BLINDNESS, 30, 0);
                }
            }
        });
    }

    /** Клинки: шесть осколков железа кружат вокруг игрока, потом по одному летят в ближайших врагов. */
    private static void blades(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.METAL, 1.0F);
        int count = Math.min(8, 3 + level / 2);
        for (int i = 0; i < count; i++) {
            int index = i;
            int release = 26 + i * 5;
            Set<UUID> struck = new HashSet<>();
            SpellEntity blade = SpellEntity.spawn(world, SpellKind.METAL_BLADE, player.getEyePos(), 1.0F, 90).charged(Element.EARTH, player);
            blade.logic(self -> {
                if (!player.isAlive()) {
                    self.discard();
                    return;
                }
                if (self.age < release) {
                    double angle = index / (double) count * Math.PI * 2 + self.age * 0.22;
                    Vec3d spot = player.getPos().add(Math.cos(angle) * 2.0, 1.2 + 0.25 * Math.sin(angle * 2), Math.sin(angle) * 2.0);
                    Spells.hover(self, spot);
                    return;
                }
                if (self.age == release) {
                    Abilities.sound(player, Sounds.METAL, 1.3F);
                    LivingEntity near = Abilities.aim(player, 30);
                    if (near == null) {
                        near = Abilities.monstersAt(player, player.getPos(), 14).stream()
                                .min(Comparator.comparingDouble(entity -> entity.squaredDistanceTo(player))).orElse(null);
                    }
                    Vec3d goal = near != null ? near.getBoundingBox().getCenter() : Spells.crosshair(player, 30);
                    self.setVelocity(goal.subtract(self.getPos()).normalize().multiply(1.6));
                }
                boolean ended = Spells.fly(self, player, 0.7, true, struck, (at, target) -> {
                    Abilities.pierce(player, target, 7 + level * 1.5F);
                    return true;
                });
                if (ended) {
                    self.discard();
                }
            });
        }
    }

    /** Буря: туча над точкой прицела восемь секунд бьёт молниями по монстрам под собой. */
    private static void storm(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d aim = Spells.crosshair(player, 26);
        double ground = Spells.groundAt(world, aim.add(0, 1, 0));
        Vec3d base = Double.isNaN(ground) ? aim : new Vec3d(aim.x, ground, aim.z);
        Vec3d cloud = base.add(0, 9, 0);
        Abilities.soundAt(world, base, Sounds.THUNDER, 1.0F);
        SpellEntity.spawn(world, SpellKind.STORM_CLOUD, cloud, 5.0F, 170).logic(self -> {
            if (self.age < 16 || self.age % 14 != 0) {
                return;
            }
            List<LivingEntity> below = Abilities.monstersAt(player, base.add(0, 2, 0), 9.5);
            Vec3d strike;
            if (below.isEmpty()) {
                strike = base.add(world.random.nextDouble() * 12 - 6, 0, world.random.nextDouble() * 12 - 6);
            } else {
                LivingEntity target = below.get(world.random.nextInt(below.size()));
                strike = target.getBoundingBox().getCenter();
                Abilities.hurt(player, target, 7 + level * 1.5F);
                Nature.shock(world, player, target, 7 + level * 1.5F, LIGHTNING_COLOR);
            }
            Nature.lightningAt(world, player, strike);
            bolt(world, cloud.add(strike.subtract(cloud).normalize().multiply(1.5)), strike, LIGHTNING_COLOR);
            Abilities.soundAt(world, strike, Sounds.LIGHTNING, 0.8F);
        });
    }

    /** Вакуум: воздух полторы секунды стягивает врагов в точку, потом схлопывается с ударом. */
    private static void vacuum(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = Spells.crosshair(player, 22);
        Abilities.soundAt(world, center, Sounds.VACUUM, 1.0F);
        SpellEntity.spawn(world, SpellKind.VACUUM, center, 6.0F, 32).charged(Element.AIR, player).logic(self -> {
            for (LivingEntity near : Abilities.monstersAt(player, center, 8)) {
                Abilities.push(near, center.subtract(near.getBoundingBox().getCenter()).multiply(0.16));
            }
            if (self.age == 30) {
                SpellEntity.spawn(world, SpellKind.WIND_BURST, center, 3.6F, 14);
                Abilities.soundAt(world, center, Sounds.AIR_GUST, 0.7F);
                for (LivingEntity near : Abilities.livingAt(player, center, 4.5)) {
                    Abilities.hurt(player, near, 14 + level * 2);
                    Abilities.push(near, near.getPos().subtract(center).normalize().multiply(1.1).add(0, 0.5, 0));
                }
            }
        });
    }
}
