package local.minevia.elements.client;

import local.minevia.elements.AltarBlock;
import local.minevia.elements.AltarBlockEntity;
import local.minevia.elements.Element;
import local.minevia.elements.MineviaElements;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Над алтарём парит ядро его стихии. Когда страж разбужен, ядро гаснет. */
final class AltarRenderer implements BlockEntityRenderer<AltarBlockEntity> {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");

    AltarRenderer(BlockEntityRendererFactory.Context context) {
    }

    @Override
    public void render(AltarBlockEntity altar, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light, int overlay) {
        BlockState state = altar.getCachedState();
        SpellMesh mesh = SpellMesh.get("altar_core");
        if (mesh == null || !state.contains(AltarBlock.AWAKE) || !state.get(AltarBlock.AWAKE)) {
            return;
        }
        float time = (System.currentTimeMillis() % 100000L) / 50.0F;
        matrices.push();
        matrices.translate(0.5, 1.45 + Math.sin(time * 0.06) * 0.12, 0.5);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(time * 2.0F));
        matrices.scale(0.55F, 0.55F, 0.55F);
        int color = Element.values()[state.get(AltarBlock.ELEMENT)].color;
        mesh.draw(matrices.peek(), consumers.getBuffer(RenderLayer.getEntityTranslucentEmissive(WHITE)), time / 30 * mesh.frames(), true, color, 1.0F,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.PLAIN);
        matrices.pop();
    }
}
