package local.minevia.elements;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Свои звуки способностей. Как они собраны и откуда записи, написано в art/sounds.py и CREDITS.md. */
public final class Sounds {
    public static final SoundEvent FIRE_CAST = of("fire_cast");
    public static final SoundEvent FIRE_BLAST = of("fire_blast");
    public static final SoundEvent FIRE_RING = of("fire_ring");
    public static final SoundEvent FIRE_ARMOR = of("fire_armor");
    public static final SoundEvent FIRE_CHARGE = of("fire_charge");
    public static final SoundEvent FLAME_LOOP = of("flame_loop");
    public static final SoundEvent WATER_RISE = of("water_rise");
    public static final SoundEvent WATER_HIT = of("water_hit");
    public static final SoundEvent WATER_HEAL = of("water_heal");
    public static final SoundEvent WATER_WHIP = of("water_whip");
    public static final SoundEvent WATER_WAVE = of("water_wave");
    public static final SoundEvent ICE_FORM = of("ice_form");
    public static final SoundEvent EARTH_RISE = of("earth_rise");
    public static final SoundEvent EARTH_THROW = of("earth_throw");
    public static final SoundEvent EARTH_HIT = of("earth_hit");
    public static final SoundEvent EARTH_QUAKE = of("earth_quake");
    public static final SoundEvent EARTH_ARMOR = of("earth_armor");
    public static final SoundEvent EARTH_SPIKE = of("earth_spike");
    public static final SoundEvent EARTH_WALL = of("earth_wall");
    public static final SoundEvent AIR_DASH = of("air_dash");
    public static final SoundEvent AIR_SAW = of("air_saw");
    public static final SoundEvent AIR_GUST = of("air_gust");
    public static final SoundEvent AIR_TORNADO = of("air_tornado");
    public static final SoundEvent AIR_DOME = of("air_dome");
    public static final SoundEvent COMBO = of("combo");
    public static final SoundEvent STEAM = of("steam");
    public static final SoundEvent MAGMA = of("magma");
    public static final SoundEvent LIGHTNING = of("lightning");
    public static final SoundEvent THUNDER = of("thunder");
    public static final SoundEvent METAL = of("metal");
    public static final SoundEvent SAND = of("sand");
    public static final SoundEvent VACUUM = of("vacuum");
    public static final SoundEvent ALTAR = of("altar");
    public static final SoundEvent TRAP = of("trap");
    public static final SoundEvent BOSS_AWAKE = of("boss_awake");
    public static final SoundEvent BOSS_HURT = of("boss_hurt");
    public static final SoundEvent BOSS_DEATH = of("boss_death");
    public static final SoundEvent SEAL_BREAK = of("seal_break");
    public static final SoundEvent WHEEL = of("wheel");
    public static final SoundEvent SWORD_SWING = of("sword_swing");
    public static final SoundEvent SWORD_HIT = of("sword_hit");
    public static final SoundEvent BOW_SHOT = of("bow_shot");
    public static final SoundEvent BOW_HIT = of("bow_hit");
    public static final SoundEvent DARK_CAST = of("dark_cast");
    public static final SoundEvent DARK_HIT = of("dark_hit");
    public static final SoundEvent LIGHT_CAST = of("light_cast");
    public static final SoundEvent LIGHT_HIT = of("light_hit");
    public static final SoundEvent HORROR_STEP = of("horror_step");
    public static final SoundEvent HORROR_STING = of("horror_sting");
    public static final SoundEvent HORROR_SCREAM = of("horror_scream");
    public static final SoundEvent HORROR_WHISPER = of("horror_whisper");
    public static final SoundEvent HORROR_BREATH = of("horror_breath");
    public static final SoundEvent HORROR_CREAK = of("horror_creak");

    private Sounds() {
    }

    private static SoundEvent of(String name) {
        Identifier id = Identifier.of(MineviaElements.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    /** Загружает класс, а вместе с ним регистрирует все звуки. */
    static void init() {
    }
}
