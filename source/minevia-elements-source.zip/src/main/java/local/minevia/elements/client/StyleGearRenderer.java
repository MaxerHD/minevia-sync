package local.minevia.elements.client;

import local.minevia.elements.MineviaElements;
import local.minevia.elements.StyleGear;
import local.minevia.elements.StyleGearItem;
import net.fabricmc.fabric.api.client.rendering.v1.BuiltinItemRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.LivingEntityFeatureRendererRegistrationCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.model.json.ModelTransformationMode;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Предметы в руках объёмные, в интерфейсе пиксельные. */
public final class StyleGearRenderer {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private StyleGearRenderer() { }
    public static void init() {
        for (var item : new net.minecraft.item.Item[] {StyleGear.SWORD, StyleGear.BOW, StyleGear.DARK, StyleGear.LIGHT})
            BuiltinItemRendererRegistry.INSTANCE.register(item, (BuiltinItemRendererRegistry.DynamicItemRenderer) StyleGearRenderer::render);
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((type, renderer, helper, context) -> {
            if (renderer instanceof PlayerEntityRenderer player) helper.register(new Gloves(player));
        });
    }
    private static String id(ItemStack stack) { return net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath(); }
    public static Identifier icon(ItemStack stack) { return Identifier.of(MineviaElements.MOD_ID, "textures/item/" + id(stack) + "_" + StyleGear.level(stack) + ".png"); }
    private static String mesh(ItemStack stack) {
        String base = stack.isOf(StyleGear.SWORD) ? "weapon_sword" : stack.isOf(StyleGear.BOW) ? "weapon_bow" : stack.isOf(StyleGear.DARK) ? "weapon_glove_dark" : "weapon_glove_light";
        return base + "_" + StyleGear.level(stack);
    }
    public static float drawProgress(ItemStack stack, net.minecraft.entity.LivingEntity owner, float delta) {
        var tag = StyleGear.data(stack);
        if (tag.contains("style_draw_start")) return StyleGearItem.draw(stack, (int) Math.max(0, owner.getWorld().getTime() - tag.getLong("style_draw_start")));
        return owner.isUsingItem() ? StyleGearItem.draw(stack, owner.getItemUseTime()) : 0;
    }
    private static void render(ItemStack stack, ModelTransformationMode mode, MatrixStack matrices, VertexConsumerProvider out, int light, int overlay) {
        if (mode == ModelTransformationMode.GUI) { sprite(stack, matrices, out, light, overlay); return; }
        // Перчатки рисует слой рук, а не предмет в ладони.
        if (StyleGear.gloves(stack) && (mode.isFirstPerson() || mode == ModelTransformationMode.THIRD_PERSON_LEFT_HAND || mode == ModelTransformationMode.THIRD_PERSON_RIGHT_HAND)) return;
        MinecraftClient client = MinecraftClient.getInstance();
        var tag = StyleGear.data(stack);
        var owner = client.world != null && tag.containsUuid("style_owner") ? client.world.getPlayerByUuid(tag.getUuid("style_owner")) : null;
        float time = client.world == null ? 0 : client.world.getTime() + client.getRenderTickCounter().getTickDelta(false);
        float phase = time * 0.45F;
        if (stack.isOf(StyleGear.BOW)) phase = owner == null ? 0 : drawProgress(stack, owner, 0) * 7;
        matrices.push();
        matrices.translate(0.5, stack.isOf(StyleGear.SWORD) ? 0.2 : 0.5, 0.5);
        if (mode == ModelTransformationMode.GROUND || mode == ModelTransformationMode.FIXED) matrices.scale(0.6F, 0.6F, 0.6F);
        // От первого лица оружие ближе к камере: в полный размер оно закрыло бы полэкрана.
        if (mode.isFirstPerson()) {
            float near = stack.isOf(StyleGear.SWORD) ? 0.58F : 0.8F;
            matrices.scale(near, near, near);
        }
        draw(stack, phase, !stack.isOf(StyleGear.BOW), time, matrices, out, light);
        matrices.pop();
    }
    private static void sprite(ItemStack stack, MatrixStack matrices, VertexConsumerProvider out, int light, int overlay) {
        var vertex = out.getBuffer(RenderLayer.getEntityCutoutNoCull(icon(stack)));
        var entry = matrices.peek();
        vertex.vertex(entry, 0, 0, 0.5F).color(-1).texture(0, 1).overlay(overlay).light(light).normal(entry, 0, 0, 1);
        vertex.vertex(entry, 1, 0, 0.5F).color(-1).texture(1, 1).overlay(overlay).light(light).normal(entry, 0, 0, 1);
        vertex.vertex(entry, 1, 1, 0.5F).color(-1).texture(1, 0).overlay(overlay).light(light).normal(entry, 0, 0, 1);
        vertex.vertex(entry, 0, 1, 0.5F).color(-1).texture(0, 0).overlay(overlay).light(light).normal(entry, 0, 0, 1);
    }
    private static void draw(ItemStack stack, float phase, boolean loop, float time, MatrixStack matrices, VertexConsumerProvider out, int light) {
        String name = mesh(stack);
        SpellMesh body = SpellMesh.get(name + "_body");
        SpellMesh glow = SpellMesh.get(name + "_glow");
        float flash = Math.max(0, 1 - (time - StyleGear.data(stack).getLong("style_flash")) / 30F);
        if (body != null) body.draw(matrices.peek(), out.getBuffer(RenderLayer.getEntitySolid(WHITE)), phase, loop, 0xFFFFFF, 1, light, SpellMesh.Surface.PLAIN);
        if (glow != null) {
            int brightness = Math.clamp((int) (205 + 25 * Math.sin(time * 0.3) + flash * 40), 0, 255);
            int tint = brightness * 0x010101;
            glow.draw(matrices.peek(), out.getBuffer(ShaderCompat.glow()), phase, loop, tint, 1, LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.PLAIN);
        }
        if (flash > 0 && body != null) body.draw(matrices.peek(), out.getBuffer(ShaderCompat.glow()), phase, loop, 0xFFFFFF, 1, LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.PLAIN);
    }
    public static void glove(AbstractClientPlayerEntity player, Arm arm, PlayerEntityModel<?> model, MatrixStack matrices, VertexConsumerProvider out, int light, float tickDelta) {
        ItemStack stack = player.getMainHandStack();
        if (!StyleGear.gloves(stack) || player.isInvisible()) return;
        matrices.push();
        (arm == Arm.RIGHT ? model.rightArm : model.leftArm).rotate(matrices);
        matrices.translate(arm == Arm.RIGHT ? -0.0625 : 0.0625, 0.55, 0);
        // Координаты модели игрока направлены вниз по Y.
        matrices.scale(arm == Arm.RIGHT ? 1 : -1, -1, -1);
        draw(stack, (player.age + tickDelta) * 0.5F, true, player.getWorld().getTime() + tickDelta, matrices, out, light);
        matrices.pop();
    }
    private static final class Gloves extends FeatureRenderer<AbstractClientPlayerEntity, PlayerEntityModel<AbstractClientPlayerEntity>> {
        Gloves(PlayerEntityRenderer context) { super(context); }
        @Override public void render(MatrixStack matrices, VertexConsumerProvider out, int light, AbstractClientPlayerEntity player,
                float limbAngle, float limbDistance, float tickDelta, float progress, float headYaw, float headPitch) {
            glove(player, Arm.RIGHT, getContextModel(), matrices, out, light, tickDelta);
            glove(player, Arm.LEFT, getContextModel(), matrices, out, light, tickDelta);
        }
    }
}
