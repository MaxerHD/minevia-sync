package local.minevia.elements.client;

import local.minevia.elements.Element;
import local.minevia.elements.ElementBoss;
import local.minevia.elements.MineviaElements;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.RotationAxis;

/** Страж храма это анимированная 3D-модель из Blender, как и способности. Исток показывает свои печати. */
final class BossRenderer extends EntityRenderer<ElementBoss> {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private static final String[] MODELS = {"boss_fire", "boss_water", "boss_earth", "boss_air", "boss_primal"};
    private static final float LOOP = 30;
    private static final int HURT_TINT = 0xFF9090;

    BossRenderer(EntityRendererFactory.Context context) {
        super(context);
        shadowRadius = 1.2F;
    }

    @Override
    public Identifier getTexture(ElementBoss entity) {
        return WHITE;
    }

    @Override
    public void render(ElementBoss boss, float yaw, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        SpellMesh mesh = SpellMesh.get(MODELS[boss.kind()]);
        if (mesh == null) {
            return;
        }
        float age = boss.age + delta;
        int tint = boss.hurtTime > 0 ? HURT_TINT : 0xFFFFFF;
        matrices.push();
        matrices.translate(0, 1.8 + Math.sin(age * 0.08) * 0.15, 0);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
        mesh.draw(matrices.peek(), consumers.getBuffer(ShaderCompat.glow()), age / LOOP * mesh.frames(), true, tint, 1.0F,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.PLAIN);
        matrices.pop();
        if (boss.kind() == ElementBoss.PRIMAL) {
            drawSeals(boss, age, matrices, consumers);
        }
    }

    /** Печати кружат вокруг Истока. Снятая печать исчезает, поэтому видно, сколько ещё осталось. */
    private static void drawSeals(ElementBoss boss, float age, MatrixStack matrices, VertexConsumerProvider consumers) {
        SpellMesh orb = SpellMesh.get("seal_orb");
        if (orb == null) {
            return;
        }
        int seals = boss.seals();
        for (Element element : Element.natural()) {
            if ((seals >> element.ordinal() & 1) == 0) {
                continue;
            }
            double angle = age * 0.05 + element.ordinal() * Math.PI / 2;
            matrices.push();
            matrices.translate(Math.cos(angle) * 3.4, 2.0 + Math.sin(age * 0.1 + element.ordinal()) * 0.5, Math.sin(angle) * 3.4);
            orb.draw(matrices.peek(), consumers.getBuffer(ShaderCompat.glow()), age / 16 * orb.frames(), true, element.color, 1.0F,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.PLAIN);
            matrices.pop();
        }
    }
}
