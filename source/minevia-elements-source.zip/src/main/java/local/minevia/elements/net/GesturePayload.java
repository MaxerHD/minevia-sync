package local.minevia.elements.net;

import local.minevia.elements.MineviaElements;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Какое движение делает игрок и сколько тиков оно длится. STOP вместо движения опускает руки. */
public record GesturePayload(int entity, int gesture, int ticks) implements CustomPayload {
    public static final int STOP = -1;
    public static final Id<GesturePayload> ID = new Id<>(Identifier.of(MineviaElements.MOD_ID, "gesture"));
    public static final PacketCodec<RegistryByteBuf, GesturePayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, GesturePayload::entity,
            PacketCodecs.VAR_INT, GesturePayload::gesture,
            PacketCodecs.VAR_INT, GesturePayload::ticks,
            GesturePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
