package local.minevia.elements.client;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import local.minevia.elements.MineviaElements;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/** Покадрово анимированная 3D-модель из Blender. Соседние кадры смешиваются, поэтому движение плавное. */
final class SpellMesh {
    /** Как поверхность отзывается на положение камеры. */
    enum Surface {
        PLAIN, WET, GAS, FOG
    }

    private static final int MAGIC = 0x4D4D5348;
    private static final Map<String, SpellMesh> LOADED = new HashMap<>();

    private final int verts;
    private final int frames;
    private final float extent;
    private final char[] quads;
    private final short[] position;
    private final byte[] normal;
    private final byte[] color;
    private final float[] px;
    private final float[] nx;
    private final int[] rgba;

    private SpellMesh(DataInputStream in) throws IOException {
        if (in.readInt() != MAGIC) {
            throw new IOException("Это не файл модели");
        }
        verts = in.readInt();
        int quadCount = in.readInt();
        frames = in.readInt();
        extent = in.readFloat();
        quads = new char[quadCount * 4];
        byte[] raw = in.readNBytes(quads.length * 2);
        ByteBuffer.wrap(raw).asCharBuffer().get(quads);
        position = new short[frames * verts * 3];
        normal = new byte[frames * verts * 3];
        color = new byte[frames * verts * 4];
        for (int f = 0; f < frames; f++) {
            ByteBuffer.wrap(in.readNBytes(verts * 6)).asShortBuffer().get(position, f * verts * 3, verts * 3);
            in.readFully(normal, f * verts * 3, verts * 3);
            in.readFully(color, f * verts * 4, verts * 4);
        }
        px = new float[verts * 3];
        nx = new float[verts * 3];
        rgba = new int[verts * 4];
    }

    /** Размер всей анимации в файле модели: ей задаётся, насколько крупно рисовать. */
    float extent() {
        return extent;
    }

    static SpellMesh get(String name) {
        return LOADED.get(name);
    }

    /** phase: номер кадра с дробной частью. Дробная часть смешивает кадр с соседним. */
    void draw(MatrixStack.Entry entry, VertexConsumer out, float phase, boolean loop, int tint, float alpha, int light, Surface surface) {
        blend(phase, loop);
        if (surface == Surface.WET) {
            shine(entry);
        } else if (surface == Surface.GAS) {
            soften(entry);
        } else if (surface == Surface.FOG) {
            thin(entry);
        }
        boolean flat = surface == Surface.FOG;
        int tr = tint >> 16 & 255;
        int tg = tint >> 8 & 255;
        int tb = tint & 255;
        boolean mirrored = entry.getPositionMatrix().determinant() < 0;
        for (int corner = 0; corner < quads.length; corner++) {
            int ordered = mirrored ? (corner / 4) * 4 + 3 - corner % 4 : corner;
            int index = quads[ordered];
            int v = index * 3;
            int c = index * 4;
            out.vertex(entry, px[v], px[v + 1], px[v + 2])
                    .color(rgba[c] * tr / 255, rgba[c + 1] * tg / 255, rgba[c + 2] * tb / 255, (int) (rgba[c + 3] * alpha))
                    .texture(0.5F, 0.5F)
                    .overlay(OverlayTexture.DEFAULT_UV)
                    .light(light)
                    .normal(entry, flat ? 0 : nx[v], flat ? 1 : nx[v + 1], flat ? 0 : nx[v + 2]);
        }
    }

    private void blend(float phase, boolean loop) {
        int first = (int) Math.floor(phase);
        float mix = phase - first;
        int second = first + 1;
        if (loop) {
            first = Math.floorMod(first, frames);
            second = Math.floorMod(second, frames);
        } else {
            first = Math.min(Math.max(first, 0), frames - 1);
            second = Math.min(Math.max(second, 0), frames - 1);
        }
        float scale = extent / 32767.0F;
        int a = first * verts * 3;
        int b = second * verts * 3;
        for (int i = 0; i < verts * 3; i++) {
            px[i] = (position[a + i] + (position[b + i] - position[a + i]) * mix) * scale;
            nx[i] = (normal[a + i] + (normal[b + i] - normal[a + i]) * mix) / 127.0F;
        }
        a = first * verts * 4;
        b = second * verts * 4;
        for (int i = 0; i < verts * 4; i++) {
            int from = color[a + i] & 255;
            rgba[i] = (int) (from + ((color[b + i] & 255) - from) * mix);
        }
    }

    /** Блик и более плотные края, как у настоящей воды и льда: зависят от положения камеры. */
    private void shine(MatrixStack.Entry entry) {
        Matrix4f matrix = entry.getPositionMatrix();
        Matrix3f rotate = entry.getNormalMatrix();
        Vector3f point = new Vector3f();
        Vector3f face = new Vector3f();
        Vector3f half = new Vector3f();
        for (int i = 0; i < verts; i++) {
            int v = i * 3;
            int c = i * 4;
            matrix.transformPosition(px[v], px[v + 1], px[v + 2], point);
            point.normalize().negate();
            rotate.transform(nx[v], nx[v + 1], nx[v + 2], face);
            face.normalize();
            float facing = Math.abs(face.dot(point));
            float rim = (1 - facing) * (1 - facing);
            half.set(0.35F, 0.85F, 0.3F).add(point).normalize();
            float glint = (float) Math.pow(Math.max(0.0F, face.dot(half)), 36);
            float add = (rim * 0.1F + glint * 0.55F) * 255;
            rgba[c] = Math.min(255, (int) (rgba[c] * 0.72F + add));
            rgba[c + 1] = Math.min(255, (int) (rgba[c + 1] * 0.72F + add));
            rgba[c + 2] = Math.min(255, (int) (rgba[c + 2] * 0.8F + add));
            rgba[c + 3] = Math.min(255, (int) (rgba[c + 3] + (rim * 0.35F + glint * 0.5F) * 255));
        }
    }

    /** Огонь и дым: край объёма тает, середина горячее, поэтому шар выглядит клубом газа, а не диском. */
    private void soften(MatrixStack.Entry entry) {
        Matrix4f matrix = entry.getPositionMatrix();
        Matrix3f rotate = entry.getNormalMatrix();
        Vector3f point = new Vector3f();
        Vector3f face = new Vector3f();
        for (int i = 0; i < verts; i++) {
            int v = i * 3;
            int c = i * 4;
            matrix.transformPosition(px[v], px[v + 1], px[v + 2], point);
            point.normalize().negate();
            rotate.transform(nx[v], nx[v + 1], nx[v + 2], face);
            face.normalize();
            float facing = Math.abs(face.dot(point));
            float edge = Math.min(1.0F, Math.max(0.0F, (facing - 0.06F) / 0.62F));
            edge = edge * edge * (3 - 2 * edge);
            float depth = 0.55F + 0.45F * facing;
            rgba[c] = (int) (rgba[c] * depth);
            rgba[c + 1] = (int) (rgba[c + 1] * depth * depth);
            rgba[c + 2] = (int) (rgba[c + 2] * depth * depth);
            rgba[c + 3] = (int) (rgba[c + 3] * edge);
        }
    }

    /** Туман и дым: цвет не трогает, только края становятся прозрачными. Свет у них ровный, сверху. */
    private void thin(MatrixStack.Entry entry) {
        Matrix4f matrix = entry.getPositionMatrix();
        Matrix3f rotate = entry.getNormalMatrix();
        Vector3f point = new Vector3f();
        Vector3f face = new Vector3f();
        for (int i = 0; i < verts; i++) {
            int v = i * 3;
            matrix.transformPosition(px[v], px[v + 1], px[v + 2], point);
            point.normalize().negate();
            rotate.transform(nx[v], nx[v + 1], nx[v + 2], face);
            face.normalize();
            float edge = Math.min(1.0F, Math.abs(face.dot(point)) / 0.55F);
            rgba[i * 4 + 3] = (int) (rgba[i * 4 + 3] * edge * edge);
        }
    }

    int frames() {
        return frames;
    }

    static final class Loader implements SimpleSynchronousResourceReloadListener {
        @Override
        public Identifier getFabricId() {
            return Identifier.of(MineviaElements.MOD_ID, "spell_meshes");
        }

        @Override
        public void reload(ResourceManager manager) {
            LOADED.clear();
            manager.findResources("mesh", id -> id.getNamespace().equals(MineviaElements.MOD_ID) && id.getPath().endsWith(".mesh"))
                    .forEach((id, resource) -> {
                        String name = id.getPath().substring("mesh/".length(), id.getPath().length() - ".mesh".length());
                        try (InputStream raw = resource.getInputStream();
                                DataInputStream in = new DataInputStream(new GZIPInputStream(raw))) {
                            LOADED.put(name, new SpellMesh(in));
                        } catch (IOException problem) {
                            throw new IllegalStateException("Не читается модель " + id, problem);
                        }
                    });
        }
    }
}
