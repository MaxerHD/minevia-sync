package local.minevia.elements;

import java.util.List;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Падает с духов. Использование добавляет опыт навыку, который игрок применял последним. Своя стихия даёт вдвое больше. */
public final class EssenceItem extends Item {
    private final Element element;

    public EssenceItem(Element element, Settings settings) {
        super(settings);
        this.element = element;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user instanceof ServerPlayerEntity player) {
            ElementState.Data data = ElementState.get(player.getServer()).getOrAssign(player.getUuid());
            if (!Mastery.essence(player, data, element)) {
                return TypedActionResult.fail(stack);
            }
            stack.decrementUnlessCreative(1, player);
        }
        return TypedActionResult.success(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.minevia_elements.essence.hint").formatted(Formatting.GRAY));
    }
}
