package local.minevia.elements.client;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.Properties;
import local.minevia.elements.Abilities;
import local.minevia.elements.Element;
import net.fabricmc.loader.api.FabricLoader;

/** Свой порядок навыков на панели и клавишах. Он хранится у игрока и на сервер не влияет: туда уходит настоящий номер навыка. */
final class SkillOrder {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("minevia_skill_order.properties");
    private static final Properties SAVED = new Properties();
    private static boolean loaded;

    private SkillOrder() {
    }

    private static void load() {
        if (loaded) {
            return;
        }
        loaded = true;
        if (Files.exists(FILE)) {
            try (Reader in = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
                SAVED.load(in);
            } catch (IOException | IllegalArgumentException broken) {
                SAVED.clear();
            }
        }
    }

    private static int[] standard() {
        int[] order = new int[Abilities.SLOTS];
        Arrays.setAll(order, slot -> slot);
        return order;
    }

    /** Порядок для стихии: в позиции i стоит навык order[i]. Испорченная запись заменяется обычным порядком. */
    static int[] of(Element element) {
        load();
        String text = element == null ? null : SAVED.getProperty(element.id());
        if (text == null) {
            return standard();
        }
        try {
            int[] order = Arrays.stream(text.split(",")).mapToInt(part -> Integer.parseInt(part.trim())).toArray();
            int[] sorted = order.clone();
            Arrays.sort(sorted);
            return Arrays.equals(sorted, standard()) ? order : standard();
        } catch (NumberFormatException broken) {
            return standard();
        }
    }

    static void swap(Element element, int first, int second) {
        int[] order = of(element);
        int a = indexOf(order, first);
        int b = indexOf(order, second);
        if (a < 0 || b < 0 || a == b) {
            return;
        }
        order[a] = second;
        order[b] = first;
        SAVED.setProperty(element.id(), String.join(",", Arrays.stream(order).mapToObj(String::valueOf).toArray(String[]::new)));
        save();
    }

    static void reset(Element element) {
        load();
        SAVED.remove(element.id());
        save();
    }

    static int indexOf(int[] order, int slot) {
        for (int i = 0; i < order.length; i++) {
            if (order[i] == slot) {
                return i;
            }
        }
        return -1;
    }

    private static void save() {
        try (Writer out = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
            SAVED.store(out, "Minevia: порядок навыков");
        } catch (IOException ignored) {
            // Порядок останется на эту игру, но навыки работают и без файла.
        }
    }
}
