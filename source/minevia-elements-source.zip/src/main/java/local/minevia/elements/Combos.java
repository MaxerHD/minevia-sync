package local.minevia.elements;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Комбо бывают двух видов. Командные: удар способностью оставляет на враге метку на шесть секунд, и удар другой
 * стихией по этой метке запускает комбо. Ещё они срабатывают, когда способности двух стихий сошлись рядом:
 * например, фаербол влетел в смерч. Чем завершён удар, решает ряд: снаряд, площадь или путь и супер-навык.
 * Цепочки: один игрок подряд применяет два своих навыка в нужном порядке.
 */
public final class Combos {
    /** Шесть пар из четырёх стихий, и у каждой пары три комбо. */
    public enum Combo {
        STEAM(Element.FIRE, Element.WATER, 0),
        FIRESTORM(Element.FIRE, Element.AIR, 0),
        MAGMA(Element.FIRE, Element.EARTH, 0),
        FROST(Element.WATER, Element.AIR, 0),
        MUD(Element.WATER, Element.EARTH, 0),
        SANDSTORM(Element.EARTH, Element.AIR, 0),
        GEYSERS(Element.FIRE, Element.WATER, 1),
        FIRE_RAIN(Element.FIRE, Element.AIR, 1),
        VOLCANO(Element.FIRE, Element.EARTH, 1),
        BLIZZARD(Element.WATER, Element.AIR, 1),
        MUDFLOW(Element.WATER, Element.EARTH, 1),
        HAIL(Element.EARTH, Element.AIR, 1),
        STEAM_BLAST(Element.FIRE, Element.WATER, 2),
        PLASMA_STORM(Element.FIRE, Element.AIR, 2),
        OBSIDIAN(Element.FIRE, Element.EARTH, 2),
        ICE_STORM(Element.WATER, Element.AIR, 2),
        TSUNAMI(Element.WATER, Element.EARTH, 2),
        GRAVITY(Element.EARTH, Element.AIR, 2);

        public final Element first;
        public final Element second;
        public final int tier;

        Combo(Element first, Element second, int tier) {
            this.first = first;
            this.second = second;
            this.tier = tier;
        }

        static Combo of(Element a, Element b, int tier) {
            for (Combo combo : values()) {
                if (combo.tier == tier && (combo.first == a && combo.second == b || combo.first == b && combo.second == a)) {
                    return combo;
                }
            }
            return null;
        }

        public String key() {
            return "combo.minevia_elements." + name().toLowerCase(java.util.Locale.ROOT);
        }
    }

    /** Цепочки одного игрока: сначала навык first, сразу за ним second. Номера это слоты навыков. */
    public enum Solo {
        SUPERNOVA(Element.FIRE, 2, 1),
        NAPALM(Element.FIRE, 0, 4),
        CROWN(Element.FIRE, 1, 3),
        TIDE(Element.WATER, 4, 0),
        LIVING_WATER(Element.WATER, 1, 4),
        FROZEN_GRIP(Element.WATER, 3, 2),
        STONE_FOREST(Element.EARTH, 1, 3),
        TITAN_STEP(Element.EARTH, 2, 1),
        LANDSLIDE(Element.EARTH, 4, 0),
        DEATH_WIND(Element.AIR, 2, 1),
        RAZOR_RING(Element.AIR, 1, 3),
        SHOCKWAVE(Element.AIR, 4, 2),
        CROSSCUT(Element.SWORD, 0, 3),
        STEEL_TEMPEST(Element.SWORD, 2, 1),
        FALLING_CROWN(Element.SWORD, 1, 4),
        PIN_CUSHION(Element.BOW, 4, 1),
        MINEFIELD(Element.BOW, 2, 3),
        STAR_HUNT(Element.BOW, 7, 8),
        SOUL_FEAST(Element.DARK, 2, 1),
        ABYSSAL_GRASP(Element.DARK, 3, 4),
        NIGHT_COURT(Element.DARK, 7, 8),
        DAWN_BREAK(Element.LIGHT, 2, 0),
        PURE_HEART(Element.LIGHT, 3, 1),
        ASCENSION(Element.LIGHT, 7, 4);

        public final Element element;
        public final int first;
        public final int second;

        Solo(Element element, int first, int second) {
            this.element = element;
            this.first = first;
            this.second = second;
        }

        static Solo of(Element element, int first, int second) {
            for (Solo solo : values()) {
                if (solo.element == element && solo.first == first && solo.second == second) {
                    return solo;
                }
            }
            return null;
        }

        public String key() {
            return "combo.minevia_elements." + name().toLowerCase(java.util.Locale.ROOT);
        }
    }

    /** Какой навык игрок применил и когда. Навык, закрывший цепочку, не начинает следующую. */
    private record Cast(int slot, long at, boolean chainable) {
    }

    private record Mark(Element element, long until, SpellEntity orb) {
    }

    private static final int MARK_TICKS = 120;
    private static final int RESTING_TICKS = 40;
    private static final double NEAR = 3.2;
    private static final double SPELL_FINDS_SPELL = 7.0;
    /** Столько тиков есть на второй навык цепочки. */
    private static final int CHAIN_TICKS = 80;

    private static final Map<UUID, Mark> MARKS = new HashMap<>();
    private static final Map<UUID, Long> RESTING = new HashMap<>();
    private static final List<SpellEntity> ACTIVE = new ArrayList<>();
    private static final Map<UUID, Cast> LAST = new HashMap<>();
    private static final Map<UUID, Cast> PREVIOUS = new HashMap<>();

    private Combos() {
    }

    static void track(SpellEntity spell) {
        if (spell.charge() != null && spell.charge().isNatural()) ACTIVE.add(spell);
    }

    static void forget(UUID id) {
        LAST.remove(id);
        PREVIOUS.remove(id);
    }

    static void clear() {
        MARKS.clear();
        RESTING.clear();
        ACTIVE.clear();
        LAST.clear();
        PREVIOUS.clear();
    }

    /** Запоминает слот до применения навыка: от него зависит ряд комбо, которое этот навык запустит. */
    static void casting(ServerPlayerEntity player, int slot) {
        UUID id = player.getUuid();
        PREVIOUS.put(id, LAST.get(id));
        LAST.put(id, new Cast(slot, player.getServer().getTicks(), true));
    }

    /** Навык применён: если он второй в цепочке, срабатывает комбо одного игрока. */
    static void chain(ServerPlayerEntity player, Element element, int slot) {
        Cast previous = PREVIOUS.remove(player.getUuid());
        long now = player.getServer().getTicks();
        if (previous == null || !previous.chainable() || now - previous.at() > CHAIN_TICKS) {
            return;
        }
        Solo solo = Solo.of(element, previous.slot(), slot);
        if (solo == null) {
            return;
        }
        LAST.put(player.getUuid(), new Cast(slot, now, false));
        Abilities.sound(player, Sounds.COMBO, 1.2F);
        Flourish.blast(player.getServerWorld(), player.getPos().add(0, 0.2, 0), 5, element.color);
        ComboMoves.solo(solo, player, levelOf(player));
        player.sendMessage(Text.translatable("message.minevia_elements.combo", Text.translatable(solo.key())), true);
    }

    /** Ряд комбо: 0 снаряд, 1 удар по площади, 2 навык пути или супер-навык. */
    private static int tier(ServerPlayerEntity player) {
        Cast last = LAST.get(player.getUuid());
        if (last == null) {
            return 0;
        }
        return switch (last.slot()) {
            case 0, 3 -> 0;
            case Abilities.PATH_SLOT, Abilities.PATH_SECOND_SLOT, Abilities.ULTIMATE_SLOT -> 2;
            default -> 1;
        };
    }

    /** Игрок ударил цель своей стихией: ставит метку или, если метка чужой стихии уже есть, запускает комбо. */
    static void hit(ServerPlayerEntity player, LivingEntity target, Element element) {
        if (element == null || !element.isNatural()) return;
        long now = player.getServer().getTicks();
        UUID id = target.getUuid();
        if (RESTING.getOrDefault(id, 0L) > now) {
            return;
        }
        Mark mark = MARKS.get(id);
        if (mark != null && mark.until() > now && mark.element() != element) {
            MARKS.remove(id);
            mark.orb().discard();
            RESTING.put(id, now + RESTING_TICKS);
            trigger(Combo.of(mark.element(), element, tier(player)), player, target.getBoundingBox().getCenter(), target);
            return;
        }
        if (mark != null) {
            mark.orb().discard();
        }
        if (!target.isAlive()) {
            return;
        }
        ServerWorld world = player.getServerWorld();
        SpellEntity orb = SpellEntity.spawn(world, SpellKind.ELEMENT_MARK, target.getPos(), 0.55F, MARK_TICKS)
                .owner(target).tint(element.color);
        orb.logic(self -> {
            self.setPosition(target.getPos());
            if (!target.isAlive()) {
                self.discard();
            }
        });
        MARKS.put(id, new Mark(element, now + MARK_TICKS, orb));
    }

    /** Ищет способности разных стихий, которые сошлись рядом. Их всегда единицы, поэтому перебор дешёвый. */
    static void tick(MinecraftServer server) {
        long now = server.getTicks();
        MARKS.values().removeIf(mark -> mark.until() <= now);
        RESTING.values().removeIf(until -> until <= now);
        ACTIVE.removeIf(SpellEntity::isRemoved);
        if (now % 2 != 0) {
            return;
        }
        for (int i = 0; i < ACTIVE.size(); i++) {
            SpellEntity a = ACTIVE.get(i);
            for (int j = i + 1; j < ACTIVE.size(); j++) {
                SpellEntity b = ACTIVE.get(j);
                if (a.charge() != b.charge() && a.getWorld() == b.getWorld() && !a.isRemoved() && !b.isRemoved()
                        && a.getPos().distanceTo(b.getPos()) < reach(a, b)) {
                    meet(a, b);
                    return;
                }
            }
        }
    }

    /** Большие способности ловят другие на большем расстоянии, иначе в смерч пришлось бы попадать точно в ось. */
    private static double reach(SpellEntity a, SpellEntity b) {
        return NEAR + (wide(a) ? 1.6 : 0) + (wide(b) ? 1.6 : 0);
    }

    private static boolean wide(SpellEntity spell) {
        SpellKind kind = spell.kind();
        return kind == SpellKind.TORNADO || kind == SpellKind.GREAT_TORNADO || kind == SpellKind.WATER_GUARDIAN
                || kind == SpellKind.WATER_WAVE || kind == SpellKind.WIND_DOME || kind == SpellKind.FLAME_RING;
    }

    private static void meet(SpellEntity a, SpellEntity b) {
        ServerPlayerEntity player = b.caster() != null ? b.caster() : a.caster();
        Combo combo = Combo.of(a.charge(), b.charge(), tier(player));
        if (combo == null) return;
        Vec3d at = a.getPos().lerp(b.getPos(), 0.5);
        ACTIVE.remove(a);
        ACTIVE.remove(b);
        trigger(combo, player, at, null);
        // Снаряд, отдавший стихию, исчезает. Смерч, волна и глыба живут дальше с новым свойством.
        for (SpellEntity spell : List.of(a, b)) {
            SpellKind kind = spell.kind();
            if (kind == SpellKind.FIREBALL || kind == SpellKind.WATER_BLOB) {
                spell.discard();
            }
        }
    }

    /** Команда для проверки графики: запускает комбо по имени там, куда смотрит игрок. */
    static boolean demo(ServerPlayerEntity player, String name) {
        Vec3d at = Spells.crosshair(player, 12);
        for (Combo combo : Combo.values()) {
            if (combo.name().equalsIgnoreCase(name)) {
                trigger(combo, player, at, null);
                return true;
            }
        }
        for (Solo solo : Solo.values()) {
            if (solo.name().equalsIgnoreCase(name)) {
                ComboMoves.solo(solo, player, levelOf(player));
                return true;
            }
        }
        return false;
    }

    private static void trigger(Combo combo, ServerPlayerEntity player, Vec3d at, LivingEntity target) {
        if (combo == null || player == null) return;
        ServerWorld world = player.getServerWorld();
        int level = levelOf(player);
        Abilities.soundAt(world, at, Sounds.COMBO, 1.0F);
        Flourish.blast(world, at, 5 + combo.tier * 2.5F, combo.first.color);
        SpellEntity.spawn(world, SpellKind.IMPACT, at, 2.2F + combo.tier, 8).tint(combo.second.color);
        switch (combo) {
            case STEAM -> steamCloud(player, at, level);
            case FIRESTORM -> storm(player, at, level, SpellKind.FIRE_TORNADO, Element.FIRE);
            case SANDSTORM -> storm(player, at, level, SpellKind.ROCK_TORNADO, Element.EARTH);
            case MAGMA -> molten(player, at, level);
            case FROST -> frost(player, at, level);
            case MUD -> mudPool(player, at, level);
            default -> ComboMoves.team(combo, player, at, level);
        }
        Box area = new Box(at, at).expand(32);
        for (PlayerEntity near : world.getEntitiesByClass(PlayerEntity.class, area, PlayerEntity::isAlive)) {
            near.sendMessage(Text.translatable("message.minevia_elements.combo", Text.translatable(combo.key())), true);
        }
        ElementBoss.onCombo(world, at, combo.first, combo.second);
    }

    private static int levelOf(ServerPlayerEntity player) {
        ElementState.Data data = ElementState.get(player.getServer()).find(player.getUuid());
        return data != null ? data.level : 1;
    }

    private static SpellEntity nearest(SpellKind kind, ServerWorld world, Vec3d at) {
        for (SpellEntity spell : ACTIVE) {
            if (spell.kind() == kind && spell.getWorld() == world && spell.getPos().distanceTo(at) < SPELL_FINDS_SPELL) {
                return spell;
            }
        }
        return null;
    }

    /** Огненный смерч или песчаная буря: живой смерч рядом меняется, а если его нет, поднимается небольшой новый. */
    private static void storm(ServerPlayerEntity player, Vec3d at, int level, SpellKind look, Element infused) {
        ServerWorld world = player.getServerWorld();
        SpellEntity tornado = nearest(SpellKind.TORNADO, world, at);
        if (tornado != null) {
            tornado.infuse(infused, look);
            tornado.setLife(tornado.age + 90);
            return;
        }
        double ground = Spells.groundAt(world, at);
        Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
        SpellEntity small = SpellEntity.spawn(world, look, base, 1.0F, 90);
        small.infuse(infused, look);
        Spells.driveTornado(small, player, () -> Vec3d.ZERO, level);
    }

    /** Облако пара: враги внутри слепнут, замедляются и получают ожоги. */
    static void steamCloud(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.soundAt(world, at, Sounds.STEAM, 1.0F);
        SpellEntity.spawn(world, SpellKind.STEAM_CLOUD, at.add(0, -0.5, 0), 3.2F, 130).logic(self -> {
            if (self.age % 10 == 0) {
                for (LivingEntity near : Abilities.monstersAt(player, at, 5.5)) {
                    Abilities.debuff(near, StatusEffects.BLINDNESS, 50, 0);
                    Abilities.debuff(near, StatusEffects.SLOWNESS, 50, 1);
                    Abilities.strike(player, near, 1 + level * 0.5F);
                }
            }
        });
    }

    /** Глыба рядом раскаляется, а если её нет, раскалённый камень падает с неба прямо в цель. */
    private static void molten(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        for (SpellKind kind : List.of(SpellKind.BOULDER, SpellKind.EARTH_CHUNK)) {
            SpellEntity rock = nearest(kind, world, at);
            if (rock != null) {
                rock.infuse(Element.FIRE, SpellKind.MAGMA_BOULDER);
                return;
            }
        }
        Vec3d fall = new Vec3d(0, -0.8, 0);
        SpellEntity stone = SpellEntity.spawn(world, SpellKind.MAGMA_BOULDER, at.add(0, 7, 0), 1.2F, 40);
        stone.setVelocity(fall);
        Set<UUID> struck = new HashSet<>();
        stone.logic(self -> {
            boolean ended = Spells.fly(self, player, 1.2, true, struck, (point, near) -> {
                Abilities.strike(player, near, 8 + level * 2);
                near.setOnFireFor(6);
                return false;
            });
            if (ended || self.getY() <= at.y - 1.5) {
                SpellEntity.spawn(world, SpellKind.FIRE_BURST, self.getPos(), 1.5F, 17);
                Abilities.soundAt(world, self.getPos(), Sounds.EARTH_HIT, 0.8F);
                magmaPool(player, self.getPos(), level + 5);
                self.discard();
            }
        });
    }

    /** Лужа магмы. Настоящей лавы нет, поэтому мир и база не пострадают. */
    static void magmaPool(ServerPlayerEntity player, Vec3d at, int power) {
        ServerWorld world = player.getServerWorld();
        double ground = Spells.groundAt(world, at.add(0, 1, 0));
        Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
        Abilities.soundAt(world, base, Sounds.MAGMA, 1.0F);
        SpellEntity.spawn(world, SpellKind.MAGMA_POOL, base, 3.4F, 130).logic(self -> {
            if (self.age % 10 == 0) {
                for (LivingEntity near : Abilities.monstersAt(player, base, 3.8)) {
                    Abilities.strike(player, near, 1 + power * 0.4F);
                    near.setOnFireFor(4);
                }
            }
        });
    }

    /** Заморозка: волна рядом застывает ледяной стеной, а цель вмерзает в кристаллы. */
    private static void frost(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.soundAt(world, at, Sounds.ICE_FORM, 0.8F);
        SpellEntity wave = nearest(SpellKind.WATER_WAVE, world, at);
        Vec3d center = at;
        if (wave != null) {
            center = wave.getPos();
            Vec3d across = wave.getRotationVector().crossProduct(new Vec3d(0, 1, 0)).normalize();
            for (int i = -4; i <= 4; i++) {
                Vec3d point = center.add(across.multiply(i * 1.1));
                double ground = Spells.groundAt(world, point.add(0, 1, 0));
                if (!Double.isNaN(ground)) {
                    SpellEntity.spawn(world, SpellKind.ICE_SHARD, new Vec3d(point.x, ground, point.z), 1.3F, 90);
                }
            }
            wave.discard();
        } else {
            double ground = Spells.groundAt(world, at.add(0, 1, 0));
            Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
            Spells.ring(world, SpellKind.ICE_SHARD, base, 1.4, 7, 80, 1.1F, 0xFFFFFF);
        }
        for (LivingEntity near : Abilities.livingAt(player, center, 4.5)) {
            Abilities.strike(player, near, 6 + level * 1.5F);
            Abilities.debuff(near, StatusEffects.SLOWNESS, 100, 5);
            near.setFrozenTicks(240);
        }
    }

    /** Топь: враги вязнут и почти не могут идти. */
    static void mudPool(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        double ground = Spells.groundAt(world, at.add(0, 1, 0));
        Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
        Abilities.soundAt(world, base, Sounds.WATER_HIT, 0.6F);
        SpellEntity.spawn(world, SpellKind.MUD_POOL, base, 4.2F, 160).logic(self -> {
            if (self.age % 10 == 0) {
                for (LivingEntity near : Abilities.monstersAt(player, base, 4.6)) {
                    Abilities.debuff(near, StatusEffects.SLOWNESS, 30, 5);
                    Abilities.debuff(near, StatusEffects.WEAKNESS, 30, 1);
                    if (self.age % 20 == 0) {
                        Abilities.strike(player, near, 1 + level * 0.3F);
                    }
                }
            }
        });
    }
}
