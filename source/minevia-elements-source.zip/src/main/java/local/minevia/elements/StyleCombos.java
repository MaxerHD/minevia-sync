package local.minevia.elements;

import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** У каждой цепочки собственный итоговый приём. */
final class StyleCombos {
    private StyleCombos() { }

    static void solo(Combos.Solo solo, ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 22);
        switch (solo) {
            case CROSSCUT -> {
                for (int side : new int[] {-1, 1})
                    StyleSupport.shot(p, SpellKind.SWORD_CLEAVE, Spells.muzzle(p, 1),
                            p.getRotationVector().rotateY(side * 0.16F).multiply(1.3), 2, 18, true,
                            (self, e) -> { Abilities.strike(p, e, 6 + level); StyleSupport.root(e, 20); }, null);
            }
            case STEEL_TEMPEST -> {
                Abilities.buff(p, StatusEffects.RESISTANCE, 80, 1);
                StyleSupport.follow(p, SpellKind.SWORD_VORTEX, 35, self -> {
                    if (self.age % 7 == 0) for (var e : Abilities.livingAt(p, p.getPos(), 4)) {
                        if (p.canSee(e)) { Abilities.strike(p, e, 3 + level); Abilities.push(e, e.getPos().subtract(p.getPos()).normalize().multiply(0.9)); }
                    }
                });
            }
            case FALLING_CROWN -> {
                for (int i = 0; i < 6; i++) {
                    double a = i * Math.PI / 3;
                    StyleSupport.fall(p, SpellKind.SWORD_FALLBLADE, at.add(Math.cos(a) * 3, 0, Math.sin(a) * 3), 1.8F, 12 + i * 3,
                            point -> blast(p, point, 2.5, 5 + level));
                }
            }
            case PIN_CUSHION -> StyleSupport.field(p, SpellKind.BOW_FAN, at, 3, 30, 5, self -> {
                for (var e : Abilities.livingAt(p, at, 4)) if (p.canSee(e)) {
                    StyleSupport.root(e, 12); Abilities.strike(p, e, 2 + level * 0.5F);
                }
            });
            case MINEFIELD -> {
                for (int i = 0; i < 4; i++) {
                    Vec3d spot = at.add((i % 2 * 2 - 1) * 2, 0, (i / 2 * 2 - 1) * 2);
                    StyleSupport.field(p, SpellKind.BOW_RETREAT, spot, 1.6F, 100, 5, self -> {
                        if (!Abilities.livingAt(p, spot, 2).isEmpty()) { blast(p, spot, 3, 7 + level); self.discard(); }
                    });
                }
            }
            case STAR_HUNT -> {
                for (var e : Abilities.livingAt(p, at, 6)) if (p.canSee(e)) {
                    Abilities.debuff(e, StatusEffects.GLOWING, 160, 0);
                    Vec3d end = e.getPos();
                    StyleSupport.fall(p, SpellKind.BOW_CELESTIAL, end, 1.8F, 16, point -> blast(p, point, 2.2, 8 + level));
                }
            }
            case SOUL_FEAST -> {
                StyleSupport.model(p, SpellKind.DARK_DRAIN, p.getPos(), 3, 30, null);
                for (var e : Abilities.livingAt(p, p.getPos(), 8)) if (p.canSee(e)) {
                    float hp = e.getHealth(); Abilities.strike(p, e, 6 + level);
                    p.heal(Math.min(2, Math.max(0, hp - e.getHealth()) * 0.2F));
                }
            }
            case ABYSSAL_GRASP -> StyleSupport.field(p, SpellKind.DARK_HANDS, at, 5, 65, 5, self -> {
                for (var e : Abilities.livingAt(p, at, 5)) if (p.canSee(e)) {
                    StyleSupport.root(e, 12);
                    if (self.age % 15 == 0) Abilities.strike(p, e, 4 + level);
                }
            });
            case NIGHT_COURT -> {
                for (var e : Abilities.livingAt(p, at, 6)) if (p.canSee(e)) {
                    Abilities.debuff(e, StatusEffects.BLINDNESS, 70, 0);
                    StyleSupport.model(p, SpellKind.DARK_GHOSTS, e.getPos(), 2, 20, self -> {
                        self.setPosition(e.getPos());
                        if (self.age == 10 && Abilities.canHit(e, p)) Abilities.strike(p, e, 9 + level);
                    });
                }
            }
            case DAWN_BREAK -> {
                StyleSupport.model(p, SpellKind.LIGHT_FAITH, p.getPos(), 3, 35, null);
                for (var ally : StyleLight.allies(p, p.getPos(), 8)) Abilities.buff(ally, StatusEffects.ABSORPTION, 100, 1);
                blast(p, Spells.crosshair(p, 18), 4, 8 + level);
            }
            case PURE_HEART -> {
                StyleSupport.model(p, SpellKind.LIGHT_CLEANSE, p.getPos(), 7, 35, null);
                for (var ally : StyleLight.allies(p, p.getPos(), 9)) {
                    StyleSupport.cleanse(ally); ally.heal(5 + level); Abilities.buff(ally, StatusEffects.REGENERATION, 80, 0);
                }
            }
            case ASCENSION -> {
                StyleSupport.field(p, SpellKind.LIGHT_COLUMN, at, 5, 60, 10, self -> {
                    blast(p, at.add(0, 1, 0), 5, 3 + level);
                    for (var ally : StyleLight.allies(p, at, 6)) Abilities.buff(ally, StatusEffects.SLOW_FALLING, 120, 0);
                });
            }
            default -> { }
        }
    }

    private static void blast(ServerPlayerEntity p, Vec3d at, double radius, float damage) {
        for (var e : Abilities.livingAt(p, at, radius)) if (p.canSee(e)) Abilities.strike(p, e, damage);
    }
}
