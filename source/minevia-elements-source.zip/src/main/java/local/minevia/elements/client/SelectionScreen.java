package local.minevia.elements.client;

import local.minevia.elements.Element;
import local.minevia.elements.net.MenuPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/** Восемь карточек: сверху стихии, снизу стили. Выбор мышью или цифрами от 1 до 8, продолжить можно через J. */
public final class SelectionScreen extends Screen {
    private int scroll;
    private boolean waiting;
    private long sentAt;

    public SelectionScreen() {
        super(Text.translatable("screen.minevia_elements.select"));
    }

    @Override
    public boolean shouldPause() { return false; }

    private static final int COLUMNS = 4;
    private static final int GAP = 6;

    private int cardWidth() { return Math.min(170, (width - 20 - GAP * (COLUMNS - 1)) / COLUMNS); }
    private int cardHeight() { return MathHelper.clamp((height - 76 - GAP) / 2, 70, 140); }
    private int left() { return (width - cardWidth() * COLUMNS - GAP * (COLUMNS - 1)) / 2; }
    private int rows() { return (Element.values().length + COLUMNS - 1) / COLUMNS; }
    private int maxScroll() { return Math.max(0, rows() * (cardHeight() + GAP) - (height - 76)); }
    private int cardX(Element option) { return left() + option.ordinal() % COLUMNS * (cardWidth() + GAP); }
    private int cardY(Element option) { return 48 + option.ordinal() / COLUMNS * (cardHeight() + GAP) - scroll; }

    @Override
    public boolean mouseScrolled(double x, double y, double horizontal, double vertical) {
        scroll = MathHelper.clamp(scroll - (int) (vertical * 28), 0, maxScroll());
        return true;
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0 || my < 46 || my >= height - 24 || waiting) return super.mouseClicked(mx, my, button);
        for (Element option : Element.values()) {
            int x = cardX(option);
            int y = cardY(option);
            if (mx < x || mx >= x + cardWidth() || my < y || my >= y + cardHeight()) continue;
            pick(option);
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    private void pick(Element option) {
        if (waiting || option == ElementsClient.element) return;
        if (ElementsClient.element != null && ElementsClient.changeReadyAt > System.currentTimeMillis()) return;
        if (ElementsClient.element == null) choose(option);
        else client.setScreen(new ConfirmScreen(confirmed -> {
            client.setScreen(this);
            if (confirmed) choose(option);
        }, Text.translatable("screen.minevia_elements.confirm_title", Text.translatable(option.key())),
                Text.translatable("screen.minevia_elements.confirm_change")));
    }

    void reply() { waiting = false; }

    @Override
    public boolean keyPressed(int key, int scanCode, int modifiers) {
        if (ElementsClient.menuKey.matchesKey(key, scanCode)) { close(); return true; }
        int digit = key - GLFW.GLFW_KEY_1;
        if (digit >= 0 && digit < Element.values().length) { pick(Element.values()[digit]); return true; }
        return super.keyPressed(key, scanCode, modifiers);
    }

    private void choose(Element option) {
        if (ClientPlayNetworking.canSend(MenuPayload.ID)) {
            ClientPlayNetworking.send(new MenuPayload(MenuPayload.CHOOSE_ELEMENT, option.ordinal()));
            waiting = true;
            sentAt = System.currentTimeMillis();
        }
    }

    @Override
    public void tick() {
        if (waiting && System.currentTimeMillis() - sentAt > 3000) waiting = false;
    }

    private void lines(DrawContext context, Text text, int x, int y, int span, int max, int color) {
        int row = 0;
        for (OrderedText line : textRenderer.wrapLines(text, span)) {
            if (row >= max) break;
            context.drawTextWithShadow(textRenderer, line, x, y + row++ * 10, color);
        }
    }

    @Override
    public void render(DrawContext context, int mx, int my, float delta) {
        super.render(context, mx, my, delta);
        context.fill(0, 0, width, height, 0xEE09111C);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFD27A);
        long seconds = Math.max(0, (ElementsClient.changeReadyAt - System.currentTimeMillis() + 999) / 1000);
        Text hint = ElementsClient.element != null && seconds > 0
                ? Text.translatable("screen.minevia_elements.change_wait", seconds / 60, seconds % 60)
                : Text.translatable("screen.minevia_elements.select_help");
        context.drawCenteredTextWithShadow(textRenderer, hint, width / 2, 28, 0xFFBECADA);
        context.enableScissor(0, 46, width, height - 24);
        for (Element option : Element.values()) {
            int x = cardX(option);
            int y = cardY(option);
            boolean hover = mx >= x && mx < x + cardWidth() && my >= y && my < y + cardHeight();
            context.fill(x, y, x + cardWidth(), y + cardHeight(), hover ? 0xFF26364A : 0xFF152132);
            context.fill(x, y, x + 2, y + cardHeight(), 0xFF000000 | option.color);
            ElementsClient.drawElementIcon(context, option, x + 6, y + 6, 24);
            context.drawTextWithShadow(textRenderer, String.valueOf(option.ordinal() + 1), x + cardWidth() - 10, y + 5, 0xFF7E8EA0);
            lines(context, Text.translatable(option.key()), x + 34, y + 8, cardWidth() - 46, 2, 0xFF000000 | option.color);
            lines(context, Text.translatable(option.key() + ".choice"), x + 6, y + 34, cardWidth() - 10, 3, 0xFFD7DEE3);
            // На мелком экране примеры навыков не помещаются, важнее описание.
            if (cardHeight() >= 100) {
                lines(context, Text.translatable(option.key() + ".examples"), x + 6, y + 68, cardWidth() - 10, 3, 0xFFE4B767);
            }
        }
        context.disableScissor();
        context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.minevia_elements.select_later"), width / 2, height - 16, 0xFF9AAFC2);
    }
}
