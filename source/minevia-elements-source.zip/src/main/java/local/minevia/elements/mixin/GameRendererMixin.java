package local.minevia.elements.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import local.minevia.elements.client.Zoom;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/** Зум меняет угол обзора только для мира: рука в кадре остаётся обычной. */
@Mixin(GameRenderer.class)
abstract class GameRendererMixin {
    @ModifyReturnValue(method = "getFov", at = @At("RETURN"))
    private double minevia$zoom(double fov, @Local(argsOnly = true) boolean changingFov) {
        return changingFov ? Zoom.apply(fov) : fov;
    }
}
