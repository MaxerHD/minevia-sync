package local.minevia.elements.net;

import java.util.UUID;
import local.minevia.elements.MineviaElements;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;

/** Сервер рассылает скин игрока всем. Пустые данные значат, что игрок вышел и скин можно забыть. */
public record PlayerSkinPayload(UUID player, byte[] png) implements CustomPayload {
    public static final Id<PlayerSkinPayload> ID = new Id<>(Identifier.of(MineviaElements.MOD_ID, "player_skin"));
    public static final PacketCodec<RegistryByteBuf, PlayerSkinPayload> CODEC = PacketCodec.tuple(
            Uuids.PACKET_CODEC, PlayerSkinPayload::player,
            PacketCodecs.BYTE_ARRAY, PlayerSkinPayload::png,
            PlayerSkinPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
