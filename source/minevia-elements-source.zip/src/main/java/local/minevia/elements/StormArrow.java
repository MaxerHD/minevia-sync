package local.minevia.elements;

/** Отметка полного натяга сохраняется вместе со стрелой. */
public interface StormArrow {
    void mineviaStorm(boolean charged);
}
