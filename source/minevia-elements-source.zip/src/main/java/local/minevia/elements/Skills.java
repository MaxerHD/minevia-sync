package local.minevia.elements;

import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

/** Дополнительные навыки стихий, вторые навыки путей и супер-навыки. */
final class Skills {
    private static final int LIGHTNING_COLOR = 0xBFD8FF;

    private Skills() {
    }

    /** Слоты 7 и 8: ещё по два навыка у каждой стихии. */
    static void extra(ServerPlayerEntity player, Element element, int slot, int level) {
        switch (element) {
            case FIRE -> {
                if (slot == 7) {
                    fireStep(player, level);
                } else {
                    sparkSwarm(player, level);
                }
            }
            case WATER -> {
                if (slot == 7) {
                    geyser(player, level);
                } else {
                    bubble(player, level);
                }
            }
            case EARTH -> {
                if (slot == 7) {
                    earthFist(player, level);
                } else {
                    stoneLeap(player, level);
                }
            }
            case AIR -> {
                if (slot == 7) {
                    flight(player, level);
                } else {
                    gust(player, level);
                }
            }
        }
    }

    /** Второй навык пути: у каждого пути теперь два приёма. */
    static void pathSecond(ServerPlayerEntity player, Element element, int path, int level) {
        switch (element) {
            case FIRE -> {
                if (path == 1) {
                    ballLightning(player, level);
                } else {
                    lavaShield(player, level);
                }
            }
            case WATER -> {
                if (path == 1) {
                    icePrison(player, level);
                } else {
                    healingRain(player, level);
                }
            }
            case EARTH -> {
                if (path == 1) {
                    sandBlast(player, level);
                } else {
                    steelStorm(player, level);
                }
            }
            case AIR -> {
                if (path == 1) {
                    skyWrath(player, level);
                } else {
                    thinAir(player, level);
                }
            }
        }
    }

    static void ultimate(ServerPlayerEntity player, Element element, int level) {
        switch (element) {
            case FIRE -> meteor(player, level);
            case WATER -> guardian(player, level);
            case EARTH -> fissure(player, level);
            case AIR -> greatTornado(player, level);
        }
    }

    static Vec3d aimGround(ServerPlayerEntity player, double range) {
        ServerWorld world = player.getServerWorld();
        Vec3d aim = Spells.crosshair(player, range);
        for (int drop = 0; drop < 24; drop += 6) {
            double ground = Spells.groundAt(world, aim.add(0, 1 - drop, 0));
            if (!Double.isNaN(ground)) {
                return new Vec3d(aim.x, ground, aim.z);
            }
        }
        // Прицел в небе: цель падает на поверхность под ним.
        int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(aim.x), (int) Math.floor(aim.z));
        return new Vec3d(aim.x, top, aim.z);
    }

    /** Удар по всем врагам рядом с точкой. */
    static void blast(ServerPlayerEntity player, Vec3d at, double radius, float damage, double throwUp) {
        for (LivingEntity near : Abilities.livingAt(player, at, radius)) {
            Abilities.pierce(player, near, damage);
            Vec3d away = near.getPos().subtract(at);
            Vec3d flat = new Vec3d(away.x, 0, away.z);
            Abilities.push(near, (flat.lengthSquared() < 0.01 ? Vec3d.ZERO : flat.normalize().multiply(throwUp * 0.7)).add(0, throwUp, 0));
        }
    }

    // ------------------------------------------------------------------ огонь

    /** Рывок вперёд: под ногами остаётся горящий след. */
    private static void fireStep(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_CAST, 1.3F);
        Vec3d velocity = Spells.flatLook(player).multiply(1.5).add(0, 0.12, 0);
        Effects.repeat(world, 7, 1, step -> {
            if (!player.isAlive()) {
                return false;
            }
            Abilities.push(player, velocity);
            player.fallDistance = 0;
            if (step % 2 == 0) {
                Vec3d at = player.getPos();
                double ground = Spells.groundAt(world, at.add(0, 1, 0));
                Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
                Nature.burn(world, player, base.add(0, 0.5, 0), 1.4);
                SpellEntity.spawn(world, SpellKind.FLAME_RING, base, 1.6F * Spells.big(level), 30 + level * 6).charged(Element.FIRE, player).logic(self -> {
                    if (self.age % 10 == 0) {
                        for (LivingEntity near : Abilities.monstersAt(player, base.add(0, 1, 0), 2.2)) {
                            Abilities.hurt(player, near, 2 + level * 0.6F);
                            near.setOnFireFor(Spells.burnTime(level));
                        }
                    }
                });
            }
            return true;
        });
    }

    /** Рой искр: три огонька кружат вокруг игрока и по одному находят врагов сами. */
    private static void sparkSwarm(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_CHARGE, 1.5F);
        int count = Math.min(6, 2 + level / 2);
        for (int i = 0; i < count; i++) {
            int index = i;
            int release = 20 + i * 12;
            Set<UUID> struck = new HashSet<>();
            SpellEntity.spawn(world, SpellKind.FIREBALL, player.getEyePos(), 0.5F, 130).charged(Element.FIRE, player).logic(self -> {
                if (!player.isAlive()) {
                    self.discard();
                    return;
                }
                if (self.age < release) {
                    double angle = index * Math.PI * 2 / count + self.age * 0.25;
                    Spells.hover(self, player.getPos().add(Math.cos(angle) * 1.8, 1.4 + 0.3 * Math.sin(angle * 2), Math.sin(angle) * 1.8));
                    return;
                }
                LivingEntity near = nearest(player, self.getPos(), 22);
                Vec3d to = near != null ? near.getBoundingBox().getCenter().subtract(self.getPos()).normalize().multiply(0.9) : self.getVelocity();
                if (to.lengthSquared() < 0.01) {
                    to = player.getRotationVector().multiply(0.9);
                }
                self.setVelocity(self.getVelocity().lerp(to, 0.25));
                boolean ended = Spells.fly(self, player, 0.6, true, struck, (at, target) -> {
                    Abilities.pierce(player, target, 5 + level);
                    target.setOnFireFor(Spells.burnTime(level));
                    return true;
                });
                if (ended) {
                    SpellEntity.spawn(world, SpellKind.FIRE_BURST, self.getPos(), 0.6F, 17);
                    Nature.burn(world, player, self.getPos(), 1.5);
                    self.discard();
                }
            });
        }
    }

    private static void ballLightning(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.LIGHTNING, 1.3F);
        SpellEntity.spawn(world, SpellKind.ORB, Spells.muzzle(player, 2.0), 1.3F * Spells.big(level), 120 + level * 20).tint(LIGHTNING_COLOR).charged(Element.FIRE, player).logic(self -> {
            LivingEntity near = nearest(player, self.getPos(), 18);
            Vec3d goal = near != null ? near.getBoundingBox().getCenter().add(0, 1, 0) : Spells.crosshair(player, 16);
            Vec3d to = goal.subtract(self.getPos());
            self.setVelocity(self.getVelocity().lerp(to.lengthSquared() < 1 ? Vec3d.ZERO : to.normalize().multiply(0.3), 0.15));
            self.setPosition(self.getPos().add(self.getVelocity()));
            if (self.age % 14 == 0 && near != null && near.squaredDistanceTo(self) < 49) {
                Paths.bolt(world, self.getPos(), near.getBoundingBox().getCenter(), LIGHTNING_COLOR);
                Abilities.soundAt(world, self.getPos(), Sounds.LIGHTNING, 1.5F);
                Abilities.pierce(player, near, 5 + level);
                Nature.shock(world, player, near, 5 + level, LIGHTNING_COLOR);
            }
        });
    }

    private static void lavaShield(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.MAGMA, 1.2F);
        int rocks = Math.min(6, 2 + level / 2);
        for (int i = 0; i < rocks; i++) {
            int index = i;
            SpellEntity.spawn(world, SpellKind.MAGMA_BOULDER, player.getPos(), 0.55F * Spells.big(level), 240).logic(self -> {
                if (!player.isAlive()) {
                    self.discard();
                    return;
                }
                double angle = index * Math.PI * 2 / rocks + self.age * 0.14;
                Spells.hover(self, player.getPos().add(Math.cos(angle) * 2.6, 1.1, Math.sin(angle) * 2.6));
                if (self.age % 10 == 0) {
                    for (LivingEntity near : Abilities.livingAt(player, self.getPos(), 1.6)) {
                        Abilities.pierce(player, near, 3 + level);
                        near.setOnFireFor(5);
                    }
                }
            });
        }
    }

    /** Метеорит: на земле загорается круг, с неба падает огромная раскалённая глыба. */
    private static void meteor(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d target = aimGround(player, 48);
        int flight = 46;
        float scale = Spells.big(level);
        double reach = 7 + level;
        Abilities.soundAt(world, target, Sounds.FIRE_CHARGE, 0.5F);
        SpellEntity.spawn(world, SpellKind.DANGER_RING, target.add(0, 0.08, 0), (float) reach * 0.8F, flight).tint(0xFF5A20);
        Vec3d start = target.add(16, 62, 10);
        Vec3d velocity = target.subtract(start).multiply(1.0 / flight);
        SpellEntity rock = SpellEntity.spawn(world, SpellKind.METEOR, start, 5.5F * scale, flight + 2).facing(velocity);
        rock.setVelocity(velocity);
        rock.logic(self -> {
            self.setPosition(self.getPos().add(velocity));
            if (self.age % 12 == 0) {
                Abilities.soundAt(world, self.getPos(), Sounds.FLAME_LOOP, 0.5F);
            }
            if (self.age >= flight) {
                SpellEntity.spawn(world, SpellKind.FIRE_BURST, target.add(0, 1, 0), 7.0F * scale, 17);
                SpellEntity.spawn(world, SpellKind.ROCK_BURST, target.add(0, 1, 0), 4.5F, 18).tint(0x5A4038);
                SpellEntity.spawn(world, SpellKind.WIND_BURST, target.add(0, 1, 0), 11.0F, 14);
                Spells.ring(world, SpellKind.GROUND_SLAB, target, 6.0, 16, 50, 1.6F, 0x4A3A34);
                Spells.ring(world, SpellKind.GROUND_SLAB, target, 10.0, 24, 50, 1.8F, 0x4A3A34);
                Abilities.soundAt(world, target, Sounds.BOSS_DEATH, 1.2F);
                Abilities.soundAt(world, target, Sounds.FIRE_BLAST, 0.6F);
                blast(player, target.add(0, 1, 0), reach, 34 + level * 4, 1.1);
                Nature.burn(world, player, target.add(0, 1, 0), 7);
                Nature.crush(world, player, target.add(0, 1, 0), 7);
                for (LivingEntity near : Abilities.livingAt(player, target, reach)) {
                    near.setOnFireFor(Spells.burnTime(level) * 2);
                }
                Combos.magmaPool(player, target, 14);
                self.discard();
            }
        });
    }

    // ------------------------------------------------------------------ вода

    private static void geyser(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = aimGround(player, 26);
        Abilities.soundAt(world, base, Sounds.WATER_RISE, 0.7F);
        SpellEntity.spawn(world, SpellKind.DANGER_RING, base.add(0, 0.08, 0), 2.6F, 10).tint(0x5CC8FF);
        Effects.later(world, 10, () -> {
            SpellEntity.spawn(world, SpellKind.WATER_GEYSER, base, 1.3F * Spells.big(level), 30);
            Abilities.soundAt(world, base, Sounds.WATER_HIT, 0.7F);
            Nature.douse(world, player, base.add(0, 0.5, 0), 3.2);
            for (LivingEntity near : Abilities.livingAt(player, base.add(0, 1.5, 0), 3.2)) {
                Abilities.hurt(player, near, 7 + level * 1.5F);
                Abilities.push(near, new Vec3d(0, 1.35, 0));
            }
        });
    }

    /** Пузырь: цель поднимается в шаре воды и беспомощно висит четыре секунды. */
    private static void bubble(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        LivingEntity target = Abilities.aim(player, 24);
        Abilities.sound(player, Sounds.WATER_RISE, 1.3F);
        if (target == null) {
            return;
        }
        Vec3d hang = target.getPos().add(0, 2.5, 0);
        SpellEntity.spawn(world, SpellKind.WATER_BLOB, target.getBoundingBox().getCenter(), 2.2F, 80).charged(Element.WATER, player).logic(self -> {
            if (!target.isAlive()) {
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, self.getPos(), 1.0F, 15);
                self.discard();
                return;
            }
            Spells.hover(self, target.getBoundingBox().getCenter());
            Abilities.push(target, hang.subtract(target.getPos()).multiply(0.2));
            target.fallDistance = 0;
            if (self.age % 20 == 0) {
                Abilities.hurt(player, target, 2 + level * 0.6F);
            }
            if (self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, self.getPos(), 1.3F, 15);
                Abilities.soundAt(world, self.getPos(), Sounds.WATER_HIT, 1.0F);
            }
        });
    }

    private static void icePrison(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        LivingEntity target = Abilities.aim(player, 26);
        Abilities.sound(player, Sounds.ICE_FORM, 0.7F);
        if (target == null) {
            return;
        }
        Vec3d base = target.getPos();
        Spells.ring(world, SpellKind.ICE_SHARD, base, 1.3, 8, 110, 1.3F, 0xFFFFFF);
        Spells.ring(world, SpellKind.ICE_SHARD, base, 2.4, 11, 110, 1.0F, 0xFFFFFF);
        Abilities.pierce(player, target, 9 + level * 2);
        Abilities.debuff(target, StatusEffects.SLOWNESS, 110, 8);
        Abilities.debuff(target, StatusEffects.WEAKNESS, 110, 2);
        target.setFrozenTicks(240);
    }

    /** Целебный дождь: туча над игроком, все друзья под ней лечатся, а монстры мокнут и слабеют. */
    private static void healingRain(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = player.getPos();
        Abilities.soundAt(world, center, Sounds.WATER_HEAL, 0.8F);
        SpellEntity.spawn(world, SpellKind.STORM_CLOUD, center.add(0, 7, 0), 3.4F, 200);
        SpellEntity.spawn(world, SpellKind.RAIN, center, 3.0F, 200);
        Effects.repeat(world, 10, 20, step -> {
            Nature.douse(world, player, center.add(0, 1, 0), 8);
            Nature.grow(world, player, center, 9);
            Box area = new Box(center, center).expand(9);
            for (PlayerEntity ally : world.getEntitiesByClass(PlayerEntity.class, area, PlayerEntity::isAlive)) {
                ally.heal(2 + level * 0.3F);
                SpellEntity.spawn(world, SpellKind.HEAL_SPIRAL, ally.getPos(), 1.0F, 20).owner(ally).tint(0x6FE3D2).logic(self -> self.setPosition(ally.getPos()));
            }
            for (LivingEntity near : Abilities.monstersAt(player, center, 9)) {
                Abilities.debuff(near, StatusEffects.WEAKNESS, 30, 1);
            }
            return true;
        });
    }

    /** Страж воды: огромная фигура из воды двадцать секунд сама ходит за врагами и бьёт их. */
    private static void guardian(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d start = Spells.groundAhead(player, 7.0).add(0, 3.2, 0);
        Abilities.soundAt(world, start, Sounds.WATER_WAVE, 0.6F);
        Abilities.soundAt(world, start, Sounds.BOSS_AWAKE, 1.5F);
        SpellEntity.spawn(world, SpellKind.WATER_SPLASH, start.add(0, -3, 0), 3.5F, 15);
        SpellEntity.spawn(world, SpellKind.WATER_GUARDIAN, start, 2.1F * Spells.big(level), 220 + level * 40).charged(Element.WATER, player).logic(self -> {
            if (!player.isAlive()) {
                self.discard();
                return;
            }
            LivingEntity near = nearest(player, self.getPos(), 22);
            // Без врагов страж идёт сбоку и чуть впереди: прямо перед игроком он закрыл бы весь обзор.
            Vec3d forward = Spells.flatLook(player);
            Vec3d beside = player.getPos().add(-forward.z * 6, 3.2, forward.x * 6).add(forward.multiply(4));
            Vec3d goal = near != null ? near.getPos().add(1.8, 3.0, 1.8) : beside;
            Vec3d to = goal.subtract(self.getPos());
            Vec3d step = to.lengthSquared() < 0.05 ? Vec3d.ZERO : to.normalize().multiply(Math.min(0.42, to.length() * 0.2));
            self.setVelocity(step);
            self.setPosition(self.getPos().add(step));
            Vec3d face = near != null ? near.getPos().subtract(self.getPos()) : step;
            if (face.horizontalLengthSquared() > 0.01) {
                self.facing(new Vec3d(face.x, 0, face.z));
            }
            if (near == null) {
                return;
            }
            if (self.age % 26 == 0 && near.squaredDistanceTo(self) < 49) {
                Vec3d at = near.getBoundingBox().getCenter();
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, at, 1.6F, 15);
                Abilities.soundAt(world, at, Sounds.WATER_HIT, 0.7F);
                blast(player, at, 3.6, 9 + level * 2, 0.55);
                Nature.douse(world, player, at, 3);
            } else if (self.age % 34 == 0) {
                Abilities.soundAt(world, self.getPos(), Sounds.WATER_WHIP, 0.8F);
                Vec3d velocity = near.getBoundingBox().getCenter().subtract(self.getPos()).normalize().multiply(1.1);
                Set<UUID> struck = new HashSet<>();
                SpellEntity shot = SpellEntity.spawn(world, SpellKind.WATER_BLOB, self.getPos(), 0.9F, 50);
                shot.setVelocity(velocity);
                shot.logic(blob -> {
                    boolean ended = Spells.fly(blob, player, 0.7, true, struck, (point, hit) -> {
                        Abilities.pierce(player, hit, 7 + level * 1.5F);
                        return true;
                    });
                    if (ended) {
                        SpellEntity.spawn(world, SpellKind.WATER_SPLASH, blob.getPos(), 0.9F, 15);
                        blob.discard();
                    }
                });
            }
            if (self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, self.getPos(), 3.2F, 15);
            }
        });
    }

    // ------------------------------------------------------------------ земля

    /** Каменный кулак вырывается из земли прямо под врагом и подбрасывает его. */
    private static void earthFist(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = aimGround(player, 24);
        int tint = Spells.groundColor(world, base);
        Abilities.soundAt(world, base, Sounds.EARTH_RISE, 1.2F);
        SpellEntity.spawn(world, SpellKind.GROUND_RING, base, 1.2F, 40).tint(tint);
        SpellEntity.spawn(world, SpellKind.DUST_PUFF, base, 1.2F, 18).tint(tint);
        Effects.later(world, 6, () -> {
            SpellEntity.spawn(world, SpellKind.ROCK_FIST, base, 1.6F * Spells.big(level), 40).tint(tint);
            Abilities.soundAt(world, base, Sounds.EARTH_HIT, 1.1F);
            Nature.crush(world, player, base.add(0, 1, 0), 2.2);
            for (LivingEntity near : Abilities.livingAt(player, base.add(0, 1, 0), 3.0)) {
                Abilities.hurt(player, near, 9 + level * 2);
                Abilities.push(near, new Vec3d(0, 1.25, 0));
            }
        });
    }

    /** Прыжок на плите: игрока выбрасывает вперёд, а приземление бьёт по всем вокруг. */
    private static void stoneLeap(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d feet = player.getPos();
        int tint = Spells.groundColor(world, feet);
        Abilities.soundAt(world, feet, Sounds.EARTH_THROW, 1.0F);
        SpellEntity.spawn(world, SpellKind.GROUND_SLAB, feet, 1.6F, 26).tint(tint);
        Abilities.push(player, Spells.flatLook(player).multiply(1.3).add(0, 1.15, 0));
        Effects.repeat(world, 80, 1, step -> {
            player.fallDistance = 0;
            if (step < 5 || !player.isOnGround()) {
                return player.isAlive();
            }
            Vec3d at = player.getPos();
            int color = Spells.groundColor(world, at);
            Spells.ring(world, SpellKind.GROUND_SLAB, at, 3.0, 10, 28, 1.1F, color);
            SpellEntity.spawn(world, SpellKind.DUST_PUFF, at, 2.4F, 18).tint(color);
            Abilities.soundAt(world, at, Sounds.EARTH_QUAKE, 1.2F);
            blast(player, at.add(0, 1, 0), 5, 9 + level * 2, 0.7);
            return false;
        });
    }

    private static void sandBlast(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d look = Spells.flatLook(player);
        Abilities.sound(player, Sounds.SAND, 1.3F);
        Effects.repeat(world, 6, 2, step -> {
            Vec3d at = player.getPos().add(look.multiply(2 + step * 2)).add(0, 1, 0);
            SpellEntity.spawn(world, SpellKind.DUST_PUFF, at, 1.6F + step * 0.25F, 18).tint(0xD9C08C);
            for (LivingEntity near : Abilities.livingAt(player, at, 2.2 + step * 0.3)) {
                Abilities.pierce(player, near, 3 + level * 0.7F);
                Abilities.debuff(near, StatusEffects.BLINDNESS, 80, 0);
                Abilities.push(near, look.multiply(0.5).add(0, 0.2, 0));
            }
            return true;
        });
    }

    /** Стальная буря: десять клинков шесть секунд кружат широким кольцом и режут всё, что рядом. */
    private static void steelStorm(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.METAL, 0.8F);
        int count = Math.min(12, 4 + level);
        for (int i = 0; i < count; i++) {
            int index = i;
            SpellEntity.spawn(world, SpellKind.METAL_BLADE, player.getEyePos(), 1.1F, 120).logic(self -> {
                if (!player.isAlive()) {
                    self.discard();
                    return;
                }
                double angle = index / (double) count * Math.PI * 2 + self.age * 0.3;
                double radius = 2 + Math.min(3.0, self.age * 0.1);
                Spells.hover(self, player.getPos().add(Math.cos(angle) * radius, 1.0 + 0.5 * Math.sin(angle * 3), Math.sin(angle) * radius));
                if (self.age % 8 == 0) {
                    for (LivingEntity near : Abilities.livingAt(player, self.getPos(), 1.5)) {
                        Abilities.pierce(player, near, 3 + level * 0.8F);
                    }
                }
                if (self.age % 16 == 0 && index == 0) {
                    Abilities.soundAt(world, self.getPos(), Sounds.METAL, 1.4F);
                }
            });
        }
    }

    /** Разлом: земля рвётся на тридцать блоков вперёд, по бокам встают скалы, из глубины бьёт магма. */
    private static void fissure(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d forward = Spells.flatLook(player);
        Vec3d across = new Vec3d(-forward.z, 0, forward.x);
        Vec3d start = player.getPos();
        Set<UUID> struck = new HashSet<>();
        Abilities.sound(player, Sounds.EARTH_QUAKE, 0.6F);
        Abilities.sound(player, Sounds.BOSS_AWAKE, 0.9F);
        Effects.repeat(world, 8 + level, 2, step -> {
            Vec3d at = start.add(forward.multiply(3 + step * 2));
            double ground = Spells.groundAt(world, at.add(0, 2, 0));
            Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
            int tint = Spells.groundColor(world, base);
            for (int side = -1; side <= 1; side += 2) {
                Vec3d edge = base.add(across.multiply(side * 2.4));
                SpellEntity.spawn(world, SpellKind.GROUND_SLAB, edge, 2.3F, 90).facing(across.multiply(side)).tint(tint);
                SpellEntity.spawn(world, SpellKind.STONE_SPIKE, edge.add(across.multiply(side * 1.6)), 1.5F, 80).tint(tint);
            }
            SpellEntity.spawn(world, SpellKind.MAGMA_POOL, base.add(0, 0.05, 0), 1.9F, 110);
            SpellEntity.spawn(world, SpellKind.DUST_PUFF, base, 2.2F, 18).tint(tint);
            if (step % 3 == 0) {
                SpellEntity.spawn(world, SpellKind.MAGMA_GEYSER, base, 0.8F, 26);
                Abilities.soundAt(world, base, Sounds.EARTH_HIT, 0.7F);
            }
            for (LivingEntity near : Abilities.livingAt(player, base.add(0, 1, 0), 4.6)) {
                if (struck.add(near.getUuid())) {
                    Abilities.pierce(player, near, 24 + level * 3);
                    Abilities.push(near, new Vec3d(0, 1.3, 0));
                    near.setOnFireFor(Spells.burnTime(level));
                }
            }
            return true;
        });
    }

    // ------------------------------------------------------------------ воздух

    /** Полёт: несколько секунд игрок летит туда, куда смотрит, а потом плавно опускается. */
    private static void flight(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_GUST, 1.3F);
        SpellEntity.spawn(world, SpellKind.WIND_BURST, player.getPos(), 2.4F, 14);
        int ticks = 60 + level * 8;
        SpellEntity.spawn(world, SpellKind.WIND_TUNNEL, player.getPos(), 0.9F, ticks).owner(player).facing(player.getRotationVector())
                .logic(self -> {
                    self.setPosition(player.getPos());
                    self.setVelocity(player.getVelocity());
                });
        Effects.repeat(world, ticks, 1, step -> {
            if (!player.isAlive()) {
                return false;
            }
            Abilities.push(player, player.getVelocity().multiply(0.55).add(player.getRotationVector().multiply(0.42)));
            player.fallDistance = 0;
            return true;
        });
        Effects.later(world, ticks, () -> Abilities.buff(player, StatusEffects.SLOW_FALLING, 100, 0));
    }

    /** Порыв: широкая волна воздуха отбрасывает всех перед игроком. */
    private static void gust(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d look = player.getRotationVector();
        Abilities.sound(player, Sounds.AIR_DASH, 0.8F);
        Effects.repeat(world, 5, 2, step -> {
            Vec3d at = player.getEyePos().add(look.multiply(2 + step * 2.5));
            SpellEntity.spawn(world, SpellKind.WIND_BURST, at, 1.4F + step * 0.5F, 14);
            Nature.blow(world, player, at, 2.5 + step * 0.5, look.multiply(0.9).add(0, 0.25, 0));
            return true;
        });
        Set<UUID> struck = new HashSet<>();
        for (LivingEntity near : Abilities.livingAt(player, player.getEyePos().add(look.multiply(7)), 8)) {
            Vec3d to = near.getBoundingBox().getCenter().subtract(player.getEyePos()).normalize();
            if (to.dotProduct(look) > 0.55 && struck.add(near.getUuid())) {
                Abilities.hurt(player, near, 4 + level);
                Abilities.push(near, look.multiply(2.0).add(0, 0.6, 0));
            }
        }
    }

    private static void skyWrath(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = aimGround(player, 34);
        SpellEntity.spawn(world, SpellKind.STORM_CLOUD, base.add(0, 11, 0), 3.0F, 50);
        Abilities.soundAt(world, base, Sounds.THUNDER, 1.1F);
        int strikes = Math.min(6, 2 + level / 2);
        for (int i = 0; i < strikes; i++) {
            Effects.later(world, 10 + i * 9, () -> {
                Vec3d strike = base.add(world.random.nextDouble() * 5 - 2.5, 0, world.random.nextDouble() * 5 - 2.5);
                Paths.bolt(world, strike.add(0, 11, 0), strike, LIGHTNING_COLOR);
                SpellEntity.spawn(world, SpellKind.WIND_BURST, strike.add(0, 0.5, 0), 2.2F, 14);
                Abilities.soundAt(world, strike, Sounds.LIGHTNING, 0.7F);
                blast(player, strike.add(0, 1, 0), 3.6, 8 + level * 2, 0.4);
                Nature.lightningAt(world, player, strike);
                Nature.burn(world, player, strike.add(0, 0.5, 0), 1.2);
            });
        }
    }

    /** Разрежение: внутри купола нечем дышать, враги вязнут и теряют силы. */
    private static void thinAir(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = Spells.crosshair(player, 24);
        Abilities.soundAt(world, center, Sounds.VACUUM, 1.3F);
        SpellEntity.spawn(world, SpellKind.WIND_DOME, center, 6.5F, 130).logic(self -> {
            if (self.age % 20 == 0) {
                for (LivingEntity near : Abilities.monstersAt(player, center, 6.5)) {
                    Abilities.hurt(player, near, 2 + level * 0.8F);
                    Abilities.debuff(near, StatusEffects.SLOWNESS, 30, 3);
                    Abilities.debuff(near, StatusEffects.WEAKNESS, 30, 2);
                }
            }
        });
    }

    /** Великий торнадо: огромная воронка идёт за взглядом игрока, а ЛКМ отпускает её вперёд. */
    private static void greatTornado(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d start = Spells.groundAhead(player, 7.0);
        Abilities.soundAt(world, start, Sounds.BOSS_AWAKE, 1.3F);
        Abilities.soundAt(world, start, Sounds.AIR_TORNADO, 0.6F);
        SpellEntity.spawn(world, SpellKind.WIND_BURST, start.add(0, 1, 0), 8.0F, 14);
        Vec3d[] drift = {Vec3d.ZERO};
        SpellEntity storm = SpellEntity.spawn(world, SpellKind.GREAT_TORNADO, start, 3.0F * Spells.big(level), 340).charged(Element.AIR, player);
        storm.logic(self -> {
            Vec3d at = self.getPos();
            if (Control.holding(player, self)) {
                Vec3d goal = aimGround(player, 34);
                Vec3d to = new Vec3d(goal.x - at.x, 0, goal.z - at.z);
                drift[0] = to.lengthSquared() < 0.2 ? Vec3d.ZERO : to.normalize().multiply(Math.min(0.5, to.length() * 0.1));
            }
            double ground = Spells.groundAt(world, at.add(0, 2, 0));
            double dy = Double.isNaN(ground) ? 0 : Math.max(-0.5, Math.min(0.5, ground - at.y));
            self.setVelocity(drift[0].add(0, dy, 0));
            self.setPosition(at.add(self.getVelocity()));
            if (self.age % 28 == 0) {
                Abilities.soundAt(world, at, Sounds.AIR_TORNADO, 0.55F);
            }
            for (LivingEntity near : Abilities.monstersAt(player, at.add(0, 4, 0), 10 + level)) {
                Vec3d core = at.subtract(near.getPos());
                Vec3d flat = new Vec3d(core.x, 0, core.z);
                double distance = Math.max(0.5, flat.length());
                Vec3d around = new Vec3d(-flat.z, 0, flat.x).normalize().multiply(0.5);
                Abilities.push(near, flat.normalize().multiply(0.42).add(around).add(0, distance < 6 ? 0.5 : 0.1, 0));
                if (self.age % 10 == 0 && distance < 7) {
                    Abilities.pierce(player, near, 4 + level);
                }
            }
        });
        Control.hold(player, Abilities.ULTIMATE_SLOT, storm, 12, () -> {
            Vec3d look = Spells.flatLook(player);
            drift[0] = look.multiply(0.45);
        });
    }

    private static LivingEntity nearest(ServerPlayerEntity player, Vec3d from, double range) {
        List<LivingEntity> list = Abilities.monstersAt(player, from, range);
        return list.stream().min(Comparator.comparingDouble(near -> near.getPos().squaredDistanceTo(from))).orElse(null);
    }
}
