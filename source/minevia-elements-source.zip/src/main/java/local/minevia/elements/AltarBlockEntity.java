package local.minevia.elements;

import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.util.math.BlockPos;

/** Данных не хранит: нужна только затем, чтобы над алтарём рисовалось живое ядро. */
public final class AltarBlockEntity extends BlockEntity {
    public AltarBlockEntity(BlockPos pos, BlockState state) {
        super(MineviaElements.ALTAR_ENTITY, pos, state);
    }
}
