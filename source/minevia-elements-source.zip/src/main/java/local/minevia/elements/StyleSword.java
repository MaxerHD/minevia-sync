package local.minevia.elements;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Серии разрезов и защитные стойки меча. */
final class StyleSword {
    private record Guard(SpellEntity spell, long stamp, int level) { }
    private static final Map<UUID, Guard> GUARDS = new HashMap<>();
    private static final Map<UUID, long[]> SERIES = new HashMap<>();

    private StyleSword() { }

    static void forget(UUID id) {
        SERIES.remove(id);
        Guard guard = GUARDS.remove(id);
        if (guard != null) guard.spell().discard();
    }

    static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayerEntity p)) return true;
        Guard guard = GUARDS.get(p.getUuid());
        if (guard == null) return true;
        if (guard.spell().isRemoved() || !StyleSupport.valid(p, Element.SWORD, guard.stamp())) {
            GUARDS.remove(p.getUuid());
            return true;
        }
        if (!(source.getAttacker() instanceof LivingEntity enemy) || !Abilities.canHit(enemy, p)) return true;
        GUARDS.remove(p.getUuid());
        guard.spell().discard();
        StyleSupport.hit(p, enemy, Math.min(24, amount + 4 + guard.level()));
        if (guard.level() >= 3) Abilities.debuff(enemy, StatusEffects.WEAKNESS, 80, 1);
        if (guard.level() >= 5) StyleSupport.area(p, p.getPos(), 5, 7, e -> StyleSupport.root(e, 35));
        Abilities.sound(p, Sounds.SWORD_HIT, 0.8F);
        return false;
    }

    static int pause(ServerPlayerEntity p) {
        long[] series = SERIES.get(p.getUuid());
        return series != null && series[1] % 3 == 0 ? 26 : 9;
    }

    static void cast(ServerPlayerEntity p, int slot, int path, int level) {
        Abilities.sound(p, Sounds.SWORD_SWING, slot == 9 ? 0.6F : 1.0F);
        switch (slot) {
            case 0 -> cleave(p, level);
            case 1 -> StyleSupport.follow(p, SpellKind.SWORD_VORTEX, 65, self -> {
                if (level >= 3 && self.age % 4 == 0) StyleSupport.area(p, p.getPos().add(0, 1, 0), 5, 0, e -> Abilities.push(e, p.getPos().subtract(e.getPos()).normalize().multiply(0.4)));
                if (level >= 5 && self.age == 60) slash(p, level, 2, true);
                if (self.age % 8 == 0) StyleSupport.area(p, p.getPos().add(0, 1, 0), 3.5, 2 + level * 0.5F,
                        e -> Abilities.push(e, e.getPos().subtract(p.getPos()).normalize().multiply(0.3)));
            });
            case 2 -> {
                var d = ElementState.get(p.getServer()).getOrAssign(p.getUuid());
                SpellEntity guard = StyleSupport.model(p, SpellKind.SWORD_PARRY, p.getPos(), 1, 100, self -> {
                    self.setPosition(p.getPos()); self.facing(Spells.flatLook(p));
                });
                Guard old = GUARDS.put(p.getUuid(), new Guard(guard, d.changedAt, level));
                if (old != null) old.spell().discard();
            }
            case 3 -> {
                StyleSupport.dash(p, SpellKind.SWORD_LUNGE, level >= 3 ? 12 : 8, 1.45, 8 + level * 1.5F);
                if (level >= 3) Abilities.buff(p, StatusEffects.RESISTANCE, 25, 1);
                if (level >= 5) Effects.later(p.getServerWorld(), 12, () -> slash(p, level, 2, true));
            }
            case 4 -> {
                Vec3d at = Skills.aimGround(p, 28);
                StyleSupport.fall(p, SpellKind.SWORD_FALLBLADE, at, 3.5F, 22, point -> {
                    StyleSupport.area(p, point.add(0, 1, 0), 5, 13 + level * 2,
                            e -> { Abilities.push(e, new Vec3d(0, 0.6, 0)); if (level >= 3) StyleSupport.root(e, 45); });
                    if (level >= 5) StyleSupport.field(p, SpellKind.SWORD_RING, point, 4, 65, 15, field -> StyleSupport.area(p, point, 5, 4, null));
                    Abilities.soundAt(p.getServerWorld(), point, Sounds.SWORD_HIT, 0.6F);
                });
            }
            case 5 -> {
                if (path == 1) riposte(p, level);
                else {
                    p.damage(p.getDamageSources().magic(), Math.min(4, Math.max(0, p.getHealth() - 1)));
                    Abilities.buff(p, StatusEffects.STRENGTH, 240, 1);
                    Abilities.buff(p, StatusEffects.SPEED, 240, 0);
                    StyleSupport.follow(p, SpellKind.SWORD_RAGE, 240, null);
                }
            }
            case 6 -> {
                if (path == 1) {
                    Abilities.buff(p, StatusEffects.SPEED, 180, 2);
                    Abilities.buff(p, StatusEffects.RESISTANCE, 100, 0);
                    StyleSupport.follow(p, SpellKind.SWORD_FLOW, 180, self -> {
                        if (self.age % 24 == 0) {
                            LivingEntity e = Abilities.aim(p, 5);
                            if (e != null) StyleSupport.hit(p, e, 3 + level);
                        }
                    });
                } else {
                    LivingEntity e = Abilities.aim(p, 12);
                    Vec3d at = e == null ? Spells.crosshair(p, 12) : e.getPos();
                    StyleSupport.fall(p, SpellKind.SWORD_EXECUTION, at, 2, 10, point -> {
                        if (e != null && e.isAlive() && e.squaredDistanceTo(point) < 9)
                            StyleSupport.hit(p, e, 10 + level * 2 + Math.min(18, (1 - e.getHealth() / e.getMaxHealth()) * 20));
                    });
                }
            }
            case 7 -> {
                LivingEntity target = Abilities.aim(p, 18);
                Vec3d at = target == null ? Spells.crosshair(p, 18) : target.getPos();
                StyleSupport.field(p, SpellKind.SWORD_NOTCH, at, 1.4F, 65, 15, self -> {
                    if (target != null && target.isAlive() && Abilities.canHit(target, p) && p.canSee(target) && target.squaredDistanceTo(at) < 25) {
                        self.setPosition(target.getPos());
                        StyleSupport.hit(p, target, 3 + level);
                        Abilities.debuff(target, StatusEffects.WEAKNESS, 45, 0);
                    }
                });
            }
            case 8 -> StyleSupport.field(p, SpellKind.SWORD_RING, p.getPos(), 4, 140, 12, self ->
                    StyleSupport.area(p, self.getPos().add(0, 1, 0), 4.5, 3 + level * 0.6F, e -> StyleSupport.root(e, 16)));
            case 9 -> {
                Vec3d at = Skills.aimGround(p, 30);
                StyleSupport.model(p, SpellKind.SWORD_THOUSAND, at, 3, 85, null);
                Effects.repeat(p.getServerWorld(), 12, 5, step -> {
                    LivingEntity target = Abilities.livingAt(p, at, 7).stream().filter(p::canSee)
                            .min(java.util.Comparator.comparingDouble(e -> e.squaredDistanceTo(at))).orElse(null);
                    Vec3d point = target == null ? at.add(Math.cos(step * 2.4) * 3, 0, Math.sin(step * 2.4) * 3) : target.getPos();
                    StyleSupport.fall(p, SpellKind.SWORD_FALLBLADE, point, 1.2F, 8, hit -> StyleSupport.area(p, hit.add(0, 1, 0), 1.8, 5 + level, null));
                    Gestures.play(p, step % 2 == 0 ? Gesture.STYLE_SWORD_CLEAVE : Gesture.STYLE_SWORD_LEFT, level);
                    return true;
                });
            }
        }
    }

    private static void cleave(ServerPlayerEntity p, int level) {
        long now = p.getServer().getTicks();
        long[] series = SERIES.computeIfAbsent(p.getUuid(), id -> new long[] {-100, 0});
        if (now - series[0] > 32) series[1] = 0;
        int side = (int) (series[1]++ % 3);
        series[0] = now;
        int count = level >= 3 ? (level >= 4 ? 3 : 2) : 1;
        for (int i = 0; i < count; i++) {
            int stroke = level >= 3 ? (i == 0 ? 1 : i == 1 ? 0 : 2) : side;
            Effects.later(p.getServerWorld(), i * 4, () -> slash(p, level, stroke, false));
        }
        if (level >= 5) Effects.later(p.getServerWorld(), 12, () -> slash(p, level, 2, true));
    }

    private static void slash(ServerPlayerEntity p, int level, int side, boolean big) {
        if (!StyleGear.equipped(p, Element.SWORD) || !p.isAlive()) return;
        Gesture gesture = side == 0 ? Gesture.STYLE_SWORD_CLEAVE : side == 1 ? Gesture.STYLE_SWORD_LEFT : Gesture.STYLE_SWORD_OVERHEAD;
        Gestures.play(p, gesture, level);
        Abilities.sound(p, Sounds.SWORD_SWING, big ? 0.65F : 1.1F + side * 0.12F);
        SpellKind kind = big ? SpellKind.SLASH_BIG : SpellKind.SLASH_ARC;
        var struck = new java.util.HashSet<UUID>();
        Vec3d direction = p.getRotationVector();
        SpellEntity arc = StyleSupport.model(p, kind, Spells.muzzle(p, 0.7), big ? 2.0F : level >= 2 ? 1.35F : 0.9F,
                big ? 14 : level >= 2 ? 8 : 6, self -> {
                    if (Spells.fly(self, p, big ? 1.7 : level >= 2 ? 1.1 : 0.7, true, struck, (at, e) -> {
                        StyleSupport.hit(p, e, (big ? 10 : 4) + level * 0.9F);
                        if (level >= 4 && side == 2 && !big) {
                            StyleSupport.model(p, SpellKind.SWORD_NOTCH, e.getPos(), 0.8F, 24, mark -> {
                                mark.setPosition(e.getPos());
                                if (mark.age == 20 && e.isAlive()) StyleSupport.hit(p, e, 3 + level);
                            });
                        }
                        return false;
                    })) self.discard();
                }).facing(direction).tint(side);
        arc.setVelocity(direction);
    }

    private static void riposte(ServerPlayerEntity p, int level) {
        LivingEntity target = Abilities.aim(p, 16);
        Vec3d at = target == null ? Spells.crosshair(p, 16) : target.getPos();
        StyleSupport.field(p, SpellKind.SWORD_RIPOSTE, at, 1.6F, 18, 6, self -> {
            if (target != null && target.isAlive() && target.squaredDistanceTo(at) < 36) {
                StyleSupport.hit(p, target, 5 + level);
                Abilities.debuff(target, StatusEffects.WEAKNESS, 80, 1);
            }
        });
    }
}
