package local.minevia.elements;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Клинки создаются силой стиля, предмет не нужен. */
final class StyleSword {
    private record Guard(SpellEntity spell, long stamp, int level) { }
    private static final Map<UUID, Guard> GUARDS = new HashMap<>();

    private StyleSword() { }

    static void forget(UUID id) {
        Guard guard = GUARDS.remove(id);
        if (guard != null) guard.spell().discard();
    }

    static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayerEntity p)) return true;
        Guard guard = GUARDS.get(p.getUuid());
        if (guard == null) return true;
        if (guard.spell().isRemoved() || !StyleSupport.valid(p, Element.SWORD, guard.stamp())) {
            GUARDS.remove(p.getUuid());
            return true;
        }
        if (!(source.getAttacker() instanceof LivingEntity enemy) || !Abilities.canHit(enemy, p)) return true;
        GUARDS.remove(p.getUuid());
        guard.spell().discard();
        StyleSupport.hit(p, enemy, Math.min(24, amount + 4 + guard.level()));
        Abilities.sound(p, Sounds.SWORD_HIT, 0.8F);
        return false;
    }

    static void cast(ServerPlayerEntity p, int slot, int path, int level) {
        Abilities.sound(p, Sounds.SWORD_SWING, slot == 9 ? 0.6F : 1.0F);
        switch (slot) {
            case 0 -> cleave(p, level);
            case 1 -> StyleSupport.follow(p, SpellKind.SWORD_VORTEX, 65, self -> {
                if (self.age % 8 == 0) StyleSupport.area(p, p.getPos().add(0, 1, 0), 3.5, 2 + level * 0.5F,
                        e -> Abilities.push(e, e.getPos().subtract(p.getPos()).normalize().multiply(0.3)));
            });
            case 2 -> {
                var d = ElementState.get(p.getServer()).getOrAssign(p.getUuid());
                SpellEntity guard = StyleSupport.model(p, SpellKind.SWORD_PARRY, p.getPos(), 1, 100, self -> {
                    self.setPosition(p.getPos()); self.facing(Spells.flatLook(p));
                });
                Guard old = GUARDS.put(p.getUuid(), new Guard(guard, d.changedAt, level));
                if (old != null) old.spell().discard();
            }
            case 3 -> StyleSupport.dash(p, SpellKind.SWORD_LUNGE, 8, 1.45, 8 + level * 1.5F);
            case 4 -> {
                Vec3d at = Skills.aimGround(p, 28);
                StyleSupport.fall(p, SpellKind.SWORD_FALLBLADE, at, 3.5F, 22, point -> {
                    StyleSupport.area(p, point.add(0, 1, 0), 5, 13 + level * 2,
                            e -> Abilities.push(e, new Vec3d(0, 0.6, 0)));
                    Abilities.soundAt(p.getServerWorld(), point, Sounds.SWORD_HIT, 0.6F);
                });
            }
            case 5 -> {
                if (path == 1) riposte(p, level);
                else {
                    p.damage(p.getDamageSources().magic(), Math.min(4, Math.max(0, p.getHealth() - 1)));
                    Abilities.buff(p, StatusEffects.STRENGTH, 240, 1);
                    Abilities.buff(p, StatusEffects.SPEED, 240, 0);
                    StyleSupport.follow(p, SpellKind.SWORD_RAGE, 240, null);
                }
            }
            case 6 -> {
                if (path == 1) {
                    Abilities.buff(p, StatusEffects.SPEED, 180, 2);
                    Abilities.buff(p, StatusEffects.RESISTANCE, 100, 0);
                    StyleSupport.follow(p, SpellKind.SWORD_FLOW, 180, self -> {
                        if (self.age % 24 == 0) {
                            LivingEntity e = Abilities.aim(p, 5);
                            if (e != null) StyleSupport.hit(p, e, 3 + level);
                        }
                    });
                } else {
                    LivingEntity e = Abilities.aim(p, 12);
                    Vec3d at = e == null ? Spells.crosshair(p, 12) : e.getPos();
                    StyleSupport.fall(p, SpellKind.SWORD_EXECUTION, at, 2, 10, point -> {
                        if (e != null && e.isAlive() && e.squaredDistanceTo(point) < 9)
                            StyleSupport.hit(p, e, 10 + level * 2 + Math.min(18, (1 - e.getHealth() / e.getMaxHealth()) * 20));
                    });
                }
            }
            case 7 -> {
                LivingEntity target = Abilities.aim(p, 18);
                Vec3d at = target == null ? Spells.crosshair(p, 18) : target.getPos();
                StyleSupport.field(p, SpellKind.SWORD_NOTCH, at, 1.4F, 65, 15, self -> {
                    if (target != null && target.isAlive() && Abilities.canHit(target, p) && p.canSee(target) && target.squaredDistanceTo(at) < 25) {
                        self.setPosition(target.getPos());
                        StyleSupport.hit(p, target, 3 + level);
                        Abilities.debuff(target, StatusEffects.WEAKNESS, 45, 0);
                    }
                });
            }
            case 8 -> StyleSupport.field(p, SpellKind.SWORD_RING, p.getPos(), 4, 140, 12, self ->
                    StyleSupport.area(p, self.getPos().add(0, 1, 0), 4.5, 3 + level * 0.6F, e -> StyleSupport.root(e, 16)));
            case 9 -> {
                Vec3d at = Skills.aimGround(p, 30);
                StyleSupport.field(p, SpellKind.SWORD_THOUSAND, at, 6, 100, 5, self ->
                        StyleSupport.area(p, at.add(0, 1, 0), 6, 2.5F + level * 0.45F,
                                e -> Abilities.debuff(e, StatusEffects.SLOWNESS, 15, 1)));
            }
        }
    }

    private static void cleave(ServerPlayerEntity p, int level) {
        StyleSupport.shot(p, SpellKind.SWORD_CLEAVE, Spells.muzzle(p, 1.5), p.getRotationVector().multiply(1.1),
                1.5F, 25, true, (self, e) -> {
                    StyleSupport.hit(p, e, 6 + level * 1.4F);
                    Abilities.soundAt(p.getServerWorld(), e.getPos(), Sounds.SWORD_HIT, 1);
                }, null);
    }

    private static void riposte(ServerPlayerEntity p, int level) {
        LivingEntity target = Abilities.aim(p, 16);
        Vec3d at = target == null ? Spells.crosshair(p, 16) : target.getPos();
        StyleSupport.field(p, SpellKind.SWORD_RIPOSTE, at, 1.6F, 18, 6, self -> {
            if (target != null && target.isAlive() && target.squaredDistanceTo(at) < 36) {
                StyleSupport.hit(p, target, 5 + level);
                Abilities.debuff(target, StatusEffects.WEAKNESS, 80, 1);
            }
        });
    }
}
