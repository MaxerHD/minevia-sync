package local.minevia.elements.temple;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import local.minevia.elements.Element;
import local.minevia.elements.MineviaElements;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.Heightmap;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureType;

/**
 * Храм стихии. Огонь стоит на суше, земля уходит под неё, воздух парит над ней,
 * а вода поднимается со дна там, где другие стоять не могут.
 */
public final class TempleStructure extends Structure {
    public static final MapCodec<TempleStructure> CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
            configCodecBuilder(instance),
            Codec.STRING.fieldOf("element").forGetter(temple -> temple.element.id())
    ).apply(instance, TempleStructure::new));

    private final Element element;

    private TempleStructure(Config config, String element) {
        super(config);
        this.element = Element.valueOf(element.toUpperCase(java.util.Locale.ROOT));
    }

    @Override
    protected Optional<StructurePosition> getStructurePosition(Context context) {
        int x = context.chunkPos().getStartX();
        int z = context.chunkPos().getStartZ();
        int size = TemplePiece.DEPTH;
        int sea = context.chunkGenerator().getSeaLevel();
        int ground = getMinCornerHeight(context, size, size);
        int floor = context.chunkGenerator().getHeightInGround(x + size / 2, z + size / 2, Heightmap.Type.OCEAN_FLOOR_WG,
                context.world(), context.noiseConfig());
        if (element != Element.WATER && floor < sea) {
            return Optional.empty();
        }
        int base = switch (element) {
            case EARTH -> ground - TemplePiece.BURIED;
            case WATER -> Math.max(ground, sea);
            default -> ground;
        };
        Direction facing = Direction.Type.HORIZONTAL.random(context.random());
        BlockPos origin = new BlockPos(x, base, z);
        return Optional.of(new StructurePosition(origin, collector -> collector.addPiece(new TemplePiece(element, origin, facing))));
    }

    @Override
    public StructureType<?> getType() {
        return MineviaElements.TEMPLE;
    }
}
