package local.minevia.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Приёмы Кузнеца, Хранителя и Звездочёта с предупреждением перед ударом. */
final class DungeonArts {
    private DungeonArts() {
    }

    static int use(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        int move = world.random.nextInt(3);
        return switch (boss.kind()) {
            case DungeonBoss.SMITH -> move == 0 ? hammer(boss, world) : move == 1 ? billets(boss, world, target) : bellows(boss, world);
            case DungeonBoss.KEEPER -> move == 0 ? whirlpool(boss, world) : move == 1 ? spears(boss, world, target) : retreat(boss, world);
            default -> move == 0 ? stars(boss, world, target) : move == 1 ? teleport(boss, world) : field(boss, world, target);
        };
    }

    private static boolean active(DungeonBoss boss) {
        return boss.isAlive() && !boss.isRemoved();
    }

    private static void warn(DungeonBoss boss, ServerWorld world, Vec3d at, float radius, int delay, Runnable action) {
        SpellEntity.spawn(world, SpellKind.DANGER_RING, at.add(0, 0.07, 0), radius, delay).tint(boss.tint());
        Effects.later(world, delay, () -> {
            if (active(boss)) {
                action.run();
            }
        });
    }

    private static int hammer(DungeonBoss boss, ServerWorld world) {
        Vec3d at = boss.getPos();
        Flourish.charge(world, at.add(0, 2.2, 0), 2.2F, 26, boss.tint());
        warn(boss, world, at, 9, 26, () -> {
            Abilities.soundAt(world, at, Sounds.EARTH_QUAKE, 0.7F);
            Set<UUID> hit = new HashSet<>();
            SpellEntity wave = SpellEntity.spawn(world, SpellKind.FORGE_WAVE, at, 0.5F, 24);
            wave.logic(self -> {
                if (!active(boss)) {
                    self.discard();
                    return;
                }
                float radius = 0.5F + self.age * 0.4F;
                self.setSize(radius);
                for (PlayerEntity player : ElementBoss.playersAt(world, at, radius + 1)) {
                    double distance = player.getPos().subtract(at).horizontalLength();
                    if (Math.abs(distance - radius) < 1.0 && Math.abs(player.getY() - at.y) < 0.8 && boss.canSee(player) && hit.add(player.getUuid())) {
                        boss.strike(world, player, 12);
                        Abilities.push(player, player.getPos().subtract(at).normalize().multiply(0.6).add(0, 0.35, 0));
                    }
                }
            });
        });
        return 65;
    }

    private static int billets(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d start = boss.getPos().add(0, 2.5, 0);
        Vec3d aim = target.getPos();
        Flourish.charge(world, start, 1.3F, 20, boss.tint());
        Effects.repeat(world, boss.angry() ? 5 : 3, 7, step -> {
            if (!active(boss)) {
                return false;
            }
            Vec3d end = aim.add((step % 3 - 1) * 2, 0.4, (step / 3) * 2);
            // Скорость рассчитана на дугу длиной в 28 тиков.
            Vec3d velocity = end.subtract(start).multiply(1.0 / 28).add(0, 0.035 * 27 / 2, 0);
            projectile(boss, world, SpellKind.HOT_BILLET, start, velocity, 0.035, 13);
            return true;
        }, 20);
        return 75;
    }

    private static int bellows(DungeonBoss boss, ServerWorld world) {
        Vec3d at = boss.getPos();
        warn(boss, world, at, 6, 32, () -> {
            SpellEntity.spawn(world, SpellKind.HEAT_BURST, at, 6, 22);
            Abilities.soundAt(world, at, Sounds.MAGMA, 0.8F);
            for (PlayerEntity player : ElementBoss.playersAt(world, at, 6)) {
                if (boss.canSee(player)) {
                    boss.strike(world, player, 9);
                    Abilities.debuff(player, StatusEffects.WEAKNESS, 80, 0);
                    Abilities.push(player, player.getPos().subtract(at).normalize().multiply(0.9).add(0, 0.3, 0));
                }
            }
        });
        return 70;
    }

    private static int whirlpool(DungeonBoss boss, ServerWorld world) {
        Vec3d at = boss.getPos().add(0, -0.8, 0);
        warn(boss, world, at, 7, 24, () -> {
            SpellEntity.spawn(world, SpellKind.DEPTH_VORTEX, at, 2.2F, 80);
            Effects.repeat(world, 16, 5, step -> {
                if (!active(boss)) {
                    return false;
                }
                for (PlayerEntity player : ElementBoss.playersAt(world, at, 7)) {
                    if (boss.canSee(player)) {
                        Vec3d pull = at.subtract(player.getPos()).multiply(0.055);
                        Abilities.push(player, player.getVelocity().add(pull.x, 0.035, pull.z));
                        if (step % 4 == 0 && player.squaredDistanceTo(at) < 7) {
                            boss.strike(world, player, 4);
                        }
                    }
                }
                return true;
            });
        });
        return 110;
    }

    private static int spears(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d start = boss.getPos().add(0, 1.6, 0);
        Vec3d direction = target.getEyePos().subtract(start).normalize();
        Flourish.charge(world, start, 1.8F, 24, boss.tint());
        Effects.later(world, 24, () -> {
            if (!active(boss)) {
                return;
            }
            for (int i = -2; i <= 2; i++) {
                projectile(boss, world, SpellKind.DEPTH_SPEAR, start, direction.rotateY(i * 0.13F).multiply(0.75), 0, 8);
            }
            Abilities.soundAt(world, start, Sounds.ICE_FORM, 1.3F);
        });
        return 65;
    }

    private static int retreat(DungeonBoss boss, ServerWorld world) {
        if (boss.getHealth() > boss.getMaxHealth() * 0.85F) {
            return whirlpool(boss, world);
        }
        boss.beginHealing(world);
        return 130;
    }

    private static Vec3d floor(ServerWorld world, Vec3d at) {
        double y = Spells.groundAt(world, at.add(0, 2, 0));
        return Double.isNaN(y) ? at : new Vec3d(at.x, y, at.z);
    }

    private static int stars(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d center = Vec3d.ofBottomCenter(boss.home());
        Vec3d aim = target.getPos();
        for (int i = 0; i < (boss.angry() ? 7 : 4); i++) {
            Vec3d marked = i == 0 ? aim : aim.add(world.random.nextDouble() * 8 - 4, 0, world.random.nextDouble() * 8 - 4);
            if (marked.subtract(center).horizontalLength() > 11) {
                marked = center;
            }
            Vec3d at = floor(world, marked);
            warn(boss, world, at, 2.3F, 36 + i * 5, () -> {
                projectile(boss, world, SpellKind.FALLING_STAR, at.add(0, 10, 0), new Vec3d(0, -0.85, 0), 0.025, 12);
            });
        }
        return 85;
    }

    private static int teleport(DungeonBoss boss, ServerWorld world) {
        Vec3d at = Vec3d.ofBottomCenter(boss.home());
        for (int attempt = 0; attempt < 32; attempt++) {
            double angle = world.random.nextDouble() * Math.PI * 2;
            Vec3d candidate = at.add(Math.cos(angle) * 20, 0, Math.sin(angle) * 20);
            double ground = Spells.groundAt(world, candidate);
            if (Double.isNaN(ground) || Math.abs(ground - at.y) > 2) {
                continue;
            }
            Vec3d to = new Vec3d(candidate.x, ground + 1.2, candidate.z);
            if (world.isSpaceEmpty(boss, boss.getBoundingBox().offset(to.subtract(boss.getPos())))) {
                Flourish.blast(world, boss.getPos(), 2, boss.tint());
                boss.perch(to);
                SpellEntity.spawn(world, SpellKind.STAR_FIELD, to.add(0, -1.1, 0), 2, 22);
                return 35;
            }
        }
        return 20;
    }

    private static int field(DungeonBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d at = floor(world, target.getPos());
        warn(boss, world, at, 5, 25, () -> {
            SpellEntity.spawn(world, SpellKind.STAR_FIELD, at.add(0, 0.08, 0), 5, 100);
            Effects.repeat(world, 20, 5, step -> {
                if (!active(boss)) {
                    return false;
                }
                for (PlayerEntity player : ElementBoss.playersAt(world, at, 5)) {
                    if (player.squaredDistanceTo(at) < 25) {
                        Abilities.debuff(player, StatusEffects.SLOWNESS, 16, 2);
                    }
                }
                return true;
            });
        });
        return 90;
    }

    private static void projectile(DungeonBoss boss, ServerWorld world, SpellKind kind, Vec3d start, Vec3d speed, double gravity, float damage) {
        Vec3d[] velocity = {speed};
        SpellEntity shot = SpellEntity.spawn(world, kind, start, kind == SpellKind.DEPTH_SPEAR ? 0.9F : 0.65F, 90).facing(speed);
        shot.setVelocity(speed);
        shot.logic(self -> {
            if (!active(boss)) {
                self.discard();
                return;
            }
            Vec3d from = self.getPos();
            Vec3d to = from.add(velocity[0]);
            HitResult block = world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, self));
            Vec3d stop = block.getPos();
            PlayerEntity struck = null;
            double nearest = from.squaredDistanceTo(stop);
            for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, new Box(from, to).expand(0.75), p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
                var intersection = player.getBoundingBox().expand(0.45).raycast(from, to);
                if (player.getBoundingBox().expand(0.45).contains(from)) {
                    struck = player;
                    nearest = 0;
                } else if (intersection.isPresent() && from.squaredDistanceTo(intersection.get()) <= nearest) {
                    nearest = from.squaredDistanceTo(intersection.get());
                    struck = player;
                }
            }
            if (struck != null) {
                boss.strike(world, struck, damage);
                if (kind == SpellKind.DEPTH_SPEAR) {
                    Abilities.debuff(struck, StatusEffects.SLOWNESS, 50, 1);
                }
                Flourish.hit(world, struck, boss.tint());
            }
            if (struck != null || block.getType() != HitResult.Type.MISS) {
                Vec3d at = struck == null ? stop : struck.getPos();
                Flourish.blast(world, at, 2.4F, boss.tint());
                if (kind == SpellKind.FALLING_STAR) {
                    for (PlayerEntity near : ElementBoss.playersAt(world, at, 2.3)) {
                        if (near != struck && boss.canSee(near)) {
                            boss.strike(world, near, damage);
                        }
                    }
                }
                self.discard();
                return;
            }
            self.setPosition(to);
            velocity[0] = velocity[0].add(0, -gravity, 0);
            self.setVelocity(velocity[0]);
            self.facing(velocity[0]);
        });
    }
}
