package local.minevia.elements;

import java.util.Comparator;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Хозяин подземелья. Спит на печати в наградной комнате и просыпается, когда подходит игрок.
 * Настоятель склепа поднимает кости и прыгает по комнате, Звонарь на крыше бьёт волнами, через которые надо
 * перепрыгивать, а Рогач несётся напролом: если он врезался в стену, он оглушён и получает больше урона.
 * Наградной сундук появляется только после победы. Если все ушли, хозяин снова засыпает.
 */
public final class DungeonBoss extends HostileEntity {
    public static final int ABBOT = 0;
    public static final int BELL = 1;
    public static final int BULL = 2;
    public static final int CALM = 0;
    public static final int WINDUP = 1;
    public static final int RUSH = 2;
    public static final int STUNNED = 3;

    private static final TrackedData<Integer> KIND = DataTracker.registerData(DungeonBoss.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> STATE = DataTracker.registerData(DungeonBoss.class, TrackedDataHandlerRegistry.INTEGER);
    private static final float[] HEALTH = {190, 230, 260};
    private static final String[] NAMES = {"abbot", "bell", "bull"};
    private static final BossBar.Color[] COLORS = {BossBar.Color.BLUE, BossBar.Color.YELLOW, BossBar.Color.RED};
    private static final int[] TINT = {0x7FD8FF, 0xFFD27A, 0xFF7A3A};
    private static final int RANGE = 22;
    private static final int STUN_TICKS = 80;
    private static final int RUSH_TICKS = 46;
    private static final float STUN_DAMAGE = 1.6F;
    private static final double RUSH_SPEED = 0.78;

    private final ServerBossBar bar = new ServerBossBar(Text.translatable("boss.minevia_elements.abbot"), BossBar.Color.BLUE, BossBar.Style.NOTCHED_10);
    private BlockPos home = BlockPos.ORIGIN;
    private int nextMove = 50;
    private int alone;
    private int hurtSound;
    private int raised;
    private int stateLeft;
    private Vec3d rushWay = Vec3d.ZERO;
    private boolean rushHit;

    public DungeonBoss(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        experiencePoints = 120;
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 200)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32)
                .add(EntityAttributes.GENERIC_ARMOR, 4);
    }

    /** Вызывается печатью. Здоровье растёт с числом игроков рядом. */
    static void wake(ServerWorld world, BlockPos sigil, int kind) {
        DungeonBoss boss = MineviaElements.DUNGEON_BOSS.create(world);
        if (boss == null) {
            return;
        }
        boss.dataTracker.set(KIND, kind);
        boss.home = sigil;
        boss.setNoGravity(kind != BULL);
        boss.setPosition(Vec3d.ofBottomCenter(sigil).add(0, kind == BULL ? 0 : 1.2, 0));
        int players = Math.max(1, world.getEntitiesByClass(PlayerEntity.class, new Box(sigil).expand(30), PlayerEntity::isAlive).size());
        float health = HEALTH[kind] * (1 + 0.6F * (players - 1));
        boss.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(health);
        boss.setHealth(health);
        boss.setPersistent();
        boss.setupBar();
        world.spawnEntity(boss);
        Flourish.blast(world, boss.getPos().add(0, 0.2, 0), 8, boss.tint());
    }

    private void setupBar() {
        bar.setName(Text.translatable("boss.minevia_elements." + NAMES[kind()]));
        bar.setColor(COLORS[kind()]);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(KIND, 0);
        builder.add(STATE, CALM);
    }

    public int kind() {
        return dataTracker.get(KIND);
    }

    public int state() {
        return dataTracker.get(STATE);
    }

    int tint() {
        return TINT[kind()];
    }

    BlockPos home() {
        return home;
    }

    boolean angry() {
        return getHealth() < getMaxHealth() / 2;
    }

    private void setState(int state, int ticks) {
        dataTracker.set(STATE, state);
        stateLeft = ticks;
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        ServerWorld world = (ServerWorld) getWorld();
        if (home.equals(BlockPos.ORIGIN)) {
            home = getBlockPos();
        }
        bar.setPercent(getHealth() / getMaxHealth());
        PlayerEntity target = closestFighter();
        if (target == null) {
            setVelocity(getVelocity().multiply(0.6, 1, 0.6));
            if (++alone > 300) {
                sleep(world);
            }
            return;
        }
        alone = 0;
        if (kind() == BULL && tickBull(world, target)) {
            return;
        }
        look(target);
        if (kind() == BULL) {
            walkTo(target);
        } else {
            float above = kind() == BELL ? 2.4F : 1.5F;
            Vec3d center = Vec3d.ofBottomCenter(home).add(0, above, 0);
            Vec3d away = getPos().subtract(target.getPos());
            Vec3d flat = new Vec3d(away.x, 0, away.z);
            Vec3d side = flat.lengthSquared() < 0.01 ? Vec3d.ZERO : flat.normalize();
            double reach = kind() == BELL ? 1.6 : 3.4;
            Vec3d spot = center.add(side.multiply(reach)).add(Math.sin(age * 0.05) * 0.6, Math.sin(age * 0.09) * 0.35, Math.cos(age * 0.05) * 0.6);
            Vec3d want = spot.subtract(getPos());
            double length = want.length();
            setVelocity(getVelocity().lerp(length < 0.1 ? Vec3d.ZERO : want.multiply(Math.min(0.24, length * 0.2) / length), 0.3));
        }
        if (--nextMove <= 0) {
            nextMove = DungeonMoves.use(this, world, target) + (angry() ? 8 : 26);
        }
    }

    private void look(PlayerEntity target) {
        Vec3d to = target.getPos().subtract(getPos());
        float yaw = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
        setYaw(yaw);
        setHeadYaw(yaw);
        setBodyYaw(yaw);
    }

    private void walkTo(PlayerEntity target) {
        Vec3d to = target.getPos().subtract(getPos());
        Vec3d flat = new Vec3d(to.x, 0, to.z);
        Vec3d step = flat.length() < 2.6 ? Vec3d.ZERO : flat.normalize().multiply(angry() ? 0.17 : 0.13);
        setVelocity(step.x, getVelocity().y, step.z);
    }

    /** Разбег Рогача. Вернёт true, пока он занят разбегом или оглушением и больше ничего не делает. */
    private boolean tickBull(ServerWorld world, PlayerEntity target) {
        int state = state();
        if (state == CALM) {
            return false;
        }
        stateLeft--;
        if (state == STUNNED) {
            setVelocity(0, getVelocity().y, 0);
            if (stateLeft <= 0) {
                setState(CALM, 0);
            }
            return true;
        }
        if (state == WINDUP) {
            setVelocity(0, getVelocity().y, 0);
            if (stateLeft <= 0) {
                setState(RUSH, RUSH_TICKS);
                rushHit = false;
                Abilities.soundAt(world, getPos(), Sounds.EARTH_THROW, 0.6F);
            }
            return true;
        }
        setVelocity(rushWay.x * RUSH_SPEED, getVelocity().y, rushWay.z * RUSH_SPEED);
        if (age % 3 == 0) {
            SpellEntity.spawn(world, SpellKind.DUST_PUFF, getPos(), 1.1F, 18).tint(0x9A8468);
        }
        if (!rushHit) {
            for (PlayerEntity player : ElementBoss.playersAt(world, getBoundingBox().getCenter(), 2.4)) {
                strike(world, player, 10);
                Abilities.push(player, rushWay.multiply(1.5).add(0, 0.7, 0));
                Flourish.hit(world, player, tint());
                rushHit = true;
            }
        }
        if (horizontalCollision) {
            Flourish.blast(world, getPos().add(rushWay.multiply(1.2)).add(0, 1, 0), 5, 0xB89A6A);
            SpellEntity.spawn(world, SpellKind.ROCK_BURST, getPos().add(rushWay).add(0, 1.2, 0), 1.6F, 18).tint(0x8A7F70);
            Abilities.soundAt(world, getPos(), Sounds.EARTH_QUAKE, 0.8F);
            say(world, "message.minevia_elements.bull_stunned");
            setState(STUNNED, STUN_TICKS);
            nextMove = STUN_TICKS + 20;
        } else if (stateLeft <= 0) {
            setState(CALM, 0);
        }
        return true;
    }

    void startRush(ServerWorld world, Vec3d way, int windup) {
        rushWay = way;
        float yaw = (float) Math.toDegrees(Math.atan2(-way.x, way.z));
        setYaw(yaw);
        setHeadYaw(yaw);
        setBodyYaw(yaw);
        setState(WINDUP, windup);
    }

    private PlayerEntity closestFighter() {
        return getWorld().getEntitiesByClass(PlayerEntity.class, new Box(home).expand(RANGE),
                        player -> player.isAlive() && !player.isCreative() && !player.isSpectator())
                .stream().min(Comparator.comparingDouble(player -> player.squaredDistanceTo(this))).orElse(null);
    }

    /** Все ушли: хозяин возвращается в печать, и бой можно начать заново. */
    private void sleep(ServerWorld world) {
        world.setBlockState(home, MineviaElements.SIGIL.getDefaultState().with(DungeonSigilBlock.KIND, kind()));
        bar.clearPlayers();
        discard();
    }

    void say(ServerWorld world, String key) {
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, new Box(home).expand(RANGE + 8), PlayerEntity::isAlive)) {
            player.sendMessage(Text.translatable(key), true);
        }
    }

    /** Сколько скелетов Настоятель уже поднимал: по разу на каждую треть здоровья. */
    boolean shouldRaise() {
        int due = getHealth() < getMaxHealth() / 3 ? 2 : getHealth() < getMaxHealth() * 2 / 3 ? 1 : 0;
        if (raised < due) {
            raised++;
            return true;
        }
        return false;
    }

    void strike(ServerWorld world, PlayerEntity player, float damage) {
        player.damage(world.getDamageSources().mobAttack(this), damage);
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isOf(DamageTypes.IN_WALL) || source.isOf(DamageTypes.FALL) || source.isOf(DamageTypes.DROWN)) {
            return false;
        }
        boolean hit = super.damage(source, state() == STUNNED ? amount * STUN_DAMAGE : amount);
        if (hit && age - hurtSound > 12 && getWorld() instanceof ServerWorld world) {
            hurtSound = age;
            Abilities.soundAt(world, getPos(), Sounds.BOSS_HURT, 1.3F);
        }
        return hit;
    }

    @Override
    public void onDeath(DamageSource source) {
        if (getWorld() instanceof ServerWorld world && !dead) {
            reward(world);
        }
        super.onDeath(source);
    }

    /** Победа: на месте печати появляется сундук, а хозяин разлетается столбом света. */
    private void reward(ServerWorld world) {
        Vec3d at = getPos();
        Flourish.rise(world, Vec3d.ofBottomCenter(home).add(0, 0.05, 0), 5, tint());
        Flourish.blast(world, at.add(0, 1, 0), 10, tint());
        SpellEntity.spawn(world, SpellKind.FIRE_BURST, at.add(0, 1.2, 0), 2.2F, 17);
        Abilities.soundAt(world, at, Sounds.BOSS_DEATH, 1.2F);
        world.setBlockState(home, Blocks.CHEST.getDefaultState());
        if (world.getBlockEntity(home) instanceof ChestBlockEntity chest) {
            chest.setLootTable(local.minevia.elements.temple.DungeonPiece.REWARDS.get(kind()), world.random.nextLong());
        }
        for (int i = 0; i < 4; i++) {
            dropStack(new ItemStack(MineviaElements.ESSENCES[world.random.nextInt(4)]));
        }
        Relics.reward(world, Vec3d.ofCenter(home), kind());
        bar.clearPlayers();
    }

    @Override
    protected void updatePostDeath() {
        if (!getWorld().isClient) {
            discard();
        }
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bar.removePlayer(player);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Kind", kind());
        nbt.putInt("Raised", raised);
        nbt.put("Home", NbtHelper.fromBlockPos(home));
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        dataTracker.set(KIND, MathHelper.clamp(nbt.getInt("Kind"), ABBOT, BULL));
        raised = nbt.getInt("Raised");
        NbtHelper.toBlockPos(nbt, "Home").ifPresent(pos -> home = pos);
        setNoGravity(kind() != BULL);
        setupBar();
    }

    @Override
    public boolean cannotDespawn() {
        return true;
    }

    @Override
    public void checkDespawn() {
    }

    @Override
    public boolean canHaveStatusEffect(StatusEffectInstance effect) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void takeKnockback(double strength, double x, double z) {
    }

    @Override
    public boolean handleFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean doesRenderOnFire() {
        return false;
    }

    @Override
    protected boolean isDisallowedInPeaceful() {
        return false;
    }
}
