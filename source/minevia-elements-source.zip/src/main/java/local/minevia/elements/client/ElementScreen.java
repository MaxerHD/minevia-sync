package local.minevia.elements.client;

import java.util.ArrayList;
import java.util.List;
import local.minevia.elements.Abilities;
import local.minevia.elements.Combos;
import local.minevia.elements.Element;
import local.minevia.elements.ElementState;
import local.minevia.elements.Mastery;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.net.MenuPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/** Меню стихии: живое ядро, уровень и четыре вкладки. Игру не ставит на паузу. */
public class ElementScreen extends Screen {
    private static final int PANEL_WIDTH = 430;
    private static final int PANEL_HEIGHT = 284;
    private static final int LEFT_WIDTH = 158;
    private static final int TAB_HEIGHT = 18;
    private static final int CARD_HEIGHT = 40;
    private static final float OPEN_MS = 260.0F;
    /** Меню не должно занимать весь экран при крупном масштабе интерфейса. */
    private static final float MENU_SCALE = 2.0F;
    private static final String[] TABS = {"abilities", "combos", "temples", "nature", "path"};
    private static final String[] NATURE = {"spirit_fire", "spirit_water", "spirit_earth", "spirit_air", "elder", "essence", "abbot", "bell", "bull", "relics", "fire_water", "douse", "lava", "ice", "ignite", "tnt", "melt", "cook", "webs", "wind", "pickup",
            "stone", "boulder_lava", "lightning", "creeper", "weather", "nether", "weak", "rain_grow"};
    private static final int NATURE_ROW = 37;
    private static final int PATH_TAB = 4;
    private static final int COMBO_ROW = 37;
    private static final int DUNGEON_COLOR = 0xB9A6D9;

    /** Строка вкладки комбо: цепочка своей стихии или комбо пары стихий. */
    private record ComboRow(Text name, Text about, Text tag, int first, int second, boolean mine) {
    }

    private final long openedAt = System.currentTimeMillis();
    private int tab;
    private int scroll;
    private List<ComboRow> comboRows;
    private int panelLeft;
    private int panelTop;
    private float panelScale = 1;

    public ElementScreen() {
        super(Text.translatable("screen.minevia_elements.title"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ElementsClient.menuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        // Стрелки: влево и вправо листают вкладки, вверх и вниз прокручивают список.
        if (keyCode == GLFW.GLFW_KEY_LEFT || keyCode == GLFW.GLFW_KEY_RIGHT) {
            tab = Math.floorMod(tab + (keyCode == GLFW.GLFW_KEY_RIGHT ? 1 : -1), TABS.length);
            scroll = 0;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_DOWN) {
            scroll = MathHelper.clamp(scroll + (keyCode == GLFW.GLFW_KEY_DOWN ? 26 : -26), 0, maxScroll());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private int localX(double mouseX) {
        return (int) Math.round((mouseX - width / 2.0) / panelScale + width / 2.0);
    }

    private int localY(double mouseY) {
        return (int) Math.round((mouseY - height / 2.0) / panelScale + height / 2.0);
    }

    private int contentX() {
        return panelLeft + LEFT_WIDTH;
    }

    private int contentRight() {
        return panelLeft + PANEL_WIDTH - 10;
    }

    private int contentTop() {
        return panelTop + TAB_HEIGHT + 12;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = localX(mouseX);
        int y = localY(mouseY);
        int tabWidth = (contentRight() - contentX()) / TABS.length;
        if (y >= panelTop + 6 && y < panelTop + 6 + TAB_HEIGHT && x >= contentX() && x < contentRight()) {
            tab = Math.min(TABS.length - 1, (x - contentX()) / tabWidth);
            scroll = 0;
            return true;
        }
        if (x >= contentX() && x < contentRight()) {
            int row = (y + scroll - contentTop()) / (CARD_HEIGHT + 4);
            if (tab == 2 && y >= contentTop() && y < viewBottom() && row < Element.values().length + MineviaElements.DUNGEONS.length) {
                ClientPlayNetworking.send(new MenuPayload(MenuPayload.FIND_TEMPLE, row));
                close();
                return true;
            }
            if (tab == PATH_TAB && canChoose() && y >= contentTop() + 34 && (y - contentTop() - 34) / 74 < 2) {
                ClientPlayNetworking.send(new MenuPayload(MenuPayload.CHOOSE_PATH, (y - contentTop() - 34) / 74 + 1));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scroll = MathHelper.clamp(scroll - (int) (vertical * 26), 0, maxScroll());
        return true;
    }

    private int viewBottom() {
        return panelTop + PANEL_HEIGHT - 8;
    }

    private int listHeight() {
        return switch (tab) {
            case 0 -> Abilities.SLOTS * (CARD_HEIGHT + 2);
            case 1 -> 24 + comboRows().size() * COMBO_ROW;
            case 2 -> (Element.values().length + MineviaElements.DUNGEONS.length) * (CARD_HEIGHT + 4) + 124;
            case 3 -> 24 + NATURE.length * NATURE_ROW;
            default -> 0;
        };
    }

    private int maxScroll() {
        return Math.max(0, listHeight() - (viewBottom() - contentTop()));
    }

    private int onScreen(int value, int middle) {
        return Math.round((value - middle) * panelScale + middle);
    }

    /** Обрезка работает в координатах экрана и не знает про масштаб меню, поэтому границы пересчитываются. */
    private void beginList(DrawContext context) {
        context.enableScissor(onScreen(contentX(), width / 2), onScreen(contentTop(), height / 2),
                onScreen(contentRight() + 6, width / 2), onScreen(viewBottom(), height / 2));
    }

    private void endList(DrawContext context, int color) {
        context.disableScissor();
        int max = maxScroll();
        if (max > 0) {
            int view = viewBottom() - contentTop();
            int bar = Math.max(18, view * view / listHeight());
            int top = contentTop() + (view - bar) * scroll / max;
            context.fill(contentRight() + 3, contentTop(), contentRight() + 5, viewBottom(), 0xFF152130);
            context.fill(contentRight() + 3, top, contentRight() + 5, top + bar, color);
        }
    }

    private List<ComboRow> comboRows() {
        if (comboRows != null) {
            return comboRows;
        }
        Element own = ElementsClient.element;
        List<ComboRow> rows = new ArrayList<>();
        for (Combos.Solo solo : Combos.Solo.values()) {
            if (solo.element == own) {
                Text steps = Text.empty().append(ElementsClient.abilityName(solo.first)).append(" \u2192 ").append(ElementsClient.abilityName(solo.second));
                rows.add(new ComboRow(Text.translatable(solo.key()), Text.translatable(solo.key() + ".desc"), steps, own.color, own.color, true));
            }
        }
        List<ComboRow> others = new ArrayList<>();
        for (Combos.Combo combo : Combos.Combo.values()) {
            boolean mine = combo.first == own || combo.second == own;
            Text tier = Text.translatable("screen.minevia_elements.combo_tier." + combo.tier);
            (mine ? rows : others).add(new ComboRow(Text.translatable(combo.key()), Text.translatable(combo.key() + ".desc"), tier,
                    combo.first.color, combo.second.color, mine));
        }
        rows.addAll(others);
        comboRows = rows;
        return rows;
    }

    private static boolean canChoose() {
        return ElementsClient.level >= ElementState.MAX_LEVEL && ElementsClient.path == 0;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        if (ElementsClient.element == null) {
            close();
            return;
        }
        float time = Math.min(1.0F, (System.currentTimeMillis() - openedAt) / OPEN_MS);
        float eased = 1.0F - (1.0F - time) * (1.0F - time) * (1.0F - time);
        int color = 0x90000000 | ElementsClient.element.color;
        panelScale = Math.min(1.0F, MENU_SCALE / (float) client.getWindow().getScaleFactor());
        int x = localX(mouseX);
        int y = localY(mouseY);
        context.getMatrices().push();
        context.getMatrices().translate(width / 2.0F, height / 2.0F, 0);
        context.getMatrices().scale(panelScale, panelScale, 1);
        context.getMatrices().translate(-width / 2.0F, -height / 2.0F, 0);
        panelLeft = (width - PANEL_WIDTH) / 2;
        panelTop = (height - PANEL_HEIGHT) / 2 + Math.round((1.0F - eased) * 24);

        context.fill(panelLeft - 1, panelTop - 1, panelLeft + PANEL_WIDTH + 1, panelTop + PANEL_HEIGHT + 1, color);
        context.fill(panelLeft, panelTop, panelLeft + PANEL_WIDTH, panelTop + PANEL_HEIGHT, 0xF20D1622);
        drawElement(context, panelLeft, panelTop, color);
        drawTabs(context, x, y, color);
        switch (tab) {
            case 0 -> {
                beginList(context);
                for (int i = 0; i < Abilities.SLOTS; i++) {
                    drawCard(context, i, contentX(), contentTop() + i * (CARD_HEIGHT + 2) - scroll, x, y, color);
                }
                endList(context, color);
            }
            case 1 -> drawCombos(context, color);
            case 2 -> drawTemples(context, x, y, color);
            case 3 -> drawNature(context, color);
            default -> drawPath(context, x, y, color);
        }
        context.getMatrices().pop();
    }

    private void drawTabs(DrawContext context, int mouseX, int mouseY, int color) {
        int tabWidth = (contentRight() - contentX()) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int left = contentX() + i * tabWidth;
            int top = panelTop + 6;
            boolean hover = mouseX >= left && mouseX < left + tabWidth - 2 && mouseY >= top && mouseY < top + TAB_HEIGHT;
            context.fill(left, top, left + tabWidth - 2, top + TAB_HEIGHT, i == tab ? 0xFF22344A : hover ? 0xFF1E2C3C : 0xFF152130);
            if (i == tab) {
                context.fill(left, top + TAB_HEIGHT - 1, left + tabWidth - 2, top + TAB_HEIGHT, color);
            }
            Text label = Text.translatable("screen.minevia_elements.tab." + TABS[i]);
            context.drawCenteredTextWithShadow(textRenderer, label, left + tabWidth / 2 - 1, top + 5, i == tab ? 0xFFFFF3DC : 0xFFAEB9C1);
        }
    }

    private void drawElement(DrawContext context, int left, int top, int color) {
        int center = left + 79;
        int pulse = (int) (Math.sin(System.currentTimeMillis() / 500.0) * 3);
        int size = 116 + pulse;
        ElementsClient.drawOrb(context, center - size / 2, top + 72 - size / 2, size);

        Text name = Text.translatable(ElementsClient.element.key());
        context.drawCenteredTextWithShadow(textRenderer, name, center, top + 140, 0xFF000000 | ElementsClient.element.color);
        Text level = Text.translatable("screen.minevia_elements.level", ElementsClient.level, ElementState.MAX_LEVEL);
        context.drawCenteredTextWithShadow(textRenderer, level, center, top + 154, 0xFFD7DEE3);

        int pipX = center - (ElementState.MAX_LEVEL * 16 - 4) / 2;
        for (int i = 0; i < ElementState.MAX_LEVEL; i++) {
            int x = pipX + i * 16;
            context.fill(x, top + 168, x + 12, top + 173, i < ElementsClient.level ? color : 0xFF2A3440);
        }

        Text hint;
        if (ElementsClient.level == 1) {
            hint = Text.translatable("screen.minevia_elements.xp", ElementsClient.xp, ElementState.XP_FOR_LEVEL_TWO);
        } else if (ElementsClient.level < ElementState.MAX_LEVEL) {
            hint = Text.translatable("screen.minevia_elements.need_core");
        } else if (ElementsClient.path == 0) {
            hint = Text.translatable("message.minevia_elements.choose_path");
        } else {
            hint = Text.translatable("screen.minevia_elements.max");
        }
        drawWrapped(context, hint, center, top + 184, 136, 3);
        drawWrapped(context, Text.translatable("screen.minevia_elements.controls"), center, top + 226, 140, 5);
    }

    private void drawWrapped(DrawContext context, Text text, int center, int y, int width, int maxLines) {
        List<OrderedText> lines = textRenderer.wrapLines(text, width);
        for (int i = 0; i < Math.min(maxLines, lines.size()); i++) {
            int lineWidth = textRenderer.getWidth(lines.get(i));
            context.drawTextWithShadow(textRenderer, lines.get(i), center - lineWidth / 2, y + i * 11, 0xFFAEB9C1);
        }
    }

    private void drawLeft(DrawContext context, Text text, int x, int y, int width, int maxLines, int color) {
        List<OrderedText> lines = textRenderer.wrapLines(text, width);
        for (int i = 0; i < Math.min(maxLines, lines.size()); i++) {
            context.drawTextWithShadow(textRenderer, lines.get(i), x, y + i * 10, color);
        }
    }

    private void drawCard(DrawContext context, int slot, int x, int y, int mouseX, int mouseY, int color) {
        int right = contentRight();
        boolean open = ElementsClient.level >= Abilities.unlockLevel(slot);
        boolean hover = mouseX >= x && mouseX < right && mouseY >= y && mouseY < y + CARD_HEIGHT;
        context.fill(x, y, right, y + CARD_HEIGHT, hover ? 0xFF1E2C3C : 0xFF152130);
        context.fill(x, y, x + 2, y + CARD_HEIGHT, open ? color : 0xFF3A444E);

        ElementsClient.drawIcon(context, slot, x + 6, y + 3, 32);
        if (!open) {
            context.fill(x + 7, y + 5, x + 37, y + 35, 0xC00A1018);
        }

        int place = java.util.Arrays.stream(ElementsClient.slots()).boxed().toList().indexOf(slot);
        String key = ElementsClient.slotLabel(slot, false);
        key = place < 0 ? "" : "[G " + (place + 1) % 10 + (key.isEmpty() ? "" : " / " + key) + "]";
        context.drawTextWithShadow(textRenderer, key, right - textRenderer.getWidth(key) - 6, y + 5, open ? 0xFFFFC76B : 0xFF7C8891);
        boolean path = Abilities.isPathSlot(slot);
        boolean unchosen = path && ElementsClient.path == 0;
        Text name = unchosen ? Text.translatable("screen.minevia_elements.path_slot") : ElementsClient.abilityName(slot);
        context.drawTextWithShadow(textRenderer, name, x + 44, y + 5, open ? 0xFFFFF3DC : 0xFF8C98A1);
        if (open && !unchosen) {
            Text rank = Text.translatable("screen.minevia_elements.skill_level", Mastery.level(ElementsClient.SKILL_XP[slot]));
            context.drawTextWithShadow(textRenderer, rank, x + 50 + textRenderer.getWidth(name), y + 5, 0xFFFFC76B);
        }

        if (open) {
            drawMastery(context, slot, x + 7, y + 36);
        }

        Text about;
        if (!open) {
            about = Text.translatable("message.minevia_elements.locked", Abilities.unlockLevel(slot));
        } else if (unchosen) {
            about = Text.translatable("message.minevia_elements.choose_path");
        } else {
            about = Text.translatable(ElementsClient.abilityKey(slot) + ".desc");
        }
        drawLeft(context, about, x + 44, y + 16, right - x - 50, 2, 0xFFAEB9C1);
    }

    /** Пять делений под значком: сколько уровней навыка есть, а текущее заполняется опытом. */
    private void drawMastery(DrawContext context, int slot, int x, int y) {
        int xp = ElementsClient.SKILL_XP[slot];
        int level = Mastery.level(xp);
        int mark = 0xFF000000 | ElementsClient.element.color;
        for (int i = 1; i <= Mastery.MAX; i++) {
            int left = x + (i - 1) * 6;
            context.fill(left, y, left + 5, y + 2, 0xFF2A3440);
            if (i < level || level == Mastery.MAX) {
                context.fill(left, y, left + 5, y + 2, mark);
            } else if (i == level) {
                int from = Mastery.start(level);
                context.fill(left, y, left + 5 * (xp - from) / (Mastery.next(level) - from), y + 2, mark);
            }
        }
    }

    private void drawCombos(DrawContext context, int color) {
        int x = contentX();
        int right = contentRight();
        beginList(context);
        drawLeft(context, Text.translatable("screen.minevia_elements.combo_help"), x + 4, contentTop() - scroll, right - x - 8, 2, 0xFFD7DEE3);
        List<ComboRow> rows = comboRows();
        for (int i = 0; i < rows.size(); i++) {
            ComboRow row = rows.get(i);
            int y = contentTop() + 24 + i * COMBO_ROW - scroll;
            if (y + 34 < contentTop() || y > viewBottom()) {
                continue;
            }
            context.fill(x, y, right, y + 34, row.mine() ? 0xFF1A2A3A : 0xFF131D2A);
            context.fill(x, y, x + 2, y + 17, 0xFF000000 | row.first());
            context.fill(x, y + 17, x + 2, y + 34, 0xFF000000 | row.second());
            context.drawTextWithShadow(textRenderer, row.name(), x + 8, y + 4, row.mine() ? 0xFFFFF3DC : 0xFFB5C0C8);
            int tagWidth = (int) (textRenderer.getWidth(row.tag()) * 0.75F);
            ElementsClient.drawSmallText(context, row.tag().getString(), right - tagWidth - 5, y + 5, 0xFFFFC76B, 0.75F);
            drawLeft(context, row.about(), x + 8, y + 15, right - x - 14, 2, 0xFFAEB9C1);
        }
        endList(context, color);
    }

    private void drawNature(DrawContext context, int color) {
        int x = contentX();
        int right = contentRight();
        beginList(context);
        drawLeft(context, Text.translatable("screen.minevia_elements.nature_help"), x + 4, contentTop() - scroll, right - x - 8, 2, 0xFFD7DEE3);
        for (int i = 0; i < NATURE.length; i++) {
            int y = contentTop() + 24 + i * NATURE_ROW - scroll;
            if (y + 34 < contentTop() || y > viewBottom()) {
                continue;
            }
            String key = "nature.minevia_elements." + NATURE[i];
            context.fill(x, y, right, y + 34, 0xFF152130);
            context.fill(x, y, x + 2, y + 34, color);
            context.drawTextWithShadow(textRenderer, Text.translatable(key), x + 8, y + 4, 0xFFFFF3DC);
            drawLeft(context, Text.translatable(key + ".desc"), x + 8, y + 15, right - x - 14, 2, 0xFFAEB9C1);
        }
        endList(context, color);
    }

    private void drawTemples(DrawContext context, int mouseX, int mouseY, int color) {
        int x = contentX();
        int right = contentRight();
        int temples = Element.values().length;
        int total = temples + MineviaElements.DUNGEONS.length;
        beginList(context);
        for (int i = 0; i < total; i++) {
            int y = contentTop() + i * (CARD_HEIGHT + 4) - scroll;
            boolean hover = mouseX >= x && mouseX < right && mouseY >= y && mouseY < y + CARD_HEIGHT && mouseY >= contentTop() && mouseY < viewBottom();
            String id = i < temples ? Element.values()[i].id() : MineviaElements.DUNGEONS[i - temples];
            int mark = i < temples ? Element.values()[i].color : DUNGEON_COLOR;
            context.fill(x, y, right, y + CARD_HEIGHT, hover ? 0xFF1E2C3C : 0xFF152130);
            context.fill(x, y, x + 2, y + CARD_HEIGHT, 0xFF000000 | mark);
            String key = "temple.minevia_elements." + id;
            context.drawTextWithShadow(textRenderer, Text.translatable(key), x + 10, y + 5, 0xFFFFF3DC);
            drawLeft(context, Text.translatable(key + ".desc"), x + 10, y + 16, right - x - 16, 2, 0xFFAEB9C1);
        }
        drawLeft(context, Text.translatable("screen.minevia_elements.temple_help"), x + 4, contentTop() + total * (CARD_HEIGHT + 4) + 4 - scroll,
                right - x - 8, 11, 0xFFD7DEE3);
        endList(context, color);
    }

    private void drawPath(DrawContext context, int mouseX, int mouseY, int color) {
        int x = contentX();
        int right = contentRight();
        Element element = ElementsClient.element;
        Text head = ElementsClient.path != 0
                ? Text.translatable("screen.minevia_elements.path_done", Text.translatable(element.pathKey(ElementsClient.path)))
                : Text.translatable(canChoose() ? "screen.minevia_elements.path_open" : "screen.minevia_elements.path_locked");
        drawLeft(context, head, x + 4, contentTop(), right - x - 8, 3, 0xFFD7DEE3);
        for (int path = 1; path <= 2; path++) {
            int y = contentTop() + 34 + (path - 1) * 74;
            boolean hover = canChoose() && mouseX >= x && mouseX < right && mouseY >= y && mouseY < y + 70;
            boolean picked = ElementsClient.path == path;
            context.fill(x, y, right, y + 70, picked ? 0xFF22344A : hover ? 0xFF1E2C3C : 0xFF152130);
            context.fill(x, y, x + 2, y + 70, picked ? 0xFF000000 | element.color : color);
            ElementsClient.drawPathIcon(context, path, x + 10, y + 11, 48);
            Text names = Text.translatable(element.pathKey(path)).append(" + ").append(Text.translatable(element.pathKey(path) + ".second"));
            context.drawTextWithShadow(textRenderer, names, x + 68, y + 10, 0xFFFFF3DC);
            drawLeft(context, Text.translatable(element.pathKey(path) + ".desc"), x + 68, y + 24, right - x - 74, 4, 0xFFAEB9C1);
        }
    }
}
