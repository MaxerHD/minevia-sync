package local.minevia.elements.client;

import java.util.ArrayList;
import java.util.List;
import local.minevia.elements.Abilities;
import local.minevia.elements.Combos;
import local.minevia.elements.Element;
import local.minevia.elements.ElementState;
import local.minevia.elements.Mastery;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.net.MenuPayload;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

/** Меню стихии: живое ядро, уровень и вкладки. Навыки это сетка значков с карточкой, комбо показаны значками. Игру не ставит на паузу. */
public class ElementScreen extends Screen {
    private static final int PANEL_WIDTH = 430;
    private static final int PANEL_HEIGHT = 284;
    private static final int LEFT_WIDTH = 158;
    private static final int TAB_HEIGHT = 18;
    private static final int CARD_HEIGHT = 40;
    private static final float OPEN_MS = 260.0F;
    /** Меню не должно занимать весь экран при крупном масштабе интерфейса. */
    private static final float MENU_SCALE = 2.0F;
    private static final String[] TABS = {"abilities", "combos", "temples", "nature", "path"};
    private static final String[] NATURE = {"spirit_fire", "spirit_water", "spirit_earth", "spirit_air", "elder", "essence", "abbot", "bell", "bull", "relics", "fire_water", "douse", "lava", "ice", "ignite", "tnt", "melt", "cook", "webs", "wind", "pickup",
            "stone", "boulder_lava", "lightning", "creeper", "weather", "nether", "weak", "rain_grow"};
    private static final int NATURE_ROW = 37;
    private static final int PATH_TAB = 4;
    private static final int DUNGEON_COLOR = 0xB9A6D9;

    private static final int CELL = 50;
    private static final int GRID_ROWS = 2;
    private static final int GRID_COLUMNS = 5;
    private static final int TEAM_ROW = 40;
    private static final int CHAIN_CARD = 62;
    private static final int VIEW_BUTTON = 16;

    /** Строка комбо с другом: две стихии, название, с чего оно срабатывает. */
    private record ComboRow(Text name, Text about, Text tag, Element first, Element second, boolean mine) {
    }

    private final long openedAt = System.currentTimeMillis();
    private int tab;
    private int scroll;
    private int selected;
    private int hovered = -1;
    private int held = -1;
    private boolean dragging;
    private boolean teamView;
    private List<ComboRow> comboRows;
    private int panelLeft;
    private int panelTop;
    private float panelScale = 1;

    public ElementScreen() {
        super(Text.translatable("screen.minevia_elements.title"));
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (ElementsClient.menuKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        // Стрелки: влево и вправо листают вкладки, вверх и вниз прокручивают список.
        if (keyCode == GLFW.GLFW_KEY_LEFT || keyCode == GLFW.GLFW_KEY_RIGHT) {
            tab = Math.floorMod(tab + (keyCode == GLFW.GLFW_KEY_RIGHT ? 1 : -1), TABS.length);
            scroll = 0;
            return true;
        }
        if (tab == 1 && keyCode == GLFW.GLFW_KEY_TAB) {
            teamView = !teamView;
            scroll = 0;
            return true;
        }
        if (tab == 0 && (keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_DOWN)) {
            int[] order = SkillOrder.of(ElementsClient.element);
            int place = SkillOrder.indexOf(order, selected);
            selected = order[Math.floorMod(place + (keyCode == GLFW.GLFW_KEY_DOWN ? 1 : -1), Abilities.SLOTS)];
            return true;
        }
        // Без мыши: Enter берёт навык, второй Enter ставит его на выбранное место, R возвращает обычный порядок.
        if (tab == 0 && (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER)) {
            if (held < 0) {
                held = selected;
            } else {
                SkillOrder.swap(ElementsClient.element, held, selected);
                held = -1;
            }
            return true;
        }
        if (tab == 0 && keyCode == GLFW.GLFW_KEY_R) {
            SkillOrder.reset(ElementsClient.element);
            held = -1;
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_UP || keyCode == GLFW.GLFW_KEY_DOWN) {
            scroll = MathHelper.clamp(scroll + (keyCode == GLFW.GLFW_KEY_DOWN ? 26 : -26), 0, maxScroll());
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    private int localX(double mouseX) {
        return (int) Math.round((mouseX - width / 2.0) / panelScale + width / 2.0);
    }

    private int localY(double mouseY) {
        return (int) Math.round((mouseY - height / 2.0) / panelScale + height / 2.0);
    }

    private int contentX() {
        return panelLeft + LEFT_WIDTH;
    }

    private int contentRight() {
        return panelLeft + PANEL_WIDTH - 10;
    }

    private int contentTop() {
        return panelTop + TAB_HEIGHT + 12;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int x = localX(mouseX);
        int y = localY(mouseY);
        int tabWidth = (contentRight() - contentX()) / TABS.length;
        if (y >= panelTop + 6 && y < panelTop + 6 + TAB_HEIGHT && x >= contentX() && x < contentRight()) {
            tab = Math.min(TABS.length - 1, (x - contentX()) / tabWidth);
            scroll = 0;
            return true;
        }
        if (x >= panelLeft + 12 && x < panelLeft + LEFT_WIDTH - 14 && y >= panelTop + 210 && y < panelTop + 226) {
            client.setScreen(new SelectionScreen());
            return true;
        }
        if (tab == 0) {
            int cell = cellAt(x, y);
            if (cell >= 0) {
                selected = cell;
                held = cell;
                dragging = true;
                return true;
            }
        }
        if (tab == 1 && y >= contentTop() && y < contentTop() + VIEW_BUTTON && x >= contentX() && x < contentRight()) {
            teamView = x >= (contentX() + contentRight()) / 2;
            scroll = 0;
            return true;
        }
        if (x >= contentX() && x < contentRight()) {
            int row = (y + scroll - contentTop()) / (CARD_HEIGHT + 4);
            if (tab == 2 && y >= contentTop() && y < viewBottom() && row < Element.natural().length + MineviaElements.DUNGEONS.length) {
                ClientPlayNetworking.send(new MenuPayload(MenuPayload.FIND_TEMPLE, row));
                close();
                return true;
            }
            if (tab == PATH_TAB && canChoose() && y >= contentTop() + 34 && (y - contentTop() - 34) / 74 < 2) {
                ClientPlayNetworking.send(new MenuPayload(MenuPayload.CHOOSE_PATH, (y - contentTop() - 34) / 74 + 1));
                return true;
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    /** Навык перетащили на другой значок: они меняются местами на панели и клавишах. */
    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (dragging) {
            int target = cellAt(localX(mouseX), localY(mouseY));
            if (target >= 0 && target != held) {
                SkillOrder.swap(ElementsClient.element, held, target);
            }
            dragging = false;
            held = -1;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontal, double vertical) {
        scroll = MathHelper.clamp(scroll - (int) (vertical * 26), 0, maxScroll());
        return true;
    }

    private int viewBottom() {
        return panelTop + PANEL_HEIGHT - 8;
    }

    /** Над списком комбо стоят две кнопки, и прокрутка начинается под ними. */
    private int listTop() {
        return tab == 1 ? contentTop() + VIEW_BUTTON + 4 : contentTop();
    }

    private int listHeight() {
        return switch (tab) {
            case 0 -> 0;
            case 1 -> teamView ? 24 + comboRows().size() * TEAM_ROW : 28 + 3 * (CHAIN_CARD + 4);
            case 2 -> (Element.natural().length + MineviaElements.DUNGEONS.length) * (CARD_HEIGHT + 4) + 124;
            case 3 -> 24 + NATURE.length * NATURE_ROW;
            default -> 0;
        };
    }

    private int maxScroll() {
        return Math.max(0, listHeight() - (viewBottom() - listTop()));
    }

    private int onScreen(int value, int middle) {
        return Math.round((value - middle) * panelScale + middle);
    }

    /** Обрезка работает в координатах экрана и не знает про масштаб меню, поэтому границы пересчитываются. */
    private void beginList(DrawContext context) {
        context.enableScissor(onScreen(contentX(), width / 2), onScreen(listTop(), height / 2),
                onScreen(contentRight() + 6, width / 2), onScreen(viewBottom(), height / 2));
    }

    private void endList(DrawContext context, int color) {
        context.disableScissor();
        int max = maxScroll();
        if (max > 0) {
            int view = viewBottom() - listTop();
            int bar = Math.max(18, view * view / listHeight());
            int top = listTop() + (view - bar) * scroll / max;
            context.fill(contentRight() + 3, listTop(), contentRight() + 5, viewBottom(), 0xFF152130);
            context.fill(contentRight() + 3, top, contentRight() + 5, top + bar, color);
        }
    }

    private List<ComboRow> comboRows() {
        if (comboRows != null) {
            return comboRows;
        }
        Element own = ElementsClient.element;
        if (!own.isNatural()) return List.of();
        List<ComboRow> rows = new ArrayList<>();
        List<ComboRow> others = new ArrayList<>();
        for (Combos.Combo combo : Combos.Combo.values()) {
            boolean mine = combo.first == own || combo.second == own;
            Text tier = Text.translatable("screen.minevia_elements.combo_tier." + combo.tier);
            (mine ? rows : others).add(new ComboRow(Text.translatable(combo.key()), Text.translatable(combo.key() + ".desc"), tier,
                    combo.first, combo.second, mine));
        }
        rows.addAll(others);
        comboRows = rows;
        return rows;
    }

    /** Выпуклая рамка как у ячеек инвентаря: светлый верх и слева, тень снизу и справа. */
    private static void frame(DrawContext context, int x, int y, int w, int h, int fill) {
        context.fill(x, y, x + w, y + h, 0xFF05090F);
        context.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF2C3C4E);
        context.fill(x + 2, y + 2, x + w - 1, y + h - 1, 0xFF0A1118);
        context.fill(x + 2, y + 2, x + w - 2, y + h - 2, fill);
    }

    private int gridX(int slot) {
        return contentX() + slot % GRID_COLUMNS * (CELL + 2);
    }

    private int gridY(int slot) {
        return contentTop() + slot / GRID_COLUMNS * (CELL - 4);
    }

    private int cellAt(int x, int y) {
        int[] order = SkillOrder.of(ElementsClient.element);
        for (int place = 0; place < Abilities.SLOTS; place++) {
            if (x >= gridX(place) && x < gridX(place) + CELL && y >= gridY(place) && y < gridY(place) + CELL - 6) {
                return order[place];
            }
        }
        return -1;
    }

    private static boolean unlocked(int slot) {
        return ElementsClient.level >= Abilities.unlockLevel(slot);
    }

    private static boolean noPathYet(int slot) {
        return Abilities.isPathSlot(slot) && ElementsClient.path == 0;
    }

    private static boolean canChoose() {
        return ElementsClient.level >= ElementState.MAX_LEVEL && ElementsClient.path == 0;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        if (ElementsClient.element == null) {
            close();
            return;
        }
        float time = Math.min(1.0F, (System.currentTimeMillis() - openedAt) / OPEN_MS);
        float eased = 1.0F - (1.0F - time) * (1.0F - time) * (1.0F - time);
        int color = 0x90000000 | ElementsClient.element.color;
        panelScale = Math.min(1.0F, MENU_SCALE / (float) client.getWindow().getScaleFactor());
        int x = localX(mouseX);
        int y = localY(mouseY);
        context.getMatrices().push();
        context.getMatrices().translate(width / 2.0F, height / 2.0F, 0);
        context.getMatrices().scale(panelScale, panelScale, 1);
        context.getMatrices().translate(-width / 2.0F, -height / 2.0F, 0);
        panelLeft = (width - PANEL_WIDTH) / 2;
        panelTop = (height - PANEL_HEIGHT) / 2 + Math.round((1.0F - eased) * 24);

        context.fill(panelLeft - 2, panelTop - 2, panelLeft + PANEL_WIDTH + 2, panelTop + PANEL_HEIGHT + 2, 0xFF05090F);
        context.fill(panelLeft - 1, panelTop - 1, panelLeft + PANEL_WIDTH + 1, panelTop + PANEL_HEIGHT + 1, color);
        context.fill(panelLeft, panelTop, panelLeft + PANEL_WIDTH, panelTop + PANEL_HEIGHT, 0xF80D1622);
        context.fill(panelLeft + LEFT_WIDTH - 5, panelTop + 6, panelLeft + LEFT_WIDTH - 4, panelTop + PANEL_HEIGHT - 6, 0xFF22303E);
        drawElement(context, panelLeft, panelTop, color);
        drawTabs(context, x, y, color);
        switch (tab) {
            case 0 -> drawSkills(context, x, y, color);
            case 1 -> drawCombos(context, color);
            case 2 -> drawTemples(context, x, y, color);
            case 3 -> drawNature(context, color);
            default -> drawPath(context, x, y, color);
        }
        context.getMatrices().pop();
        if (tab == 0 && x >= contentX() && x < contentRight() && y >= contentTop() + 94 && y < viewBottom()) {
            int shown = hovered >= 0 ? hovered : selected;
            List<OrderedText> lines = new ArrayList<>();
            lines.addAll(textRenderer.wrapLines(Text.translatable(ElementsClient.abilityKey(shown) + ".desc"), 290));
            if (!ElementsClient.element.isNatural() && shown < 5) {
                int rank = Mastery.level(ElementsClient.SKILL_XP[shown]);
                for (int n = 1; n <= Mastery.MAX; n++) {
                    boolean learned = unlocked(shown) && n <= rank;
                    Text row = Text.translatable("screen.minevia_elements.rank_" + (learned ? "open" : "locked"), n,
                            Text.translatable(ElementsClient.abilityKey(shown) + ".rank" + n))
                            .formatted(learned ? net.minecraft.util.Formatting.GOLD : net.minecraft.util.Formatting.GRAY);
                    lines.addAll(textRenderer.wrapLines(row, 290));
                }
            }
            context.drawOrderedTooltip(textRenderer, lines, mouseX, mouseY);
        }
    }

    private void drawTabs(DrawContext context, int mouseX, int mouseY, int color) {
        int tabWidth = (contentRight() - contentX()) / TABS.length;
        for (int i = 0; i < TABS.length; i++) {
            int left = contentX() + i * tabWidth;
            int top = panelTop + 6;
            boolean hover = mouseX >= left && mouseX < left + tabWidth - 2 && mouseY >= top && mouseY < top + TAB_HEIGHT;
            context.fill(left, top, left + tabWidth - 2, top + TAB_HEIGHT, i == tab ? 0xFF22344A : hover ? 0xFF1E2C3C : 0xFF152130);
            if (i == tab) {
                context.fill(left, top + TAB_HEIGHT - 1, left + tabWidth - 2, top + TAB_HEIGHT, color);
            }
            Text label = Text.translatable("screen.minevia_elements.tab." + TABS[i]);
            context.drawCenteredTextWithShadow(textRenderer, label, left + tabWidth / 2 - 1, top + 5, i == tab ? 0xFFFFF3DC : 0xFFAEB9C1);
        }
    }

    private void drawElement(DrawContext context, int left, int top, int color) {
        int center = left + 79;
        int pulse = (int) (Math.sin(System.currentTimeMillis() / 500.0) * 3);
        int size = 116 + pulse;
        ElementsClient.drawOrb(context, center - size / 2, top + 72 - size / 2, size);

        Text name = Text.translatable(ElementsClient.element.key());
        context.drawCenteredTextWithShadow(textRenderer, name, center, top + 140, 0xFF000000 | ElementsClient.element.color);
        Text level = Text.translatable("screen.minevia_elements.level", ElementsClient.level, ElementState.MAX_LEVEL);
        context.drawCenteredTextWithShadow(textRenderer, level, center, top + 154, 0xFFD7DEE3);

        int pipX = center - (ElementState.MAX_LEVEL * 16 - 4) / 2;
        for (int i = 0; i < ElementState.MAX_LEVEL; i++) {
            int x = pipX + i * 16;
            context.fill(x, top + 168, x + 12, top + 173, i < ElementsClient.level ? color : 0xFF2A3440);
        }

        Text hint;
        if (ElementsClient.level == 1) {
            hint = Text.translatable("screen.minevia_elements.xp", ElementsClient.xp, ElementState.XP_FOR_LEVEL_TWO);
        } else if (ElementsClient.level < ElementState.MAX_LEVEL) {
            hint = Text.translatable("screen.minevia_elements.need_core");
        } else if (ElementsClient.path == 0) {
            hint = Text.translatable("message.minevia_elements.choose_path");
        } else {
            hint = Text.translatable("screen.minevia_elements.max");
        }
        drawWrapped(context, hint, center, top + 176, 136, 3);
        frame(context, left + 12, top + 210, LEFT_WIDTH - 26, 16, 0xFF22344A);
        context.drawCenteredTextWithShadow(textRenderer, Text.translatable("screen.minevia_elements.change"), center, top + 214, 0xFFFFC76B);
        drawWrapped(context, Text.translatable("screen.minevia_elements.controls"), center, top + 226, 140, 5);
    }

    private void drawWrapped(DrawContext context, Text text, int center, int y, int width, int maxLines) {
        List<OrderedText> lines = textRenderer.wrapLines(text, width);
        for (int i = 0; i < Math.min(maxLines, lines.size()); i++) {
            int lineWidth = textRenderer.getWidth(lines.get(i));
            context.drawTextWithShadow(textRenderer, lines.get(i), center - lineWidth / 2, y + i * 11, 0xFFAEB9C1);
        }
    }

    private void drawLeft(DrawContext context, Text text, int x, int y, int width, int maxLines, int color) {
        List<OrderedText> lines = textRenderer.wrapLines(text, width);
        for (int i = 0; i < Math.min(maxLines, lines.size()); i++) {
            context.drawTextWithShadow(textRenderer, lines.get(i), x, y + i * 10, color);
        }
    }

    /** Сетка значков сверху, снизу карточка навыка: при наведении показывается он, а щелчок закрепляет выбор. */
    private void drawSkills(DrawContext context, int mouseX, int mouseY, int color) {
        hovered = cellAt(mouseX, mouseY);
        int shown = hovered >= 0 ? hovered : selected;
        int[] order = SkillOrder.of(ElementsClient.element);
        for (int place = 0; place < Abilities.SLOTS; place++) {
            int slot = order[place];
            int x = gridX(place);
            int y = gridY(place);
            int size = CELL - 6;
            frame(context, x, y, CELL, size, slot == held ? 0xFF4A3A18 : slot == shown ? 0xFF22344A : 0xFF131D2A);
            if (slot == shown) {
                context.fill(x, y + size - 2, x + CELL, y + size, 0xFF000000 | ElementsClient.element.color);
            }
            if (!dragging || slot != held) {
                ElementsClient.drawSlot(context, slot, x + 9, y + 6, 32);
            }
            context.drawTextWithShadow(textRenderer, String.valueOf((place + 1) % 10), x + CELL - 9, y + size - 11, 0xFF9AAFC2);
            if (unlocked(slot) && !noPathYet(slot)) {
                String rank = String.valueOf(Mastery.level(ElementsClient.SKILL_XP[slot]));
                context.drawTextWithShadow(textRenderer, rank, x + 4, y + 4, 0xFFFFC76B);
            }
            if (slot == Abilities.ULTIMATE_SLOT) {
                context.fill(x + 2, y + 2, x + CELL - 2, y + 3, 0xFFFFD27A);
            }
        }
        drawSkillCard(context, shown, contentX(), contentTop() + GRID_ROWS * (CELL - 4) + 2, color);
        context.drawTextWithShadow(textRenderer, Text.translatable(held >= 0 ? "screen.minevia_elements.order_pick" : "screen.minevia_elements.order_help"), contentX(), viewBottom() - 10, 0xFF8FA0B2);
        if (dragging && held >= 0) {
            ElementsClient.drawSlot(context, held, mouseX - 16, mouseY - 16, 32);
        }
    }

    private void drawSkillCard(DrawContext context, int slot, int x, int y, int color) {
        int right = contentRight();
        int bottom = viewBottom();
        boolean open = unlocked(slot);
        boolean unchosen = noPathYet(slot);
        frame(context, x, y, right - x, bottom - y, 0xFF131D2A);
        frame(context, x + 6, y + 6, 44, 44, 0xFF0D1622);
        ElementsClient.drawSlot(context, slot, x + 12, y + 12, 32);
        Text name = unchosen ? Text.translatable("screen.minevia_elements.path_slot") : ElementsClient.abilityName(slot);
        context.drawTextWithShadow(textRenderer, name, x + 56, y + 8, open ? 0xFFFFF3DC : 0xFF8C98A1);
        if (open && !unchosen) {
            int xp = ElementsClient.SKILL_XP[slot];
            int level = Mastery.level(xp);
            Text rank = Text.translatable("screen.minevia_elements.skill_level", level);
            context.drawTextWithShadow(textRenderer, rank, right - textRenderer.getWidth(rank) - 8, y + 8, 0xFFFFC76B);
            drawMastery(context, slot, x + 56, y + 20, right - x - 64);
            Text progress = level >= Mastery.MAX ? Text.translatable("screen.minevia_elements.skill_top")
                    : Text.translatable("screen.minevia_elements.skill_xp", xp, Mastery.next(level));
            ElementsClient.drawSmallText(context, progress.getString(), x + 56, y + 26, 0xFFAEB9C1, 0.75F);
        }
        Text keys = Text.translatable("screen.minevia_elements.skill_keys", keyText(slot));
        Text wait = Text.translatable("screen.minevia_elements.skill_wait", String.format(java.util.Locale.ROOT, "%.2f", Abilities.cooldown(ElementsClient.element, slot) / 20.0));
        ElementsClient.drawSmallText(context, keys.getString(), x + 56, y + 35, 0xFFFFC76B, 0.75F);
        ElementsClient.drawSmallText(context, wait.getString(), x + 56, y + 43, 0xFFAEB9C1, 0.75F);

        Text about;
        if (!open) {
            about = Text.translatable("message.minevia_elements.locked", Abilities.unlockLevel(slot));
        } else if (unchosen) {
            about = Text.translatable("message.minevia_elements.choose_path");
        } else {
            about = Text.translatable(ElementsClient.abilityKey(slot) + ".desc");
        }
        drawLeft(context, about, x + 8, y + 56, right - x - 16, 3, 0xFFD7DEE3);
        if (!ElementsClient.element.isNatural() && slot < 5)
            ElementsClient.drawSmallText(context, Text.translatable("screen.minevia_elements.ranks_hint").getString(), x + 8, y + 82, 0xFFFFC76B, 0.7F);
        drawSkillChains(context, slot, x + 8, y + 94, right);
    }

    private static String keyText(int slot) {
        int digit = AbilityBar.digit(slot);
        String key = ElementsClient.slotLabel(slot, false);
        String bar = digit < 0 ? "" : "G " + digit;
        return key.isEmpty() ? bar : bar.isEmpty() ? key : bar + " / " + key;
    }

    /** С какими навыками этот собирается в цепочку и какое комбо с другом запускает. */
    private void drawSkillChains(DrawContext context, int slot, int x, int y, int right) {
        int tier = local.minevia.elements.SkillLayout.tier(ElementsClient.element, slot);
        Text team = ElementsClient.element.isNatural() ? Text.translatable("screen.minevia_elements.skill_team", Text.translatable("screen.minevia_elements.combo_tier." + tier)) : Text.translatable("screen.minevia_elements.no_team");
        ElementsClient.drawSmallText(context, team.getString(), x, y, 0xFFAEB9C1, 0.75F);
        int at = y + 9;
        for (Combos.Solo solo : Combos.Solo.values()) {
            if (solo.element == ElementsClient.element && (solo.first == slot || solo.second == slot)) {
                ElementsClient.drawIcon(context, solo.first, x, at, 14);
                context.drawTextWithShadow(textRenderer, "\u2192", x + 16, at + 3, 0xFFFFC76B);
                ElementsClient.drawIcon(context, solo.second, x + 25, at, 14);
                context.drawTextWithShadow(textRenderer, Text.translatable(solo.key()), x + 44, at + 3, 0xFFFFF3DC);
                at += 16;
            }
        }
    }

    /** Пять делений под значком: сколько уровней навыка есть, а текущее заполняется опытом. */
    private void drawMastery(DrawContext context, int slot, int x, int y, int width) {
        int xp = ElementsClient.SKILL_XP[slot];
        int level = Mastery.level(xp);
        int mark = 0xFF000000 | ElementsClient.element.color;
        int step = width / Mastery.MAX;
        for (int i = 1; i <= Mastery.MAX; i++) {
            int left = x + (i - 1) * step;
            context.fill(left, y, left + step - 1, y + 3, 0xFF2A3440);
            if (i < level || level == Mastery.MAX) {
                context.fill(left, y, left + step - 1, y + 3, mark);
            } else if (i == level) {
                int from = Mastery.start(level);
                context.fill(left, y, left + (step - 1) * (xp - from) / (Mastery.next(level) - from), y + 3, mark);
            }
        }
    }

    private void drawCombos(DrawContext context, int color) {
        int x = contentX();
        int right = contentRight();
        int middle = (x + right) / 2;
        for (int side = 0; side < 2; side++) {
            boolean on = (side == 1) == teamView;
            int left = side == 0 ? x : middle + 1;
            int end = side == 0 ? middle - 1 : right;
            frame(context, left, contentTop(), end - left, VIEW_BUTTON, on ? 0xFF22344A : 0xFF131D2A);
            Text label = Text.translatable("screen.minevia_elements.combo_view." + (side == 0 ? "solo" : "team"));
            context.drawCenteredTextWithShadow(textRenderer, label, (left + end) / 2, contentTop() + 4, on ? 0xFFFFF3DC : 0xFFAEB9C1);
        }
        beginList(context);
        if (teamView) {
            drawTeamCombos(context, x, right);
        } else {
            drawChains(context, x, right);
        }
        endList(context, color);
    }

    /** Свои цепочки крупно: два значка, стрелка, название и что нажимать. */
    private void drawChains(DrawContext context, int x, int right) {
        int top = listTop() - scroll;
        drawLeft(context, Text.translatable("screen.minevia_elements.solo_help"), x + 4, top, right - x - 8, 2, 0xFFD7DEE3);
        int y = top + 26;
        for (Combos.Solo solo : Combos.Solo.values()) {
            if (solo.element != ElementsClient.element) {
                continue;
            }
            boolean ready = unlocked(solo.first) && unlocked(solo.second);
            frame(context, x, y, right - x, CHAIN_CARD, ready ? 0xFF1A2A3A : 0xFF131D2A);
            ElementsClient.drawSlot(context, solo.first, x + 8, y + 7, 32);
            context.drawTextWithShadow(textRenderer, "\u2192", x + 44, y + 19, 0xFFFFC76B);
            ElementsClient.drawSlot(context, solo.second, x + 54, y + 7, 32);
            Text steps = Text.translatable("screen.minevia_elements.solo_keys", AbilityBar.digit(solo.first), AbilityBar.digit(solo.second));
            ElementsClient.drawSmallText(context, steps.getString(), x + 10, y + 46, 0xFFFFC76B, 0.75F);
            context.drawTextWithShadow(textRenderer, Text.translatable(solo.key()), x + 94, y + 7, ready ? 0xFFFFF3DC : 0xFF8C98A1);
            drawLeft(context, Text.translatable(solo.key() + ".desc"), x + 94, y + 19, right - x - 100, 3, 0xFFAEB9C1);
            y += CHAIN_CARD + 4;
        }
    }

    /** Комбо с другом: значки двух стихий, название и чем надо завершить удар. Свои идут первыми. */
    private void drawTeamCombos(DrawContext context, int x, int right) {
        int top = listTop() - scroll;
        drawLeft(context, Text.translatable(ElementsClient.element.isNatural() ? "screen.minevia_elements.combo_help" : "screen.minevia_elements.no_team"), x + 4, top, right - x - 8, 2, 0xFFD7DEE3);
        List<ComboRow> rows = comboRows();
        for (int i = 0; i < rows.size(); i++) {
            ComboRow row = rows.get(i);
            int y = top + 24 + i * TEAM_ROW;
            if (y + TEAM_ROW < listTop() || y > viewBottom()) {
                continue;
            }
            frame(context, x, y, right - x, TEAM_ROW - 3, row.mine() ? 0xFF1A2A3A : 0xFF131D2A);
            ElementsClient.drawElementIcon(context, row.first(), x + 6, y + 6, 16);
            ElementsClient.drawElementIcon(context, row.second(), x + 18, y + 15, 16);
            context.drawTextWithShadow(textRenderer, row.name(), x + 40, y + 5, row.mine() ? 0xFFFFF3DC : 0xFFB5C0C8);
            int tagWidth = (int) (textRenderer.getWidth(row.tag()) * 0.75F);
            ElementsClient.drawSmallText(context, row.tag().getString(), right - tagWidth - 7, y + 6, 0xFFFFC76B, 0.75F);
            drawLeft(context, row.about(), x + 40, y + 16, right - x - 46, 2, 0xFFAEB9C1);
        }
    }

    private void drawNature(DrawContext context, int color) {
        int x = contentX();
        int right = contentRight();
        beginList(context);
        if (!ElementsClient.element.isNatural()) {
            drawLeft(context, Text.translatable("screen.minevia_elements.style_nature"), x + 4, contentTop(), right - x - 8, 8, 0xFFD7DEE3);
            endList(context, color);
            return;
        }
        drawLeft(context, Text.translatable("screen.minevia_elements.nature_help"), x + 4, contentTop() - scroll, right - x - 8, 2, 0xFFD7DEE3);
        for (int i = 0; i < NATURE.length; i++) {
            int y = contentTop() + 24 + i * NATURE_ROW - scroll;
            if (y + 34 < contentTop() || y > viewBottom()) {
                continue;
            }
            String key = "nature.minevia_elements." + NATURE[i];
            context.fill(x, y, right, y + 34, 0xFF152130);
            context.fill(x, y, x + 2, y + 34, color);
            context.drawTextWithShadow(textRenderer, Text.translatable(key), x + 8, y + 4, 0xFFFFF3DC);
            drawLeft(context, Text.translatable(key + ".desc"), x + 8, y + 15, right - x - 14, 2, 0xFFAEB9C1);
        }
        endList(context, color);
    }

    private void drawTemples(DrawContext context, int mouseX, int mouseY, int color) {
        int x = contentX();
        int right = contentRight();
        int temples = Element.natural().length;
        int total = temples + MineviaElements.DUNGEONS.length;
        beginList(context);
        for (int i = 0; i < total; i++) {
            int y = contentTop() + i * (CARD_HEIGHT + 4) - scroll;
            boolean hover = mouseX >= x && mouseX < right && mouseY >= y && mouseY < y + CARD_HEIGHT && mouseY >= contentTop() && mouseY < viewBottom();
            String id = i < temples ? Element.natural()[i].id() : MineviaElements.DUNGEONS[i - temples];
            int mark = i < temples ? Element.natural()[i].color : DUNGEON_COLOR;
            context.fill(x, y, right, y + CARD_HEIGHT, hover ? 0xFF1E2C3C : 0xFF152130);
            context.fill(x, y, x + 2, y + CARD_HEIGHT, 0xFF000000 | mark);
            String key = "temple.minevia_elements." + id;
            context.drawTextWithShadow(textRenderer, Text.translatable(key), x + 10, y + 5, 0xFFFFF3DC);
            drawLeft(context, Text.translatable(key + ".desc"), x + 10, y + 16, right - x - 16, 2, 0xFFAEB9C1);
        }
        drawLeft(context, Text.translatable("screen.minevia_elements.temple_help"), x + 4, contentTop() + total * (CARD_HEIGHT + 4) + 4 - scroll,
                right - x - 8, 11, 0xFFD7DEE3);
        endList(context, color);
    }

    private void drawPath(DrawContext context, int mouseX, int mouseY, int color) {
        int x = contentX();
        int right = contentRight();
        Element element = ElementsClient.element;
        Text head = ElementsClient.path != 0
                ? Text.translatable("screen.minevia_elements.path_done", Text.translatable(element.pathTitleKey(ElementsClient.path)))
                : Text.translatable(canChoose() ? "screen.minevia_elements.path_open" : "screen.minevia_elements.path_locked");
        drawLeft(context, head, x + 4, contentTop(), right - x - 8, 3, 0xFFD7DEE3);
        for (int path = 1; path <= 2; path++) {
            int y = contentTop() + 34 + (path - 1) * 74;
            boolean hover = canChoose() && mouseX >= x && mouseX < right && mouseY >= y && mouseY < y + 70;
            boolean picked = ElementsClient.path == path;
            context.fill(x, y, right, y + 70, picked ? 0xFF22344A : hover ? 0xFF1E2C3C : 0xFF152130);
            context.fill(x, y, x + 2, y + 70, picked ? 0xFF000000 | element.color : color);
            ElementsClient.drawPathIcon(context, path, x + 10, y + 11, 48);
            Text names = Text.translatable(element.pathKey(path)).append(" + ").append(Text.translatable(element.pathKey(path) + ".second"));
            if (element.isNatural()) {
                drawLeft(context, names, x + 68, y + 8, right - x - 74, 2, 0xFFFFF3DC);
            } else {
                context.drawTextWithShadow(textRenderer, Text.translatable(element.pathTitleKey(path)), x + 68, y + 5, 0xFFFFC76B);
                drawLeft(context, names, x + 68, y + 17, right - x - 74, 2, 0xFFFFF3DC);
            }
            drawLeft(context, Text.translatable(element.pathKey(path) + ".desc"), x + 68, y + 38, right - x - 74, 3, 0xFFAEB9C1);
        }
    }
}
