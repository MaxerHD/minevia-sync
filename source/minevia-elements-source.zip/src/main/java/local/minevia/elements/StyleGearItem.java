package local.minevia.elements;

import java.util.List;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.BowItem;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.UseAction;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/** Лук натягивается без расходных стрел. */
public final class StyleGearItem extends Item {
    public final Element element;
    public StyleGearItem(Element element, Settings settings) { super(settings); this.element = element; }
    @Override public UseAction getUseAction(ItemStack stack) { return element == Element.BOW ? UseAction.BOW : UseAction.NONE; }
    @Override public int getMaxUseTime(ItemStack stack, LivingEntity user) { return 72000; }
    @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (element != Element.BOW || hand != Hand.MAIN_HAND) return TypedActionResult.pass(stack);
        if (user instanceof ServerPlayerEntity p) {
            if (!StyleGear.require(p, element) || !StyleBow.beginUse(p)) return TypedActionResult.fail(stack);
        }
        user.setCurrentHand(hand);
        return TypedActionResult.consume(stack);
    }
    @Override public void onStoppedUsing(ItemStack stack, World world, LivingEntity user, int remaining) {
        if (user instanceof ServerPlayerEntity p) StyleBow.releaseUse(p);
    }
    public static float draw(ItemStack stack, int ticks) {
        return BowItem.getPullProgress(Math.round(ticks * (StyleGear.level(stack) >= 2 ? 1.45F : 1)));
    }
    @Override public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("screen.minevia_elements.skill_level", StyleGear.level(stack)));
        tooltip.add(Text.translatable("item.minevia_elements.style_gear.hint"));
    }
}
