package local.minevia.elements;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import local.minevia.elements.net.PlayerSkinPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;

/**
 * Скины без сторонних сервисов: без лицензии игра не знает чужих скинов, поэтому хозяин мира
 * принимает файл от каждого игрока и рассылает остальным.
 */
final class Skins {
    private static final int MAX_BYTES = 24000;
    private static final int SIZE = 64;
    private static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A};
    private static final Map<UUID, byte[]> KNOWN = new HashMap<>();

    private Skins() {
    }

    static void upload(ServerPlayerEntity player, byte[] png) {
        if (!valid(png)) {
            return;
        }
        KNOWN.put(player.getUuid(), png);
        broadcast(player.getServer(), new PlayerSkinPayload(player.getUuid(), png));
    }

    /** Заголовок PNG хранит размер картинки: файл другого размера или вовсе не картинка отсекается сразу. */
    private static boolean valid(byte[] png) {
        if (png.length < 24 || png.length > MAX_BYTES) {
            return false;
        }
        for (int i = 0; i < PNG.length; i++) {
            if (png[i] != PNG[i]) {
                return false;
            }
        }
        return readInt(png, 16) == SIZE && readInt(png, 20) == SIZE;
    }

    private static int readInt(byte[] data, int at) {
        return (data[at] & 255) << 24 | (data[at + 1] & 255) << 16 | (data[at + 2] & 255) << 8 | data[at + 3] & 255;
    }

    /** Новый игрок получает скины всех, кто уже в мире. */
    static void sendAll(ServerPlayerEntity player) {
        if (ServerPlayNetworking.canSend(player, PlayerSkinPayload.ID)) {
            KNOWN.forEach((id, png) -> ServerPlayNetworking.send(player, new PlayerSkinPayload(id, png)));
        }
    }

    static void forget(ServerPlayerEntity player, MinecraftServer server) {
        if (KNOWN.remove(player.getUuid()) != null) {
            broadcast(server, new PlayerSkinPayload(player.getUuid(), new byte[0]));
        }
    }

    private static void broadcast(MinecraftServer server, PlayerSkinPayload payload) {
        for (ServerPlayerEntity other : server.getPlayerManager().getPlayerList()) {
            if (ServerPlayNetworking.canSend(other, PlayerSkinPayload.ID)) {
                ServerPlayNetworking.send(other, payload);
            }
        }
    }
}
