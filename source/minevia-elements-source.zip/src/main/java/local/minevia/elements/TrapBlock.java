package local.minevia.elements;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.World;

/**
 * Плита ловушки. Срабатывает, когда на неё наступил игрок: сначала полсекунды горит предупреждение,
 * и за это время можно отскочить. Потом плита остывает три секунды.
 */
public final class TrapBlock extends Block {
    public static final IntProperty ELEMENT = IntProperty.of("element", 0, 3);
    public static final BooleanProperty ARMED = BooleanProperty.of("armed");
    private static final int WARNING = 10;
    private static final int REARM = 60;

    public TrapBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(ELEMENT, 0).with(ARMED, true));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(ELEMENT, ARMED);
    }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        if (!(world instanceof ServerWorld server) || !state.get(ARMED) || !(entity instanceof PlayerEntity player)
                || player.isCreative() || player.isSpectator()) {
            return;
        }
        world.setBlockState(pos, state.with(ARMED, false));
        world.scheduleBlockTick(pos, this, REARM);
        Vec3d top = Vec3d.ofBottomCenter(pos.up());
        int element = state.get(ELEMENT);
        SpellEntity.spawn(server, SpellKind.DANGER_RING, top.add(0, 0.06, 0), 2.0F, WARNING).tint(Element.natural()[element].color);
        Abilities.soundAt(server, top, Sounds.TRAP, 1.0F);
        Effects.later(server, WARNING, () -> spring(server, top, element));
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        world.setBlockState(pos, state.with(ARMED, true));
    }

    private static void spring(ServerWorld world, Vec3d top, int element) {
        switch (element) {
            case 0 -> {
                SpellEntity.spawn(world, SpellKind.MAGMA_GEYSER, top, 0.9F, 24);
                Abilities.soundAt(world, top, Sounds.MAGMA, 1.2F);
            }
            case 1 -> {
                SpellEntity.spawn(world, SpellKind.ICE_SHARD, top, 1.3F, 50);
                Abilities.soundAt(world, top, Sounds.ICE_FORM, 1.1F);
            }
            case 2 -> {
                SpellEntity.spawn(world, SpellKind.STONE_SPIKE, top, 1.0F, 34).tint(0x8A7F70);
                Abilities.soundAt(world, top, Sounds.EARTH_SPIKE, 1.0F);
            }
            default -> {
                SpellEntity.spawn(world, SpellKind.WIND_BURST, top.add(0, 0.5, 0), 2.6F, 14);
                Abilities.soundAt(world, top, Sounds.AIR_GUST, 1.2F);
            }
        }
        for (PlayerEntity player : ElementBoss.playersAt(world, top.add(0, 1, 0), 2.2)) {
            player.damage(world.getDamageSources().magic(), element == 3 ? 3 : 6);
            switch (element) {
                case 0 -> player.setOnFireFor(4);
                case 1 -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 2, false, false, true));
                case 2 -> Abilities.push(player, new Vec3d(0, 0.85, 0));
                default -> {
                    double angle = world.random.nextDouble() * Math.PI * 2;
                    Abilities.push(player, new Vec3d(Math.cos(angle) * 1.3, 0.5, Math.sin(angle) * 1.3));
                }
            }
        }
    }
}
