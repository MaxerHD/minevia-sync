package local.minevia.elements;

import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/** Общие эффекты поверх любого навыка: рунный круг при касте, вспышка при ударе, волна и угольки при взрыве. Всё это 3D-модели. */
final class Flourish {
    private static final int HIT_PAUSE = 5;
    private static final Map<LivingEntity, Integer> LAST_HIT = new WeakHashMap<>();

    private Flourish() {
    }

    /** Под ногами вспыхивает круг цвета стихии, а у супер-навыка ещё и столб света. */
    static void cast(ServerPlayerEntity player, Element element, int slot) {
        ServerWorld world = player.getServerWorld();
        Vec3d feet = player.getPos().add(0, 0.05, 0);
        if (slot == Abilities.ULTIMATE_SLOT) {
            rise(world, feet, 3.6F, element.color);
            return;
        }
        SpellEntity.spawn(world, SpellKind.SIGIL, feet, 1.2F, 14).tint(element.color);
    }

    /** Вспышка на цели. Часто бьющие навыки не должны заливать ею весь экран, поэтому между вспышками есть пауза. */
    static void hit(ServerWorld world, LivingEntity target, int color) {
        int now = world.getServer().getTicks();
        Integer last = LAST_HIT.get(target);
        if (last != null && now - last < HIT_PAUSE) {
            return;
        }
        LAST_HIT.put(target, now);
        SpellEntity.spawn(world, SpellKind.IMPACT, target.getBoundingBox().getCenter(), 0.9F + target.getWidth() * 0.4F, 8).tint(color);
    }

    /** Взрыв: волна расходится по кругу, а вверх летят угольки. */
    static void blast(ServerWorld world, Vec3d at, float size, int color) {
        SpellEntity.spawn(world, SpellKind.SHOCK_RING, at, size, 14).tint(color);
        SpellEntity.spawn(world, SpellKind.EMBERS, at, Math.max(1, size * 0.55F), 24).tint(color);
    }

    /** Торжественный момент: рунный круг на земле и столб света из него. */
    static void rise(ServerWorld world, Vec3d at, float size, int color) {
        SpellEntity.spawn(world, SpellKind.SIGIL, at, size, 36).tint(color);
        SpellEntity.spawn(world, SpellKind.LIGHT_PILLAR, at, size * 0.6F, 26).tint(color);
        SpellEntity.spawn(world, SpellKind.EMBERS, at, size * 0.6F, 28).tint(color);
    }

    /** Навык вырос: игрока обнимает столб света его стихии. */
    static void levelUp(ServerPlayerEntity player, int color) {
        rise(player.getServerWorld(), player.getPos().add(0, 0.05, 0), 1.6F, color);
    }

    /** Закрут силы перед приёмом: видно, что сейчас ударят. */
    static void charge(ServerWorld world, Vec3d at, float size, int ticks, int color) {
        SpellEntity.spawn(world, SpellKind.CHARGE, at, size, ticks).tint(color);
    }
}
