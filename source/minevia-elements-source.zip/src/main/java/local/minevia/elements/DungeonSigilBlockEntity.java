package local.minevia.elements;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Следит, не подошёл ли игрок. Пробуждение длится две секунды: круг разгорается, и только потом появляется хозяин. */
public final class DungeonSigilBlockEntity extends BlockEntity {
    private static final double WAKE_RANGE = 8.5;
    private static final int RITUAL_TICKS = 44;
    private static final int[] TINT = {0x7FD8FF, 0xFFD27A, 0xFF7A3A, 0xFF9138, 0x60DACA, 0xC2A4FF};

    private int ritual;

    public DungeonSigilBlockEntity(BlockPos pos, BlockState state) {
        super(MineviaElements.SIGIL_ENTITY, pos, state);
    }

    static void tick(World world, BlockPos pos, BlockState state, DungeonSigilBlockEntity sigil) {
        if (!(world instanceof ServerWorld server)) {
            return;
        }
        int kind = state.get(DungeonSigilBlock.KIND);
        if (sigil.ritual > 0) {
            if (--sigil.ritual == 0) {
                world.setBlockState(pos, Blocks.AIR.getDefaultState());
                DungeonBoss.wake(server, pos, kind);
            }
            return;
        }
        if (server.getTime() % 10 != 0) {
            return;
        }
        boolean near = !server.getEntitiesByClass(PlayerEntity.class, new Box(pos).expand(WAKE_RANGE),
                player -> player.isAlive() && !player.isSpectator() && !player.isCreative()).isEmpty();
        if (near) {
            sigil.ritual = RITUAL_TICKS;
            Vec3d at = Vec3d.ofBottomCenter(pos).add(0, 0.1, 0);
            Flourish.rise(server, at, 4.5F, TINT[kind]);
            Flourish.charge(server, at.add(0, 1.6, 0), 3.0F, RITUAL_TICKS, TINT[kind]);
            Abilities.soundAt(server, at, Sounds.BOSS_AWAKE, 1.2F);
            Abilities.soundAt(server, at, Sounds.ALTAR, 0.8F);
        }
    }
}
