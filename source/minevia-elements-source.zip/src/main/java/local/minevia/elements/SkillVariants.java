package local.minevia.elements;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.UUID;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Приёмы с отдельными условиями срабатывания. */
final class SkillVariants {
    private record Heat(SpellEntity spell, CastContext.Token context, int level) { }
    private static final Map<UUID, Heat> HEAT = new HashMap<>();

    private SkillVariants() { }

    static void forget(UUID id) {
        Heat heat = HEAT.remove(id);
        if (heat != null) heat.spell().discard();
    }

    static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof ServerPlayerEntity p) || amount <= 0) return true;
        Heat heat = HEAT.get(p.getUuid());
        if (heat == null) return true;
        if (heat.spell().isRemoved() || heat.context() == null || !heat.context().valid()) {
            forget(p.getUuid()); return true;
        }
        if (!(source.getAttacker() instanceof LivingEntity enemy) || !Abilities.canHit(enemy, p)) return true;
        HEAT.remove(p.getUuid());
        heat.spell().discard();
        CastContext.run(heat.context(), () -> {
            float damage = 5 + heat.level() + Math.min(8, amount);
            StyleSupport.area(p, p.getPos().add(0, 1, 0), 4, damage, e -> {
                if (e.isOnFire()) StyleSupport.hit(p, e, 3 + heat.level());
                e.setOnFireFor(Spells.burnTime(heat.level()));
            });
            Flourish.blast(p.getServerWorld(), p.getPos().add(0, 1, 0), 5, Element.FIRE.color);
        });
        return true;
    }

    static void reactiveFlame(ServerPlayerEntity p, int level) {
        SpellEntity shell = StyleSupport.model(p, SpellKind.FLAME_AURA, p.getPos(), 1.2F, 200,
                self -> self.setPosition(p.getPos()));
        Heat old = HEAT.put(p.getUuid(), new Heat(shell, CastContext.capture(), level));
        if (old != null) old.spell().discard();
        Abilities.buff(p, StatusEffects.FIRE_RESISTANCE, 200, 0);
    }

    static void iceCrown(ServerPlayerEntity p, int level) {
        var caught = new HashSet<UUID>();
        StyleSupport.model(p, SpellKind.ICE_SHARD, p.getPos(), 1.2F, 120, self -> {
            self.setPosition(p.getPos());
            Box area = p.getBoundingBox().expand(5 + level * 0.3);
            for (ProjectileEntity shot : p.getServerWorld().getEntitiesByClass(ProjectileEntity.class, area,
                    e -> e.getOwner() == null || e.getOwner() instanceof LivingEntity owner && Abilities.canHit(owner, p))) {
                if (!caught.add(shot.getUuid())) continue;
                Vec3d velocity = shot.getVelocity();
                boolean gravity = shot.hasNoGravity();
                shot.setNoGravity(true);
                Abilities.push(shot, Vec3d.ZERO);
                StyleSupport.model(p, SpellKind.ICE_SHARD, shot.getPos(), 0.5F, 40, null);
                Effects.cleanup(p.getServerWorld(), 40, () -> {
                    if (!shot.isRemoved()) { shot.setNoGravity(gravity); Abilities.push(shot, velocity); }
                });
            }
        });
    }

    static void plates(ServerPlayerEntity p, int level) {
        int color = Spells.groundColor(p.getServerWorld(), p.getPos());
        Effects.repeat(p.getServerWorld(), 3, 14, step -> {
            Vec3d look = p.getRotationVector();
            StyleSupport.shot(p, SpellKind.GROUND_SLAB, Spells.muzzle(p, 1.8), look.multiply(1.5), 1.3F, 32, true,
                    (self, e) -> { StyleSupport.hit(p, e, 5 + level); StyleSupport.root(e, 25); }, null);
            StyleSupport.model(p, SpellKind.STONE_PLATES, p.getPos(), 0.8F, 14, null).tint(color);
            return true;
        });
    }

    static void thrownBoulder(ServerPlayerEntity p, int level) {
        StyleSupport.shot(p, SpellKind.BOULDER, Spells.muzzle(p, 2), p.getRotationVector().multiply(1.25),
                1.05F * Spells.big(level), 65, false, (self, e) -> {
                    StyleSupport.hit(p, e, 8 + level * 2);
                    Abilities.push(e, self.getVelocity().normalize().multiply(1.1).add(0, 0.4, 0));
                }, at -> {
                    Flourish.blast(p.getServerWorld(), at, 3, Element.EARTH.color);
                    Nature.crush(p.getServerWorld(), p, at, 2.2);
                });
    }

    static void ignition(ServerPlayerEntity p, int level) {
        LivingEntity target = Abilities.aim(p, 26);
        if (target == null) return;
        StyleSupport.model(p, SpellKind.ELEMENT_MARK, target.getPos(), 0.9F, 100, self -> {
            if (!Abilities.canHit(target, p)) { self.discard(); return; }
            self.setPosition(target.getPos());
            if (self.age < 20 || !target.isOnFire() && self.age < 99) return;
            boolean burning = target.isOnFire();
            StyleSupport.area(p, target.getBoundingBox().getCenter(), burning ? 4.5 : 2, 5 + level * (burning ? 2 : 1),
                    e -> e.setOnFireFor(Spells.burnTime(level)));
            Flourish.blast(p.getServerWorld(), target.getBoundingBox().getCenter(), burning ? 5 : 2, Element.FIRE.color);
            self.discard();
        }).tint(Element.FIRE.color);
    }

    static void soulSphere(ServerPlayerEntity p, int level) {
        Vec3d at = Spells.crosshair(p, 16);
        StyleSupport.field(p, SpellKind.DARK_SPHERE, at, 1.4F, 120, 20, self -> {
            LivingEntity enemy = nearest(p, at, 10);
            if (enemy == null) return;
            Vec3d to = enemy.getBoundingBox().getCenter().subtract(at);
            StyleSupport.model(p, SpellKind.DARK_DRAIN, at, (float) to.length(), 8, null).facing(to);
            float before = enemy.getHealth();
            StyleSupport.hit(p, enemy, 3 + level);
            p.heal(Math.min(1.5F, Math.max(0, before - enemy.getHealth()) * 0.25F));
            Abilities.debuff(enemy, StatusEffects.WEAKNESS, 40, 0);
        });
    }

    static void graspTrap(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 25);
        StyleSupport.model(p, SpellKind.DARK_HANDS, at, 2, 180, self -> {
            if (self.age < 12) return;
            LivingEntity e = nearest(p, at.add(0, 1, 0), 2.8);
            if (e == null) return;
            StyleSupport.hit(p, e, 6 + level);
            StyleSupport.model(p, SpellKind.DARK_HANDS, e.getPos(), 1.4F, 60, bind -> {
                if (!Abilities.canHit(e, p)) { bind.discard(); return; }
                bind.setPosition(e.getPos());
                StyleSupport.root(e, 8);
                if (bind.age % 20 == 0) {
                    float hp = e.getHealth(); StyleSupport.hit(p, e, 2 + level * 0.5F);
                    if (level >= 5) p.heal(Math.min(0.5F, Math.max(0, hp - e.getHealth())));
                }
                if (level >= 3) Abilities.debuff(e, StatusEffects.WEAKNESS, 30, 1);
            });
            self.discard();
        });
    }

    static void fearCone(ServerPlayerEntity p, int level) {
        Vec3d eye = p.getEyePos(), look = p.getRotationVector();
        StyleSupport.model(p, SpellKind.DARK_NIGHTMARE, Spells.muzzle(p, 3), 2, 24, null).facing(look);
        for (LivingEntity e : Abilities.livingAt(p, eye, 12)) {
            Vec3d to = e.getBoundingBox().getCenter().subtract(eye);
            if (to.normalize().dotProduct(look) < 0.65 || !p.canSee(e)) continue;
            StyleSupport.hit(p, e, 3 + level);
            Abilities.debuff(e, StatusEffects.BLINDNESS, 60, 0);
            StyleSupport.model(p, SpellKind.DARK_CURSE, e.getPos(), 0.7F, 45, self -> {
                if (!Abilities.canHit(e, p) || !p.canSee(e)) { self.discard(); return; }
                self.setPosition(e.getPos());
                Abilities.push(e, e.getPos().subtract(p.getPos()).normalize().multiply(0.45).add(0, 0.05, 0));
            });
        }
    }

    static void ghostBrand(ServerPlayerEntity p, int level) {
        LivingEntity target = Abilities.aim(p, 25);
        if (target == null) return;
        float cost = Math.min(3, Math.max(0, p.getHealth() - 1));
        p.damage(p.getDamageSources().magic(), cost);
        StyleSupport.model(p, SpellKind.DARK_GHOSTS, target.getPos(), 1.5F, 100, self -> {
            if (!Abilities.canHit(target, p)) { self.discard(); return; }
            self.setPosition(target.getPos());
            if (self.age % 20 == 0) {
                StyleSupport.hit(p, target, 3 + level + cost * 0.5F);
                Abilities.debuff(target, StatusEffects.WEAKNESS, 30, 1);
            }
        });
    }

    static void duelist(ServerPlayerEntity p, int level) {
        StyleSupport.follow(p, SpellKind.SWORD_RING, 140, self -> {
            if (Abilities.aim(p, 5) != null) {
                Abilities.buff(p, StatusEffects.STRENGTH, 12, level >= 4 ? 1 : 0);
                Abilities.buff(p, StatusEffects.SPEED, 12, 1);
                Abilities.buff(p, StatusEffects.RESISTANCE, 12, 0);
            }
        });
    }

    static void thousandStep(ServerPlayerEntity p, int level) {
        Vec3d direction = Spells.flatLook(p);
        StyleSupport.dash(p, SpellKind.SWORD_THOUSAND, 28, 0.7, 12 + level * 2);
        Effects.repeat(p.getServerWorld(), 6, 5, step -> {
            StyleSupport.shot(p, SpellKind.SLASH_BIG, Spells.muzzle(p, 1), direction.multiply(0.7), 2.2F, 6, true,
                    (self, e) -> StyleSupport.hit(p, e, 4 + level), null);
            return true;
        });
    }

    static void rescue(ServerPlayerEntity p, int level) {
        LivingEntity ally = StyleSupport.ally(p, 24);
        StyleSupport.cleanse(ally);
        Mastery.aid(p, ally, 3 + level);
        Abilities.buff(ally, StatusEffects.SLOW_FALLING, 180, 0);
        StyleSupport.model(p, SpellKind.LIGHT_WINGS, ally.getPos(), 1, 60, self -> {
            if (!ally.isAlive()) { self.discard(); return; }
            self.setPosition(ally.getPos());
            if (self.age < 20) Abilities.push(ally, ally.getVelocity().multiply(0.5).add(0, 0.22, 0));
            ally.fallDistance = 0;
        });
    }

    static void judgmentShield(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 32);
        for (var ally : StyleLight.allies(p, at, 8)) {
            StyleSupport.cleanse(ally);
            Mastery.aid(p, ally, 5 + level);
            Abilities.buff(ally, StatusEffects.ABSORPTION, 140, 2);
            Abilities.buff(ally, StatusEffects.RESISTANCE, 140, 1);
            float[] health = {ally.getHealth()};
            StyleSupport.model(p, SpellKind.LIGHT_JUDGMENT, ally.getPos(), 1.5F, 140, self -> {
                if (!ally.isAlive()) { self.discard(); return; }
                self.setPosition(ally.getPos());
                if (self.age % 10 != 0) return;
                if (ally.getHealth() < health[0]) {
                    LivingEntity enemy = nearest(p, ally.getPos(), 16);
                    if (enemy != null) {
                        Vec3d end = enemy.getBoundingBox().getCenter();
                        StyleSupport.model(p, SpellKind.LIGHT_COLUMN, end, 1.5F, 14, null);
                        StyleSupport.hit(p, enemy, 6 + level);
                    }
                }
                health[0] = ally.getHealth();
            });
        }
    }

    static void hammerCharge(ServerPlayerEntity p, int level) {
        StyleSupport.dash(p, SpellKind.LIGHT_HAMMER, 10, 0.8, 5 + level);
        Effects.later(p.getServerWorld(), 10, () -> {
            StyleSupport.area(p, p.getPos().add(0, 1, 0), 4, 8 + level, e -> StyleSupport.root(e, 35));
            Flourish.blast(p.getServerWorld(), p.getPos(), 4, Element.LIGHT.color);
        });
    }

    static void huntBrand(ServerPlayerEntity p, int level) {
        LivingEntity target = Abilities.aim(p, 40);
        if (target == null) return;
        Vec3d origin = target.getPos();
        Abilities.debuff(target, StatusEffects.GLOWING, 160, 0);
        StyleSupport.model(p, SpellKind.BOW_SEEKERS, target.getPos(), 1, 160, self -> {
            if (!Abilities.canHit(target, p)) { self.discard(); return; }
            self.setPosition(target.getPos());
            if (target.squaredDistanceTo(origin) < 9 && self.age < 159) return;
            StyleSupport.hit(p, target, 10 + level * 2);
            StyleSupport.root(target, 45);
            self.discard();
        });
    }

    static void plagueTrap(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 25);
        StyleSupport.model(p, SpellKind.DARK_PLAGUE, at, 2, 200, self -> {
            if (self.age < 16 || nearest(p, at, 3) == null) return;
            StyleSupport.area(p, at.add(0, 1, 0), 5, 5 + level, e -> {
                Abilities.debuff(e, StatusEffects.POISON, 100, 0);
                Abilities.debuff(e, StatusEffects.WEAKNESS, 100, 1);
            });
            Flourish.blast(p.getServerWorld(), at, 5, Element.DARK.color);
            self.discard();
        });
    }

    static void magmaMines(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 24);
        for (int i = 0; i < 3; i++) {
            Vec3d spot = at.add(Spells.flatLook(p).multiply(i * 3));
            StyleSupport.model(p, SpellKind.MAGMA_BOULDER, spot, 0.65F, 220, self -> {
                if (self.age < 12) return;
                LivingEntity enemy = nearest(p, spot, 2.5);
                if (enemy == null) return;
                StyleSupport.area(p, spot, 3.5, 5 + level * (enemy.isOnFire() ? 2 : 1), e -> e.setOnFireFor(6));
                Flourish.blast(p.getServerWorld(), spot, 4, Element.FIRE.color);
                self.discard();
            });
        }
    }

    static void iceBrand(ServerPlayerEntity p, int level) {
        LivingEntity target = Abilities.aim(p, 26);
        if (target == null) return;
        StyleSupport.model(p, SpellKind.ICE_SHARD, target.getPos(), 1, 60, self -> {
            if (!Abilities.canHit(target, p)) { self.discard(); return; }
            self.setPosition(target.getPos());
            if (self.age == 40) {
                StyleSupport.hit(p, target, 9 + level * 2);
                StyleSupport.root(target, 100);
                Abilities.debuff(target, StatusEffects.WEAKNESS, 100, 1);
                target.setFrozenTicks(240);
                Flourish.blast(p.getServerWorld(), target.getPos(), 2, Element.WATER.color);
                self.discard();
            }
        });
    }

    static void thicket(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 24);
        for (int x = -2; x <= 2; x++) {
            for (int z : new int[] {-2, 2}) {
                BlockPos pos = BlockPos.ofFloored(at.add(x, 0, z));
                Effects.temporaryBlock(p.getServerWorld(), pos, Blocks.OAK_FENCE.getDefaultState(), 0, 140);
                StyleSupport.model(p, SpellKind.BOW_THICKET, Vec3d.ofBottomCenter(pos), 0.8F, 140, self -> {
                    if (self.age % 20 == 0) StyleSupport.area(p, self.getPos(), 1.6, 2 + level, e -> StyleSupport.root(e, 25));
                });
            }
        }
    }

    static void blessingShields(ServerPlayerEntity p, int level) {
        for (var ally : StyleLight.allies(p, p.getPos(), 10)) {
            Abilities.buff(ally, StatusEffects.ABSORPTION, 200, 1);
            StyleSupport.model(p, SpellKind.LIGHT_BLESSING, ally.getPos(), 1.4F, 200, self -> {
                self.setPosition(ally.getPos());
                for (ProjectileEntity shot : p.getServerWorld().getEntitiesByClass(ProjectileEntity.class,
                        ally.getBoundingBox().expand(2), e -> e.getOwner() instanceof LivingEntity owner && Abilities.canHit(owner, p))) {
                    if (shot.getVelocity().dotProduct(ally.getBoundingBox().getCenter().subtract(shot.getPos())) > 0)
                        Abilities.push(shot, shot.getVelocity().multiply(-0.8));
                }
            });
        }
    }

    static LivingEntity nearest(ServerPlayerEntity p, Vec3d at, double range) {
        return Abilities.livingAt(p, at, range).stream().filter(p::canSee)
                .filter(e -> e.getBoundingBox().getCenter().squaredDistanceTo(at) <= range * range)
                .min(java.util.Comparator.comparingDouble(e -> e.squaredDistanceTo(at))).orElse(null);
    }
}
