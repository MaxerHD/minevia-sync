package local.minevia.elements.client;

import com.mojang.blaze3d.systems.RenderSystem;
import java.io.IOException;
import java.nio.file.Files;
import local.minevia.elements.Abilities;
import local.minevia.elements.Element;
import local.minevia.elements.ElementState;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.net.CastPayload;
import local.minevia.elements.net.GesturePayload;
import local.minevia.elements.net.MenuPayload;
import local.minevia.elements.net.PlayerSkinPayload;
import local.minevia.elements.net.StatePayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.ResourcePackActivationType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.render.block.entity.BlockEntityRendererFactories;
import net.minecraft.client.util.InputUtil;
import net.minecraft.resource.ResourceType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ElementsClient implements ClientModInitializer {
    private static final String CATEGORY = "category.minevia_elements";
    // В сборке заняты почти все буквы, а у клавиши работает только одно действие: эти свободны.
    private static final int[] DEFAULT_KEYS = {
            GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_H, GLFW.GLFW_KEY_N, GLFW.GLFW_KEY_UNKNOWN, GLFW.GLFW_KEY_UNKNOWN, GLFW.GLFW_KEY_UNKNOWN,
            GLFW.GLFW_KEY_UNKNOWN, GLFW.GLFW_KEY_UNKNOWN, GLFW.GLFW_KEY_UNKNOWN, GLFW.GLFW_KEY_UNKNOWN};
    /** Столько тиков надо держать первую клавишу, чтобы открылся круг, а не сработала способность. */
    private static final int WHEEL_DELAY = 4;
    private static final int SLOT = 8;
    private static final int HUD_COLUMNS = 5;
    private static final int HUD_ROW = 10;
    private static final String HELD_HINT_FILE = "minevia_held_hint_seen";
    private static final int ORB_FRAMES = 24;
    private static final int ORB_COLUMNS = 6;
    private static final int ORB_SIZE = 256;

    static final KeyBinding[] KEYS = new KeyBinding[Abilities.SLOTS];
    static KeyBinding menuKey;

    static Element element;
    static int level;
    static int xp;
    static int path;
    static long changeReadyAt;
    private static boolean receivedState;
    private static boolean showSelection;
    /** Игрок держит снаряд: ЛКМ стреляет им, а колесо мыши двигает его. */
    static boolean held;
    /** Подсказка про удержание нужна только в первый раз, поэтому об этом остаётся отметка в папке настроек. */
    private static boolean heldHintSeen;
    private static boolean holding;
    private static boolean heldWithShift;
    private static int heldTicks;
    static final int[] COOLDOWN = new int[Abilities.SLOTS];
    static final int[] SKILL_XP = new int[Abilities.SLOTS];

    @Override
    public void onInitializeClient() {
        ParticleFog.disable();
        var bow = local.minevia.elements.Weapons.STORM_BOW;
        net.fabricmc.fabric.api.object.builder.v1.client.model.FabricModelPredicateProviderRegistry.register(bow, Identifier.of("pull"),
                (stack, world, user, seed) -> user == null || user.getActiveItem() != stack ? 0 : (stack.getMaxUseTime(user) - user.getItemUseTimeLeft()) / 20.0F);
        net.fabricmc.fabric.api.object.builder.v1.client.model.FabricModelPredicateProviderRegistry.register(bow, Identifier.of("pulling"),
                (stack, world, user, seed) -> user != null && user.isUsingItem() && user.getActiveItem() == stack ? 1 : 0);
        heldHintSeen = Files.exists(FabricLoader.getInstance().getConfigDir().resolve(HELD_HINT_FILE));
        EntityRendererRegistry.register(MineviaElements.SPELL, SpellRenderer::new);
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new SpellMesh.Loader());
        for (int i = 0; i < KEYS.length; i++) {
            KEYS[i] = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                    "key.minevia_elements.ability" + (i + 1), InputUtil.Type.KEYSYM, DEFAULT_KEYS[i], CATEGORY));
        }
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.minevia_elements.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_J, CATEGORY));
        Zoom.key = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.minevia_elements.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, CATEGORY));
        ClientPlayNetworking.registerGlobalReceiver(StatePayload.ID, (payload, context) -> {
            if (context.client().currentScreen instanceof SelectionScreen selection) selection.reply();
            Element before = element;
            element = local.minevia.elements.SelectionRules.choice(payload.element());
            if (before != element) { AbilityBar.reset(); AbilityWheel.close(); }
            showSelection |= !receivedState && element == null;
            receivedState = true;
            int wait = payload.slots().size() > Abilities.SLOTS * 2 ? payload.slots().get(Abilities.SLOTS * 2) : 0;
            changeReadyAt = System.currentTimeMillis() + wait * 1000L;
            if (element != null && before != element && context.client().currentScreen instanceof SelectionScreen) {
                context.client().setScreen(new ElementScreen());
            }
            level = payload.level();
            xp = payload.xp();
            path = payload.path();
            if (held && !payload.held()) {
                markHeldHintSeen();
            }
            held = payload.held();
            for (int i = 0; i < COOLDOWN.length; i++) {
                COOLDOWN[i] = payload.slots().get(i);
                SKILL_XP[i] = payload.slots().get(COOLDOWN.length + i);
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            element = null;
            receivedState = false;
            showSelection = false;
            held = false;
            AbilityBar.reset();
            SkinClient.clear(client);
        });
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> SkinClient.upload());
        // Паки друзей скачиваются с Modrinth как есть, поэтому исправление их конфликта живёт в самом моде и всегда лежит сверху.
        FabricLoader.getInstance().getModContainer(MineviaElements.MOD_ID).ifPresent(mod -> ResourceManagerHelper.registerBuiltinResourcePack(
                Identifier.of(MineviaElements.MOD_ID, "minevia_fixes"), mod, Text.literal("Minevia: исправления паков"), ResourcePackActivationType.ALWAYS_ENABLED));
        ClientPlayNetworking.registerGlobalReceiver(GesturePayload.ID, (payload, context) -> GestureClient.receive(payload));
        ClientPlayNetworking.registerGlobalReceiver(PlayerSkinPayload.ID,
                (payload, context) -> SkinClient.receive(context.client(), payload.player(), payload.png()));
        BlockEntityRendererFactories.register(MineviaElements.ALTAR_ENTITY, AltarRenderer::new);
        EntityRendererRegistry.register(MineviaElements.BOSS, BossRenderer::new);
        EntityRendererRegistry.register(MineviaElements.DUNGEON_BOSS, DungeonBossRenderer::new);
        BlockRenderLayerMap.INSTANCE.putBlock(MineviaElements.SIGIL, RenderLayer.getCutout());
        for (var spirit : MineviaElements.SPIRITS) {
            EntityRendererRegistry.register(spirit, ElementMobRenderer::new);
        }
        ClientTickEvents.START_CLIENT_TICK.register(ElementsClient::beforeInput);
        ClientTickEvents.END_CLIENT_TICK.register(ElementsClient::tick);
        HudRenderCallback.EVENT.register(ElementsClient::draw);
    }

    /** Идёт раньше обработки клавиш игры: пока снаряд в руках, ЛКМ стреляет им, а не бьёт и не ломает блок. */
    private static void beforeInput(MinecraftClient client) {
        AbilityBar.beforeInput(client);
        if (!held || client.currentScreen != null) {
            return;
        }
        KeyBinding attack = client.options.attackKey;
        boolean fired = false;
        while (attack.wasPressed()) {
            fired = true;
        }
        attack.setPressed(false);
        if (fired && ClientPlayNetworking.canSend(MenuPayload.ID)) {
            ClientPlayNetworking.send(new MenuPayload(MenuPayload.RELEASE, 0));
        }
    }

    private static void markHeldHintSeen() {
        if (heldHintSeen) {
            return;
        }
        heldHintSeen = true;
        try {
            Files.writeString(FabricLoader.getInstance().getConfigDir().resolve(HELD_HINT_FILE), "1");
        } catch (IOException error) {
            MineviaElements.LOGGER.warn("Не удалось сохранить отметку подсказки", error);
        }
    }

    /** Колесо мыши приближает и отдаляет снаряд в руках. Вернёт false, если снаряда нет. */
    public static boolean scrollHeld(double vertical) {
        if (!held || MinecraftClient.getInstance().currentScreen != null || !ClientPlayNetworking.canSend(MenuPayload.ID)) {
            return false;
        }
        ClientPlayNetworking.send(new MenuPayload(MenuPayload.ADJUST, (int) Math.signum(vertical)));
        return true;
    }

    private static void tick(MinecraftClient client) {
        for (int i = 0; i < COOLDOWN.length; i++) {
            if (COOLDOWN[i] > 0) {
                COOLDOWN[i]--;
            }
        }
        if (showSelection && client.player != null && client.currentScreen == null) {
            showSelection = false;
            client.setScreen(new SelectionScreen());
        }
        tickFirstKey(client);
        for (int i = 1; i < KEYS.length; i++) {
            while (KEYS[i].wasPressed()) {
                // Shift + вторая клавиша даёт пятую способность, а Shift + третья супер-навык.
                boolean shift = client.options.sneakKey.isPressed();
                cast(shift && i == 1 ? 4 : shift && i == 2 ? Abilities.ULTIMATE_SLOT : i);
            }
        }
        while (menuKey.wasPressed()) {
            if (receivedState && client.currentScreen == null) {
                client.setScreen(element == null ? new SelectionScreen() : new ElementScreen());
            }
        }
    }

    /**
     * Первая клавиша делает три вещи: короткое нажатие открывает панель с цифрами, а если снаряд в руках, стреляет им.
     * Shift с ней даёт четвёртую способность, а если её держать, открывается круг всех способностей.
     */
    private static void tickFirstKey(MinecraftClient client) {
        boolean pressed = false;
        while (KEYS[0].wasPressed()) {
            pressed = true;
        }
        if (client.currentScreen != null || element == null) {
            holding = false;
            AbilityWheel.close();
            return;
        }
        if (pressed && !holding) {
            holding = true;
            heldTicks = 0;
            heldWithShift = client.options.sneakKey.isPressed();
        }
        if (!holding) {
            return;
        }
        if (KEYS[0].isPressed()) {
            heldTicks++;
            if (heldTicks >= WHEEL_DELAY && !heldWithShift && !AbilityWheel.isOpen()) {
                AbilityBar.close();
                AbilityWheel.open();
            }
            return;
        }
        holding = false;
        if (AbilityWheel.isOpen()) {
            int slot = AbilityWheel.close();
            if (slot >= 0) {
                cast(slot);
            }
        } else if (heldWithShift) {
            cast(3);
        } else if (held) {
            ClientPlayNetworking.send(new MenuPayload(MenuPayload.RELEASE, 0));
        } else {
            AbilityBar.toggle();
        }
    }

    public static boolean barOpen() {
        return AbilityBar.isOpen();
    }

    /** Колесо мыши листает панель навыков, пока она открыта. */
    public static boolean scrollBar(double vertical) {
        return AbilityBar.scroll(vertical);
    }

    static void cast(int slot) {
        if (element == null) return;
        AbilityBar.noteCast(slot);
        if (MinecraftClient.getInstance().player != null && ClientPlayNetworking.canSend(CastPayload.ID)) {
            ClientPlayNetworking.send(new CastPayload(slot));
        }
    }

    /** Какие навыки показывать: два навыка пути появляются после выбора пути. */
    static int[] slots() {
        return java.util.stream.IntStream.range(0, Abilities.SLOTS)
                .filter(slot -> path > 0 || !Abilities.isPathSlot(slot)).toArray();
    }

    /** Ключ перевода навыка с учётом выбранного пути. */
    static String abilityKey(int slot) {
        if (slot == Abilities.PATH_SLOT) {
            return element.pathKey(Math.max(1, path));
        }
        if (slot == Abilities.PATH_SECOND_SLOT) {
            return element.pathKey(Math.max(1, path)) + ".second";
        }
        return element.abilityKey(slot);
    }

    static Text abilityName(int slot) {
        return Text.translatable(abilityKey(slot));
    }

    /** Подпись клавиши латиницей: на русской раскладке игра показала бы другую букву. */
    static String keyLabel(KeyBinding key) {
        int code = KeyBindingHelper.getBoundKeyOf(key).getCode();
        if (code >= GLFW.GLFW_KEY_A && code <= GLFW.GLFW_KEY_Z) {
            return String.valueOf((char) code);
        }
        return key.getBoundKeyLocalizedText().getString();
    }

    static String slotLabel(int slot, boolean compact) {
        if (!KEYS[slot].isUnbound()) {
            return keyLabel(KEYS[slot]);
        }
        String shift = compact ? "S+" : "Shift+";
        if (slot == 3 || slot == 4) {
            return shift + keyLabel(KEYS[slot - 3]);
        }
        if (slot == Abilities.ULTIMATE_SLOT) {
            return shift + keyLabel(KEYS[2]);
        }
        return "";
    }

    static Identifier abilityIcon(int slot) {
        String suffix = switch (slot) {
            case Abilities.PATH_SLOT -> "path" + Math.max(1, path);
            case Abilities.PATH_SECOND_SLOT -> "path" + Math.max(1, path) + "b";
            default -> String.valueOf(slot + 1);
        };
        return Identifier.of(MineviaElements.MOD_ID, "textures/gui/ability/" + element.id() + "_" + suffix + ".png");
    }

    /** Кадр зацикленной 3D-анимации ядра, отрендеренной в Blender. */
    static void drawOrb(DrawContext context, int x, int y, int size) {
        if (!element.isNatural()) {
            drawElementIcon(context, element, x, y, size);
            return;
        }
        String name = element.id();
        Identifier sheet = Identifier.of(MineviaElements.MOD_ID, "textures/gui/orb/" + name + ".png");
        int frame = (int) (System.currentTimeMillis() / 75 % ORB_FRAMES);
        int u = frame % ORB_COLUMNS * ORB_SIZE;
        int v = frame / ORB_COLUMNS * ORB_SIZE;
        int rows = ORB_FRAMES / ORB_COLUMNS;
        RenderSystem.enableBlend();
        context.setShaderColor(0.82F, 0.82F, 0.82F, 0.92F);
        context.drawTexture(sheet, x, y, size, size, u, v, ORB_SIZE, ORB_SIZE, ORB_SIZE * ORB_COLUMNS, ORB_SIZE * rows);
        context.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }

    static void drawIcon(DrawContext context, int slot, int x, int y, int size) {
        RenderSystem.enableBlend();
        context.drawTexture(abilityIcon(slot), x, y, size, size, 0, 0, 64, 64, 64, 64);
        RenderSystem.disableBlend();
    }

    /** Значок с перезарядкой: он тускнеет и снова наливается цветом снизу вверх. Закрытый навык почти не виден. */
    static void drawSlot(DrawContext context, int slot, int x, int y, int size) {
        boolean open = level >= Abilities.unlockLevel(slot);
        Identifier icon = abilityIcon(slot);
        RenderSystem.enableBlend();
        if (!open || COOLDOWN[slot] > 0) {
            float shade = open ? 0.4F : 0.22F;
            context.setShaderColor(shade, shade, shade, open ? 0.9F : 0.6F);
            context.drawTexture(icon, x, y, size, size, 0, 0, 64, 64, 64, 64);
            context.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        }
        if (open) {
            int hidden = size * COOLDOWN[slot] / Abilities.COOLDOWNS[slot];
            int skipped = 64 * hidden / size;
            context.drawTexture(icon, x, y + hidden, size, size - hidden, 0, skipped, 64, 64 - skipped, 64, 64);
        }
        RenderSystem.disableBlend();
    }

    /** Значок стихии: первый навык, он узнаётся лучше всего. */
    static void drawElementIcon(DrawContext context, Element of, int x, int y, int size) {
        Identifier icon = Identifier.of(MineviaElements.MOD_ID, "textures/gui/ability/" + of.id() + "_1.png");
        RenderSystem.enableBlend();
        context.drawTexture(icon, x, y, size, size, 0, 0, 64, 64, 64, 64);
        RenderSystem.disableBlend();
    }

    static void drawPathIcon(DrawContext context, int path, int x, int y, int size) {
        Identifier icon = Identifier.of(MineviaElements.MOD_ID, "textures/gui/ability/" + element.id() + "_path" + path + ".png");
        RenderSystem.enableBlend();
        context.drawTexture(icon, x, y, size, size, 0, 0, 64, 64, 64, 64);
        RenderSystem.disableBlend();
    }

    static void drawSmallText(DrawContext context, String text, int x, int y, int color, float scale) {
        MinecraftClient client = MinecraftClient.getInstance();
        context.getMatrices().push();
        context.getMatrices().translate(x, y, 200);
        context.getMatrices().scale(scale, scale, 1);
        context.drawTextWithShadow(client.textRenderer, text, 0, 0, color);
        context.getMatrices().pop();
    }

    private static void draw(DrawContext context, RenderTickCounter counter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (element == null || client.options.hudHidden || client.getDebugHud().shouldShowDebugHud()) {
            return;
        }
        AbilityWheel.draw(context);
        AbilityBar.draw(context);
        int x = context.getScaledWindowWidth() / 2 + 96;
        int y = context.getScaledWindowHeight() - 12;
        // Открытая панель показывает те же значки крупнее, а второй ряд рядом только мешал бы.
        // Десять значков в ряд не влезают справа от хотбара на маленьком окне, поэтому они идут двумя рядами.
        int[] shown = slots();
        int rows = (shown.length + HUD_COLUMNS - 1) / HUD_COLUMNS;
        for (int index = 0; index < shown.length && !AbilityBar.isOpen(); index++) {
            int left = x + index % HUD_COLUMNS * (SLOT + 2);
            int top = y - (rows - 1 - index / HUD_COLUMNS) * HUD_ROW;
            context.fill(left - 1, top - 1, left + SLOT + 1, top + SLOT + 1, 0x70000000);
            drawSlot(context, shown[index], left, top, SLOT);
        }
        if (level == 1) {
            int width = HUD_COLUMNS * (SLOT + 2) - 2;
            int filled = width * xp / ElementState.XP_FOR_LEVEL_TWO;
            int top = y - (rows - 1) * HUD_ROW - 3;
            context.fill(x, top, x + width, top + 1, 0x90000000);
            context.fill(x, top, x + filled, top + 1, 0xFF000000 | element.color);
        }
        if (held && !heldHintSeen) {
            Text hint = Text.translatable("hud.minevia_elements.held");
            context.drawCenteredTextWithShadow(client.textRenderer, hint, context.getScaledWindowWidth() / 2,
                    context.getScaledWindowHeight() / 2 + 18, 0xFFFFF3DC);
        }
    }
}
