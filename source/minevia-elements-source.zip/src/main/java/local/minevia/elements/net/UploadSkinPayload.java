package local.minevia.elements.net;

import local.minevia.elements.MineviaElements;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Игрок отдаёт серверу свой скин, выбранный в лаунчере. */
public record UploadSkinPayload(byte[] png) implements CustomPayload {
    public static final Id<UploadSkinPayload> ID = new Id<>(Identifier.of(MineviaElements.MOD_ID, "upload_skin"));
    public static final PacketCodec<RegistryByteBuf, UploadSkinPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.BYTE_ARRAY, UploadSkinPayload::png, UploadSkinPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
