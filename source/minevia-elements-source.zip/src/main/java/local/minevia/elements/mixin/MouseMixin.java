package local.minevia.elements.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import local.minevia.elements.client.AbilityWheel;
import local.minevia.elements.client.ElementsClient;
import local.minevia.elements.client.Zoom;
import net.minecraft.client.Mouse;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Круг способностей, зум и удержанный снаряд забирают мышь себе: движение идёт в указатель круга, колесо в приближение или дальность снаряда. */
@Mixin(Mouse.class)
abstract class MouseMixin {
    @WrapOperation(method = "updateMouse", at = @At(value = "INVOKE",
            target = "Lnet/minecraft/client/network/ClientPlayerEntity;changeLookDirection(DD)V"))
    private void minevia$steerWheel(ClientPlayerEntity player, double dx, double dy, Operation<Void> original) {
        if (!AbilityWheel.steer(dx, dy)) {
            double scale = Zoom.mouseScale();
            original.call(player, dx * scale, dy * scale);
        }
    }

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void minevia$zoomScroll(long window, double horizontal, double vertical, CallbackInfo info) {
        if (Zoom.scroll(vertical) || ElementsClient.scrollHeld(vertical)) {
            info.cancel();
        }
    }
}
