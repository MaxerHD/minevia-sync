package local.minevia.elements;
/** Соответствие старых слотов новой раскладке. */
public final class SkillLayout {
    private static final int[][] OLD_TO_NEW = {
        {0,4,2,3,1}, {4,1,2,3,0}, {3,1,2,0,4}, {2,0,1,3,4},
        {0,1,2,3,4}, {0,2,1,3,4}, {2,0,1,3,4}, {4,1,2,3,0}};
    private SkillLayout() { }
    public static int current(Element element, int old) { return old < 5 ? OLD_TO_NEW[element.ordinal()][old] : old; }
    public static int legacy(Element element, int slot) {
        if (slot >= 5) return slot;
        for (int i = 0; i < 5; i++) if (current(element, i) == slot) return i;
        return slot;
    }
    public static int tier(Element element, int slot) {
        if (slot == 5 || slot == 6 || slot == 9) return 2;
        return switch (element) {
            case FIRE -> slot == 0 || slot == 3 || slot == 8 ? 0 : 1;
            case WATER -> slot == 3 || slot == 4 ? 0 : 1;
            case EARTH -> slot == 0 || slot == 3 ? 0 : 1;
            case AIR -> slot == 0 || slot == 2 ? 0 : 1;
            default -> 1;
        };
    }
}
