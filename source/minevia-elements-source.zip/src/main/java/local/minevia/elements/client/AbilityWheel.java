package local.minevia.elements.client;

import local.minevia.elements.Abilities;
import local.minevia.elements.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.text.Text;

/**
 * Круг способностей: зажал клавишу, повёл мышью к нужной способности, отпустил. Так все
 * способности живут на одной клавише. Короткое нажатие открывает панель с цифрами, она в {@link AbilityBar}.
 */
public final class AbilityWheel {
    private static final double REACH = 90;
    private static final double DEAD_ZONE = 22;
    private static final int RING = 72;
    private static final int ICON = 32;

    private static boolean open;
    private static double pointerX;
    private static double pointerY;
    private static int hovered = -1;

    private AbilityWheel() {
    }

    static boolean isOpen() {
        return open;
    }

    static void open() {
        open = true;
        pointerX = 0;
        pointerY = 0;
        hovered = -1;
    }

    /** Закрывает круг и возвращает выбранный слот, либо -1, если мышь осталась в середине. */
    static int close() {
        open = false;
        return hovered;
    }

    /** Вызывается вместо поворота камеры. Вернёт false, если круг закрыт и камера должна двигаться как обычно. */
    public static boolean steer(double dx, double dy) {
        if (!open) {
            return false;
        }
        pointerX += dx * 0.8;
        pointerY += dy * 0.8;
        double length = Math.hypot(pointerX, pointerY);
        if (length > REACH) {
            pointerX *= REACH / length;
            pointerY *= REACH / length;
            length = REACH;
        }
        int next = -1;
        if (length >= DEAD_ZONE) {
            double angle = Math.atan2(pointerX, -pointerY);
            int[] slots = ElementsClient.slots();
            double sector = Math.PI * 2 / slots.length;
            int slot = slots[(int) Math.floor((angle + sector / 2 + Math.PI * 2) / sector) % slots.length];
            next = ElementsClient.level >= Abilities.unlockLevel(slot) ? slot : -1;
        }
        if (next != hovered) {
            hovered = next;
            if (next >= 0) {
                MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(Sounds.WHEEL, 1.0F, 0.6F));
            }
        }
        return true;
    }

    static void draw(DrawContext context) {
        if (!open) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        int centerX = context.getScaledWindowWidth() / 2;
        int centerY = context.getScaledWindowHeight() / 2;
        int color = 0xFF000000 | ElementsClient.element.color;
        int[] slots = ElementsClient.slots();
        for (int index = 0; index < slots.length; index++) {
            int i = slots[index];
            double angle = Math.PI * 2 * index / slots.length;
            int x = centerX + (int) Math.round(Math.sin(angle) * RING) - ICON / 2;
            int y = centerY - (int) Math.round(Math.cos(angle) * RING) - ICON / 2;
            boolean ready = ElementsClient.level >= Abilities.unlockLevel(i);
            boolean chosen = i == hovered;
            int grow = chosen ? 3 : 0;
            context.fill(x - 2 - grow, y - 2 - grow, x + ICON + 2 + grow, y + ICON + 2 + grow, chosen ? color : 0x90202C38);
            context.fill(x - 1 - grow, y - 1 - grow, x + ICON + 1 + grow, y + ICON + 1 + grow, 0xE00D1620);
            ElementsClient.drawSlot(context, i, x - grow, y - grow, ICON + grow * 2);
            if (ready && ElementsClient.COOLDOWN[i] > 0) {
                String seconds = String.valueOf(ElementsClient.COOLDOWN[i] / 20 + 1);
                context.drawCenteredTextWithShadow(client.textRenderer, seconds, x + ICON / 2, y + ICON / 2 - 4, 0xFFFFFFFF);
            }
        }
        // Указатель: куда сейчас смотрит мышь внутри круга.
        int dotX = centerX + (int) (pointerX * RING / REACH);
        int dotY = centerY + (int) (pointerY * RING / REACH);
        context.fill(dotX - 2, dotY - 2, dotX + 2, dotY + 2, color);
        if (hovered >= 0) {
            Text name = ElementsClient.abilityName(hovered);
            context.drawCenteredTextWithShadow(client.textRenderer, name, centerX, centerY + RING + ICON / 2 + 10, color);
        }
    }
}
