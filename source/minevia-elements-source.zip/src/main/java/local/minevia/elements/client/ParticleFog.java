package local.minevia.elements.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import local.minevia.elements.MineviaElements;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Particle Rain рисует туман полупрозрачными частицами, а Derivative смешивать их не умеет, и земля покрывается
 * плоскими серыми пятнами. Туман и так есть в шейдере, поэтому частицы тумана выключаются в файле настроек того мода.
 * Запускается до загрузки ресурсов, а всё, что игрок настроил сам, в этом файле остаётся.
 */
final class ParticleFog {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String[] FOG = {"fog", "vertical_fog", "fog_after_rain", "vertical_fog_after_rain"};

    private ParticleFog() {
    }

    static void disable() {
        if (!FabricLoader.getInstance().isModLoaded("particlerain")) {
            return;
        }
        Path file = FabricLoader.getInstance().getConfigDir().resolve("particlerain").resolve("particles.json");
        try {
            JsonObject all = Files.exists(file) ? JsonParser.parseString(Files.readString(file)).getAsJsonObject() : new JsonObject();
            boolean changed = false;
            for (String name : FOG) {
                if (!all.has(name)) {
                    JsonObject off = new JsonObject();
                    off.addProperty("enabled", false);
                    all.add(name, off);
                    changed = true;
                }
            }
            if (changed) {
                Files.createDirectories(file.getParent());
                Files.writeString(file, GSON.toJson(all));
            }
        } catch (IOException | RuntimeException error) {
            MineviaElements.LOGGER.warn("Не удалось выключить туман Particle Rain", error);
        }
    }
}
