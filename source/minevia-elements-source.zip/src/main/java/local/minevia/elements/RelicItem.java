package local.minevia.elements;

import java.util.List;
import java.util.Locale;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Реликвия хозяина подземелья. У каждого хозяина их три, и ни одна другая вещь в игре так не работает. */
public final class RelicItem extends Item {
    /** Порядок важен: по три на хозяина, номер хранится в мире как отметка о том, что игрок уже получил. */
    public enum Kind {
        SOUL_STAFF(50), BONE_CHARM(0), ABBOT_LANTERN(0),
        BELL_HAMMER(160), HAND_BELL(400), STORM_FEATHER(70),
        RAM_HORN(200), STONE_HEART(0), MAZE_THREAD(240);

        final int cooldown;

        Kind(int cooldown) {
            this.cooldown = cooldown;
        }

        public String id() {
            return name().toLowerCase(Locale.ROOT);
        }
    }

    private final Kind kind;

    public RelicItem(Kind kind, Settings settings) {
        super(settings);
        this.kind = kind;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (kind.cooldown == 0) {
            return TypedActionResult.pass(stack);
        }
        if (user instanceof ServerPlayerEntity player) {
            Relics.use(kind, player);
            player.getItemCooldownManager().set(this, kind.cooldown);
        }
        return TypedActionResult.success(stack);
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.minevia_elements." + kind.id() + ".hint").formatted(Formatting.GRAY));
    }
}
