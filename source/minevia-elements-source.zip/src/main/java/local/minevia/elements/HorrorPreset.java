package local.minevia.elements;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

/** Приглушает From The Fog до лёгкой жути: он ходит рядом, но не ломает базу и не кричит в лицо. */
final class HorrorPreset {
    private static final String OPTIONS = "ftf.configOptions";
    private static final String MARKER = "mineviaPreset";
    /** Скримеры, вылет игры, запрет сна и всё, что портит постройки. */
    private static final String[] OFF = {
            "crashConfig", "jumpscareConfig", "noSleepConfig", "burningBaseConfig",
            "poofingTorchesConfig", "crimsonCurseConfig", "nightmareMechanicConfig", "dreadfulDonationConfig"
    };

    private HorrorPreset() {
    }

    /** Срабатывает один раз на мир, чтобы настройки игрока из меню мода не сбрасывались. */
    static void apply(MinecraftServer server) {
        if (!FabricLoader.getInstance().isModLoaded("watching")) {
            return;
        }
        CommandManager commands = server.getCommandManager();
        ServerCommandSource source = server.getCommandSource().withSilent();
        // Функции загрузки мода идут только на первом такте, а в новом мире таблицы ещё нет.
        commands.executeWithPrefix(source, "scoreboard objectives add " + OPTIONS + " dummy");
        String once = "execute unless score " + MARKER + " " + OPTIONS + " matches 1 run ";
        // Без этого значения мод на первом такте сам вернёт часть настроек к своим.
        commands.executeWithPrefix(source, once + "scoreboard players set autoConfig " + OPTIONS + " 0");
        for (String option : OFF) {
            commands.executeWithPrefix(source, once + "scoreboard players set " + option + " " + OPTIONS + " 0");
        }
        commands.executeWithPrefix(source, once + "scoreboard players set sightingChanceConfig " + OPTIONS + " 3");
        commands.executeWithPrefix(source, "scoreboard players set " + MARKER + " " + OPTIONS + " 1");
    }
}
