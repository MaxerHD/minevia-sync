package local.minevia.elements;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;

/** Настраивает From The Fog: страшно, но база цела, спать можно, игра не вылетает. */
final class HorrorPreset {
    private static final String OPTIONS = "ftf.configOptions";
    private static final String MARKER = "mineviaPreset";
    /** Номер набора настроек: новый набор один раз заменяет старый в уже созданных мирах. */
    private static final int VERSION = 2;
    /** Поджог базы, вылет игры и запрет сна портят игру, а не пугают. */
    private static final String[] OFF = {"crashConfig", "noSleepConfig", "burningBaseConfig"};
    private static final String[] ON = {"jumpscareConfig", "poofingTorchesConfig", "crimsonCurseConfig", "nightmareMechanicConfig", "dreadfulDonationConfig"};

    private HorrorPreset() {
    }

    /** Срабатывает один раз на мир, чтобы настройки игрока из меню мода не сбрасывались. */
    static void apply(MinecraftServer server) {
        if (!FabricLoader.getInstance().isModLoaded("watching")) {
            return;
        }
        CommandManager commands = server.getCommandManager();
        ServerCommandSource source = server.getCommandSource().withSilent();
        // Функции загрузки мода идут только на первом такте, а в новом мире таблицы ещё нет.
        commands.executeWithPrefix(source, "scoreboard objectives add " + OPTIONS + " dummy");
        String once = "execute unless score " + MARKER + " " + OPTIONS + " matches " + VERSION + " run ";
        // Без этого значения мод на первом такте сам вернёт часть настроек к своим.
        commands.executeWithPrefix(source, once + "scoreboard players set autoConfig " + OPTIONS + " 0");
        for (String option : OFF) {
            commands.executeWithPrefix(source, once + "scoreboard players set " + option + " " + OPTIONS + " 0");
        }
        for (String option : ON) {
            commands.executeWithPrefix(source, once + "scoreboard players set " + option + " " + OPTIONS + " 1");
        }
        commands.executeWithPrefix(source, once + "scoreboard players set sightingChanceConfig " + OPTIONS + " 2");
        commands.executeWithPrefix(source, "scoreboard players set " + MARKER + " " + OPTIONS + " " + VERSION);
    }
}
