package local.minevia.elements;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleFactory;
import net.fabricmc.fabric.api.gamerule.v1.GameRuleRegistry;
import net.minecraft.block.BlockState;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameRules;
import net.minecraft.world.Heightmap;
import net.minecraft.world.LightType;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/**
 * Свои страшные события: они не ломают постройки и живут только в виде моделей, которых нет в сохранении.
 * Гигант ходит за спиной, призрак крадётся, пока на него не смотрят, глаза следят из темноты, коконы висят в лесу.
 * Выключается правилом /gamerule mineviaHorror false.
 */
public final class Horror {
    public static final GameRules.Key<GameRules.BooleanRule> ENABLED = GameRuleRegistry.register(
            "mineviaHorror", GameRules.Category.MISC, GameRuleFactory.createBooleanRule(true));
    private static final int CHECK = 40;
    private static final int MIN_GAP = 5 * 60 * 20;
    private static final int MAX_GAP = 12 * 60 * 20;
    private static final float COLOSSUS_SIZE = 60;
    private static final double COLOSSUS_SPEED = 0.2;
    private static final Map<UUID, Integer> NEXT = new HashMap<>();

    private Horror() {
    }

    /** Правило игры надо зарегистрировать при старте: мир создаёт список правил раньше первого такта. */
    static void init() {
    }

    static void tick(MinecraftServer server) {
        if (server.getTicks() % CHECK != 0 || !server.getGameRules().getBoolean(ENABLED)) {
            return;
        }
        int now = server.getTicks();
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            if (player.isSpectator() || player.isCreative() || player.getServerWorld().getRegistryKey() != World.OVERWORLD) {
                continue;
            }
            int due = NEXT.computeIfAbsent(player.getUuid(), id -> now + gap(player));
            if (now >= due && surprise(player)) {
                NEXT.put(player.getUuid(), now + gap(player));
            }
        }
    }

    private static int gap(ServerPlayerEntity player) {
        return MIN_GAP + player.getRandom().nextInt(MAX_GAP - MIN_GAP);
    }

    private static boolean surprise(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        BlockPos feet = player.getBlockPos();
        boolean underground = world.getLightLevel(LightType.SKY, feet) == 0;
        boolean dark = world.getLightLevel(feet) <= 5;
        float roll = player.getRandom().nextFloat();
        if (underground) {
            return dark && (roll < 0.5F ? wraith(player) : eyes(player));
        }
        if (!world.isNight()) {
            return false;
        }
        if (roll < 0.45F) {
            return colossus(player);
        }
        return roll < 0.8F ? cocoon(player) : dark && wraith(player);
    }

    /** Команда для проверки: показывает событие сразу. */
    public static boolean start(ServerPlayerEntity player, String name) {
        return switch (name) {
            case "colossus" -> colossus(player);
            case "wraith" -> wraith(player);
            case "eyes" -> eyes(player);
            case "cocoon" -> cocoon(player);
            default -> false;
        };
    }

    private static Vec3d flatLook(ServerPlayerEntity player) {
        Vec3d look = player.getRotationVector();
        Vec3d flat = new Vec3d(look.x, 0, look.z);
        return flat.lengthSquared() < 1.0E-4 ? new Vec3d(0, 0, 1) : flat.normalize();
    }

    private static Vec3d turned(Vec3d flat, double degrees) {
        double a = Math.toRadians(degrees);
        return new Vec3d(flat.x * Math.cos(a) - flat.z * Math.sin(a), 0, flat.x * Math.sin(a) + flat.z * Math.cos(a));
    }

    private static double ground(ServerWorld world, double x, double z, double fallback) {
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        if (!world.isChunkLoaded(bx >> 4, bz >> 4)) {
            return fallback;
        }
        return world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, bx, bz);
    }

    private static void sound(ServerWorld world, Vec3d at, SoundEvent sound, float volume, float pitch) {
        world.playSound(null, at.x, at.y, at.z, sound, SoundCategory.AMBIENT, volume, pitch);
    }

    private static boolean colossus(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d back = turned(flatLook(player), 180 + (player.getRandom().nextDouble() - 0.5) * 120);
        Vec3d spot = player.getPos().add(back.multiply(74 + player.getRandom().nextDouble() * 12));
        Vec3d walk = turned(back, player.getRandom().nextBoolean() ? 90 : -90);
        Vec3d at = new Vec3d(spot.x, ground(world, spot.x, spot.z, player.getY() - 3), spot.z).subtract(walk.multiply(60));
        SpellEntity.spawn(world, SpellKind.HORROR_COLOSSUS, at, COLOSSUS_SIZE, 760).facing(walk).logic(self -> {
            Vec3d next = self.getPos().add(walk.multiply(COLOSSUS_SPEED));
            double height = ground(world, next.x, next.z, next.y);
            self.setVelocity(walk.multiply(COLOSSUS_SPEED));
            self.setPosition(next.x, next.y + (height - next.y) * 0.06, next.z);
            if (self.age % 45 == 0) {
                sound(world, self.getPos(), Sounds.HORROR_STEP, 9.0F, 0.85F + world.random.nextFloat() * 0.2F);
            }
            if (player.isRemoved() || player.squaredDistanceTo(self) < 24 * 24) {
                self.discard();
            }
        });
        return true;
    }

    private static Vec3d floorNear(ServerWorld world, Vec3d spot) {
        BlockPos start = BlockPos.ofFloored(spot);
        for (int dy : new int[] {0, 1, -1, 2, -2, 3, -3, 4, -4}) {
            BlockPos feet = start.up(dy);
            if (world.getBlockState(feet).getCollisionShape(world, feet).isEmpty()
                    && world.getBlockState(feet.up()).getCollisionShape(world, feet.up()).isEmpty()
                    && world.getBlockState(feet.down()).isSolidBlock(world, feet.down())) {
                return Vec3d.ofBottomCenter(feet);
            }
        }
        return null;
    }

    private static boolean wraith(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d back = flatLook(player).multiply(-(7 + player.getRandom().nextDouble() * 3));
        Vec3d at = floorNear(world, player.getPos().add(back));
        if (at == null) {
            return false;
        }
        SpellEntity.spawn(world, SpellKind.HORROR_WRAITH, at, 1, 500).facing(player.getPos().subtract(at)).logic(self -> {
            if (player.isRemoved() || player.getWorld() != world) {
                self.discard();
                return;
            }
            Vec3d to = player.getPos().subtract(self.getPos());
            double distance = to.length();
            Vec3d eyes = player.getEyePos();
            Vec3d seen = self.getPos().add(0, 1.8, 0).subtract(eyes).normalize();
            boolean watched = player.getRotationVector().dotProduct(seen) > 0.72 && clearView(world, player, eyes, self.getPos().add(0, 1.8, 0));
            if (watched && self.age > 8) {
                sound(world, self.getPos(), Sounds.HORROR_STING, 1.6F, 1.0F);
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 70, 0, false, false, false));
                self.discard();
                return;
            }
            if (distance < 1.7) {
                sound(world, player.getPos(), Sounds.HORROR_SCREAM, 1.8F, 1.0F);
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 120, 0, false, false, false));
                if (player.getHealth() > 8) {
                    player.damage(world.getDamageSources().magic(), 4);
                }
                self.discard();
                return;
            }
            if (self.age % 62 == 0 && distance < 12) {
                sound(world, self.getPos(), Sounds.HORROR_BREATH, 0.9F, 0.9F + world.random.nextFloat() * 0.2F);
            }
            Vec3d move = to.normalize().multiply(0.085);
            self.facing(to);
            self.setVelocity(move);
            self.setPosition(self.getPos().add(move));
        });
        return true;
    }

    private static boolean clearView(ServerWorld world, ServerPlayerEntity player, Vec3d from, Vec3d to) {
        return world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.VISUAL, RaycastContext.FluidHandling.NONE, player)).getType() == HitResult.Type.MISS;
    }

    private static boolean eyes(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d from = player.getEyePos();
        Vec3d look = turned(flatLook(player), (player.getRandom().nextDouble() - 0.5) * 70);
        Vec3d far = from.add(look.multiply(20));
        BlockHitResult hit = world.raycast(new RaycastContext(from, far, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        double reach = hit.getType() == HitResult.Type.MISS ? 15 : hit.getPos().distanceTo(from) - 0.7;
        if (reach < 7) {
            return false;
        }
        Vec3d at = from.add(look.multiply(reach));
        if (world.getLightLevel(BlockPos.ofFloored(at)) > 7) {
            return false;
        }
        SpellEntity.spawn(world, SpellKind.HORROR_EYES, at, 1, 280).facing(from.subtract(at)).logic(self -> {
            if (self.age == 6) {
                sound(world, self.getPos(), Sounds.HORROR_WHISPER, 1.2F, 0.9F + world.random.nextFloat() * 0.2F);
            }
            if (player.isRemoved() || player.squaredDistanceTo(self) < 5.5 * 5.5) {
                self.discard();
            }
        });
        return true;
    }

    private static boolean cocoon(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d look = flatLook(player);
        for (int attempt = 0; attempt < 64; attempt++) {
            Vec3d side = turned(look, 80 + player.getRandom().nextDouble() * 200);
            Vec3d spot = player.getPos().add(side.multiply(16 + player.getRandom().nextDouble() * 18));
            int x = (int) Math.floor(spot.x);
            int z = (int) Math.floor(spot.z);
            if (!world.isChunkLoaded(x >> 4, z >> 4)) {
                continue;
            }
            int floor = world.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            int y = world.getTopY(Heightmap.Type.MOTION_BLOCKING, x, z) - 1;
            while (y > floor && isCanopy(world.getBlockState(new BlockPos(x, y - 1, z)))) {
                y--;
            }
            if (y - floor < 4 || !isCanopy(world.getBlockState(new BlockPos(x, y, z)))) {
                continue;
            }
            SpellEntity.spawn(world, SpellKind.HORROR_COCOON, new Vec3d(x + 0.5, y, z + 0.5), 1, 1400).logic(self -> {
                if (self.age % 78 == 20) {
                    sound(world, self.getPos(), Sounds.HORROR_CREAK, 1.1F, 0.85F + world.random.nextFloat() * 0.3F);
                }
                if (player.isRemoved() || player.squaredDistanceTo(self) < 9 * 9) {
                    self.discard();
                }
            });
            return true;
        }
        return false;
    }

    private static boolean isCanopy(BlockState state) {
        return state.isIn(BlockTags.LEAVES);
    }
}
