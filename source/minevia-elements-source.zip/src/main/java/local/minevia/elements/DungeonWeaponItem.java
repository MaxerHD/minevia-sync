package local.minevia.elements;

import java.util.List;
import java.util.Locale;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Оружие из наградных сундуков, отдельно от реликвий. */
public final class DungeonWeaponItem extends ToolItem {
    public enum Kind {
        CINDERWING(3, -2.4F), TIDAL_TRIDENT(4, -2.7F), NIGHT_SHARD(1, -1.4F),
        CHIME_MAUL(6, -3.3F), WINDCUTTER(2, -1.8F), GRAVITY_FLAIL(5, -3.0F), SOUL_SCYTHE(4, -2.8F);

        final int damage;
        final float speed;

        Kind(int damage, float speed) {
            this.damage = damage;
            this.speed = speed;
        }

        public String id() {
            return name().toLowerCase(Locale.ROOT);
        }
    }

    private final Kind kind;

    public DungeonWeaponItem(Kind kind, Settings settings) {
        super(ToolMaterials.NETHERITE, settings);
        this.kind = kind;
    }

    public Kind kind() {
        return kind;
    }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (attacker instanceof ServerPlayerEntity player) {
            Weapons.hit(kind, stack, target, player);
        }
        return true;
    }

    @Override
    public void postDamageEntity(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        stack.damage(1, attacker, EquipmentSlot.MAINHAND);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        if (user.getItemCooldownManager().isCoolingDown(this)) {
            return TypedActionResult.fail(stack);
        }
        if (kind != Kind.TIDAL_TRIDENT && kind != Kind.WINDCUTTER && kind != Kind.GRAVITY_FLAIL) {
            return TypedActionResult.pass(stack);
        }
        if (user instanceof ServerPlayerEntity player && !Weapons.use(kind, stack, player, hand)) {
            return TypedActionResult.fail(stack);
        }
        return TypedActionResult.success(stack, world.isClient);
    }

    @Override
    public void inventoryTick(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (entity instanceof ServerPlayerEntity player && (player.isOnGround() || player.isTouchingWater() || player.isClimbing())) {
            Weapons.landed(player);
        }
    }

    @Override
    public void appendTooltip(ItemStack stack, TooltipContext context, List<Text> tooltip, TooltipType type) {
        tooltip.add(Text.translatable("item.minevia_elements." + kind.id() + ".hint").formatted(Formatting.GRAY));
    }
}
