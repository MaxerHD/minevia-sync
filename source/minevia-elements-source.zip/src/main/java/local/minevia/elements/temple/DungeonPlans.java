package local.minevia.elements.temple;

import local.minevia.elements.DungeonBoss;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.TrapBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.LadderBlock;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;

/** Новые планы: все решения берутся из одного зерна на целое строение. */
final class DungeonPlans {
    private final DungeonPiece piece;
    private final DungeonPiece.Kind kind;
    private final StructureWorldAccess world;
    private final BlockBox box;
    private final Random loot;
    private final java.util.Random plan;

    DungeonPlans(DungeonPiece piece, DungeonPiece.Kind kind, StructureWorldAccess world, BlockBox box, Random loot, java.util.Random plan) {
        this.piece = piece;
        this.kind = kind;
        this.world = world;
        this.box = box;
        this.loot = loot;
        this.plan = plan;
    }

    void generate() {
        switch (kind) {
            case FORGE -> forge();
            case SANCTUARY -> sanctuary();
            case OBSERVATORY -> observatory();
            default -> throw new IllegalStateException(kind.name());
        }
    }

    private void put(Block block, int x, int y, int z) {
        piece.place(world, box, block.getDefaultState(), x, y, z);
    }

    private void fill(Block block, int x0, int y0, int z0, int x1, int y1, int z1) {
        for (int x = x0; x <= x1; x++) {
            for (int y = y0; y <= y1; y++) {
                for (int z = z0; z <= z1; z++) {
                    put(block, x, y, z);
                }
            }
        }
    }

    private void mob(int x, int y, int z, EntityType<?> type) {
        piece.spawner(world, box, loot, x, y, z, type);
    }

    private void trap(int x, int y, int z, int element) {
        piece.place(world, box, MineviaElements.TRAP.getDefaultState().with(TrapBlock.ELEMENT, element), x, y, z);
    }

    private void shaft(Block wall, int bottom, int top) {
        // Воздух отделён стеной от моря и грунта, выход всегда выше воды.
        fill(wall, 18, bottom, 1, 22, top + 4, 5);
        fill(Blocks.AIR, 19, bottom, 2, 21, top + 3, 4);
        for (int y = bottom; y <= top + 1; y++) {
            piece.place(world, box, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.SOUTH), 20, y, 2);
        }
        fill(wall, 18, top, 1, 22, top, 5);
        put(Blocks.AIR, 20, top, 2);
        piece.place(world, box, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.SOUTH), 20, top, 2);
        fill(Blocks.AIR, 19, top + 1, 5, 21, top + 3, 5);
        put(Blocks.SEA_LANTERN, 20, top + 3, 3);
    }

    private void forge() {
        fill(Blocks.POLISHED_BLACKSTONE_BRICKS, 0, 0, 0, 40, 13, 40);
        fill(Blocks.AIR, 1, 3, 1, 39, 12, 39);
        fill(Blocks.POLISHED_BASALT, 1, 2, 1, 39, 2, 39);
        // Каналы закрыты решёткой; широкие каменные мосты проходят поверх них.
        for (int z : new int[] {12, 19}) {
            fill(Blocks.LAVA, 2, 1, z, 38, 1, z + 2);
            fill(Blocks.IRON_BARS, 2, 2, z, 38, 2, z + 2);
            for (int x : new int[] {8, 20, 32}) {
                fill(Blocks.POLISHED_BASALT, x - 2, 2, z, x + 2, 2, z + 2);
            }
        }
        for (int x : new int[] {5, 35}) {
            for (int z : new int[] {7, 17, 27, 35}) {
                fill(Blocks.BASALT, x, 3, z, x + 1, 11, z + 1);
                put(Blocks.WAXED_COPPER_BLOCK, x, 9, z);
                put(Blocks.SHROOMLIGHT, x, 10, z);
                fill(Blocks.CHAIN, x + 2, 8, z, x + 2, 12, z);
            }
        }
        for (int x : new int[] {10, 30}) {
            put(Blocks.ANVIL, x, 3, 8);
            put(Blocks.BLAST_FURNACE, x, 3, 10);
            mob(x, 3, 16, x == 10 ? EntityType.WITHER_SKELETON : MineviaElements.SPIRITS[0]);
            piece.cache(world, box, loot, x, 3, 5);
        }
        for (int i = 0; i < 12; i++) {
            int x = 3 + plan.nextInt(35);
            int z = 6 + plan.nextInt(18);
            if (Math.abs(x - 20) > 3 && z != 12 && z != 13 && z != 14 && z != 19 && z != 20 && z != 21) {
                trap(x, 2, z, 0);
            }
        }
        fill(Blocks.WAXED_CUT_COPPER, 18, 2, 28, 22, 2, 32);
        piece.sigil(world, box, 20, 3, 30, DungeonBoss.SMITH);
        shaft(Blocks.POLISHED_BLACKSTONE_BRICKS, 3, piece.entryHeight);
        fill(Blocks.AIR, 19, 3, 5, 21, 6, 6);
    }

    private void sanctuary() {
        fill(Blocks.DARK_PRISMARINE, 0, 0, 0, 40, 13, 40);
        fill(Blocks.AIR, 1, 3, 1, 39, 12, 39);
        fill(Blocks.PRISMARINE_BRICKS, 1, 2, 1, 39, 2, 39);
        fill(Blocks.WATER, 1, 3, 1, 39, 6, 39);
        // Непрерывная сухая дорожка до печати и обратно; над водой четыре блока воздуха.
        fill(Blocks.PRISMARINE_BRICKS, 18, 6, 3, 22, 6, 31);
        fill(Blocks.PRISMARINE_BRICKS, 8, 6, 14, 32, 6, 18);
        fill(Blocks.PRISMARINE_BRICKS, 12, 6, 24, 28, 6, 37);
        for (int x : new int[] {6, 34}) {
            for (int z : new int[] {8, 20, 33}) {
                fill(Blocks.PRISMARINE_BRICKS, x, 3, z, x + 1, 11, z + 1);
                put(Blocks.SEA_LANTERN, x, 9, z);
            }
        }
        // Ступени из бассейнов к воздуху, без прыжка через высокий борт.
        for (int x : new int[] {9, 30}) {
            for (int step = 0; step < 4; step++) {
                fill(Blocks.PRISMARINE_BRICKS, x, 2, 10 + step, x + 1, 3 + step, 10 + step);
            }
        }
        mob(6, 3, 15, EntityType.DROWNED);
        mob(34, 3, 25, EntityType.GUARDIAN);
        mob(32, 7, 16, MineviaElements.SPIRITS[1]);
        for (int x : new int[] {12, 28}) {
            piece.cache(world, box, loot, x, 7, 16);
            trap(x + 1, 6, 17, 1);
        }
        for (int z = 8; z < 38; z += 6) {
            put(Blocks.SEA_LANTERN, 20, 12, z);
        }
        piece.sigil(world, box, 20, 7, 30, DungeonBoss.KEEPER);
        shaft(Blocks.DARK_PRISMARINE, 7, Math.max(14, piece.entryHeight));
        fill(Blocks.AIR, 19, 7, 5, 21, 10, 6);
    }

    private void observatory() {
        // Полая опора с лестницей и входом на уровне земли.
        fill(Blocks.CALCITE, 18, 0, 1, 22, 51, 5);
        fill(Blocks.AIR, 19, 1, 2, 21, 51, 4);
        fill(Blocks.AIR, 19, 1, 1, 21, 3, 1);
        for (int y = 1; y <= 49; y++) {
            piece.place(world, box, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.SOUTH), 20, y, 2);
        }
        fill(Blocks.AIR, 19, 49, 5, 21, 51, 5);
        for (int x = 0; x <= 40; x++) {
            for (int z = 0; z <= 40; z++) {
                boolean deck = Math.hypot(x - 10, z - 12) <= 8 || Math.hypot(x - 30, z - 12) <= 8
                        || Math.hypot(x - 20, z - 30) <= 10;
                boolean bridge = x >= 8 && x <= 32 && z >= 10 && z <= 14
                        || x >= 18 && x <= 22 && z >= 3 && z <= 30;
                if (!deck && !bridge) {
                    continue;
                }
                fill(Blocks.AIR, x, 49, z, x, 61, z);
                put((x + z) % 5 == 0 ? Blocks.WAXED_OXIDIZED_CUT_COPPER : Blocks.CALCITE, x, 48, z);
                // Край определяется тем же предикатом, независимо от порядка чанков.
                if (!platform(x - 1, z) || !platform(x + 1, z) || !platform(x, z - 1) || !platform(x, z + 1)) {
                    put(Blocks.GLASS, x, 49, z);
                    put(Blocks.GLASS, x, 50, z);
                }
            }
        }
        // Выход лестницы очищается после настила.
        for (int y = 48; y <= 49; y++) {
            piece.place(world, box, Blocks.LADDER.getDefaultState().with(LadderBlock.FACING, Direction.SOUTH), 20, y, 2);
        }
        fill(Blocks.AIR, 19, 49, 3, 21, 51, 6);
        for (int x : new int[] {10, 30}) {
            fill(Blocks.WAXED_OXIDIZED_COPPER, x, 49, 11, x, 51, 11);
            fill(Blocks.WAXED_CUT_COPPER, x, 52, 10, x, 52, 14);
            put(Blocks.TINTED_GLASS, x, 52, 15);
            put(Blocks.LIGHTNING_ROD, x, 53, 10);
            mob(x - 3, 49, 13, x == 10 ? EntityType.STRAY : MineviaElements.SPIRITS[3]);
            piece.cache(world, box, loot, x, 49, 16);
            trap(x + 3, 48, 12, 3);
        }
        for (int x : new int[] {14, 26}) {
            fill(Blocks.CALCITE, x, 49, 35, x, 56, 35);
            put(Blocks.SEA_LANTERN, x, 57, 35);
        }
        piece.sigil(world, box, 20, 49, 30, DungeonBoss.ASTRONOMER);
    }

    private static boolean platform(int x, int z) {
        return Math.hypot(x - 10, z - 12) <= 8 || Math.hypot(x - 30, z - 12) <= 8
                || Math.hypot(x - 20, z - 30) <= 10 || x >= 8 && x <= 32 && z >= 10 && z <= 14
                || x >= 18 && x <= 22 && z >= 3 && z <= 30;
    }
}
