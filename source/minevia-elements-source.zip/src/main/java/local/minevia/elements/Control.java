package local.minevia.elements;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/**
 * Удержание способности: снаряд не улетает сразу, а висит там, куда смотрит игрок.
 * Им можно водить и бить врагов, колесо мыши двигает его ближе и дальше,
 * а ЛКМ или повторное нажатие того же навыка запускает снаряд.
 */
final class Control {
    private static final int MAX_TICKS = 240;
    private static final double MIN_DISTANCE = 2.5;
    private static final double MAX_DISTANCE = 26;
    private static final double SIDE_SHIFT = 1.1;
    private static final double DOWN_SHIFT = 0.6;

    private static final class Held {
        int slot;
        SpellEntity spell;
        double distance;
        long until;
        Runnable release;
    }

    private static final Map<UUID, Held> HELD = new HashMap<>();

    private Control() {
    }

    static void hold(ServerPlayerEntity player, int slot, SpellEntity spell, double distance, Runnable release) {
        release(player);
        Held held = new Held();
        held.slot = slot;
        held.spell = spell;
        held.distance = distance;
        held.until = player.getServer().getTicks() + MAX_TICKS;
        held.release = release;
        HELD.put(player.getUuid(), held);
        MineviaElements.sync(player);
    }

    static boolean active(ServerPlayerEntity player) {
        return HELD.containsKey(player.getUuid());
    }

    static boolean holding(ServerPlayerEntity player, SpellEntity spell) {
        Held held = HELD.get(player.getUuid());
        return held != null && held.spell == spell;
    }

    /**
     * Точка, в которой висит снаряд: перед игроком, но не за стеной. Он сдвинут вправо и вниз от прицела:
     * иначе закрывал бы цель, а автофокус шейдера цеплялся бы за него и размывал весь мир.
     */
    static Vec3d spot(ServerPlayerEntity player) {
        Held held = HELD.get(player.getUuid());
        double distance = held != null ? held.distance : 5;
        var hit = player.raycast(distance, 1.0F, false);
        double reach = Math.min(distance, Math.max(MIN_DISTANCE, hit.getPos().distanceTo(player.getEyePos()) - 0.8));
        Vec3d look = player.getRotationVector();
        Vec3d right = look.crossProduct(new Vec3d(0, 1, 0)).normalize();
        return player.getEyePos().add(look.multiply(reach)).add(right.multiply(SIDE_SHIFT)).add(0, -DOWN_SHIFT, 0);
    }

    static void adjust(ServerPlayerEntity player, int steps) {
        Held held = HELD.get(player.getUuid());
        if (held != null) {
            held.distance = MathHelper.clamp(held.distance + MathHelper.clamp(steps, -3, 3) * 1.5, MIN_DISTANCE, MAX_DISTANCE);
        }
    }

    /** Повторное нажатие навыка, который сейчас в руках, это выстрел, а не новый навык. */
    static boolean releaseSlot(ServerPlayerEntity player, int slot) {
        Held held = HELD.get(player.getUuid());
        return held != null && held.slot == slot && release(player);
    }

    static boolean release(ServerPlayerEntity player) {
        Held held = HELD.remove(player.getUuid());
        if (held == null) {
            return false;
        }
        if (!held.spell.isRemoved()) {
            held.release.run();
            Gestures.release(player);
        } else {
            Gestures.stop(player);
        }
        MineviaElements.sync(player);
        return true;
    }

    static void forget(UUID id) {
        Held held = HELD.remove(id);
        if (held != null) held.spell.discard();
    }

    /** Снаряд сам уходит через двенадцать секунд, а если он пропал или игрок погиб, удержание снимается. */
    static void tick(MinecraftServer server) {
        long now = server.getTicks();
        for (UUID id : HELD.keySet().toArray(new UUID[0])) {
            Held held = HELD.get(id);
            ServerPlayerEntity player = server.getPlayerManager().getPlayer(id);
            if (player == null || !player.isAlive() || held.spell.isRemoved()) {
                HELD.remove(id);
                if (player != null) {
                    Gestures.stop(player);
                    MineviaElements.sync(player);
                }
            } else if (held.until <= now) {
                release(player);
            }
        }
    }
}
