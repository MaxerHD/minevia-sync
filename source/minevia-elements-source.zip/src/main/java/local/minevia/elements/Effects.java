package local.minevia.elements;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/** Отложенные шаги способностей и временные блоки. */
public final class Effects {
    private record Task(long at, Runnable action) {
    }

    private static final List<Task> TASKS = new ArrayList<>();
    private static final List<TemporaryBlock> PLACED = new ArrayList<>();

    private Effects() {
    }

    public static void tick(MinecraftServer server) {
        long now = server.getTicks();
        List<Task> due = new ArrayList<>();
        TASKS.removeIf(task -> {
            if (task.at() > now) {
                return false;
            }
            due.add(task);
            return true;
        });
        due.forEach(task -> task.action().run());
    }

    public static void clear() {
        TASKS.clear();
    }

    /** Шаг повторяющегося эффекта. Вернуть false, чтобы остановить его раньше времени. */
    public interface Step {
        boolean run(int index);
    }

    public static void repeat(ServerWorld world, int times, int interval, Step step) {
        repeatFrom(world, 0, times, interval, step);
    }

    private static void repeatFrom(ServerWorld world, int index, int times, int interval, Step step) {
        if (index >= times || !step.run(index)) {
            return;
        }
        later(world, interval, () -> repeatFrom(world, index + 1, times, interval, step));
    }

    static void later(ServerWorld world, int delay, Runnable action) {
        TASKS.add(new Task(world.getServer().getTicks() + delay, action));
    }

    /** Временный блок: ставится только в пустую клетку и потом убирается, чужие блоки не трогаются. */
    public static void temporaryBlock(ServerWorld world, BlockPos pos, BlockState state, int delay, int lifetime) {
        later(world, delay, () -> {
            if (!world.getBlockState(pos).isReplaceable() || !world.getFluidState(pos).isEmpty()) {
                return;
            }
            world.setBlockState(pos, state);
            TemporaryBlock placed = new TemporaryBlock(world, pos, state);
            PLACED.add(placed);
            later(world, lifetime, () -> {
                placed.remove();
                PLACED.remove(placed);
            });
        });
    }

    /** Перед выключением мира убирает стены, чтобы они не остались в сохранении. */
    public static void removeTemporaryBlocks() {
        PLACED.forEach(TemporaryBlock::remove);
        PLACED.clear();
    }

    private record TemporaryBlock(ServerWorld world, BlockPos pos, BlockState state) {
        void remove() {
            if (world.getBlockState(pos).equals(state)) {
                world.setBlockState(pos, Blocks.AIR.getDefaultState());
            }
        }
    }
}
