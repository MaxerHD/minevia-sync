package local.minevia.elements;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;

/** Отложенные шаги способностей. Блоков в мире способности не ставят. */
public final class Effects {
    private record Task(long at, Runnable action) {
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private Effects() {
    }

    public static void tick(MinecraftServer server) {
        long now = server.getTicks();
        List<Task> due = new ArrayList<>();
        TASKS.removeIf(task -> {
            if (task.at() > now) {
                return false;
            }
            due.add(task);
            return true;
        });
        due.forEach(task -> task.action().run());
    }

    public static void clear() {
        TASKS.clear();
    }

    /** Шаг повторяющегося эффекта. Вернуть false, чтобы остановить его раньше времени. */
    public interface Step {
        boolean run(int index);
    }

    public static void repeat(ServerWorld world, int times, int interval, Step step) {
        repeatFrom(world, 0, times, interval, step);
    }

    /** То же, но первый шаг случается не сразу, а через delay тиков. */
    public static void repeat(ServerWorld world, int times, int interval, Step step, int delay) {
        later(world, delay, () -> repeatFrom(world, 0, times, interval, step));
    }

    private static void repeatFrom(ServerWorld world, int index, int times, int interval, Step step) {
        if (index >= times || !step.run(index)) {
            return;
        }
        later(world, interval, () -> repeatFrom(world, index + 1, times, interval, step));
    }

    static void later(ServerWorld world, int delay, Runnable action) {
        CastContext.Token token = CastContext.capture();
        TASKS.add(new Task(world.getServer().getTicks() + delay, () -> CastContext.run(token, action)));
    }

    /** Уборка выполняется и после смены стиля. */
    static void cleanup(ServerWorld world, int delay, Runnable action) {
        TASKS.add(new Task(world.getServer().getTicks() + delay, action));
    }
}
