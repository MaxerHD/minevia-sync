package local.minevia.elements.client;

import java.util.EnumMap;
import java.util.Map;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.SpellEntity;
import local.minevia.elements.SpellKind;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;

/** Рисует способности настоящими 3D-моделями. Частицы игры здесь не участвуют. */
final class SpellRenderer extends EntityRenderer<SpellEntity> {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private static final Map<SpellKind, Look> LOOKS = new EnumMap<>(SpellKind.class);

    private enum Blend {
        GLOW, FIRE, ADD, WATER, SOLID, SMOKE, CLOUD;

        RenderLayer layer() {
            return switch (this) {
                case ADD -> RenderLayer.getEyes(WHITE);
                case SOLID, CLOUD -> RenderLayer.getEntitySolid(WHITE);
                case SMOKE -> ShaderCompat.needsDepth() ? ShaderCompat.glow() : RenderLayer.getEntityTranslucent(WHITE);
                default -> ShaderCompat.glow();
            };
        }

        SpellMesh.Surface surface() {
            return switch (this) {
                case WATER -> SpellMesh.Surface.WET;
                case FIRE -> SpellMesh.Surface.GAS;
                case SMOKE, CLOUD -> SpellMesh.Surface.FOG;
                default -> SpellMesh.Surface.PLAIN;
            };
        }
    }

    private enum Facing {
        UPRIGHT, HEADING, FLAT, OWNER_LOOK, WHIP
    }

    /** Один слой модели. loop: тиков на круг анимации, 0 значит «проиграть один раз за всю жизнь». */
    private record Part(String mesh, Blend blend, float loop, float scale) {
    }

    private record Look(Facing facing, Part[] parts, float lift, float tilt, float spin, float tumble, float rise, int riseTicks,
            boolean ring, boolean hideForOwner, int fade, boolean stretch, boolean tinted, boolean overHead, boolean beam, boolean pure, int burst) {
    }

    private static final class Builder {
        private final Part[] parts;
        private Facing facing = Facing.UPRIGHT;
        private float lift;
        private float tilt;
        private float spin;
        private float tumble;
        private float rise;
        private int riseTicks;
        private boolean ring;
        private boolean hide;
        private int fade = 5;
        private boolean stretch;
        private boolean tinted;
        private boolean overHead;
        private boolean pure;
        private boolean beam;
        private int burst;

        private Builder(Part... parts) {
            this.parts = parts;
        }

        Builder facing(Facing value) {
            facing = value;
            return this;
        }

        Builder lift(float value) {
            lift = value;
            return this;
        }

        Builder tilt(float value) {
            tilt = value;
            return this;
        }

        Builder spin(float value) {
            spin = value;
            return this;
        }

        Builder tumble(float value) {
            tumble = value;
            return this;
        }

        Builder rise(float height, int ticks) {
            rise = height;
            riseTicks = ticks;
            return this;
        }

        Builder ring() {
            ring = true;
            return this;
        }

        Builder hide() {
            hide = true;
            return this;
        }

        Builder fade(int ticks) {
            fade = ticks;
            return this;
        }

        Builder stretch() {
            stretch = true;
            return this;
        }

        Builder tinted() {
            tinted = true;
            return this;
        }

        /** Цвет из сущности без смягчения: метки и молнии должны быть чистыми. */
        Builder raw() {
            tinted = true;
            pure = true;
            return this;
        }

        /** Метка висит над головой цели, какой бы высокой та ни была. */
        Builder overHead() {
            overHead = true;
            return this;
        }

        /** Луч: размер задаёт только длину, толщина остаётся постоянной. */
        Builder beam() {
            beam = true;
            return this;
        }

        /** Поток вырывается и опадает: длина растёт за столько тиков в начале и спадает за столько же в конце. */
        Builder burst(int ticks) {
            burst = ticks;
            return this;
        }

        void as(SpellKind kind) {
            LOOKS.put(kind, new Look(facing, parts, lift, tilt, spin, tumble, rise, riseTicks, ring, hide, fade, stretch, tinted, overHead, beam, pure, burst));
        }
    }

    private static Builder look(Part... parts) {
        return new Builder(parts);
    }

    private static Part part(String mesh, Blend blend, float loop) {
        return new Part(mesh, blend, loop, 1.0F);
    }

    static {
        look(part("fireball_outer", Blend.FIRE, 15), part("fireball_mid", Blend.FIRE, 13), part("fireball_core", Blend.FIRE, 11)).facing(Facing.HEADING).fade(0).as(SpellKind.FIREBALL);
        look(part("fire_burst_outer", Blend.FIRE, 0), part("fire_burst_core", Blend.FIRE, 0), part("fire_shock", Blend.GLOW, 0)).fade(0).as(SpellKind.FIRE_BURST);
        look(part("flame_ring", Blend.GLOW, 14)).ring().fade(7).as(SpellKind.FLAME_RING);
        look(part("flame_ring", Blend.GLOW, 16)).ring().hide().fade(12).as(SpellKind.FLAME_AURA);
        look(part("flame_stream_smoke", Blend.SMOKE, 15), part("flame_stream_body", Blend.GLOW, 10), part("flame_stream_core", Blend.GLOW, 8),
                part("flame_stream_sparks", Blend.GLOW, 10)).facing(Facing.OWNER_LOOK).burst(7).fade(7).as(SpellKind.FLAME_JET);

        look(part("water_blob", Blend.WATER, 22)).facing(Facing.HEADING).stretch().fade(0).as(SpellKind.WATER_BLOB);
        look(part("water_splash", Blend.WATER, 0)).fade(0).as(SpellKind.WATER_SPLASH);
        look(part("water_stream", Blend.WATER, 12)).facing(Facing.WHIP).fade(3).as(SpellKind.WATER_WHIP);
        look(part("helix", Blend.GLOW, 22)).tinted().hide().fade(10).as(SpellKind.HEAL_SPIRAL);
        look(part("water_wave", Blend.WATER, 26)).facing(Facing.FLAT).fade(8).as(SpellKind.WATER_WAVE);
        look(part("ice_shard", Blend.WATER, 1)).facing(Facing.FLAT).rise(2.3F, 6).fade(0).as(SpellKind.ICE_SHARD);

        look(part("boulder", Blend.SOLID, 1)).facing(Facing.HEADING).tumble(9).tinted().fade(0).as(SpellKind.BOULDER);
        look(part("earth_chunk", Blend.SOLID, 1)).facing(Facing.HEADING).tumble(9).fade(0).as(SpellKind.EARTH_CHUNK);
        look(part("rock_burst", Blend.SOLID, 0)).tinted().fade(0).as(SpellKind.ROCK_BURST);
        look(part("dust_puff", Blend.FIRE, 0)).tinted().fade(0).as(SpellKind.DUST_PUFF);
        look(part("ground_ring", Blend.SOLID, 1)).ring().rise(0.75F, 5).tinted().fade(0).as(SpellKind.GROUND_RING);
        look(part("ground_slab", Blend.SOLID, 1)).facing(Facing.FLAT).rise(1.5F, 4).tinted().fade(0).as(SpellKind.GROUND_SLAB);
        look(part("stone_spike", Blend.SOLID, 1)).rise(2.9F, 4).tinted().fade(0).as(SpellKind.STONE_SPIKE);
        look(part("stone_plates", Blend.SOLID, 1)).spin(5).tinted().hide().fade(0).as(SpellKind.STONE_PLATES);
        look(part("stone_wall", Blend.SOLID, 1)).rise(5.4F, 10).tinted().fade(0).as(SpellKind.STONE_WALL);

        look(part("wind_saw", Blend.GLOW, 8)).facing(Facing.HEADING).tilt(-58).spin(-46).fade(0).as(SpellKind.WIND_SAW);
        look(part("wind_burst", Blend.GLOW, 0)).ring().fade(0).as(SpellKind.WIND_BURST);
        look(part("wind_tunnel", Blend.GLOW, 6)).facing(Facing.HEADING).lift(1.0F).fade(4).as(SpellKind.WIND_TUNNEL);
        look(part("tornado", Blend.GLOW, 20)).fade(10).as(SpellKind.TORNADO);
        look(part("wind_dome", Blend.GLOW, 22)).lift(1.0F).fade(10).as(SpellKind.WIND_DOME);

        look(part("element_mark", Blend.GLOW, 16)).spin(7).raw().overHead().fade(8).as(SpellKind.ELEMENT_MARK);
        look(part("fire_tornado", Blend.GLOW, 20)).fade(10).as(SpellKind.FIRE_TORNADO);
        look(part("rock_tornado", Blend.SMOKE, 20), part("rock_orbit", Blend.SOLID, 20)).fade(10).as(SpellKind.ROCK_TORNADO);
        look(part("steam_cloud", Blend.SMOKE, 40)).fade(26).as(SpellKind.STEAM_CLOUD);
        look(part("magma_boulder", Blend.SOLID, 1), part("magma_boulder_core", Blend.GLOW, 16)).facing(Facing.HEADING).tumble(9).fade(0).as(SpellKind.MAGMA_BOULDER);
        look(part("magma_pool_crust", Blend.SOLID, 1), part("magma_pool", Blend.GLOW, 30)).rise(0.45F, 12).fade(0).as(SpellKind.MAGMA_POOL);
        look(part("mud_pool", Blend.SOLID, 1), part("mud_bubbles", Blend.SOLID, 44)).rise(0.4F, 12).fade(0).as(SpellKind.MUD_POOL);

        look(part("ice_bolt", Blend.WATER, 1)).facing(Facing.HEADING).fade(0).as(SpellKind.ICE_BOLT);
        look(part("mist_ring", Blend.FIRE, 44)).fade(30).as(SpellKind.MIST);
        look(part("lightning", Blend.GLOW, 4)).facing(Facing.HEADING).raw().beam().fade(5).as(SpellKind.LIGHTNING);
        look(part("magma_geyser", Blend.GLOW, 0)).fade(0).as(SpellKind.MAGMA_GEYSER);
        look(part("sand_pit", Blend.SOLID, 26)).fade(0).rise(0.5F, 8).as(SpellKind.SAND_PIT);
        look(part("metal_blade", Blend.SOLID, 1)).facing(Facing.HEADING).spin(30).fade(0).as(SpellKind.METAL_BLADE);
        look(part("storm_cloud", Blend.CLOUD, 44)).fade(20).as(SpellKind.STORM_CLOUD);
        look(part("vacuum", Blend.GLOW, 0)).fade(0).as(SpellKind.VACUUM);
        look(part("danger_ring", Blend.GLOW, 12)).raw().fade(0).as(SpellKind.DANGER_RING);

        look(part("wind_orb", Blend.GLOW, 10)).fade(0).as(SpellKind.WIND_ORB);
        look(part("ball_lightning", Blend.GLOW, 8)).raw().spin(21).fade(8).as(SpellKind.ORB);
        look(part("meteor", Blend.GLOW, 16), part("meteor_tail", Blend.FIRE, 12)).facing(Facing.HEADING).fade(0).as(SpellKind.METEOR);
        look(part("water_geyser", Blend.WATER, 0)).fade(0).as(SpellKind.WATER_GEYSER);
        look(part("water_guardian", Blend.WATER, 44)).facing(Facing.FLAT).fade(16).as(SpellKind.WATER_GUARDIAN);
        look(part("rock_fist", Blend.SOLID, 0)).tinted().fade(0).as(SpellKind.ROCK_FIST);
        look(part("great_tornado", Blend.GLOW, 18), part("rock_orbit", Blend.SOLID, 24)).fade(14).as(SpellKind.GREAT_TORNADO);
        look(part("rain_column", Blend.WATER, 10)).fade(14).as(SpellKind.RAIN);

        look(part("shock_ring", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.SHOCK_RING);
        look(part("charge_swirl", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.CHARGE);
        look(part("impact_star", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.IMPACT);
        look(part("embers", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.EMBERS);
        look(part("soul_flame", Blend.GLOW, 14)).fade(6).as(SpellKind.SOUL_FLAME);
        look(part("sigil", Blend.GLOW, 12)).raw().spin(5).fade(10).as(SpellKind.SIGIL);
        look(part("light_pillar", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.LIGHT_PILLAR);

        look(part("sand_stream_smoke", Blend.SMOKE, 14), part("sand_stream_body", Blend.GLOW, 9), part("sand_stream_sparks", Blend.GLOW, 9))
                .facing(Facing.OWNER_LOOK).burst(5).fade(6).as(SpellKind.SAND_JET);
        look(part("wind_stream_body", Blend.GLOW, 8), part("wind_stream_sparks", Blend.GLOW, 8))
                .facing(Facing.OWNER_LOOK).burst(4).fade(5).as(SpellKind.WIND_JET);
        look(part("jet_splash", Blend.GLOW, 9)).fade(6).as(SpellKind.JET_SPLASH);
        look(part("scorch", Blend.GLOW, 22)).fade(26).as(SpellKind.SCORCH);
        look(part("forge_wave", Blend.GLOW, 20)).raw().fade(5).as(SpellKind.FORGE_WAVE);
        look(part("hot_billet", Blend.GLOW, 16)).facing(Facing.HEADING).tumble(8).fade(0).as(SpellKind.HOT_BILLET);
        look(part("heat_burst", Blend.GLOW, 0)).fade(4).as(SpellKind.HEAT_BURST);
        look(part("depth_vortex", Blend.WATER, 24)).fade(12).as(SpellKind.DEPTH_VORTEX);
        look(part("depth_spear", Blend.WATER, 16)).facing(Facing.HEADING).fade(0).as(SpellKind.DEPTH_SPEAR);
        look(part("depth_heal", Blend.WATER, 24)).fade(8).as(SpellKind.DEPTH_HEAL);
        look(part("falling_star", Blend.GLOW, 16)).facing(Facing.HEADING).fade(0).as(SpellKind.FALLING_STAR);
        look(part("star_field", Blend.GLOW, 24)).raw().fade(12).as(SpellKind.STAR_FIELD);
        look(part("cinder_arc", Blend.FIRE, 16)).facing(Facing.HEADING).fade(4).as(SpellKind.CINDER_ARC);
        look(part("tidal_dash", Blend.WATER, 16)).facing(Facing.HEADING).fade(3).as(SpellKind.TIDAL_DASH);
        look(part("gravity_knot", Blend.GLOW, 24)).raw().fade(8).as(SpellKind.GRAVITY_KNOT);
        look(part("soul_cleave", Blend.WATER, 0)).facing(Facing.HEADING).fade(5).as(SpellKind.SOUL_CLEAVE);

        look(part("sword_cleave_body", Blend.SOLID, 24), part("sword_cleave_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.SWORD_CLEAVE);
        look(part("sword_vortex_body", Blend.SOLID, 24), part("sword_vortex_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_VORTEX);
        look(part("sword_parry_body", Blend.SOLID, 24), part("sword_parry_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_PARRY);
        look(part("sword_lunge_body", Blend.SOLID, 24), part("sword_lunge_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.SWORD_LUNGE);
        look(part("sword_fallblade_body", Blend.SOLID, 24), part("sword_fallblade_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.SWORD_FALLBLADE);
        look(part("sword_notch_body", Blend.SOLID, 24), part("sword_notch_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_NOTCH);
        look(part("sword_ring_body", Blend.SOLID, 24), part("sword_ring_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_RING);
        look(part("sword_thousand_body", Blend.SOLID, 24), part("sword_thousand_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_THOUSAND);
        look(part("sword_riposte_body", Blend.SOLID, 24), part("sword_riposte_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_RIPOSTE);
        look(part("sword_flow_body", Blend.SOLID, 24), part("sword_flow_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_FLOW);
        look(part("sword_rage_body", Blend.SOLID, 24), part("sword_rage_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.SWORD_RAGE);
        look(part("sword_execution_body", Blend.SOLID, 24), part("sword_execution_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.SWORD_EXECUTION);
        look(part("bow_aimed_body", Blend.SOLID, 24), part("bow_aimed_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.BOW_AIMED);
        look(part("bow_fan_body", Blend.SOLID, 24), part("bow_fan_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.BOW_FAN);
        look(part("bow_retreat_body", Blend.SOLID, 24), part("bow_retreat_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.BOW_RETREAT);
        look(part("bow_rain_body", Blend.SOLID, 24), part("bow_rain_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.BOW_RAIN);
        look(part("bow_harpoon_body", Blend.SOLID, 24), part("bow_harpoon_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.BOW_HARPOON);
        look(part("bow_trap_body", Blend.SOLID, 24), part("bow_trap_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.BOW_TRAP);
        look(part("bow_explosive_body", Blend.SOLID, 24), part("bow_explosive_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.BOW_EXPLOSIVE);
        look(part("bow_celestial_body", Blend.SOLID, 24), part("bow_celestial_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.BOW_CELESTIAL);
        look(part("bow_piercing_body", Blend.SOLID, 24), part("bow_piercing_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.BOW_PIERCING);
        look(part("bow_focus_body", Blend.SOLID, 24), part("bow_focus_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.BOW_FOCUS);
        look(part("bow_seekers_body", Blend.SOLID, 24), part("bow_seekers_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.BOW_SEEKERS);
        look(part("bow_thicket_body", Blend.SOLID, 24), part("bow_thicket_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.BOW_THICKET);
        look(part("dark_sphere_body", Blend.SOLID, 24), part("dark_sphere_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.DARK_SPHERE);
        look(part("dark_drain_body", Blend.SOLID, 24), part("dark_drain_glow", Blend.GLOW, 24)).facing(Facing.HEADING).beam().fade(0).as(SpellKind.DARK_DRAIN);
        look(part("dark_curse_body", Blend.SOLID, 24), part("dark_curse_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_CURSE);
        look(part("dark_hands_body", Blend.SOLID, 24), part("dark_hands_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_HANDS);
        look(part("dark_hole_body", Blend.SOLID, 24), part("dark_hole_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_HOLE);
        look(part("dark_nightmare_body", Blend.SOLID, 24), part("dark_nightmare_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_NIGHTMARE);
        look(part("dark_ghosts_body", Blend.SOLID, 24), part("dark_ghosts_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.DARK_GHOSTS);
        look(part("dark_eclipse_body", Blend.SOLID, 24), part("dark_eclipse_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_ECLIPSE);
        look(part("dark_wraith_body", Blend.SOLID, 24), part("dark_wraith_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_WRAITH);
        look(part("horror_colossus_body", Blend.SOLID, 90), part("horror_colossus_eyes", Blend.GLOW, 90)).facing(Facing.FLAT).fade(0).as(SpellKind.HORROR_COLOSSUS);
        look(part("horror_wraith_body", Blend.SOLID, 64), part("horror_wraith_eyes", Blend.GLOW, 64)).facing(Facing.FLAT).fade(0).as(SpellKind.HORROR_WRAITH);
        look(part("horror_eyes", Blend.GLOW, 120)).facing(Facing.FLAT).fade(0).as(SpellKind.HORROR_EYES);
        look(part("horror_cocoon", Blend.SOLID, 150)).fade(0).as(SpellKind.HORROR_COCOON);
        look(part("dark_soulguard_body", Blend.SOLID, 24), part("dark_soulguard_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_SOULGUARD);
        look(part("dark_plague_body", Blend.SOLID, 24), part("dark_plague_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_PLAGUE);
        look(part("dark_pact_body", Blend.SOLID, 24), part("dark_pact_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.DARK_PACT);
        look(part("light_ray_body", Blend.SOLID, 24), part("light_ray_glow", Blend.GLOW, 24)).facing(Facing.HEADING).beam().fade(0).as(SpellKind.LIGHT_RAY);
        look(part("light_heal_body", Blend.SOLID, 24), part("light_heal_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_HEAL);
        look(part("light_faith_body", Blend.SOLID, 24), part("light_faith_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_FAITH);
        look(part("light_cleanse_body", Blend.SOLID, 24), part("light_cleanse_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_CLEANSE);
        look(part("light_column_body", Blend.SOLID, 24), part("light_column_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_COLUMN);
        look(part("light_wings_body", Blend.SOLID, 24), part("light_wings_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_WINGS);
        look(part("light_spark_body", Blend.SOLID, 24), part("light_spark_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_SPARK);
        look(part("light_judgment_body", Blend.SOLID, 24), part("light_judgment_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_JUDGMENT);
        look(part("light_hammer_body", Blend.SOLID, 24), part("light_hammer_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.LIGHT_HAMMER);
        look(part("light_armor_body", Blend.SOLID, 24), part("light_armor_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_ARMOR);
        look(part("light_sanctuary_body", Blend.SOLID, 24), part("light_sanctuary_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_SANCTUARY);
        look(part("light_blessing_body", Blend.SOLID, 24), part("light_blessing_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.LIGHT_BLESSING);

        look(part("great_wave_body", Blend.WATER, 24), part("great_wave_glow", Blend.GLOW, 24)).facing(Facing.FLAT).fade(0).as(SpellKind.GREAT_WAVE);
        look(part("slash_arc_body", Blend.GLOW, 0), part("slash_arc_glow", Blend.GLOW, 0)).facing(Facing.HEADING).fade(0).as(SpellKind.SLASH_ARC);
        look(part("slash_big_body", Blend.GLOW, 0), part("slash_big_glow", Blend.GLOW, 0)).facing(Facing.HEADING).fade(0).as(SpellKind.SLASH_BIG);
        look(part("arrow_power_body", Blend.SOLID, 24), part("arrow_power_glow", Blend.GLOW, 24)).facing(Facing.HEADING).fade(0).as(SpellKind.ARROW_POWER);
    }

    SpellRenderer(EntityRendererFactory.Context context) {
        super(context);
        shadowRadius = 0;
    }

    /**
     * Заклинание за спиной или далеко за краем экрана не рисуется. Лучи, плети и струи тянутся от владельца
     * на неизвестную длину, поэтому их видно всегда, а остальным берётся объём модели с небольшим запасом.
     */
    @Override
    public boolean shouldRender(SpellEntity spell, Frustum frustum, double x, double y, double z) {
        Look look = LOOKS.get(spell.kind());
        if (look == null) {
            return false;
        }
        if (look.beam() || look.facing() == Facing.WHIP || look.facing() == Facing.OWNER_LOOK) {
            return true;
        }
        float reach = 0;
        for (Part part : look.parts()) {
            SpellMesh mesh = SpellMesh.get(part.mesh());
            if (mesh != null) {
                reach = Math.max(reach, mesh.extent() * part.scale());
            }
        }
        double r = reach * Math.max(spell.size(), 0.1F) * 1.3 + 2 + look.lift() + look.rise() + (look.stretch() ? 8 : 0);
        Box box = new Box(spell.getX() - r, spell.getY() - r, spell.getZ() - r, spell.getX() + r, spell.getY() + r, spell.getZ() + r);
        Entity owner = spell.ownerEntity();
        if (owner != null) {
            box = box.union(owner.getBoundingBox().expand(r));
        }
        return frustum.isVisible(box);
    }

    @Override
    public Identifier getTexture(SpellEntity entity) {
        return WHITE;
    }

    @Override
    public void render(SpellEntity spell, float yaw, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        if (ShaderCompat.shadowPass()) {
            return;
        }
        Look look = LOOKS.get(spell.kind());
        MinecraftClient client = MinecraftClient.getInstance();
        Entity owner = spell.ownerEntity();
        boolean firstPerson = owner == client.player && !client.gameRenderer.getCamera().isThirdPerson();
        if (look == null || look.hideForOwner() && firstPerson) {
            return;
        }
        float age = spell.age + delta;
        float life = Math.max(1, spell.life());
        float size = spell.shownSize(delta);
        if (look.beam() || look.parts()[0].blend() == Blend.SOLID || look.parts()[0].loop() == 0) {
            size = spell.size();
        }
        float fade = look.fade() > 0 ? MathHelper.clamp((life - age) / look.fade(), 0, 1) : 1;
        int color = look.pure() ? spell.tintColor() : look.tinted() ? softened(spell.tintColor()) : 0xFFFFFF;

        matrices.push();
        Vec3d self = spell.getLerpedPos(delta);
        if (owner != null) {
            Vec3d at = owner.getLerpedPos(delta);
            double up = look.facing() == Facing.OWNER_LOOK ? owner.getStandingEyeHeight() : 0;
            matrices.translate(at.x - self.x, at.y + up - self.y, at.z - self.z);
        }
        matrices.translate(0, look.lift() + riseOffset(look, age, life), 0);
        if (look.overHead() && owner != null) {
            matrices.translate(0, owner.getHeight() + 0.5F, 0);
        }
        orient(spell, look, matrices, owner, firstPerson, delta);
        if (spell.kind() == SpellKind.SLASH_ARC || spell.kind() == SpellKind.SLASH_BIG)
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(spell.tintColor() == 0 ? -35 : spell.tintColor() == 1 ? 35 : 90));
        if (look.tilt() != 0) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(look.tilt()));
        }
        if (look.spin() != 0) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(age * look.spin()));
        }
        if (look.tumble() != 0) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(age * look.tumble()));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(age * look.tumble() * 0.6F));
        }
        float stretchZ = 1;
        if (look.facing() == Facing.WHIP) {
            stretchZ = whipLength(spell, owner, age, delta);
        } else if (look.stretch()) {
            stretchZ = 1 + (float) Math.min(1.6, spell.getVelocity().length() * 1.1);
        }
        float thin = look.stretch() ? 1 / (float) Math.sqrt(stretchZ) : 1;
        if (look.burst() > 0) {
            float out = MathHelper.clamp(age / look.burst(), 0, 1);
            float back = MathHelper.clamp((life - age) / look.burst(), 0, 1);
            stretchZ = Math.max(0.02F, (1 - (1 - out) * (1 - out)) * back);
        }

        for (Part part : look.parts()) {
            SpellMesh mesh = SpellMesh.get(part.mesh());
            if (mesh == null) {
                continue;
            }
            matrices.push();
            float s = size * part.scale();
            float tall = look.ring() ? Math.min(1.5F, (float) Math.sqrt(Math.max(size, 0.01F))) * part.scale() : s;
            if (look.facing() == Facing.WHIP) {
                matrices.translate(0, 0, 1.3F);
                matrices.scale(0.8F, 0.8F, Math.max(0.1F, stretchZ - 1.3F));
            } else if (look.beam()) {
                float width = spell.kind() != SpellKind.DARK_DRAIN ? 1 : spell.tintColor() >= 2 && spell.tintColor() <= 5 ? 0.75F : 0.48F;
                matrices.scale(width, width, s);
            } else {
                matrices.scale(s * thin, tall * thin, s * stretchZ);
            }
            boolean loop = part.loop() > 0;
            float phase = loop ? age / part.loop() * mesh.frames() : age / life * (mesh.frames() - 1);
            float strength = part.blend() == Blend.SOLID ? 1 : part.blend() == Blend.ADD ? fade * 0.3F : fade;
            int shown = part.blend() == Blend.SOLID || part.blend() == Blend.SMOKE || part.blend() == Blend.CLOUD ? groundLight(spell) : LightmapTextureManager.MAX_LIGHT_COORDINATE;
            mesh.draw(matrices.peek(), consumers.getBuffer(part.blend().layer()), phase, loop, color, strength, shown,
                    part.blend().surface());
            matrices.pop();
        }
        matrices.pop();

        if (spell.kind() == SpellKind.WATER_BLOB) {
            drawStream(spell, self, age, size, matrices, consumers);
        }
    }

    /** Хвост потока: уменьшающиеся копии капли по пройденному пути сливаются в струю. */
    private static void drawStream(SpellEntity spell, Vec3d self, float age, float size, MatrixStack matrices, VertexConsumerProvider consumers) {
        SpellMesh mesh = SpellMesh.get("water_blob");
        if (mesh == null) {
            return;
        }
        int index = 0;
        Vec3d previous = self;
        for (Vec3d past : spell.trail()) {
            index++;
            Vec3d step = past.subtract(previous);
            double length = step.length();
            if (length > 0.02) {
                float s = size * 0.5F * (1 - index / 10.0F);
                Vec3d middle = previous.add(step.multiply(0.5));
                Vec3d to = step.multiply(1 / length);
                matrices.push();
                matrices.translate(middle.x - self.x, middle.y - self.y, middle.z - self.z);
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
                // Капля вытягивается на весь шаг и заходит на соседние, поэтому копии сливаются в струю.
                matrices.scale(s, s, Math.max(s, (float) length * 0.95F));
                mesh.draw(matrices.peek(), consumers.getBuffer(Blend.WATER.layer()), (age + index * 2) / 22 * mesh.frames(), true,
                        0xFFFFFF, 0.9F, LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.WET);
                matrices.pop();
            }
            previous = past;
        }
    }

    private static void orient(SpellEntity spell, Look look, MatrixStack matrices, Entity owner, boolean firstPerson, float delta) {
        switch (look.facing()) {
            case HEADING -> {
                Vec3d to = spell.heading(delta);
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
            }
            case FLAT -> matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-spell.getYaw()));
            case OWNER_LOOK -> {
                Vec3d to = owner != null ? owner.getRotationVec(delta) : spell.getRotationVector();
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
                // Струя выходит из рук: в лицо игроку она бы закрыла весь обзор.
                matrices.translate(firstPerson ? 0.32F : 0.2F, firstPerson ? -0.46F : -0.3F, firstPerson ? 1.0F : 0.5F);
            }
            case WHIP -> {
                Vec3d from = whipStart(owner, spell, delta);
                Entity target = spell.targetEntity();
                Vec3d to = target != null ? target.getLerpedPos(delta).add(0, target.getHeight() / 2, 0).subtract(from).normalize() : spell.getRotationVector();
                matrices.translate(0, 1.2, 0);
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
            }
            default -> {
            }
        }
    }

    private static Vec3d whipStart(Entity owner, SpellEntity spell, float delta) {
        return (owner != null ? owner.getLerpedPos(delta) : spell.getLerpedPos(delta)).add(0, 1.2, 0);
    }

    /** Плеть вылетает к цели за три тика и так же быстро возвращается. */
    private static float whipLength(SpellEntity spell, Entity owner, float age, float delta) {
        Entity target = spell.targetEntity();
        Vec3d from = whipStart(owner, spell, delta);
        float reach = target != null ? (float) target.getLerpedPos(delta).add(0, target.getHeight() / 2, 0).distanceTo(from) : spell.size();
        float out = MathHelper.clamp(age / 3, 0, 1);
        float back = MathHelper.clamp((spell.life() - age) / 4, 0, 1);
        return Math.max(0.1F, reach * out * back);
    }

    /** Модель выходит из земли в начале жизни и уходит обратно в конце. */
    private static float riseOffset(Look look, float age, float life) {
        if (look.rise() == 0) {
            return 0;
        }
        float up = MathHelper.clamp(age / look.riseTicks(), 0, 1);
        float down = MathHelper.clamp((life - age) / look.riseTicks(), 0, 1);
        float shown = Math.min(1 - (1 - up) * (1 - up), down);
        return -look.rise() * (1 - shown);
    }

    /** Свет берётся над землёй и над блоками стены: внутри них модель была бы чёрной. */
    private static int groundLight(SpellEntity spell) {
        int above = spell.kind() == SpellKind.STONE_WALL ? 6 : 2;
        return WorldRenderer.getLightmapCoordinates(spell.getWorld(), BlockPos.ofFloored(spell.getPos()).up(above));
    }

    /** Цвета карты кричащие: подмешивает к цвету грунта спокойный серо-коричневый камень. */
    private static int softened(int color) {
        int red = (color >> 16 & 255) * 2 / 5 + 96;
        int green = (color >> 8 & 255) * 2 / 5 + 88;
        int blue = (color & 255) * 2 / 5 + 76;
        return red << 16 | green << 8 | blue;
    }
}
