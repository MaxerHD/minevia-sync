package local.minevia.elements.client;

import java.util.EnumMap;
import java.util.Map;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.SpellEntity;
import local.minevia.elements.SpellKind;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Quaternionf;

/** Рисует способности настоящими 3D-моделями. Частицы игры здесь не участвуют. */
final class SpellRenderer extends EntityRenderer<SpellEntity> {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private static final Map<SpellKind, Look> LOOKS = new EnumMap<>(SpellKind.class);

    private enum Blend {
        GLOW, FIRE, ADD, WATER, SOLID, SMOKE, CLOUD;

        RenderLayer layer() {
            return switch (this) {
                case ADD -> RenderLayer.getEyes(WHITE);
                case SOLID, CLOUD -> RenderLayer.getEntitySolid(WHITE);
                case SMOKE -> ShaderCompat.needsDepth() ? ShaderCompat.glow() : RenderLayer.getEntityTranslucent(WHITE);
                default -> ShaderCompat.glow();
            };
        }

        SpellMesh.Surface surface() {
            return switch (this) {
                case WATER -> SpellMesh.Surface.WET;
                case FIRE -> SpellMesh.Surface.GAS;
                case SMOKE, CLOUD -> SpellMesh.Surface.FOG;
                default -> SpellMesh.Surface.PLAIN;
            };
        }
    }

    private enum Facing {
        UPRIGHT, HEADING, FLAT, OWNER_LOOK, WHIP
    }

    /** Один слой модели. loop: тиков на круг анимации, 0 значит «проиграть один раз за всю жизнь». */
    private record Part(String mesh, Blend blend, float loop, float scale) {
    }

    private record Look(Facing facing, Part[] parts, float lift, float tilt, float spin, float tumble, float rise, int riseTicks,
            boolean ring, boolean hideForOwner, int fade, boolean stretch, boolean tinted, boolean overHead, boolean beam, boolean pure) {
    }

    private static final class Builder {
        private final Part[] parts;
        private Facing facing = Facing.UPRIGHT;
        private float lift;
        private float tilt;
        private float spin;
        private float tumble;
        private float rise;
        private int riseTicks;
        private boolean ring;
        private boolean hide;
        private int fade = 5;
        private boolean stretch;
        private boolean tinted;
        private boolean overHead;
        private boolean pure;
        private boolean beam;

        private Builder(Part... parts) {
            this.parts = parts;
        }

        Builder facing(Facing value) {
            facing = value;
            return this;
        }

        Builder lift(float value) {
            lift = value;
            return this;
        }

        Builder tilt(float value) {
            tilt = value;
            return this;
        }

        Builder spin(float value) {
            spin = value;
            return this;
        }

        Builder tumble(float value) {
            tumble = value;
            return this;
        }

        Builder rise(float height, int ticks) {
            rise = height;
            riseTicks = ticks;
            return this;
        }

        Builder ring() {
            ring = true;
            return this;
        }

        Builder hide() {
            hide = true;
            return this;
        }

        Builder fade(int ticks) {
            fade = ticks;
            return this;
        }

        Builder stretch() {
            stretch = true;
            return this;
        }

        Builder tinted() {
            tinted = true;
            return this;
        }

        /** Цвет из сущности без смягчения: метки и молнии должны быть чистыми. */
        Builder raw() {
            tinted = true;
            pure = true;
            return this;
        }

        /** Метка висит над головой цели, какой бы высокой та ни была. */
        Builder overHead() {
            overHead = true;
            return this;
        }

        /** Луч: размер задаёт только длину, толщина остаётся постоянной. */
        Builder beam() {
            beam = true;
            return this;
        }

        void as(SpellKind kind) {
            LOOKS.put(kind, new Look(facing, parts, lift, tilt, spin, tumble, rise, riseTicks, ring, hide, fade, stretch, tinted, overHead, beam, pure));
        }
    }

    private static Builder look(Part... parts) {
        return new Builder(parts);
    }

    private static Part part(String mesh, Blend blend, float loop) {
        return new Part(mesh, blend, loop, 1.0F);
    }

    static {
        look(part("fireball_outer", Blend.FIRE, 15), part("fireball_mid", Blend.FIRE, 13), part("fireball_core", Blend.FIRE, 11)).facing(Facing.HEADING).fade(0).as(SpellKind.FIREBALL);
        look(part("fire_burst_outer", Blend.FIRE, 0), part("fire_burst_core", Blend.FIRE, 0), part("fire_shock", Blend.GLOW, 0)).fade(0).as(SpellKind.FIRE_BURST);
        look(part("flame_ring", Blend.GLOW, 14)).ring().fade(7).as(SpellKind.FLAME_RING);
        look(part("flame_ring", Blend.GLOW, 16)).ring().hide().fade(12).as(SpellKind.FLAME_AURA);
        look(part("flame_jet_outer", Blend.GLOW, 11), part("flame_jet_core", Blend.GLOW, 9))
                .facing(Facing.OWNER_LOOK).fade(6).as(SpellKind.FLAME_JET);

        look(part("water_blob", Blend.WATER, 22)).facing(Facing.HEADING).stretch().fade(0).as(SpellKind.WATER_BLOB);
        look(part("water_splash", Blend.WATER, 0)).fade(0).as(SpellKind.WATER_SPLASH);
        look(part("water_stream", Blend.WATER, 12)).facing(Facing.WHIP).fade(3).as(SpellKind.WATER_WHIP);
        look(part("helix", Blend.GLOW, 22)).tinted().hide().fade(10).as(SpellKind.HEAL_SPIRAL);
        look(part("water_wave", Blend.WATER, 26)).facing(Facing.FLAT).fade(8).as(SpellKind.WATER_WAVE);
        look(part("ice_shard", Blend.WATER, 1)).facing(Facing.FLAT).rise(2.3F, 6).fade(0).as(SpellKind.ICE_SHARD);

        look(part("boulder", Blend.SOLID, 1)).facing(Facing.HEADING).tumble(9).tinted().fade(0).as(SpellKind.BOULDER);
        look(part("earth_chunk", Blend.SOLID, 1)).facing(Facing.HEADING).tumble(9).fade(0).as(SpellKind.EARTH_CHUNK);
        look(part("rock_burst", Blend.SOLID, 0)).tinted().fade(0).as(SpellKind.ROCK_BURST);
        look(part("dust_puff", Blend.FIRE, 0)).tinted().fade(0).as(SpellKind.DUST_PUFF);
        look(part("ground_ring", Blend.SOLID, 1)).ring().rise(0.75F, 5).tinted().fade(0).as(SpellKind.GROUND_RING);
        look(part("ground_slab", Blend.SOLID, 1)).facing(Facing.FLAT).rise(1.5F, 4).tinted().fade(0).as(SpellKind.GROUND_SLAB);
        look(part("stone_spike", Blend.SOLID, 1)).rise(2.9F, 4).tinted().fade(0).as(SpellKind.STONE_SPIKE);
        look(part("stone_plates", Blend.SOLID, 1)).spin(5).tinted().hide().fade(0).as(SpellKind.STONE_PLATES);
        look(part("stone_wall", Blend.SOLID, 1)).rise(5.4F, 10).tinted().fade(0).as(SpellKind.STONE_WALL);

        look(part("wind_saw", Blend.GLOW, 8)).facing(Facing.HEADING).tilt(-58).spin(-46).fade(0).as(SpellKind.WIND_SAW);
        look(part("wind_burst", Blend.GLOW, 0)).ring().fade(0).as(SpellKind.WIND_BURST);
        look(part("wind_tunnel", Blend.GLOW, 6)).facing(Facing.HEADING).lift(1.0F).fade(4).as(SpellKind.WIND_TUNNEL);
        look(part("tornado", Blend.GLOW, 20)).fade(10).as(SpellKind.TORNADO);
        look(part("wind_dome", Blend.GLOW, 22)).lift(1.0F).fade(10).as(SpellKind.WIND_DOME);

        look(part("element_mark", Blend.GLOW, 16)).spin(7).raw().overHead().fade(8).as(SpellKind.ELEMENT_MARK);
        look(part("fire_tornado", Blend.GLOW, 20)).fade(10).as(SpellKind.FIRE_TORNADO);
        look(part("rock_tornado", Blend.SMOKE, 20), part("rock_orbit", Blend.SOLID, 20)).fade(10).as(SpellKind.ROCK_TORNADO);
        look(part("steam_cloud", Blend.FIRE, 40)).fade(26).as(SpellKind.STEAM_CLOUD);
        look(part("magma_boulder", Blend.GLOW, 16)).facing(Facing.HEADING).tumble(9).fade(0).as(SpellKind.MAGMA_BOULDER);
        look(part("magma_pool", Blend.GLOW, 30)).fade(24).as(SpellKind.MAGMA_POOL);
        look(part("mud_pool", Blend.WATER, 34)).fade(24).as(SpellKind.MUD_POOL);

        look(part("ice_bolt", Blend.WATER, 1)).facing(Facing.HEADING).fade(0).as(SpellKind.ICE_BOLT);
        look(part("mist_ring", Blend.FIRE, 44)).fade(30).as(SpellKind.MIST);
        look(part("lightning", Blend.GLOW, 4)).facing(Facing.HEADING).raw().beam().fade(5).as(SpellKind.LIGHTNING);
        look(part("magma_geyser", Blend.GLOW, 0)).fade(0).as(SpellKind.MAGMA_GEYSER);
        look(part("sand_pit", Blend.SOLID, 26)).fade(0).rise(0.5F, 8).as(SpellKind.SAND_PIT);
        look(part("metal_blade", Blend.SOLID, 1)).facing(Facing.HEADING).spin(30).fade(0).as(SpellKind.METAL_BLADE);
        look(part("storm_cloud", Blend.CLOUD, 44)).fade(20).as(SpellKind.STORM_CLOUD);
        look(part("vacuum", Blend.GLOW, 0)).fade(0).as(SpellKind.VACUUM);
        look(part("danger_ring", Blend.GLOW, 12)).raw().fade(0).as(SpellKind.DANGER_RING);

        look(part("wind_orb", Blend.GLOW, 10)).fade(0).as(SpellKind.WIND_ORB);
        look(part("ball_lightning", Blend.GLOW, 8)).raw().spin(21).fade(8).as(SpellKind.ORB);
        look(part("meteor", Blend.GLOW, 16), part("meteor_tail", Blend.FIRE, 12)).facing(Facing.HEADING).fade(0).as(SpellKind.METEOR);
        look(part("water_geyser", Blend.WATER, 0)).fade(0).as(SpellKind.WATER_GEYSER);
        look(part("water_guardian", Blend.WATER, 44)).facing(Facing.FLAT).fade(16).as(SpellKind.WATER_GUARDIAN);
        look(part("rock_fist", Blend.SOLID, 0)).tinted().fade(0).as(SpellKind.ROCK_FIST);
        look(part("great_tornado", Blend.GLOW, 18), part("rock_orbit", Blend.SOLID, 24)).fade(14).as(SpellKind.GREAT_TORNADO);
        look(part("rain_column", Blend.WATER, 10)).fade(14).as(SpellKind.RAIN);

        look(part("shock_ring", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.SHOCK_RING);
        look(part("charge_swirl", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.CHARGE);
        look(part("impact_star", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.IMPACT);
        look(part("embers", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.EMBERS);
        look(part("soul_flame", Blend.GLOW, 14)).fade(6).as(SpellKind.SOUL_FLAME);
        look(part("sigil", Blend.GLOW, 12)).raw().spin(5).fade(10).as(SpellKind.SIGIL);
        look(part("light_pillar", Blend.GLOW, 0)).raw().fade(0).as(SpellKind.LIGHT_PILLAR);
    }

    SpellRenderer(EntityRendererFactory.Context context) {
        super(context);
        shadowRadius = 0;
    }

    @Override
    public boolean shouldRender(SpellEntity entity, Frustum frustum, double x, double y, double z) {
        return true;
    }

    @Override
    public Identifier getTexture(SpellEntity entity) {
        return WHITE;
    }

    @Override
    public void render(SpellEntity spell, float yaw, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        Look look = LOOKS.get(spell.kind());
        MinecraftClient client = MinecraftClient.getInstance();
        Entity owner = spell.ownerEntity();
        boolean firstPerson = owner == client.player && !client.gameRenderer.getCamera().isThirdPerson();
        if (look == null || look.hideForOwner() && firstPerson) {
            return;
        }
        float age = spell.age + delta;
        float life = Math.max(1, spell.life());
        float size = spell.shownSize(delta);
        if (look.beam() || look.parts()[0].blend() == Blend.SOLID || look.parts()[0].loop() == 0) {
            size = spell.size();
        }
        float fade = look.fade() > 0 ? MathHelper.clamp((life - age) / look.fade(), 0, 1) : 1;
        int color = look.pure() ? spell.tintColor() : look.tinted() ? softened(spell.tintColor()) : 0xFFFFFF;

        matrices.push();
        Vec3d self = spell.getLerpedPos(delta);
        if (owner != null) {
            Vec3d at = owner.getLerpedPos(delta);
            double up = look.facing() == Facing.OWNER_LOOK ? owner.getStandingEyeHeight() : 0;
            matrices.translate(at.x - self.x, at.y + up - self.y, at.z - self.z);
        }
        matrices.translate(0, look.lift() + riseOffset(look, age, life), 0);
        if (look.overHead() && owner != null) {
            matrices.translate(0, owner.getHeight() + 0.5F, 0);
        }
        orient(spell, look, matrices, owner, firstPerson, delta);
        if (look.tilt() != 0) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(look.tilt()));
        }
        if (look.spin() != 0) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(age * look.spin()));
        }
        if (look.tumble() != 0) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(age * look.tumble()));
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(age * look.tumble() * 0.6F));
        }
        float stretchZ = 1;
        if (look.facing() == Facing.WHIP) {
            stretchZ = whipLength(spell, owner, age, delta);
        } else if (look.stretch()) {
            stretchZ = 1 + (float) Math.min(1.6, spell.getVelocity().length() * 1.1);
        }
        float thin = look.stretch() ? 1 / (float) Math.sqrt(stretchZ) : 1;

        for (Part part : look.parts()) {
            SpellMesh mesh = SpellMesh.get(part.mesh());
            if (mesh == null) {
                continue;
            }
            matrices.push();
            float s = size * part.scale();
            float tall = look.ring() ? Math.min(1.5F, (float) Math.sqrt(Math.max(size, 0.01F))) * part.scale() : s;
            if (look.facing() == Facing.WHIP) {
                matrices.translate(0, 0, 1.3F);
                matrices.scale(0.8F, 0.8F, Math.max(0.1F, stretchZ - 1.3F));
            } else if (look.beam()) {
                matrices.scale(1, 1, s);
            } else {
                matrices.scale(s * thin, tall * thin, s * stretchZ);
            }
            boolean loop = part.loop() > 0;
            float phase = loop ? age / part.loop() * mesh.frames() : age / life * (mesh.frames() - 1);
            float strength = part.blend() == Blend.ADD ? fade * 0.3F : fade;
            int shown = part.blend() == Blend.SOLID || part.blend() == Blend.SMOKE || part.blend() == Blend.CLOUD ? groundLight(spell) : LightmapTextureManager.MAX_LIGHT_COORDINATE;
            mesh.draw(matrices.peek(), consumers.getBuffer(part.blend().layer()), phase, loop, color, strength, shown,
                    part.blend().surface());
            matrices.pop();
        }
        matrices.pop();

        if (spell.kind() == SpellKind.WATER_BLOB) {
            drawStream(spell, self, age, size, matrices, consumers);
        }
    }

    /** Хвост потока: уменьшающиеся копии капли по пройденному пути сливаются в струю. */
    private static void drawStream(SpellEntity spell, Vec3d self, float age, float size, MatrixStack matrices, VertexConsumerProvider consumers) {
        SpellMesh mesh = SpellMesh.get("water_blob");
        if (mesh == null) {
            return;
        }
        int index = 0;
        Vec3d previous = self;
        for (Vec3d past : spell.trail()) {
            index++;
            Vec3d step = past.subtract(previous);
            double length = step.length();
            if (length > 0.02) {
                float s = size * 0.5F * (1 - index / 10.0F);
                Vec3d middle = previous.add(step.multiply(0.5));
                Vec3d to = step.multiply(1 / length);
                matrices.push();
                matrices.translate(middle.x - self.x, middle.y - self.y, middle.z - self.z);
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
                // Капля вытягивается на весь шаг и заходит на соседние, поэтому копии сливаются в струю.
                matrices.scale(s, s, Math.max(s, (float) length * 0.95F));
                mesh.draw(matrices.peek(), consumers.getBuffer(Blend.WATER.layer()), (age + index * 2) / 22 * mesh.frames(), true,
                        0xFFFFFF, 0.9F, LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.WET);
                matrices.pop();
            }
            previous = past;
        }
    }

    private static void orient(SpellEntity spell, Look look, MatrixStack matrices, Entity owner, boolean firstPerson, float delta) {
        switch (look.facing()) {
            case HEADING -> {
                Vec3d to = spell.heading(delta);
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
            }
            case FLAT -> matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-spell.getYaw()));
            case OWNER_LOOK -> {
                Vec3d to = owner != null ? owner.getRotationVec(delta) : spell.getRotationVector();
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
                // Струя выходит из рук: в лицо игроку она бы закрыла весь обзор.
                matrices.translate(firstPerson ? 0.32F : 0.2F, firstPerson ? -0.46F : -0.3F, firstPerson ? 1.0F : 0.5F);
            }
            case WHIP -> {
                Vec3d from = whipStart(owner, spell, delta);
                Entity target = spell.targetEntity();
                Vec3d to = target != null ? target.getLerpedPos(delta).add(0, target.getHeight() / 2, 0).subtract(from).normalize() : spell.getRotationVector();
                matrices.translate(0, 1.2, 0);
                matrices.multiply(new Quaternionf().rotationTo(0, 0, 1, (float) to.x, (float) to.y, (float) to.z));
            }
            default -> {
            }
        }
    }

    private static Vec3d whipStart(Entity owner, SpellEntity spell, float delta) {
        return (owner != null ? owner.getLerpedPos(delta) : spell.getLerpedPos(delta)).add(0, 1.2, 0);
    }

    /** Плеть вылетает к цели за три тика и так же быстро возвращается. */
    private static float whipLength(SpellEntity spell, Entity owner, float age, float delta) {
        Entity target = spell.targetEntity();
        Vec3d from = whipStart(owner, spell, delta);
        float reach = target != null ? (float) target.getLerpedPos(delta).add(0, target.getHeight() / 2, 0).distanceTo(from) : spell.size();
        float out = MathHelper.clamp(age / 3, 0, 1);
        float back = MathHelper.clamp((spell.life() - age) / 4, 0, 1);
        return Math.max(0.1F, reach * out * back);
    }

    /** Модель выходит из земли в начале жизни и уходит обратно в конце. */
    private static float riseOffset(Look look, float age, float life) {
        if (look.rise() == 0) {
            return 0;
        }
        float up = MathHelper.clamp(age / look.riseTicks(), 0, 1);
        float down = MathHelper.clamp((life - age) / look.riseTicks(), 0, 1);
        float shown = Math.min(1 - (1 - up) * (1 - up), down);
        return -look.rise() * (1 - shown);
    }

    /** Свет берётся над землёй и над блоками стены: внутри них модель была бы чёрной. */
    private static int groundLight(SpellEntity spell) {
        int above = spell.kind() == SpellKind.STONE_WALL ? 6 : 2;
        return WorldRenderer.getLightmapCoordinates(spell.getWorld(), BlockPos.ofFloored(spell.getPos()).up(above));
    }

    /** Цвета карты кричащие: подмешивает к цвету грунта спокойный серо-коричневый камень. */
    private static int softened(int color) {
        int red = (color >> 16 & 255) * 2 / 5 + 96;
        int green = (color >> 8 & 255) * 2 / 5 + 88;
        int blue = (color & 255) * 2 / 5 + 76;
        return red << 16 | green << 8 | blue;
    }
}
