package local.minevia.elements;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Тени, проклятия и призывы без крови. */
final class StyleDark {
    private StyleDark() { }

    static void cast(ServerPlayerEntity p, int slot, int path, int level) {
        Abilities.sound(p, Sounds.DARK_CAST, slot == 9 ? 0.6F : 1);
        switch (slot) {
            case 0 -> StyleSupport.held(p, 0, SpellKind.DARK_SPHERE, level, Sounds.DARK_CAST, false,
                    (self, e) -> {
                        StyleSupport.hit(p, e, 7 + level * 1.5F);
                        Abilities.debuff(e, StatusEffects.WEAKNESS, 80, 0); soundHit(p, e.getPos());
                    }, null);
            case 1 -> drain(p, level);
            case 2 -> {
                LivingEntity target = Abilities.aim(p, 28);
                Vec3d at = target == null ? Spells.crosshair(p, 28) : target.getPos();
                StyleSupport.model(p, SpellKind.DARK_CURSE, at, 1, 140, self -> {
                    if (target == null || !target.isAlive() || !Abilities.canHit(target, p)) { self.discard(); return; }
                    self.setPosition(target.getPos());
                    if (self.age % 20 == 0) {
                        StyleSupport.hit(p, target, 2 + level * 0.5F);
                        Abilities.debuff(target, StatusEffects.WEAKNESS, 30, 1);
                    }
                });
            }
            case 3 -> {
                Vec3d at = Skills.aimGround(p, 25);
                StyleSupport.field(p, SpellKind.DARK_HANDS, at, 3, 100, 4, self ->
                        StyleSupport.area(p, at.add(0, 1, 0), 3.5, self.age % 20 == 0 ? 3 + level : 0,
                                e -> StyleSupport.root(e, 8)));
            }
            case 4 -> hole(p, Skills.aimGround(p, 30).add(0, 1, 0), level);
            case 5 -> {
                if (path == 1) wraith(p, level);
                else plague(p, level);
            }
            case 6 -> {
                if (path == 1) {
                    Abilities.buff(p, StatusEffects.RESISTANCE, 160, 1);
                    StyleSupport.follow(p, SpellKind.DARK_SOULGUARD, 160, self -> {
                        if (self.age % 30 == 0) {
                            LivingEntity e = Abilities.aim(p, 8);
                            if (e != null) {
                                float before = e.getHealth(); StyleSupport.hit(p, e, 3 + level * 0.6F);
                                p.heal(Math.min(2, Math.max(0, before - e.getHealth()) * 0.25F));
                            }
                        }
                    });
                } else {
                    float cost = Math.min(6, Math.max(0, p.getHealth() - 1));
                    p.damage(p.getDamageSources().magic(), cost);
                    StyleSupport.follow(p, SpellKind.DARK_PACT, 100, self -> {
                        if (self.age % 20 == 0) {
                            LivingEntity e = Abilities.aim(p, 26);
                            if (e != null) StyleSupport.hit(p, e, 4 + level + cost * 0.8F);
                        }
                    });
                    Abilities.buff(p, StatusEffects.ABSORPTION, 100, 0);
                }
            }
            case 7 -> {
                Vec3d at = Spells.crosshair(p, 22);
                StyleSupport.field(p, SpellKind.DARK_NIGHTMARE, at, 4, 100, 15, self ->
                        StyleSupport.area(p, at, 5, 2 + level * 0.5F, e -> {
                            Abilities.debuff(e, StatusEffects.BLINDNESS, 40, 0);
                            Abilities.push(e, e.getPos().subtract(at).normalize().multiply(0.6));
                        }));
            }
            case 8 -> ghosts(p, level);
            case 9 -> {
                Vec3d at = Skills.aimGround(p, 40);
                StyleSupport.field(p, SpellKind.DARK_ECLIPSE, at, 8, 140, 10, self -> {
                    StyleSupport.area(p, at.add(0, 1, 0), 8, 4 + level * 0.7F, e -> {
                        Abilities.debuff(e, StatusEffects.DARKNESS, 35, 0);
                        Abilities.debuff(e, StatusEffects.WEAKNESS, 35, 1);
                    });
                    if (self.age % 30 == 0) soundHit(p, at);
                });
            }
        }
    }

    private static void soundHit(ServerPlayerEntity p, Vec3d at) {
        Abilities.soundAt(p.getServerWorld(), at, Sounds.DARK_HIT, 1);
    }

    private static void drain(ServerPlayerEntity p, int level) {
        LivingEntity target = Abilities.aim(p, 18);
        StyleSupport.model(p, SpellKind.DARK_DRAIN, p.getEyePos(), 1, 65, self -> {
            if (target == null || !target.isAlive() || !p.canSee(target) || p.squaredDistanceTo(target) > 24 * 24) {
                self.discard(); return;
            }
            Vec3d span = target.getBoundingBox().getCenter().subtract(p.getEyePos());
            self.setPosition(p.getEyePos()); self.facing(span); self.setSize((float) span.length());
            if (self.age % 10 == 0) {
                float before = target.getHealth();
                StyleSupport.hit(p, target, 2 + level * 0.6F);
                p.heal(Math.min(2.5F, Math.max(0, before - target.getHealth()) * 0.4F));
            }
        });
    }

    private static void hole(ServerPlayerEntity p, Vec3d at, int level) {
        StyleSupport.field(p, SpellKind.DARK_HOLE, at, 4, 120, 2, self -> {
            for (LivingEntity e : Abilities.livingAt(p, at, 7)) {
                if (!p.canSee(e)) continue;
                Vec3d to = at.subtract(e.getBoundingBox().getCenter());
                Abilities.push(e, to.normalize().multiply(Math.min(0.7, to.length() * 0.15)));
                if (self.age % 12 == 0 && to.length() < 3.5) StyleSupport.hit(p, e, 3 + level);
            }
        });
    }

    private static void ghosts(ServerPlayerEntity p, int level) {
        for (int i = 0; i < 5; i++) {
            int index = i;
            var struck = new java.util.HashSet<java.util.UUID>();
            StyleSupport.model(p, SpellKind.DARK_GHOSTS, p.getEyePos(), 0.9F, 100, self -> {
                if (self.age < 20 + index * 5) {
                    double a = index * Math.PI * 2 / 5 + self.age * 0.08;
                    Spells.hover(self, p.getPos().add(Math.cos(a) * 2, 1.6, Math.sin(a) * 2));
                    self.facing(p.getRotationVector()); return;
                }
                if (self.getVelocity().lengthSquared() < 0.2) self.setVelocity(p.getRotationVector().multiply(1.4));
                self.facing(self.getVelocity());
                if (Spells.fly(self, p, 0.5, true, struck, (at, e) -> {
                    StyleSupport.hit(p, e, 4 + level); Abilities.debuff(e, StatusEffects.WEAKNESS, 60, 0); return true;
                })) self.discard();
            });
        }
    }

    private static void wraith(ServerPlayerEntity p, int level) {
        Vec3d at = Skills.aimGround(p, 18);
        StyleSupport.field(p, SpellKind.DARK_WRAITH, at, 1.8F, 200, 24, self -> {
            LivingEntity target = Abilities.livingAt(p, at, 16).stream().filter(p::canSee)
                    .min(java.util.Comparator.comparingDouble(e -> e.squaredDistanceTo(at))).orElse(null);
            if (target == null) return;
            Vec3d start = at.add(0, 1.8, 0);
            StyleSupport.shot(p, SpellKind.DARK_WRAITH, start,
                    target.getBoundingBox().getCenter().subtract(start).normalize().multiply(1.3), 0.55F, 30,
                    false, (bolt, e) -> StyleSupport.hit(p, e, 4 + level), null);
        });
    }

    private static void plague(ServerPlayerEntity p, int level) {
        LivingEntity first = Abilities.aim(p, 25);
        Vec3d at = first == null ? Spells.crosshair(p, 25) : first.getPos();
        StyleSupport.field(p, SpellKind.DARK_PLAGUE, at, 3.5F, 130, 20, self ->
                StyleSupport.area(p, at.add(0, 1, 0), 5, 3 + level * 0.7F,
                        e -> { Abilities.debuff(e, StatusEffects.POISON, 30, 0); Abilities.debuff(e, StatusEffects.WEAKNESS, 50, 1); }));
    }
}
