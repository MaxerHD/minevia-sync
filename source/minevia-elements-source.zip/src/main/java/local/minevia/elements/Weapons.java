package local.minevia.elements;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.WeakHashMap;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterials;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Механики оружия: учитывают заряд удара, союзников, стены и прочность. */
public final class Weapons {
    public static final List<Item> ITEMS = new ArrayList<>();
    public static final Item STORM_BOW;
    private static final Map<PlayerEntity, Swing> SWINGS = new WeakHashMap<>();
    private static final Set<PlayerEntity> JUMPED = java.util.Collections.newSetFromMap(new WeakHashMap<>());

    private record Swing(float charge, float fall) {
    }

    static {
        for (DungeonWeaponItem.Kind kind : DungeonWeaponItem.Kind.values()) {
            Item.Settings settings = new Item.Settings().rarity(Rarity.EPIC).fireproof()
                    .attributeModifiers(SwordItem.createAttributeModifiers(ToolMaterials.NETHERITE, kind.damage, kind.speed));
            Item item = Registry.register(Registries.ITEM, Identifier.of(MineviaElements.MOD_ID, kind.id()), new DungeonWeaponItem(kind, settings));
            ITEMS.add(item);
        }
        STORM_BOW = Registry.register(Registries.ITEM, Identifier.of(MineviaElements.MOD_ID, "storm_bow"),
                new StormBowItem(new Item.Settings().maxDamage(768).rarity(Rarity.EPIC).fireproof()));
        ITEMS.add(STORM_BOW);
    }

    private Weapons() {
    }

    static void init() {
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (source.getAttacker() instanceof ServerPlayerEntity player && is(player.getMainHandStack(), DungeonWeaponItem.Kind.SOUL_SCYTHE)) {
                Abilities.buff(player, StatusEffects.SPEED, 70, 1);
                Flourish.rise(player.getServerWorld(), player.getPos(), 1.2F, 0x8AE9DC);
            }
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (source.getAttacker() instanceof ServerPlayerEntity player && special(source, player)
                    && entity != player && !Abilities.canHit(entity, player)) {
                return false;
            }
            return true;
        });
    }

    private static boolean special(DamageSource source, ServerPlayerEntity player) {
        return isSpecial(player.getMainHandStack()) || source.getSource() instanceof net.minecraft.entity.projectile.PersistentProjectileEntity arrow
                && arrow.getWeaponStack() != null && arrow.getWeaponStack().isOf(STORM_BOW);
    }

    public static boolean isSpecial(ItemStack stack) {
        return stack.getItem() instanceof DungeonWeaponItem || stack.getItem() instanceof StormBowItem;
    }

    private static boolean is(ItemStack stack, DungeonWeaponItem.Kind kind) {
        return stack.getItem() instanceof DungeonWeaponItem weapon && weapon.kind() == kind;
    }

    public static boolean begin(PlayerEntity player, Entity target) {
        SWINGS.remove(player);
        if (!(player instanceof ServerPlayerEntity server) || !(player.getMainHandStack().getItem() instanceof DungeonWeaponItem)) {
            return true;
        }
        if (!Abilities.canHit(target, server)) {
            return false;
        }
        SWINGS.put(player, new Swing(player.getAttackCooldownProgress(0.5F), player.fallDistance));
        return true;
    }

    public static void end(PlayerEntity player) {
        SWINGS.remove(player);
    }

    public static float damage(PlayerEntity player, Entity target, float amount) {
        if (!(player.getMainHandStack().getItem() instanceof DungeonWeaponItem weapon)) {
            return amount;
        }
        if (weapon.kind() == DungeonWeaponItem.Kind.NIGHT_SHARD && target instanceof LivingEntity living) {
            Vec3d behind = player.getPos().subtract(living.getPos()).multiply(1, 0, 1).normalize();
            Vec3d facing = living.getRotationVector().multiply(1, 0, 1).normalize();
            if (behind.dotProduct(facing) < -0.55) {
                return amount * 3;
            }
        }
        Swing swing = SWINGS.get(player);
        if (weapon.kind() == DungeonWeaponItem.Kind.CHIME_MAUL && swing != null && swing.fall() > 1.5F) {
            return amount + Math.min(32, swing.fall() * 2.4F) * (0.2F + 0.8F * swing.charge() * swing.charge());
        }
        return amount;
    }

    static void landed(PlayerEntity player) {
        JUMPED.remove(player);
    }

    static void hit(DungeonWeaponItem.Kind kind, ItemStack stack, LivingEntity target, ServerPlayerEntity player) {
        Swing swing = SWINGS.get(player);
        if (kind == DungeonWeaponItem.Kind.TIDAL_TRIDENT) {
            player.heal(0.25F);
        }
        if (swing == null) {
            return;
        }
        ServerWorld world = player.getServerWorld();
        Flourish.hit(world, target, kind == DungeonWeaponItem.Kind.CINDERWING ? 0xFF9138 : 0xB3E6F0);
        if (kind != DungeonWeaponItem.Kind.SOUL_SCYTHE && swing.charge() > 0.9F) {
            sweep(player, target);
        }
        switch (kind) {
            case CINDERWING -> {
                var nbt = stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT).copyNbt();
                int count = (nbt.getInt("MineviaCinderHits") + 1) % 3;
                nbt.putInt("MineviaCinderHits", count);
                stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
                if (count == 0) {
                    cinder(player, swing.charge());
                }
            }
            case TIDAL_TRIDENT -> player.heal(0.25F);
            case CHIME_MAUL -> {
                if (swing.fall() > 1.5F) {
                    groundWave(player, target, swing.fall(), swing.charge());
                    player.fallDistance = 0;
                }
            }
            case SOUL_SCYTHE -> cleave(player, target, swing.charge());
            default -> {
            }
        }
    }

    static boolean use(DungeonWeaponItem.Kind kind, ItemStack stack, ServerPlayerEntity player, Hand hand) {
        ServerWorld world = player.getServerWorld();
        int cooldown;
        if (kind == DungeonWeaponItem.Kind.WINDCUTTER) {
            if (player.isOnGround() || player.isTouchingWater() || player.isClimbing() || player.hasVehicle() || player.isFallFlying() || !JUMPED.add(player)) {
                return false;
            }
            Abilities.push(player, Spells.flatLook(player).multiply(0.4).add(0, 0.8, 0));
            player.fallDistance = 0;
            SpellEntity.spawn(world, SpellKind.WIND_BURST, player.getPos(), 1.5F, 14);
            Abilities.sound(player, Sounds.AIR_GUST, 1.6F);
            cooldown = 40;
        } else if (kind == DungeonWeaponItem.Kind.TIDAL_TRIDENT) {
            dash(player, stack, hand);
            cooldown = 70;
        } else if (kind == DungeonWeaponItem.Kind.GRAVITY_FLAIL) {
            gravity(player);
            cooldown = 100;
        } else {
            return false;
        }
        player.getItemCooldownManager().set(stack.getItem(), cooldown);
        stack.damage(2, player, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        return true;
    }

    private static boolean visible(ServerPlayerEntity player, Vec3d from, LivingEntity target) {
        return player.getServerWorld().raycast(new RaycastContext(from, target.getBoundingBox().getCenter(),
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player)).getType() == HitResult.Type.MISS;
    }

    private static void strike(ServerPlayerEntity player, LivingEntity target, float amount) {
        if (Abilities.canHit(target, player)) {
            Abilities.hurt(player, target, amount);
        }
    }

    private static void cinder(ServerPlayerEntity player, float charge) {
        ServerWorld world = player.getServerWorld();
        Vec3d direction = Spells.flatLook(player);
        SpellEntity arc = SpellEntity.spawn(world, SpellKind.CINDER_ARC, player.getPos().add(0, 0.9, 0), 1.6F, 18).facing(direction);
        Vec3d speed = direction.multiply(0.55);
        Set<UUID> hit = new HashSet<>();
        arc.setVelocity(speed);
        arc.logic(self -> {
            if (!player.isAlive() || player.getWorld() != world) {
                self.discard();
                return;
            }
            Vec3d from = self.getPos();
            Vec3d to = from.add(speed);
            if (world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, self)).getType() != HitResult.Type.MISS) {
                self.discard();
                return;
            }
            self.setPosition(to);
            for (LivingEntity near : Abilities.livingAt(player, to, 1.7)) {
                if (visible(player, to, near) && hit.add(near.getUuid())) {
                    strike(player, near, 6 * (0.2F + 0.8F * charge * charge));
                    Flourish.hit(world, near, 0xFF9138);
                }
            }
        });
        Abilities.sound(player, Sounds.MAGMA, 1.5F);
    }

    private static void dash(ServerPlayerEntity player, ItemStack weapon, Hand hand) {
        ServerWorld world = player.getServerWorld();
        Vec3d direction = player.getRotationVector();
        int ticks = player.isTouchingWater() ? 16 : 8;
        Set<UUID> hit = new HashSet<>();
        Effects.repeat(world, ticks, 1, step -> {
            if (!player.isAlive() || player.getWorld() != world || player.getStackInHand(hand) != weapon || player.horizontalCollision) {
                return false;
            }
            Vec3d speed = direction.multiply(0.85);
            Abilities.push(player, speed);
            player.fallDistance = 0;
            SpellEntity.spawn(world, SpellKind.TIDAL_DASH, player.getPos().add(0, 0.7, 0), 1.1F, 8).facing(direction);
            // Коридор проверяется до стены; попадания не достают сквозь неё.
            Box path = player.getBoundingBox().stretch(speed).expand(0.35);
            for (LivingEntity near : world.getEntitiesByClass(LivingEntity.class, path, e -> Abilities.canHit(e, player))) {
                if (player.canSee(near) && hit.add(near.getUuid())) {
                    float before = near.getHealth();
                    strike(player, near, 7);
                    if (near.getHealth() < before) {
                        player.heal(0.75F);
                    }
                }
            }
            return true;
        });
        Abilities.sound(player, Sounds.WATER_WAVE, 1.2F);
    }

    private static void groundWave(ServerPlayerEntity player, LivingEntity primary, float fall, float charge) {
        ServerWorld world = player.getServerWorld();
        Vec3d at = primary.getPos();
        float radius = Math.min(6, 2.5F + fall * 0.18F);
        SpellEntity.spawn(world, SpellKind.FORGE_WAVE, at, radius, 20).tint(0xFFD27A);
        for (LivingEntity near : Abilities.livingAt(player, at, radius)) {
            if (near != primary && near.squaredDistanceTo(at) <= radius * radius && Math.abs(near.getY() - at.y) < 1.8 && visible(player, at.add(0, 0.7, 0), near)) {
                strike(player, near, Math.min(16, 4 + fall) * (0.2F + 0.8F * charge * charge));
                Abilities.push(near, near.getPos().subtract(at).normalize().multiply(0.6).add(0, 0.45, 0));
            }
        }
        Abilities.sound(player, Sounds.EARTH_QUAKE, 0.8F);
    }

    private static void gravity(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        Vec3d from = player.getEyePos();
        Vec3d to = from.add(player.getRotationVector().multiply(5));
        HitResult hit = world.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
        Vec3d point = hit.getType() == HitResult.Type.MISS ? to : hit.getPos().subtract(player.getRotationVector().multiply(0.6));
        SpellEntity.spawn(world, SpellKind.GRAVITY_KNOT, point, 1.5F, 40);
        Effects.repeat(world, 10, 4, step -> {
            if (!player.isAlive() || player.getWorld() != world) {
                return false;
            }
            for (LivingEntity near : Abilities.livingAt(player, point, 6)) {
                if (near.squaredDistanceTo(point) <= 36 && visible(player, point, near)) {
                    Vec3d pull = point.subtract(near.getBoundingBox().getCenter());
                    Abilities.push(near, pull.length() < 0.4 ? Vec3d.ZERO : pull.normalize().multiply(Math.min(0.65, pull.length() * 0.18)));
                    Abilities.debuff(near, StatusEffects.SLOWNESS, 12, 0);
                }
            }
            return true;
        });
        Abilities.sound(player, Sounds.VACUUM, 0.8F);
    }

    private static void sweep(ServerPlayerEntity player, LivingEntity primary) {
        double ratio = player.getAttributeValue(EntityAttributes.PLAYER_SWEEPING_DAMAGE_RATIO);
        if (ratio <= 0 || !player.isOnGround() || player.isSprinting()) {
            return;
        }
        SpellEntity.spawn(player.getServerWorld(), SpellKind.SOUL_CLEAVE, player.getPos().add(0, 0.8, 0), 1.8F, 10).facing(Spells.flatLook(player));
        for (LivingEntity near : Abilities.livingAt(player, primary.getPos(), 1.7)) {
            if (near != primary && player.squaredDistanceTo(near) < 9 && player.canSee(near)) {
                strike(player, near, 1 + (float) (ratio * player.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE)));
            }
        }
    }

    private static void cleave(ServerPlayerEntity player, LivingEntity primary, float charge) {
        Vec3d direction = Spells.flatLook(player);
        SpellEntity.spawn(player.getServerWorld(), SpellKind.SOUL_CLEAVE, player.getPos().add(0, 0.9, 0), 3.8F, 14).facing(direction);
        for (LivingEntity near : Abilities.livingAt(player, player.getPos(), 4)) {
            Vec3d offset = near.getPos().subtract(player.getPos());
            if (near != primary && offset.lengthSquared() <= 16 && offset.multiply(1, 0, 1).normalize().dotProduct(direction) > 0.15 && player.canSee(near)) {
                strike(player, near, (float) player.getAttributeValue(EntityAttributes.GENERIC_ATTACK_DAMAGE) * (0.75F + (float) player.getAttributeValue(EntityAttributes.PLAYER_SWEEPING_DAMAGE_RATIO)) * (0.2F + 0.8F * charge * charge));
            }
        }
    }

    public static boolean arrowCanHit(Entity arrow, Entity target) {
        return !(arrow instanceof net.minecraft.entity.projectile.PersistentProjectileEntity projectile)
                || !(projectile.getOwner() instanceof ServerPlayerEntity player) || Abilities.canHit(target, player);
    }

    public static void chain(net.minecraft.entity.projectile.PersistentProjectileEntity arrow, LivingEntity struck) {
        if (!(arrow.getOwner() instanceof ServerPlayerEntity player) || !Abilities.canHit(struck, player) && struck.isAlive()) {
            return;
        }
        Vec3d at = struck.getBoundingBox().getCenter();
        LivingEntity next = Abilities.livingAt(player, at, 6).stream().filter(e -> e != struck && e.squaredDistanceTo(at) <= 36 && visible(player, at, e))
                .min(java.util.Comparator.comparingDouble(e -> e.squaredDistanceTo(at))).orElse(null);
        if (next != null) {
            Vec3d end = next.getBoundingBox().getCenter();
            SpellEntity.spawn(player.getServerWorld(), SpellKind.LIGHTNING, at, (float) at.distanceTo(end), 8).facing(end.subtract(at)).tint(0xC7DEFF);
            strike(player, next, 8);
            Flourish.hit(player.getServerWorld(), next, 0xC7DEFF);
        }
    }
}
