package local.minevia.elements;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

/**
 * Лаунчер не раздаёт настройки чужих модов, поэтому умеренные значения кладёт сам мод.
 * Файлы пишутся только если их ещё нет: настройки игрока не трогаем.
 * Исключение одно: скример на весь экран владелец сборки попросил убрать, и его выключаем один раз у всех.
 */
public final class HorrorDefaults implements PreLaunchEntrypoint {
    private static final String[] FILES = {"serversidehorror.json", "face_of_horror-server.toml", "face_of_horror-default-server.toml", "hollow-reborn.json"};
    private static final String MARK = "minevia_horror.json";
    private static final int VERSION = 1;

    @Override
    public void onPreLaunch() {
        Path config = FabricLoader.getInstance().getConfigDir();
        for (String name : FILES) {
            Path target = config.resolve(name);
            if (Files.exists(target)) {
                continue;
            }
            try (InputStream source = HorrorDefaults.class.getResourceAsStream("/minevia_defaults/" + name)) {
                if (source != null) {
                    Files.createDirectories(config);
                    Files.copy(source, target);
                }
            } catch (IOException e) {
                MineviaElements.LOGGER.warn("Не удалось положить настройки {}", name, e);
            }
        }
        noScreamers(config);
    }

    private static void noScreamers(Path config) {
        Path mark = config.resolve(MARK);
        try {
            if (Files.exists(mark) && Files.readString(mark).contains("\"version\": " + VERSION)) {
                return;
            }
            Path horror = config.resolve("serversidehorror.json");
            if (Files.isRegularFile(horror)) {
                String text = Files.readString(horror, StandardCharsets.UTF_8);
                String off = text.replaceAll("\"jumpscare_enable\"\\s*:\\s*true", "\"jumpscare_enable\": false");
                if (!off.equals(text)) {
                    Files.writeString(horror, off, StandardCharsets.UTF_8);
                }
            }
            Files.writeString(mark, "{\"version\": " + VERSION + "}\n");
        } catch (IOException | RuntimeException e) {
            MineviaElements.LOGGER.warn("Не удалось выключить скримеры", e);
        }
    }
}
