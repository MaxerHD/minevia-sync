package local.minevia.elements;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.entrypoint.PreLaunchEntrypoint;

/**
 * Лаунчер не раздаёт настройки чужих модов, поэтому умеренные значения кладёт сам мод.
 * Файлы пишутся только если их ещё нет: настройки игрока не трогаем.
 */
public final class HorrorDefaults implements PreLaunchEntrypoint {
    private static final String[] FILES = {"serversidehorror.json", "face_of_horror-server.toml", "face_of_horror-default-server.toml", "hollow-reborn.json", "devcounterentity.json"};

    @Override
    public void onPreLaunch() {
        Path config = FabricLoader.getInstance().getConfigDir();
        for (String name : FILES) {
            Path target = config.resolve(name);
            if (Files.exists(target)) {
                continue;
            }
            try (InputStream source = HorrorDefaults.class.getResourceAsStream("/minevia_defaults/" + name)) {
                if (source != null) {
                    Files.createDirectories(config);
                    Files.copy(source, target);
                }
            } catch (IOException e) {
                MineviaElements.LOGGER.warn("Не удалось положить настройки {}", name, e);
            }
        }
    }
}
