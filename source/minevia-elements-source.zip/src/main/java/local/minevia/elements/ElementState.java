package local.minevia.elements;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

/** Стихии игроков хранятся в самом мире, поэтому переживают перезаход и смерть. */
public class ElementState extends PersistentState {
    /** Шестой уровень это вторая ступень: игрок выбирает путь своей стихии. */
    public static final int MAX_LEVEL = 6;
    public static final int XP_FOR_LEVEL_TWO = 30;

    public static final class Data {
        public Element element;
        public int level = 1;
        public int xp = 0;
        /** 0 пока путь не выбран, иначе 1 или 2. */
        public int path = 0;
    }

    private static final Type<ElementState> TYPE = new Type<>(ElementState::new, ElementState::fromNbt, null);

    private final Map<UUID, Data> players = new HashMap<>();
    private final Random random = new Random();

    public static ElementState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, MineviaElements.MOD_ID);
    }

    private static ElementState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        ElementState state = new ElementState();
        for (String key : nbt.getKeys()) {
            NbtCompound entry = nbt.getCompound(key);
            Data data = new Data();
            data.element = Element.valueOf(entry.getString("element"));
            data.level = entry.getInt("level");
            data.xp = entry.getInt("xp");
            data.path = entry.getInt("path");
            state.players.put(UUID.fromString(key), data);
        }
        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        players.forEach((id, data) -> {
            NbtCompound entry = new NbtCompound();
            entry.putString("element", data.element.name());
            entry.putInt("level", data.level);
            entry.putInt("xp", data.xp);
            entry.putInt("path", data.path);
            nbt.put(id.toString(), entry);
        });
        return nbt;
    }

    public Data find(UUID id) {
        return players.get(id);
    }

    public Data getOrAssign(UUID id) {
        Data data = players.get(id);
        if (data != null) {
            return data;
        }
        List<Element> taken = new ArrayList<>();
        players.values().forEach(other -> taken.add(other.element));
        data = new Data();
        data.element = ElementAssigner.pick(taken, random);
        players.put(id, data);
        markDirty();
        return data;
    }

    public void remove(UUID id) {
        players.remove(id);
        markDirty();
    }

    public Map<UUID, Data> all() {
        return players;
    }
}
