package local.minevia.elements;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

/** Стихии игроков хранятся в самом мире, поэтому переживают перезаход и смерть. */
public class ElementState extends PersistentState {
    /** Шестой уровень это вторая ступень: игрок выбирает путь своей стихии. */
    public static final int MAX_LEVEL = 6;
    public static final int XP_FOR_LEVEL_TWO = 30;

    public static final class Data {
        public Element element;
        public int level = 1;
        public int xp = 0;
        /** 0 пока путь не выбран, иначе 1 или 2. */
        public int path = 0;
        /** Опыт каждого навыка: от него зависит его уровень. */
        public int[] skills = new int[Abilities.SLOTS];
        /** Какие реликвии игрок уже получал: по биту на реликвию. */
        public int relics = 0;
        public long changedAt = 0;
    }

    private static final Type<ElementState> TYPE = new Type<>(ElementState::new, ElementState::fromNbt, null);

    private final Map<UUID, Data> players = new HashMap<>();

    public static ElementState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, MineviaElements.MOD_ID);
    }

    private static ElementState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        ElementState state = new ElementState();
        for (String key : nbt.getKeys()) {
            NbtCompound entry = nbt.getCompound(key);
            Data data = new Data();
            String saved = entry.getString("element");
            try { data.element = Element.valueOf(saved); }
            catch (IllegalArgumentException ignored) { data.element = null; }
            data.changedAt = entry.getLong("changedAt");
            data.level = Math.max(1, Math.min(MAX_LEVEL, entry.getInt("level")));
            data.xp = entry.getInt("xp");
            data.path = entry.getInt("path");
            data.skills = Arrays.copyOf(entry.getIntArray("skills"), Abilities.SLOTS);
            data.relics = entry.getInt("relics");
            state.players.put(UUID.fromString(key), data);
        }
        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        players.forEach((id, data) -> {
            NbtCompound entry = new NbtCompound();
            entry.putString("element", data.element == null ? "" : data.element.name());
            entry.putLong("changedAt", data.changedAt);
            entry.putInt("level", data.level);
            entry.putInt("xp", data.xp);
            entry.putInt("path", data.path);
            entry.putIntArray("skills", data.skills);
            entry.putInt("relics", data.relics);
            nbt.put(id.toString(), entry);
        });
        return nbt;
    }

    public Data find(UUID id) {
        return players.get(id);
    }

    public Data getOrAssign(UUID id) {
        Data data = players.get(id);
        if (data != null) {
            return data;
        }
        data = new Data();
        players.put(id, data);
        markDirty();
        return data;
    }

    public boolean choose(UUID id, int choice, long now) {
        Data data = getOrAssign(id);
        Element next = SelectionRules.choice(choice);
        if (!SelectionRules.allowed(data.element, next, data.changedAt, now)) return false;
        data.element = next;
        data.changedAt = now;
        data.path = 0;
        Arrays.fill(data.skills, 0);
        markDirty();
        return true;
    }

    public void remove(UUID id) {
        players.remove(id);
        markDirty();
    }

    public Map<UUID, Data> all() {
        return players;
    }
}
