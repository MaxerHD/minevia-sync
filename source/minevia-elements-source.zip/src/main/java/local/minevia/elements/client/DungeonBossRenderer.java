package local.minevia.elements.client;

import local.minevia.elements.DungeonBoss;
import local.minevia.elements.MineviaElements;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Хозяева подземелий: анимированные 3D-модели. Рогач пригибается перед разбегом и шатается, когда оглушён. */
final class DungeonBossRenderer extends EntityRenderer<DungeonBoss> {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private static final String[] MODELS = {"boss_abbot", "boss_bell", "boss_bull"};
    private static final int HURT_TINT = 0xFF9090;
    private static final float STRIDE = 7.0F;

    DungeonBossRenderer(EntityRendererFactory.Context context) {
        super(context);
        shadowRadius = 1.0F;
    }

    @Override
    public Identifier getTexture(DungeonBoss entity) {
        return WHITE;
    }

    @Override
    public void render(DungeonBoss boss, float yaw, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        int kind = boss.kind();
        SpellMesh mesh = SpellMesh.get(MODELS[kind]);
        if (mesh == null) {
            return;
        }
        float age = boss.age + delta;
        float body = MathHelper.lerpAngleDegrees(delta, boss.prevBodyYaw, boss.bodyYaw);
        int tint = boss.hurtTime > 0 ? HURT_TINT : 0xFFFFFF;
        int state = boss.state();
        float phase = kind == DungeonBoss.BULL
                ? boss.limbAnimator.getPos(delta) / STRIDE * mesh.frames()
                : age / (kind == DungeonBoss.BELL ? 44 : 36) * mesh.frames();
        matrices.push();
        if (kind != DungeonBoss.BULL) {
            matrices.translate(0, Math.sin(age * 0.07) * 0.12, 0);
        }
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-body));
        if (state == DungeonBoss.WINDUP) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(14 + (float) Math.sin(age * 1.4) * 3));
        } else if (state == DungeonBoss.RUSH) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(9));
            phase = age / 7 * mesh.frames();
        } else if (state == DungeonBoss.STUNNED) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) Math.sin(age * 0.35) * 7));
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-6));
        }
        mesh.draw(matrices.peek(), consumers.getBuffer(ShaderCompat.glow()), phase, true, tint, 1.0F,
                LightmapTextureManager.MAX_LIGHT_COORDINATE, SpellMesh.Surface.PLAIN);
        matrices.pop();
    }
}
