package local.minevia.elements;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Страж храма. Все четыре стража и Исток это одна сущность с разным набором приёмов. У каждого приёма
 * есть предупреждение на земле, поэтому от него можно уйти. Исток закрыт печатями: их снимают только комбо.
 */
public final class ElementBoss extends HostileEntity {
    public static final int PRIMAL = 4;

    private static final TrackedData<Integer> KIND = DataTracker.registerData(ElementBoss.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> SEALS = DataTracker.registerData(ElementBoss.class, TrackedDataHandlerRegistry.INTEGER);
    private static final float[] HEALTH = {320, 320, 420, 280, 900};
    private static final int HOME_RANGE = 56;
    private static final int OPEN_TICKS = 300;

    private final ServerBossBar bar = new ServerBossBar(Text.translatable("boss.minevia_elements.fire"),
            BossBar.Color.RED, BossBar.Style.NOTCHED_10);
    private final Set<UUID> fighters = new HashSet<>();
    private BlockPos home = BlockPos.ORIGIN;
    private int nextMove = 60;
    private int nextHelp = 300;
    private int alone;
    private int openFor;
    private int allSeals;
    private int hurtSound;

    public ElementBoss(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        setNoGravity(true);
        experiencePoints = 300;
    }

    public static DefaultAttributeContainer.Builder attributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 320)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 48)
                .add(EntityAttributes.GENERIC_ARMOR, 6);
    }

    /** Вызывает стража у алтаря. Здоровье растёт с числом игроков рядом. */
    public static ElementBoss summon(ServerWorld world, BlockPos altar, int kind, int sealMask) {
        ElementBoss boss = MineviaElements.BOSS.create(world);
        if (boss == null) {
            return null;
        }
        boss.dataTracker.set(KIND, kind);
        boss.home = altar;
        boss.allSeals = sealMask;
        boss.dataTracker.set(SEALS, sealMask);
        boss.setPosition(Vec3d.ofCenter(altar.up(5)));
        int players = Math.max(1, world.getEntitiesByClass(PlayerEntity.class, new Box(altar).expand(40), PlayerEntity::isAlive).size());
        float health = HEALTH[kind] * (1 + 0.6F * (players - 1));
        boss.getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(health);
        boss.setHealth(health);
        boss.setPersistent();
        boss.setupBar();
        world.spawnEntity(boss);
        Abilities.soundAt(world, boss.getPos(), Sounds.BOSS_AWAKE, 1.0F);
        return boss;
    }

    private void setupBar() {
        int kind = kind();
        bar.setName(Text.translatable(kind == PRIMAL ? "boss.minevia_elements.primal" : "boss.minevia_elements." + Element.values()[kind].id()));
        bar.setColor(switch (kind) {
            case 0 -> BossBar.Color.RED;
            case 1 -> BossBar.Color.BLUE;
            case 2 -> BossBar.Color.GREEN;
            case 3 -> BossBar.Color.WHITE;
            default -> BossBar.Color.PURPLE;
        });
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(KIND, 0);
        builder.add(SEALS, 0);
    }

    public int kind() {
        return dataTracker.get(KIND);
    }

    public int seals() {
        return dataTracker.get(SEALS);
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        ServerWorld world = (ServerWorld) getWorld();
        if (home.equals(BlockPos.ORIGIN)) {
            // Вызван командой, а не алтарём: домом считается место появления.
            home = getBlockPos().down(3);
        }
        bar.setPercent(getHealth() / getMaxHealth());
        PlayerEntity target = closestFighter();
        if (target == null) {
            driftTo(Vec3d.ofCenter(home.up(5)));
            if (++alone > 400) {
                sleep(world);
            }
            return;
        }
        alone = 0;
        fighters.add(target.getUuid());
        double keep = kind() == 2 ? 6 : 10;
        Vec3d to = target.getPos().subtract(getPos());
        Vec3d flat = new Vec3d(to.x, 0, to.z);
        Vec3d spot = target.getPos().subtract(flat.normalize().multiply(keep)).add(0, 3.5, 0);
        spot = spot.add(Math.sin(age * 0.05) * 2.5, Math.sin(age * 0.09) * 0.6, Math.cos(age * 0.05) * 2.5);
        Vec3d limit = Vec3d.ofCenter(home);
        if (new Vec3d(spot.x - limit.x, 0, spot.z - limit.z).length() > 15) {
            spot = limit.add(new Vec3d(spot.x - limit.x, 0, spot.z - limit.z).normalize().multiply(15)).add(0, 4, 0);
        }
        spot = new Vec3d(spot.x, Math.min(spot.y, home.getY() + 8), spot.z);
        driftTo(spot);
        float yaw = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
        setYaw(yaw);
        setHeadYaw(yaw);
        setBodyYaw(yaw);

        boolean angry = getHealth() < getMaxHealth() / 2;
        if (--nextMove <= 0) {
            nextMove = (angry ? 46 : 74) + world.random.nextInt(16);
            BossMoves.use(this, world, target, kind() == PRIMAL ? world.random.nextInt(4) : kind());
        }
        if (angry && --nextHelp <= 0) {
            nextHelp = 340;
            callHelp(world);
        }
        if (openFor > 0 && --openFor == 0) {
            dataTracker.set(SEALS, allSeals);
            Abilities.soundAt(world, getPos(), Sounds.ALTAR, 1.0F);
            say(world, "message.minevia_elements.seals_back");
        }
    }

    private void driftTo(Vec3d spot) {
        Vec3d want = spot.subtract(getPos());
        double length = want.length();
        Vec3d step = length < 0.1 ? Vec3d.ZERO : want.multiply(Math.min(0.32, length * 0.2) / length);
        setVelocity(getVelocity().lerp(step, 0.3));
    }

    private PlayerEntity closestFighter() {
        Box area = new Box(home).expand(HOME_RANGE);
        return getWorld().getEntitiesByClass(PlayerEntity.class, area, player -> player.isAlive() && !player.isCreative() && !player.isSpectator())
                .stream().min(Comparator.comparingDouble(player -> player.squaredDistanceTo(this))).orElse(null);
    }

    /** Все ушли: страж засыпает, и алтарь снова можно разбудить. */
    private void sleep(ServerWorld world) {
        BlockState state = world.getBlockState(home);
        if (state.getBlock() instanceof AltarBlock) {
            world.setBlockState(home, state.with(AltarBlock.AWAKE, true));
        }
        bar.clearPlayers();
        discard();
    }

    private void callHelp(ServerWorld world) {
        EntityType<?> helper = MineviaElements.SPIRITS[kind() == PRIMAL ? world.random.nextInt(4) : kind()];
        for (int i = 0; i < 2; i++) {
            BlockPos at = home.add(world.random.nextInt(13) - 6, 1, world.random.nextInt(13) - 6);
            helper.spawn(world, at, SpawnReason.MOB_SUMMONED);
        }
    }

    private void say(ServerWorld world, String key) {
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, new Box(home).expand(HOME_RANGE), PlayerEntity::isAlive)) {
            player.sendMessage(Text.translatable(key), true);
        }
    }

    /** Комбо рядом с Истоком снимает печати обеих своих стихий. */
    static void onCombo(ServerWorld world, Vec3d at, Element first, Element second) {
        Box area = new Box(at, at).expand(40);
        for (ElementBoss boss : world.getEntitiesByClass(ElementBoss.class, area, entity -> entity.kind() == PRIMAL)) {
            boss.breakSeals(world, first, second);
        }
    }

    private void breakSeals(ServerWorld world, Element first, Element second) {
        int left = seals();
        int after = left & ~(1 << first.ordinal()) & ~(1 << second.ordinal());
        if (after == left) {
            return;
        }
        dataTracker.set(SEALS, after);
        Abilities.soundAt(world, getPos(), Sounds.SEAL_BREAK, 1.0F);
        if (after == 0) {
            openFor = OPEN_TICKS;
            say(world, "message.minevia_elements.seals_gone");
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (source.isOf(DamageTypes.IN_WALL) || source.isOf(DamageTypes.FALL) || source.isOf(DamageTypes.DROWN)) {
            return false;
        }
        if (kind() == PRIMAL && seals() != 0 && !source.isOf(DamageTypes.GENERIC_KILL)) {
            if (source.getAttacker() instanceof ServerPlayerEntity player) {
                player.sendMessage(Text.translatable("message.minevia_elements.sealed"), true);
            }
            return false;
        }
        boolean hit = super.damage(source, amount);
        if (hit) {
            if (source.getAttacker() instanceof ServerPlayerEntity player) {
                fighters.add(player.getUuid());
            }
            if (age - hurtSound > 12 && getWorld() instanceof ServerWorld world) {
                hurtSound = age;
                Abilities.soundAt(world, getPos(), Sounds.BOSS_HURT, 1.0F);
            }
        }
        return hit;
    }

    @Override
    public void onDeath(DamageSource source) {
        if (getWorld() instanceof ServerWorld world && !dead) {
            reward(world);
        }
        super.onDeath(source);
    }

    /** Каждый участник получает своё Ядро: одно уже выпадает с любого босса, остальные добавляются здесь. */
    private void reward(ServerWorld world) {
        int kind = kind();
        Vec3d at = getPos();
        SpellEntity.spawn(world, SpellKind.FIRE_BURST, at, 3.0F, 17);
        SpellEntity.spawn(world, SpellKind.WIND_BURST, at, 5.0F, 14);
        Abilities.soundAt(world, at, Sounds.BOSS_DEATH, 1.0F);
        for (int i = 1; i < Math.max(1, fighters.size()); i++) {
            dropStack(new ItemStack(MineviaElements.ELEMENT_CORE));
        }
        if (kind == PRIMAL) {
            dropStack(new ItemStack(Items.NETHER_STAR));
            dropStack(new ItemStack(MineviaElements.ELEMENT_CORE, 2));
            say(world, "message.minevia_elements.primal_down");
        } else {
            dropStack(new ItemStack(MineviaElements.SEALS[kind]));
        }
        bar.clearPlayers();
    }

    /** Обычный дымок смерти не показывается: страж разлетается своей моделью. */
    @Override
    protected void updatePostDeath() {
        if (!getWorld().isClient) {
            discard();
        }
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);
        bar.addPlayer(player);
    }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) {
        super.onStoppedTrackingBy(player);
        bar.removePlayer(player);
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("Kind", kind());
        nbt.putInt("AllSeals", allSeals);
        nbt.put("Home", NbtHelper.fromBlockPos(home));
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        dataTracker.set(KIND, MathHelper.clamp(nbt.getInt("Kind"), 0, PRIMAL));
        allSeals = nbt.getInt("AllSeals");
        dataTracker.set(SEALS, allSeals);
        NbtHelper.toBlockPos(nbt, "Home").ifPresent(pos -> home = pos);
        setupBar();
    }

    @Override
    public void setCustomName(@Nullable Text name) {
        super.setCustomName(name);
        if (name != null) {
            bar.setName(name);
        }
    }

    @Override
    public boolean cannotDespawn() {
        return true;
    }

    @Override
    public void checkDespawn() {
    }

    @Override
    public boolean canHaveStatusEffect(StatusEffectInstance effect) {
        return false;
    }

    @Override
    public boolean isPushable() {
        return false;
    }

    @Override
    public void takeKnockback(double strength, double x, double z) {
    }

    @Override
    public boolean handleFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean doesRenderOnFire() {
        return false;
    }

    @Override
    protected boolean isDisallowedInPeaceful() {
        return false;
    }

    /** Игроки, по которым бьёт приём: только те, кто реально в бою. */
    static List<PlayerEntity> playersAt(ServerWorld world, Vec3d center, double radius) {
        Box area = new Box(center, center).expand(radius);
        List<PlayerEntity> near = new ArrayList<>();
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, area, PlayerEntity::isAlive)) {
            if (!player.isCreative() && !player.isSpectator() && player.getBoundingBox().getCenter().distanceTo(center) <= radius) {
                near.add(player);
            }
        }
        return near;
    }

    void strike(ServerWorld world, PlayerEntity player, float damage) {
        player.damage(world.getDamageSources().mobAttack(this), damage);
    }

    /** Замедление игрока без вихря частиц вокруг него. */
    static void slow(PlayerEntity player, int ticks, int amplifier) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, ticks, amplifier, false, false, true));
    }
}
