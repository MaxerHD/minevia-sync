package local.minevia.elements;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** Опыт сохраняется; рост дают успешные попадания и полезное лечение. */
public final class Mastery {
    public static final int MAX = 5;
    private static final int[] NEED = {0, 30, 90, 210, 390};

    private static final int ESSENCE_XP = 5;

    private static final Map<UUID, long[]> HIT_AT = new HashMap<>();
    private static final Map<UUID, long[]> AID_AT = new HashMap<>();
    private static final Map<UUID, Integer> LAST = new HashMap<>();

    private Mastery() {
    }

    public static int level(int xp) {
        int level = 1;
        while (level < MAX && xp >= NEED[level]) {
            level++;
        }
        return level;
    }

    /** Сколько опыта нужно для уровня после данного, или 0, если уровень последний. */
    public static int next(int level) {
        return level < MAX ? NEED[level] : 0;
    }

    /** Опыт, с которого начинается уровень. */
    public static int start(int level) {
        return NEED[level - 1];
    }

    /** Сила навыка в формулах урона и размера: от 1 у новичка до 7 у мастера на высшем уровне стихии. */
    static int power(ElementState.Data data, int slot) {
        return level(data.skills[slot]) + (data.level - 1) / 2;
    }

    /** Редкие навыки получают больше опыта за попадание. */
    private static int gain(Element element, int slot) {
        return 2 + Abilities.cooldown(element, slot) / 420;
    }

    static void cast(ServerPlayerEntity player, ElementState.Data data, int slot) {
        LAST.put(player.getUuid(), slot);
    }

    static void hit(ServerPlayerEntity player, ElementState.Data data) {
        CastContext.Token context = CastContext.capture();
        if (context == null || !context.valid() || !context.player().equals(player.getUuid())) return;
        int slot = context.slot();
        if (reward(player, data.element, slot, HIT_AT, 20)) add(player, data, slot, gain(data.element, slot));
    }

    /** Лечение без восстановленного здоровья опыта не даёт. */
    static void aid(ServerPlayerEntity player, net.minecraft.entity.LivingEntity ally, float amount) {
        float before = ally.getHealth();
        ally.heal(amount);
        CastContext.Token context = CastContext.capture();
        if (ally.getHealth() <= before || context == null || !context.valid()) return;
        ElementState.Data data = ElementState.get(player.getServer()).find(player.getUuid());
        if (data != null && context.player().equals(player.getUuid())
                && reward(player, data.element, context.slot(), AID_AT, 100)
                && reward(player, data.element, context.slot(), HIT_AT, 20)) add(player, data, context.slot(), 1);
    }

    private static boolean reward(ServerPlayerEntity player, Element element, int slot, Map<UUID, long[]> times, int pause) {
        int index = element.ordinal() * Abilities.SLOTS + slot;
        long[] ready = times.computeIfAbsent(player.getUuid(), id -> new long[Element.values().length * Abilities.SLOTS]);
        long now = player.getServer().getTicks();
        if (now < ready[index]) return false;
        ready[index] = now + pause;
        return true;
    }

    /** Эссенция питает навык, который применяли последним. Вернёт false, если он уже на высшем уровне. */
    static boolean essence(ServerPlayerEntity player, ElementState.Data data, Element element) {
        if (data.element == null) return false;
        int slot = LAST.getOrDefault(player.getUuid(), 0);
        if (level(data.skills[slot]) >= MAX) {
            player.sendMessage(Text.translatable("message.minevia_elements.essence_max"), true);
            return false;
        }
        add(player, data, slot, element == data.element ? ESSENCE_XP * 2 : ESSENCE_XP);
        Abilities.sound(player, Sounds.WHEEL, 1.4F);
        MineviaElements.sync(player);
        return true;
    }

    static void forget(UUID id) {
        HIT_AT.remove(id);
        AID_AT.remove(id);
        LAST.remove(id);
    }

    private static void add(ServerPlayerEntity player, ElementState.Data data, int slot, int amount) {
        int before = level(data.skills[slot]);
        data.skills[slot] += amount;
        ElementState.get(player.getServer()).markDirty();
        int after = level(data.skills[slot]);
        if (after > before) {
            String key = switch (slot) {
                case Abilities.PATH_SLOT -> data.element.pathKey(Math.max(1, data.path));
                case Abilities.PATH_SECOND_SLOT -> data.element.pathKey(Math.max(1, data.path)) + ".second";
                default -> data.element.abilityKey(slot);
            };
            player.sendMessage(Text.translatable("message.minevia_elements.skill_up", Text.translatable(key), after), true);
            Abilities.sound(player, Sounds.SEAL_BREAK, 1.6F);
            Flourish.levelUp(player, data.element.color);
            MineviaElements.sync(player);
        }
    }
}
