package local.minevia.elements;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/**
 * Уровни навыков. Навык растёт от применения, а первый удар каждого применения даёт вдвое больше:
 * чем чаще игрок им дерётся, тем он крупнее и сильнее. Уровень стихии открывает навыки и немного поднимает их все.
 */
public final class Mastery {
    public static final int MAX = 5;
    private static final int[] NEED = {0, 10, 30, 70, 130};

    private static final int ESSENCE_XP = 5;

    private static final Map<UUID, Integer> PENDING = new HashMap<>();
    private static final Map<UUID, Integer> LAST = new HashMap<>();

    private Mastery() {
    }

    public static int level(int xp) {
        int level = 1;
        while (level < MAX && xp >= NEED[level]) {
            level++;
        }
        return level;
    }

    /** Сколько опыта нужно для уровня после данного, или 0, если уровень последний. */
    public static int next(int level) {
        return level < MAX ? NEED[level] : 0;
    }

    /** Опыт, с которого начинается уровень. */
    public static int start(int level) {
        return NEED[level - 1];
    }

    /** Сила навыка в формулах урона и размера: от 1 у новичка до 7 у мастера на высшем уровне стихии. */
    static int power(ElementState.Data data, int slot) {
        return level(data.skills[slot]) + (data.level - 1) / 2;
    }

    /** Редкие навыки растут за меньшее число применений, иначе супер-навык не дорос бы никогда. */
    private static int gain(int slot) {
        return 1 + Abilities.COOLDOWNS[slot] / 300;
    }

    static void cast(ServerPlayerEntity player, ElementState.Data data, int slot) {
        PENDING.put(player.getUuid(), slot);
        LAST.put(player.getUuid(), slot);
        add(player, data, slot, gain(slot));
    }

    static void hit(ServerPlayerEntity player, ElementState.Data data) {
        Integer slot = PENDING.remove(player.getUuid());
        if (slot != null) {
            add(player, data, slot, gain(slot));
        }
    }

    /** Эссенция питает навык, который применяли последним. Вернёт false, если он уже на высшем уровне. */
    static boolean essence(ServerPlayerEntity player, ElementState.Data data, Element element) {
        int slot = LAST.getOrDefault(player.getUuid(), 0);
        if (level(data.skills[slot]) >= MAX) {
            player.sendMessage(Text.translatable("message.minevia_elements.essence_max"), true);
            return false;
        }
        add(player, data, slot, element == data.element ? ESSENCE_XP * 2 : ESSENCE_XP);
        Abilities.sound(player, Sounds.WHEEL, 1.4F);
        MineviaElements.sync(player);
        return true;
    }

    static void forget(UUID id) {
        PENDING.remove(id);
        LAST.remove(id);
    }

    private static void add(ServerPlayerEntity player, ElementState.Data data, int slot, int amount) {
        int before = level(data.skills[slot]);
        data.skills[slot] += amount;
        ElementState.get(player.getServer()).markDirty();
        int after = level(data.skills[slot]);
        if (after > before) {
            String key = switch (slot) {
                case Abilities.PATH_SLOT -> data.element.pathKey(Math.max(1, data.path));
                case Abilities.PATH_SECOND_SLOT -> data.element.pathKey(Math.max(1, data.path)) + ".second";
                default -> data.element.abilityKey(slot);
            };
            player.sendMessage(Text.translatable("message.minevia_elements.skill_up", Text.translatable(key), after), true);
            Abilities.sound(player, Sounds.SEAL_BREAK, 1.6F);
            MineviaElements.sync(player);
        }
    }
}
