package local.minevia.elements.client;

import local.minevia.elements.Element;
import local.minevia.elements.ElementMob;
import local.minevia.elements.MineviaElements;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Духи стихий это анимированные 3D-модели, как способности и стражи. Голем шагает в такт ходьбе, остальные живут сами. */
final class ElementMobRenderer extends EntityRenderer<ElementMob> {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private static final int HURT_TINT = 0xFF9090;
    /** Модель голема проходит полный шаг за столько единиц ходьбы. */
    private static final float STRIDE = 4.5F;

    ElementMobRenderer(EntityRendererFactory.Context context) {
        super(context);
        shadowRadius = 0.5F;
    }

    @Override
    public Identifier getTexture(ElementMob entity) {
        return WHITE;
    }

    @Override
    public void render(ElementMob mob, float yaw, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        Element element = mob.element();
        SpellMesh mesh = SpellMesh.get("mob_" + element.id());
        if (mesh == null) {
            return;
        }
        float age = mob.age + delta;
        float body = MathHelper.lerpAngleDegrees(delta, mob.prevBodyYaw, mob.bodyYaw);
        float size = mob.getScale();
        int tint = mob.hurtTime > 0 ? HURT_TINT : 0xFFFFFF;
        float phase = switch (element) {
            case EARTH -> mob.limbAnimator.getPos(delta) / STRIDE * mesh.frames();
            case FIRE -> age / 18 * mesh.frames();
            case WATER -> age / 26 * mesh.frames();
            case AIR -> age / 13 * mesh.frames();
            default -> throw new IllegalStateException("Природная стихия: " + element);
        };
        boolean solid = element == Element.EARTH;
        RenderLayer layer = solid ? RenderLayer.getEntitySolid(WHITE) : ShaderCompat.glow();
        int shown = solid ? light : LightmapTextureManager.MAX_LIGHT_COORDINATE;
        SpellMesh.Surface surface = element == Element.WATER ? SpellMesh.Surface.WET : SpellMesh.Surface.PLAIN;
        matrices.push();
        if (element == Element.FIRE || element == Element.AIR) {
            matrices.translate(0, Math.sin(age * 0.12) * 0.08, 0);
        }
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-body));
        matrices.scale(size, size, size);
        mesh.draw(matrices.peek(), consumers.getBuffer(layer), phase, true, tint, 1.0F, shown, surface);
        matrices.pop();
    }
}
