package local.minevia.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/** Что делают комбо второго и третьего ряда и цепочки одного игрока. Удары здесь без меток, иначе комбо запускали бы друг друга. */
final class ComboMoves {
    private static final int STORM_BLUE = 0xBFD8FF;
    private static final int PLASMA = 0xFFB060;

    /** Что происходит с врагами в точке падения снаряда. */
    private interface Landing {
        void at(Vec3d point);
    }

    private ComboMoves() {
    }

    static void team(Combos.Combo combo, ServerPlayerEntity player, Vec3d at, int level) {
        switch (combo) {
            case GEYSERS -> geysers(player, at, level);
            case FIRE_RAIN -> fireRain(player, at, level);
            case VOLCANO -> volcano(player, at, level);
            case BLIZZARD -> blizzard(player, at, level);
            case MUDFLOW -> mudflow(player, at, level);
            case HAIL -> hail(player, at, level);
            case STEAM_BLAST -> steamBlast(player, at, level);
            case PLASMA_STORM -> plasma(player, at, level);
            case OBSIDIAN -> obsidian(player, at, level);
            case ICE_STORM -> iceStorm(player, at, level);
            case TSUNAMI -> tsunami(player, at, level);
            case GRAVITY -> gravity(player, at, level);
            default -> {
            }
        }
    }

    static void solo(Combos.Solo solo, ServerPlayerEntity player, int level) {
        if (!solo.element.isNatural()) { StyleCombos.solo(solo, player, level); return; }
        switch (solo) {
            case SUPERNOVA -> supernova(player, level);
            case NAPALM -> napalm(player, level);
            case CROWN -> crown(player, level);
            case TIDE -> tide(player, level);
            case LIVING_WATER -> livingWater(player, level);
            case FROZEN_GRIP -> frozenGrip(player, level);
            case STONE_FOREST -> stoneForest(player, level);
            case TITAN_STEP -> titanStep(player, level);
            case LANDSLIDE -> landslide(player, level);
            case DEATH_WIND -> deathWind(player, level);
            case RAZOR_RING -> razorRing(player, level);
            case SHOCKWAVE -> shockwave(player, level);
        }
    }

    private static Vec3d ground(ServerWorld world, Vec3d at) {
        double ground = Spells.groundAt(world, at.add(0, 2, 0));
        return Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
    }

    private static void slam(ServerPlayerEntity player, Vec3d at, double radius, float damage, double throwUp) {
        for (LivingEntity near : Abilities.livingAt(player, at, radius)) {
            Abilities.strike(player, near, damage);
            Vec3d away = near.getPos().subtract(at);
            Vec3d flat = new Vec3d(away.x, 0, away.z);
            Abilities.push(near, (flat.lengthSquared() < 0.01 ? Vec3d.ZERO : flat.normalize().multiply(throwUp * 0.7)).add(0, throwUp, 0));
        }
    }

    /** Снаряды один за другим падают с неба в случайные точки круга. */
    private static void rain(ServerPlayerEntity player, Vec3d at, SpellKind kind, int count, double radius, float size, int tint, Landing landing) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = ground(world, at);
        Effects.repeat(world, count, 3, step -> {
            double angle = world.random.nextDouble() * Math.PI * 2;
            double distance = Math.sqrt(world.random.nextDouble()) * radius;
            Vec3d spot = ground(world, base.add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance));
            Vec3d fall = new Vec3d(0.12, -1.1, 0.07);
            SpellEntity drop = SpellEntity.spawn(world, kind, spot.subtract(fall.multiply(14)), size, 16).facing(fall).tint(tint);
            drop.setVelocity(fall);
            drop.logic(self -> {
                self.setPosition(self.getPos().add(fall));
                if (self.age >= 14) {
                    landing.at(spot);
                    self.discard();
                }
            });
            return true;
        });
    }

    // ------------------------------------------------------------------ команда: удар по площади

    /** Кипяток: кругом бьют струи кипящей воды. */
    private static void geysers(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = ground(world, at);
        Abilities.soundAt(world, base, Sounds.STEAM, 0.8F);
        for (int i = 0; i < 6; i++) {
            double angle = i / 6.0 * Math.PI * 2;
            Vec3d spot = ground(world, base.add(Math.cos(angle) * 3.5, 0, Math.sin(angle) * 3.5));
            Effects.later(world, i * 3, () -> {
                SpellEntity.spawn(world, SpellKind.WATER_GEYSER, spot, 0.9F, 26);
                Abilities.soundAt(world, spot, Sounds.WATER_HIT, 0.8F);
                slam(player, spot.add(0, 1, 0), 2.4, 4 + level, 0.8);
            });
        }
        Combos.steamCloud(player, base.add(0, 1, 0), level);
    }

    private static void fireRain(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.soundAt(world, at, Sounds.FIRE_CHARGE, 0.7F);
        rain(player, at, SpellKind.FIREBALL, 16, 7, 0.7F, 0xFFFFFF, spot -> {
            SpellEntity.spawn(world, SpellKind.FIRE_BURST, spot.add(0, 0.5, 0), 0.8F, 17);
            Abilities.soundAt(world, spot, Sounds.FIRE_BLAST, 1.3F);
            for (LivingEntity near : Abilities.livingAt(player, spot, 2.4)) {
                Abilities.strike(player, near, 3 + level);
                near.setOnFireFor(4);
            }
        });
    }

    /** Вулкан: столб магмы и раскалённые камни, которые разлетаются по дуге. */
    private static void volcano(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = ground(world, at);
        Abilities.soundAt(world, base, Sounds.EARTH_QUAKE, 0.7F);
        SpellEntity.spawn(world, SpellKind.MAGMA_GEYSER, base, 2.0F, 34);
        slam(player, base.add(0, 1, 0), 4, 8 + level * 2, 1.0);
        Combos.magmaPool(player, base, level + 5);
        for (int i = 0; i < 7; i++) {
            double angle = i / 7.0 * Math.PI * 2;
            Vec3d[] velocity = {new Vec3d(Math.cos(angle) * 0.45, 0.9, Math.sin(angle) * 0.45)};
            Set<UUID> struck = new HashSet<>();
            SpellEntity stone = SpellEntity.spawn(world, SpellKind.MAGMA_BOULDER, base.add(0, 2, 0), 0.6F, 70);
            stone.setVelocity(velocity[0]);
            stone.logic(self -> {
                velocity[0] = velocity[0].add(0, -0.06, 0);
                self.setVelocity(velocity[0]);
                boolean ended = Spells.fly(self, player, 0.8, self.age > 4, struck, (point, near) -> {
                    Abilities.strike(player, near, 5 + level);
                    near.setOnFireFor(5);
                    return true;
                });
                if (ended) {
                    SpellEntity.spawn(world, SpellKind.FIRE_BURST, self.getPos(), 0.7F, 17);
                    Abilities.soundAt(world, self.getPos(), Sounds.EARTH_HIT, 1.2F);
                    self.discard();
                }
            });
        }
    }

    private static void blizzard(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = ground(world, at);
        Abilities.soundAt(world, base, Sounds.ICE_FORM, 0.6F);
        SpellEntity.spawn(world, SpellKind.MIST, base, 5.0F, 110);
        rain(player, at, SpellKind.ICE_BOLT, 18, 6.5, 1.0F, 0xFFFFFF, spot -> {
            SpellEntity.spawn(world, SpellKind.WATER_SPLASH, spot, 0.5F, 15);
            Abilities.soundAt(world, spot, Sounds.ICE_FORM, 1.4F);
            for (LivingEntity near : Abilities.livingAt(player, spot, 2.2)) {
                Abilities.strike(player, near, 3 + level);
                Abilities.debuff(near, StatusEffects.SLOWNESS, 60, 3);
                near.setFrozenTicks(160);
            }
        });
    }

    /** Сель: поток грязи идёт от игрока через цель и тащит всех с собой. */
    private static void mudflow(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d to = at.subtract(player.getPos());
        Vec3d flat = new Vec3d(to.x, 0, to.z);
        Vec3d forward = flat.lengthSquared() < 0.1 ? Spells.flatLook(player) : flat.normalize();
        Vec3d start = ground(world, at.subtract(forward.multiply(3)));
        Abilities.soundAt(world, start, Sounds.WATER_WAVE, 0.7F);
        Set<UUID> struck = new HashSet<>();
        Effects.repeat(world, 8, 3, step -> {
            Vec3d spot = ground(world, start.add(forward.multiply(step * 2.0)));
            SpellEntity.spawn(world, SpellKind.MUD_POOL, spot, 2.6F, 90);
            SpellEntity.spawn(world, SpellKind.DUST_PUFF, spot, 1.6F, 18).tint(0x6A5238);
            for (LivingEntity near : Abilities.livingAt(player, spot.add(0, 1, 0), 3.2)) {
                Abilities.push(near, forward.multiply(0.8).add(0, 0.2, 0));
                Abilities.debuff(near, StatusEffects.SLOWNESS, 80, 3);
                if (struck.add(near.getUuid())) {
                    Abilities.strike(player, near, 6 + level * 1.5F);
                }
            }
            return true;
        });
    }

    private static void hail(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.soundAt(world, at, Sounds.EARTH_THROW, 0.7F);
        rain(player, at, SpellKind.BOULDER, 14, 6.5, 0.6F, 0x8A7F70, spot -> {
            SpellEntity.spawn(world, SpellKind.ROCK_BURST, spot.add(0, 0.5, 0), 0.7F, 18).tint(0x8A7F70);
            Abilities.soundAt(world, spot, Sounds.EARTH_HIT, 1.2F);
            for (LivingEntity near : Abilities.livingAt(player, spot, 2.3)) {
                Abilities.strike(player, near, 4 + level);
                Abilities.debuff(near, StatusEffects.SLOWNESS, 30, 1);
            }
        });
    }

    // ------------------------------------------------------------------ команда: удар пути или супер-навыка

    private static void steamBlast(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = ground(world, at);
        SpellEntity.spawn(world, SpellKind.DANGER_RING, base.add(0, 0.08, 0), 7.0F, 16).tint(0xE8F6FF);
        Abilities.soundAt(world, base, Sounds.STEAM, 0.6F);
        Effects.later(world, 16, () -> {
            SpellEntity.spawn(world, SpellKind.FIRE_BURST, base.add(0, 1, 0), 3.4F, 17);
            SpellEntity.spawn(world, SpellKind.WIND_BURST, base.add(0, 1, 0), 8.0F, 14);
            SpellEntity.spawn(world, SpellKind.STEAM_CLOUD, base, 5.0F, 110);
            Abilities.soundAt(world, base, Sounds.FIRE_BLAST, 0.6F);
            slam(player, base.add(0, 1, 0), 8, 18 + level * 3, 1.1);
        });
    }

    /** Плазма: шар раскалённого воздуха шесть секунд бьёт дугами по всем вокруг. */
    private static void plasma(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.soundAt(world, at, Sounds.LIGHTNING, 0.7F);
        SpellEntity.spawn(world, SpellKind.ORB, at.add(0, 1, 0), 2.2F, 120).tint(PLASMA).logic(self -> {
            if (self.age % 12 != 0) {
                return;
            }
            for (LivingEntity near : Abilities.livingAt(player, self.getPos(), 9)) {
                Paths.bolt(world, self.getPos(), near.getBoundingBox().getCenter(), PLASMA);
                Abilities.strike(player, near, 4 + level);
                near.setOnFireFor(3);
            }
            Abilities.soundAt(world, self.getPos(), Sounds.LIGHTNING, 1.4F);
        });
    }

    /** Обсидиан: враги оказываются в каменном кольце, которое через три секунды взрывается. */
    private static void obsidian(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = ground(world, at);
        Abilities.soundAt(world, base, Sounds.EARTH_WALL, 0.7F);
        Spells.ring(world, SpellKind.STONE_SPIKE, base, 3.2, 14, 62, 1.5F, 0x2A2030);
        SpellEntity.spawn(world, SpellKind.MAGMA_POOL, base, 3.0F, 62);
        for (LivingEntity near : Abilities.livingAt(player, base.add(0, 1, 0), 4.2)) {
            Abilities.debuff(near, StatusEffects.SLOWNESS, 60, 8);
            near.setOnFireFor(3);
        }
        Effects.later(world, 60, () -> {
            SpellEntity.spawn(world, SpellKind.ROCK_BURST, base.add(0, 1, 0), 3.0F, 18).tint(0x2A2030);
            SpellEntity.spawn(world, SpellKind.FIRE_BURST, base.add(0, 1, 0), 2.6F, 17);
            Abilities.soundAt(world, base, Sounds.EARTH_HIT, 0.6F);
            slam(player, base.add(0, 1, 0), 5.5, 16 + level * 3, 0.9);
        });
    }

    /** Ледяной шторм: копья вылетают по спирали из одной точки во все стороны. */
    private static void iceStorm(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = at.add(0, 1, 0);
        Abilities.soundAt(world, center, Sounds.ICE_FORM, 0.6F);
        SpellEntity.spawn(world, SpellKind.TORNADO, ground(world, at), 1.3F, 70).tint(STORM_BLUE);
        Effects.repeat(world, 24, 2, step -> {
            double angle = step * 0.82;
            Vec3d velocity = new Vec3d(Math.cos(angle), 0.03, Math.sin(angle)).multiply(1.15);
            Set<UUID> struck = new HashSet<>();
            SpellEntity spear = SpellEntity.spawn(world, SpellKind.ICE_BOLT, center, 1.0F, 18).facing(velocity);
            spear.setVelocity(velocity);
            spear.logic(self -> {
                boolean ended = Spells.fly(self, player, 0.7, true, struck, (point, near) -> {
                    Abilities.strike(player, near, 4 + level);
                    Abilities.debuff(near, StatusEffects.SLOWNESS, 60, 3);
                    near.setFrozenTicks(160);
                    return true;
                });
                if (ended) {
                    self.discard();
                }
            });
            return true;
        });
    }

    private static void tsunami(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d to = at.subtract(player.getPos());
        Vec3d flat = new Vec3d(to.x, 0, to.z);
        Vec3d forward = flat.lengthSquared() < 0.1 ? Spells.flatLook(player) : flat.normalize();
        Vec3d start = ground(world, at.subtract(forward.multiply(6)));
        Abilities.soundAt(world, start, Sounds.WATER_WAVE, 0.6F);
        Set<UUID> struck = new HashSet<>();
        SpellEntity wave = SpellEntity.spawn(world, SpellKind.WATER_WAVE, start, 3.2F, 60).facing(forward);
        wave.setVelocity(forward.multiply(0.7));
        wave.logic(self -> {
            Vec3d spot = self.getPos();
            double ground = Spells.groundAt(world, spot.add(0, 1, 0));
            double dy = Double.isNaN(ground) ? 0 : Math.max(-0.5, Math.min(0.5, ground - spot.y));
            self.setVelocity(forward.multiply(0.7).add(0, dy, 0));
            self.setPosition(spot.add(self.getVelocity()));
            for (LivingEntity near : Abilities.livingAt(player, self.getPos().add(0, 1.5, 0), 8)) {
                Abilities.push(near, forward.multiply(0.95).add(0, 0.3, 0));
                if (struck.add(near.getUuid())) {
                    Abilities.strike(player, near, 12 + level * 2);
                }
            }
        });
    }

    /** Гравитация: враги взлетают в воздух и через полторы секунды падают с ударом. */
    private static void gravity(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d base = ground(world, at);
        Abilities.soundAt(world, base, Sounds.VACUUM, 0.7F);
        SpellEntity.spawn(world, SpellKind.VACUUM, base.add(0, 4, 0), 6.0F, 32);
        Spells.ring(world, SpellKind.GROUND_SLAB, base, 4.0, 12, 32, 1.3F, 0x8A7F70);
        Effects.repeat(world, 30, 1, step -> {
            for (LivingEntity near : Abilities.livingAt(player, base.add(0, 3, 0), 7)) {
                Vec3d in = base.add(0, 6, 0).subtract(near.getPos());
                Abilities.push(near, in.multiply(0.12));
                near.fallDistance = 0;
            }
            return true;
        });
        Effects.later(world, 30, () -> {
            for (LivingEntity near : Abilities.livingAt(player, base.add(0, 4, 0), 7)) {
                Abilities.strike(player, near, 16 + level * 3);
                Abilities.push(near, new Vec3d(0, -2.4, 0));
            }
            SpellEntity.spawn(world, SpellKind.DUST_PUFF, base, 4.0F, 18).tint(0x8A7F70);
            Abilities.soundAt(world, base, Sounds.EARTH_QUAKE, 0.8F);
        });
    }

    // ------------------------------------------------------------------ цепочки одного игрока

    /** Броня, потом кольцо: вокруг игрока вспыхивает волна огня. */
    private static void supernova(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d at = player.getPos().add(0, 1, 0);
        SpellEntity.spawn(world, SpellKind.FIRE_BURST, at, 3.0F, 17);
        Abilities.soundAt(world, at, Sounds.FIRE_BLAST, 0.7F);
        slam(player, at, 7, 10 + level * 2, 0.8);
        for (LivingEntity near : Abilities.livingAt(player, at, 7)) {
            near.setOnFireFor(8);
        }
    }

    /** Шар, потом огнемёт: горящая полоса на земле вдоль взгляда. */
    private static void napalm(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d forward = Spells.flatLook(player);
        Vec3d start = player.getPos();
        Effects.repeat(world, 6, 3, step -> {
            Vec3d spot = ground(world, start.add(forward.multiply(3 + step * 2.6)));
            SpellEntity.spawn(world, SpellKind.MAGMA_POOL, spot, 1.8F, 110).logic(self -> {
                if (self.age % 10 == 0) {
                    for (LivingEntity near : Abilities.monstersAt(player, spot.add(0, 1, 0), 2.4)) {
                        Abilities.strike(player, near, 1 + level * 0.5F);
                        near.setOnFireFor(5);
                    }
                }
            });
            return true;
        });
    }

    /** Кольцо, потом большой шар: восемь огненных шаров разлетаются во все стороны. */
    private static void crown(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_CAST, 0.8F);
        for (int i = 0; i < 8; i++) {
            double angle = i / 8.0 * Math.PI * 2;
            Vec3d velocity = new Vec3d(Math.cos(angle), 0.02, Math.sin(angle)).multiply(0.85);
            Set<UUID> struck = new HashSet<>();
            SpellEntity ball = SpellEntity.spawn(world, SpellKind.FIREBALL, player.getPos().add(0, 1.2, 0), 0.7F, 30).facing(velocity);
            ball.setVelocity(velocity);
            ball.logic(self -> {
                boolean ended = Spells.fly(self, player, 0.7, true, struck, (point, near) -> {
                    Abilities.strike(player, near, 6 + level);
                    near.setOnFireFor(5);
                    return true;
                });
                if (ended) {
                    SpellEntity.spawn(world, SpellKind.FIRE_BURST, self.getPos(), 0.8F, 17);
                    self.discard();
                }
            });
        }
    }

    /** Волна, потом поток: впереди одна за другой бьют три водяные струи. */
    private static void tide(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d forward = Spells.flatLook(player);
        Vec3d start = player.getPos();
        Effects.repeat(world, 3, 6, step -> {
            Vec3d spot = ground(world, start.add(forward.multiply(5 + step * 4)));
            SpellEntity.spawn(world, SpellKind.WATER_GEYSER, spot, 1.2F, 26);
            Abilities.soundAt(world, spot, Sounds.WATER_HIT, 0.8F);
            slam(player, spot.add(0, 1, 0), 3, 6 + level, 1.0);
            return true;
        });
    }

    /** Лечение, потом волна: друзья рядом получают восстановление на десять секунд. */
    private static void livingWater(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Box area = player.getBoundingBox().expand(10);
        Abilities.sound(player, Sounds.WATER_HEAL, 1.2F);
        for (PlayerEntity ally : world.getEntitiesByClass(PlayerEntity.class, area, PlayerEntity::isAlive)) {
            Abilities.buff(ally, StatusEffects.REGENERATION, 200, level >= 4 ? 1 : 0);
            Abilities.buff(ally, StatusEffects.SPEED, 200, 0);
            SpellEntity.spawn(world, SpellKind.HEAL_SPIRAL, ally.getPos(), 1.3F, 34).owner(ally).tint(0x6FE3D2).logic(self -> self.setPosition(ally.getPos()));
        }
    }

    /** Плеть, потом лёд: все враги вокруг притягиваются к игроку и вмерзают. */
    private static void frozenGrip(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = player.getPos();
        Abilities.soundAt(world, center, Sounds.ICE_FORM, 0.7F);
        for (LivingEntity near : Abilities.monstersAt(player, center, 10)) {
            Vec3d pull = center.subtract(near.getPos());
            Abilities.push(near, pull.multiply(0.22).add(0, 0.25, 0));
            Abilities.strike(player, near, 5 + level);
            Abilities.debuff(near, StatusEffects.SLOWNESS, 100, 6);
            near.setFrozenTicks(220);
        }
        Effects.later(world, 8, () -> Spells.ring(world, SpellKind.ICE_SHARD, center, 3.0, 12, 80, 1.3F, 0xFFFFFF));
    }

    /** Толчок, потом шипы: вокруг игрока вырастают два кольца шипов. */
    private static void stoneForest(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = player.getPos();
        int tint = Spells.groundColor(world, center);
        Abilities.soundAt(world, center, Sounds.EARTH_SPIKE, 0.7F);
        for (int ring = 0; ring < 2; ring++) {
            double radius = 4 + ring * 3;
            Effects.later(world, ring * 6, () -> {
                Spells.ring(world, SpellKind.STONE_SPIKE, center, radius, (int) radius * 3, 60, 1.3F, tint);
                slam(player, center.add(0, 1, 0), radius + 1, 7 + level * 1.5F, 0.8);
            });
        }
    }

    /** Броня, потом толчок: три каменных кулака бьют вокруг игрока. */
    private static void titanStep(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d center = player.getPos();
        int tint = Spells.groundColor(world, center);
        Effects.repeat(world, 3, 5, step -> {
            double angle = step / 3.0 * Math.PI * 2 + 0.6;
            Vec3d spot = ground(world, center.add(Math.cos(angle) * 4, 0, Math.sin(angle) * 4));
            SpellEntity.spawn(world, SpellKind.ROCK_FIST, spot, 1.5F, 34).tint(tint);
            Abilities.soundAt(world, spot, Sounds.EARTH_HIT, 0.8F);
            slam(player, spot.add(0, 1, 0), 3.4, 8 + level * 1.5F, 1.0);
            return true;
        });
    }

    /** Стена, потом глыба: впереди катятся пять каменных шаров. */
    private static void landslide(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d forward = Spells.flatLook(player);
        Vec3d across = new Vec3d(-forward.z, 0, forward.x);
        int tint = Spells.groundColor(world, player.getPos());
        Abilities.sound(player, Sounds.EARTH_THROW, 0.7F);
        for (int i = -2; i <= 2; i++) {
            Vec3d start = ground(world, player.getPos().add(forward.multiply(2)).add(across.multiply(i * 1.6))).add(0, 0.8, 0);
            Set<UUID> struck = new HashSet<>();
            SpellEntity rock = SpellEntity.spawn(world, SpellKind.BOULDER, start, 0.9F, 40).tint(tint);
            rock.setVelocity(forward.multiply(0.75));
            rock.logic(self -> {
                double ground = Spells.groundAt(world, self.getPos().add(0, 1, 0));
                double dy = Double.isNaN(ground) ? 0 : Math.max(-0.5, Math.min(0.5, ground + 0.8 - self.getY()));
                self.setVelocity(forward.multiply(0.75).add(0, dy, 0));
                self.setPosition(self.getPos().add(self.getVelocity()));
                for (LivingEntity near : Abilities.livingAt(player, self.getPos(), 1.6)) {
                    if (struck.add(near.getUuid())) {
                        Abilities.strike(player, near, 7 + level * 1.5F);
                        Abilities.push(near, forward.multiply(1.0).add(0, 0.5, 0));
                    }
                }
                if (self.age >= self.life() - 1) {
                    SpellEntity.spawn(world, SpellKind.ROCK_BURST, self.getPos(), 0.8F, 18).tint(tint);
                }
            });
        }
    }

    /** Рывок, потом пила: четыре диска разлетаются крестом. */
    private static void deathWind(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_SAW, 0.8F);
        for (int i = 0; i < 4; i++) {
            double angle = i / 4.0 * Math.PI * 2 + 0.78;
            Vec3d velocity = new Vec3d(Math.cos(angle), 0, Math.sin(angle)).multiply(1.0);
            Set<UUID> struck = new HashSet<>();
            SpellEntity saw = SpellEntity.spawn(world, SpellKind.WIND_SAW, player.getPos().add(0, 1.2, 0), 1.2F, 22).facing(velocity);
            saw.setVelocity(velocity);
            saw.logic(self -> {
                boolean ended = Spells.fly(self, player, 1.2, true, struck, (point, near) -> {
                    Abilities.strike(player, near, 6 + level);
                    return false;
                });
                if (ended) {
                    self.discard();
                }
            });
        }
    }

    /** Пила, потом смерч: вокруг игрока шесть секунд кружат три диска. */
    private static void razorRing(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_SAW, 1.2F);
        for (int i = 0; i < 3; i++) {
            int index = i;
            SpellEntity.spawn(world, SpellKind.WIND_SAW, player.getPos(), 1.1F, 120).logic(self -> {
                if (!player.isAlive()) {
                    self.discard();
                    return;
                }
                double angle = index / 3.0 * Math.PI * 2 + self.age * 0.26;
                Spells.hover(self, player.getPos().add(Math.cos(angle) * 3.2, 1.2, Math.sin(angle) * 3.2));
                if (self.age % 8 == 0) {
                    for (LivingEntity near : Abilities.livingAt(player, self.getPos(), 1.7)) {
                        Abilities.strike(player, near, 3 + level * 0.8F);
                    }
                }
            });
        }
    }

    /** Купол, потом рывок: воздух вокруг игрока резко расходится и сбивает всех с ног. */
    private static void shockwave(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d at = player.getPos().add(0, 1, 0);
        Abilities.soundAt(world, at, Sounds.AIR_GUST, 0.6F);
        SpellEntity.spawn(world, SpellKind.WIND_BURST, at, 9.0F, 14);
        slam(player, at, 9, 7 + level * 1.5F, 1.3);
    }
}
