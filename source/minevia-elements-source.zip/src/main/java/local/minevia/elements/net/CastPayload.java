package local.minevia.elements.net;

import local.minevia.elements.MineviaElements;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

public record CastPayload(int slot) implements CustomPayload {
    public static final Id<CastPayload> ID = new Id<>(Identifier.of(MineviaElements.MOD_ID, "cast"));
    public static final PacketCodec<RegistryByteBuf, CastPayload> CODEC =
            PacketCodec.tuple(PacketCodecs.VAR_INT, CastPayload::slot, CastPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
