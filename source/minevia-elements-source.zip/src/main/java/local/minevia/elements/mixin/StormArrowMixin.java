package local.minevia.elements.mixin;

import local.minevia.elements.StormArrow;
import local.minevia.elements.Weapons;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Полный выстрел разряжается один раз; отметка переживает выгрузку чанка. */
@Mixin(PersistentProjectileEntity.class)
abstract class StormArrowMixin implements StormArrow {
    @Unique
    private static final TrackedData<Boolean> MINEVIA_STORM = DataTracker.registerData(PersistentProjectileEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    @Unique
    private boolean mineviaCharged;

    @Inject(method = "initDataTracker", at = @At("TAIL"))
    private void mineviaTracker(DataTracker.Builder builder, CallbackInfo ci) {
        builder.add(MINEVIA_STORM, false);
    }

    @Override
    public void mineviaStorm(boolean charged) {
        ((PersistentProjectileEntity) (Object) this).getDataTracker().set(MINEVIA_STORM, true);
        mineviaCharged = charged;
    }

    @Unique
    private boolean mineviaSpecial() {
        return ((PersistentProjectileEntity) (Object) this).getDataTracker().get(MINEVIA_STORM);
    }

    @Inject(method = "canHit(Lnet/minecraft/entity/Entity;)Z", at = @At("HEAD"), cancellable = true)
    private void mineviaAlly(Entity target, CallbackInfoReturnable<Boolean> cir) {
        if (mineviaSpecial() && !Weapons.arrowCanHit((Entity) (Object) this, target)) {
            cir.setReturnValue(false);
        }
    }

    @Redirect(method = "onEntityHit", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;damage(Lnet/minecraft/entity/damage/DamageSource;F)Z"))
    private boolean mineviaChain(Entity target, DamageSource source, float amount) {
        if (mineviaSpecial() && !Weapons.arrowCanHit((Entity) (Object) this, target)) {
            return false;
        }
        boolean hit = target.damage(source, amount);
        if (hit && mineviaCharged && target instanceof LivingEntity living) {
            mineviaCharged = false;
            Weapons.chain((PersistentProjectileEntity) (Object) this, living);
        }
        return hit;
    }

    @Redirect(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V"))
    private void mineviaNoParticles(World world, ParticleEffect effect, double x, double y, double z, double vx, double vy, double vz) {
        if (!mineviaSpecial()) {
            world.addParticle(effect, x, y, z, vx, vy, vz);
        }
    }

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void mineviaSave(NbtCompound nbt, CallbackInfo ci) {
        nbt.putBoolean("MineviaStorm", mineviaSpecial());
        nbt.putBoolean("MineviaCharged", mineviaCharged);
    }

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void mineviaLoad(NbtCompound nbt, CallbackInfo ci) {
        ((PersistentProjectileEntity) (Object) this).getDataTracker().set(MINEVIA_STORM, nbt.getBoolean("MineviaStorm"));
        mineviaCharged = nbt.getBoolean("MineviaCharged");
    }
}
