package local.minevia.elements;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Натяжение лука и дальние приёмы. */
final class StyleBow {
    private static final java.util.Set<java.util.UUID> USING = new java.util.HashSet<>();
    private StyleBow() { }

    static void cast(ServerPlayerEntity p, int slot, int path, int level) {
        Abilities.sound(p, Sounds.BOW_SHOT, 1.2F);
        switch (slot) {
            case 0 -> draw(p, level);
            case 2 -> { fan(p, level); if (level >= 5) Effects.later(p.getServerWorld(), 6, () -> fan(p, level)); }
            case 1 -> {
                trap(p, SpellKind.BOW_RETREAT, p.getPos(), level, true);
                if (level >= 3) { Abilities.buff(p, StatusEffects.SPEED, 65, 1); trap(p, SpellKind.BOW_RETREAT, p.getPos().add(Spells.flatLook(p).multiply(-2)), level, true); }
                if (level >= 5) Abilities.buff(p, StatusEffects.INVISIBILITY, 45, 0);
                StyleSupport.dash(p, SpellKind.BOW_RETREAT, 6, -1.2, 0);
            }
            case 3 -> { Vec3d at = Skills.aimGround(p, 35); rain(p, at, level, false);
                if (level >= 3) StyleSupport.field(p, SpellKind.BOW_TRAP, at, 3, 65, 10, self -> StyleSupport.area(p, at, 5, 0, e -> StyleSupport.root(e, 15)));
                if (level >= 5) Effects.later(p.getServerWorld(), 65, () -> rain(p, at, level, true));
            }
            case 4 -> StyleSupport.shot(p, SpellKind.BOW_HARPOON, Spells.muzzle(p, 1.5),
                    p.getRotationVector().multiply(2.3), 0.9F, 45, false, (self, e) -> {
                StyleSupport.hit(p, e, 5 + level);
                if (level >= 3) StyleSupport.root(e, 50);
                if (level >= 5) StyleSupport.area(p, e.getPos(), 4, 5, enemy -> Abilities.push(enemy, e.getPos().subtract(enemy.getPos()).normalize().multiply(0.8)));
                StyleSupport.model(p, SpellKind.BOW_HARPOON, e.getPos(), 0.7F, 16, tether -> {
                    tether.setPosition(e.getBoundingBox().getCenter());
                    if (e.isAlive() && Abilities.canHit(e, p))
                        Abilities.push(e, p.getPos().subtract(e.getPos()).normalize().multiply(0.75).add(0, 0.12, 0));
                });
                impact(p, e);
            }, null);
            case 5 -> {
                if (path == 1) StyleSupport.held(p, 5, SpellKind.BOW_PIERCING, level, Sounds.BOW_SHOT, true,
                        (self, e) -> { StyleSupport.hit(p, e, 12 + level * 2); impact(p, e); }, null);
                else SkillVariants.huntBrand(p, level);
            }
            case 6 -> {
                if (path == 1) {
                    Vec3d origin = p.getPos();
                    StyleSupport.follow(p, SpellKind.BOW_FOCUS, 120, self -> {
                        if (p.squaredDistanceTo(origin) > 1) { self.discard(); return; }
                        if (self.age % 20 == 0) {
                            LivingEntity e = Abilities.aim(p, 75);
                            if (e != null) {
                                StyleSupport.shot(p, SpellKind.BOW_AIMED, Spells.muzzle(p, 1),
                                        e.getBoundingBox().getCenter().subtract(p.getEyePos()).normalize().multiply(3.5),
                                        0.75F, 35, false, (arrow, target) -> StyleSupport.hit(p, target, 5 + level), null);
                            }
                        }
                    });
                } else SkillVariants.thicket(p, level);
            }
            case 7 -> trap(p, SpellKind.BOW_TRAP, Skills.aimGround(p, 24), level, false);
            case 8 -> StyleSupport.held(p, 8, SpellKind.BOW_EXPLOSIVE, level, Sounds.BOW_SHOT, false,
                    (self, e) -> StyleSupport.hit(p, e, 3 + level), at -> {
                        StyleSupport.area(p, at, 4, 10 + level * 1.5F,
                                e -> Abilities.push(e, e.getPos().subtract(at).normalize().multiply(0.8)));
                        Flourish.blast(p.getServerWorld(), at, 4, 0xFF7A30);
                        Abilities.soundAt(p.getServerWorld(), at, Sounds.BOW_HIT, 0.6F);
                    });
            case 9 -> constellation(p, level);
        }
    }

    static boolean beginUse(ServerPlayerEntity p) {
        if (Control.active(p)) return false;
        USING.add(p.getUuid());
        try { Abilities.cast(p, 0); } finally { USING.remove(p.getUuid()); }
        return Control.active(p);
    }

    static void releaseUse(ServerPlayerEntity p) { Control.releaseSlot(p, 0); }

    private static void draw(ServerPlayerEntity p, int level) {
        SpellEntity held = StyleSupport.model(p, SpellKind.ARROW_POWER, p.getEyePos(), 0, 300, self -> {
            if (!Control.holding(p, self)) { self.discard(); return; }
            self.setPosition(p.getEyePos());
            self.setSize(0);
        });
        var drawTag = StyleGear.data(p.getMainHandStack());
        drawTag.putLong("style_draw_start", p.getWorld().getTime());
        p.getMainHandStack().set(net.minecraft.component.DataComponentTypes.CUSTOM_DATA, net.minecraft.component.type.NbtComponent.of(drawTag));
        if (USING.contains(p.getUuid())) p.setCurrentHand(net.minecraft.util.Hand.MAIN_HAND);
        Control.hold(p, 0, held, 1, () -> {
            float charge = StyleGearItem.draw(p.getMainHandStack(), held.age);
            held.discard();
            var tag = StyleGear.data(p.getMainHandStack()); tag.remove("style_draw_start");
            p.getMainHandStack().set(net.minecraft.component.DataComponentTypes.CUSTOM_DATA, net.minecraft.component.type.NbtComponent.of(tag));
            p.clearActiveItem();
            if (charge < 0.1F) return;
            Gestures.play(p, Gesture.STYLE_BOW_RELEASE, level);
            int count = level >= 3 ? 2 : 1;
            boolean[] finale = {false};
            for (int i = 0; i < count; i++) {
                Vec3d direction = p.getRotationVector().rotateY(count == 1 ? 0 : (i == 0 ? -0.025F : 0.025F));
                powerArrow(p, level, charge, Spells.muzzle(p, 0.8), direction, false, finale);
            }
            Abilities.sound(p, Sounds.BOW_SHOT, 0.9F + charge * 0.4F);
        });
    }

    private static void powerArrow(ServerPlayerEntity p, int level, float charge, Vec3d start, Vec3d direction, boolean falling, boolean[] finale) {
        var struck = new java.util.HashSet<java.util.UUID>();
        SpellEntity shot = StyleSupport.model(p, SpellKind.ARROW_POWER, start, 1.5F * (falling ? 2.4F : 0.45F + charge * 0.3F), 70, self -> {
            boolean done = Spells.fly(self, p, 1.5 * (falling ? 1.1 : 0.3), true, struck, (at, e) -> {
                StyleSupport.hit(p, e, (falling ? 16 : 4 + level * 1.6F) * charge);
                impact(p, e);
                Flourish.blast(p.getServerWorld(), at, falling ? 4 : 2, Element.BOW.color);
                return falling || level < 4 || struck.size() >= 2;
            });
            if (level >= 2 && self.age % 3 == 0) StyleSupport.model(p, SpellKind.ARROW_POWER, self.getPos(), 0.23F, 7, null).facing(direction);
            if (!falling && level >= 5 && charge >= 0.99F && !finale[0] && (done || !struck.isEmpty())) {
                finale[0] = true;
                Vec3d at = self.getPos();
                StyleSupport.model(p, SpellKind.DANGER_RING, at, 1.5F, 18, null);
                Effects.later(p.getServerWorld(), 14, () -> powerArrow(p, level, 1, at.add(0, 16, 0), new Vec3d(0, -1, 0), true, finale));
            }
            if (done || self.age == self.life() - 1) {
                Flourish.blast(p.getServerWorld(), self.getPos(), falling ? 4 : 2, Element.BOW.color);
                self.discard();
            }
        }).facing(direction);
        shot.setVelocity(direction.multiply((1.6 + level * 0.22) * charge * (falling ? 1.2 : 1)));
    }

    private static void impact(ServerPlayerEntity p, LivingEntity e) {
        Abilities.soundAt(p.getServerWorld(), e.getPos(), Sounds.BOW_HIT, 1);
    }

    private static void fan(ServerPlayerEntity p, int level) {
        Vec3d look = p.getRotationVector();
        for (int i = -3; i <= 3; i++) {
            Vec3d direction = look.rotateY(i * 0.12F).multiply(2.1);
            StyleSupport.shot(p, SpellKind.BOW_FAN, Spells.muzzle(p, 1.5), direction, 0.8F, 28, level >= 3,
                    (self, e) -> { StyleSupport.hit(p, e, 3 + level * 0.7F); if (level >= 3) Abilities.debuff(e, StatusEffects.SLOWNESS, 60, 1); impact(p, e); }, null);
        }
    }

    private static void trap(ServerPlayerEntity p, SpellKind kind, Vec3d at, int level, boolean explosive) {
        StyleSupport.model(p, kind, at, 1.4F, 240, self -> {
            if (self.age < 12) return;
            var targets = Abilities.livingAt(p, at.add(0, 0.5, 0), 1.8);
            if (targets.isEmpty()) return;
            if (explosive) StyleSupport.area(p, at, 3, 7 + level, e -> StyleSupport.root(e, 40));
            else {
                LivingEntity e = targets.get(0);
                StyleSupport.hit(p, e, 5 + level);
                StyleSupport.model(p, kind, e.getPos(), 1, 60, bind -> {
                    if (!e.isAlive() || !Abilities.canHit(e, p)) { bind.discard(); return; }
                    bind.setPosition(e.getPos()); StyleSupport.root(e, 6);
                });
            }
            Abilities.soundAt(p.getServerWorld(), at, Sounds.BOW_HIT, 0.8F);
            self.discard();
        });
    }

    private static void rain(ServerPlayerEntity p, Vec3d at, int level, boolean ultimate) {
        SpellKind kind = ultimate ? SpellKind.BOW_CELESTIAL : SpellKind.BOW_RAIN;
        if (ultimate) {
            StyleSupport.fall(p, kind, at, 6, 35, point -> {
                StyleSupport.area(p, point.add(0, 1, 0), 8, 28 + level * 4,
                        e -> { StyleSupport.root(e, 50); impact(p, e); });
                StyleSupport.field(p, kind, point.add(0, 3.4, 0), 4, 60, 15, self ->
                        StyleSupport.area(p, point.add(0, 1, 0), 5, 3 + level, null)).facing(new Vec3d(0, -1, 0));
            });
            return;
        }
        StyleSupport.field(p, SpellKind.DANGER_RING, at.add(0, 0.05, 0), 4.2F, 65, 4, self -> {
            double angle = self.age * 2.4;
            double r = 1 + (self.age % 5) * 0.8;
            Vec3d start = at.add(Math.cos(angle) * r, 12, Math.sin(angle) * r);
            StyleSupport.shot(p, kind, start, new Vec3d(0, -1.7, 0), 0.8F, 12, false,
                    (arrow, e) -> StyleSupport.hit(p, e, 4 + level), null);
        }).tint(Element.BOW.color);
    }

    private static void constellation(ServerPlayerEntity p, int level) {
        var struck = new java.util.HashSet<java.util.UUID>();
        Vec3d[] direction = {p.getRotationVector()};
        SpellEntity arrow = StyleSupport.model(p, SpellKind.BOW_CELESTIAL, Spells.muzzle(p, 1), 1.6F, 130, self -> {
            self.facing(self.getVelocity());
            boolean blocked = Spells.fly(self, p, 0.65, true, struck, (at, e) -> {
                StyleSupport.hit(p, e, (float) ((14 + level * 2) * Math.pow(0.88, struck.size() - 1)));
                StyleSupport.root(e, 30);
                impact(p, e);
                if (struck.size() >= 6) return true;
                LivingEntity next = Abilities.livingAt(p, e.getPos(), 18).stream()
                        .filter(target -> !struck.contains(target.getUuid()) && p.canSee(target))
                        .min(java.util.Comparator.comparingDouble(target -> target.squaredDistanceTo(e))).orElse(null);
                if (next == null) return true;
                direction[0] = next.getBoundingBox().getCenter().subtract(self.getPos()).normalize();
                self.setVelocity(direction[0].multiply(2.2));
                return false;
            });
            if (blocked) self.discard();
        });
        arrow.setVelocity(direction[0].multiply(2.2));
    }


}
