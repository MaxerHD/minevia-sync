package local.minevia.elements;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;

/** Энергетический лук работает с пустыми руками. */
final class StyleBow {
    private StyleBow() { }

    static void cast(ServerPlayerEntity p, int slot, int path, int level) {
        Abilities.sound(p, Sounds.BOW_SHOT, 1.2F);
        switch (slot) {
            case 0 -> StyleSupport.held(p, 0, SpellKind.BOW_AIMED, level, Sounds.BOW_SHOT, false,
                    (self, e) -> { StyleSupport.hit(p, e, (7 + level * 1.8F) * (self.size() / 0.8F)); impact(p, e); }, null);
            case 1 -> fan(p, level);
            case 2 -> {
                trap(p, SpellKind.BOW_RETREAT, p.getPos(), level, true);
                StyleSupport.dash(p, SpellKind.BOW_RETREAT, 6, -1.2, 0);
            }
            case 3 -> rain(p, Skills.aimGround(p, 35), level, false);
            case 4 -> StyleSupport.held(p, 4, SpellKind.BOW_HARPOON, level, Sounds.BOW_SHOT, false, (self, e) -> {
                StyleSupport.hit(p, e, 5 + level);
                StyleSupport.model(p, SpellKind.BOW_HARPOON, e.getPos(), 0.7F, 16, tether -> {
                    tether.setPosition(e.getBoundingBox().getCenter());
                    if (e.isAlive() && Abilities.canHit(e, p))
                        Abilities.push(e, p.getPos().subtract(e.getPos()).normalize().multiply(0.75).add(0, 0.12, 0));
                });
                impact(p, e);
            }, null);
            case 5 -> {
                if (path == 1) StyleSupport.held(p, 5, SpellKind.BOW_PIERCING, level, Sounds.BOW_SHOT, true,
                        (self, e) -> { StyleSupport.hit(p, e, 12 + level * 2); impact(p, e); }, null);
                else seekers(p, level);
            }
            case 6 -> {
                if (path == 1) {
                    Vec3d origin = p.getPos();
                    StyleSupport.follow(p, SpellKind.BOW_FOCUS, 120, self -> {
                        if (p.squaredDistanceTo(origin) > 1) { self.discard(); return; }
                        if (self.age % 20 == 0) {
                            LivingEntity e = Abilities.aim(p, 75);
                            if (e != null) {
                                StyleSupport.shot(p, SpellKind.BOW_FOCUS, Spells.muzzle(p, 1),
                                        e.getBoundingBox().getCenter().subtract(p.getEyePos()).normalize().multiply(3.5),
                                        0.75F, 35, false, (arrow, target) -> StyleSupport.hit(p, target, 5 + level), null);
                            }
                        }
                    });
                } else {
                    Vec3d at = Skills.aimGround(p, 24);
                    for (int i = 0; i < 5; i++) {
                        double a = i * Math.PI * 2 / 5;
                        trap(p, SpellKind.BOW_THICKET, at.add(Math.cos(a) * 3, 0, Math.sin(a) * 3), level + 1, false);
                    }
                }
            }
            case 7 -> trap(p, SpellKind.BOW_TRAP, Skills.aimGround(p, 24), level, false);
            case 8 -> StyleSupport.held(p, 8, SpellKind.BOW_EXPLOSIVE, level, Sounds.BOW_SHOT, false,
                    (self, e) -> StyleSupport.hit(p, e, 3 + level), at -> {
                        StyleSupport.area(p, at, 4, 10 + level * 1.5F,
                                e -> Abilities.push(e, e.getPos().subtract(at).normalize().multiply(0.8)));
                        StyleSupport.model(p, SpellKind.BOW_EXPLOSIVE, at, 3, 12, null);
                        Abilities.soundAt(p.getServerWorld(), at, Sounds.BOW_HIT, 0.6F);
                    });
            case 9 -> rain(p, Skills.aimGround(p, 50), level, true);
        }
    }

    private static void impact(ServerPlayerEntity p, LivingEntity e) {
        Abilities.soundAt(p.getServerWorld(), e.getPos(), Sounds.BOW_HIT, 1);
    }

    private static void fan(ServerPlayerEntity p, int level) {
        Vec3d look = p.getRotationVector();
        for (int i = -3; i <= 3; i++) {
            Vec3d direction = look.rotateY(i * 0.12F).multiply(2.1);
            StyleSupport.shot(p, SpellKind.BOW_FAN, Spells.muzzle(p, 1.5), direction, 0.8F, 28, false,
                    (self, e) -> { StyleSupport.hit(p, e, 3 + level * 0.7F); impact(p, e); }, null);
        }
    }

    private static void trap(ServerPlayerEntity p, SpellKind kind, Vec3d at, int level, boolean explosive) {
        StyleSupport.model(p, kind, at, 1.4F, 240, self -> {
            if (self.age < 12) return;
            var targets = Abilities.livingAt(p, at.add(0, 0.5, 0), 1.8);
            if (targets.isEmpty()) return;
            if (explosive) StyleSupport.area(p, at, 3, 7 + level, e -> StyleSupport.root(e, 40));
            else {
                LivingEntity e = targets.get(0);
                StyleSupport.hit(p, e, 5 + level);
                StyleSupport.model(p, kind, e.getPos(), 1, 60, bind -> {
                    if (!e.isAlive() || !Abilities.canHit(e, p)) { bind.discard(); return; }
                    bind.setPosition(e.getPos()); StyleSupport.root(e, 6);
                });
            }
            Abilities.soundAt(p.getServerWorld(), at, Sounds.BOW_HIT, 0.8F);
            self.discard();
        });
    }

    private static void rain(ServerPlayerEntity p, Vec3d at, int level, boolean ultimate) {
        SpellKind kind = ultimate ? SpellKind.BOW_CELESTIAL : SpellKind.BOW_RAIN;
        if (ultimate) {
            StyleSupport.fall(p, kind, at, 6, 35, point -> {
                StyleSupport.area(p, point.add(0, 1, 0), 8, 28 + level * 4,
                        e -> { StyleSupport.root(e, 50); impact(p, e); });
                StyleSupport.field(p, kind, point, 4, 60, 15, self ->
                        StyleSupport.area(p, point.add(0, 1, 0), 5, 3 + level, null));
            });
            return;
        }
        StyleSupport.field(p, kind, at.add(0, 10, 0), 3, 65, 4, self -> {
            double angle = self.age * 2.4;
            double r = 1 + (self.age % 5) * 0.8;
            Vec3d start = at.add(Math.cos(angle) * r, 12, Math.sin(angle) * r);
            StyleSupport.shot(p, kind, start, new Vec3d(0, -1.7, 0), 0.8F, 12, false,
                    (arrow, e) -> StyleSupport.hit(p, e, 4 + level), null);
        });
    }

    private static void seekers(ServerPlayerEntity p, int level) {
        for (int i = 0; i < 3; i++) {
            LivingEntity locked = Abilities.aim(p, 40);
            var struck = new java.util.HashSet<java.util.UUID>();
            StyleSupport.model(p, SpellKind.BOW_SEEKERS, Spells.muzzle(p, 1.5).add(i - 1, 0, 0), 0.85F, 65, self -> {
                Vec3d wanted = locked != null && locked.isAlive() && p.canSee(locked)
                        ? locked.getBoundingBox().getCenter().subtract(self.getPos()).normalize().multiply(1.8)
                        : p.getRotationVector().multiply(1.8);
                self.setVelocity(self.getVelocity().lerp(wanted, 0.3));
                self.facing(self.getVelocity());
                if (Spells.fly(self, p, 0.45, true, struck, (at, e) -> {
                    StyleSupport.hit(p, e, 6 + level); Abilities.debuff(e, StatusEffects.GLOWING, 100, 0); return true;
                })) self.discard();
            });
        }
    }
}
