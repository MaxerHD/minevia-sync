package local.minevia.elements.temple;

import local.minevia.elements.AltarBlock;
import local.minevia.elements.Element;
import local.minevia.elements.MineviaElements;
import local.minevia.elements.TrapBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.StairsBlock;
import net.minecraft.loot.LootTables;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.structure.StructureContext;
import net.minecraft.structure.StructurePiece;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.StructureWorldAccess;
import net.minecraft.world.gen.StructureAccessor;
import net.minecraft.world.gen.chunk.ChunkGenerator;

/**
 * Весь храм одним куском: площадка, коридор с ловушками и круглый зал с алтарём под куполом.
 * Строится кодом, а не из файла, поэтому у всех четырёх стихий один план и разные материалы.
 */
public final class TemplePiece extends StructurePiece {
    static final int WIDTH = 41;
    static final int DEPTH = 64;
    /** На сколько блоков храм земли уходит под поверхность. */
    static final int BURIED = 8;
    private static final int LIFT = 30;
    private static final int CENTER_X = 20;
    private static final int CENTER_Z = 43;
    private static final int RADIUS = 19;
    private static final int HALL_START = 9;
    private static final int HALL_END = 25;

    private record Style(BlockState floor, BlockState wall, BlockState roof, BlockState trim, BlockState light,
            BlockState channel, BlockState base, BlockState stairs) {
    }

    private final Element element;

    TemplePiece(Element element, BlockPos origin, Direction facing) {
        super(MineviaElements.TEMPLE_PIECE, 0, createBox(origin.getX(), origin.getY(), origin.getZ(), facing, WIDTH, height(element), DEPTH));
        this.element = element;
        setOrientation(facing);
    }

    public TemplePiece(NbtCompound nbt) {
        super(MineviaElements.TEMPLE_PIECE, nbt);
        element = Element.natural()[nbt.getInt("Element")];
    }

    @Override
    protected void writeNbt(StructureContext context, NbtCompound nbt) {
        nbt.putInt("Element", element.ordinal());
    }

    private static int floorY(Element element) {
        return element == Element.AIR ? LIFT : 2;
    }

    private static int height(Element element) {
        return floorY(element) + 22 + (element == Element.EARTH ? BURIED : 0);
    }

    private Style style() {
        return switch (element) {
            case FIRE -> new Style(Blocks.POLISHED_BLACKSTONE_BRICKS.getDefaultState(), Blocks.BLACKSTONE.getDefaultState(),
                    Blocks.POLISHED_BASALT.getDefaultState(), Blocks.GILDED_BLACKSTONE.getDefaultState(),
                    Blocks.SHROOMLIGHT.getDefaultState(), Blocks.LAVA.getDefaultState(), Blocks.BASALT.getDefaultState(),
                    Blocks.POLISHED_BLACKSTONE_BRICK_STAIRS.getDefaultState());
            case WATER -> new Style(Blocks.DARK_PRISMARINE.getDefaultState(), Blocks.PRISMARINE_BRICKS.getDefaultState(),
                    Blocks.PRISMARINE.getDefaultState(), Blocks.CUT_COPPER.getDefaultState(),
                    Blocks.SEA_LANTERN.getDefaultState(), Blocks.WATER.getDefaultState(), Blocks.PRISMARINE.getDefaultState(),
                    Blocks.DARK_PRISMARINE_STAIRS.getDefaultState());
            case EARTH -> new Style(Blocks.MOSSY_STONE_BRICKS.getDefaultState(), Blocks.DEEPSLATE_BRICKS.getDefaultState(),
                    Blocks.ROOTED_DIRT.getDefaultState(), Blocks.CHISELED_DEEPSLATE.getDefaultState(),
                    Blocks.OCHRE_FROGLIGHT.getDefaultState(), Blocks.MOSS_BLOCK.getDefaultState(), Blocks.COBBLED_DEEPSLATE.getDefaultState(),
                    Blocks.MOSSY_STONE_BRICK_STAIRS.getDefaultState());
            case AIR -> new Style(Blocks.SMOOTH_QUARTZ.getDefaultState(), Blocks.CALCITE.getDefaultState(),
                    Blocks.WHITE_STAINED_GLASS.getDefaultState(), Blocks.CHISELED_QUARTZ_BLOCK.getDefaultState(),
                    Blocks.PEARLESCENT_FROGLIGHT.getDefaultState(), Blocks.LIGHT_BLUE_STAINED_GLASS.getDefaultState(), Blocks.QUARTZ_BRICKS.getDefaultState(),
                    Blocks.QUARTZ_STAIRS.getDefaultState());
            default -> throw new IllegalStateException("Природная стихия: " + element);
        };
    }

    @Override
    public void generate(StructureWorldAccess world, StructureAccessor accessor, ChunkGenerator generator, Random random,
            BlockBox box, ChunkPos chunk, BlockPos pivot) {
        Style style = style();
        int floor = floorY(element);
        hall(world, box, style, floor);
        corridor(world, box, style, floor);
        plaza(world, box, style, floor);
        if (element == Element.AIR) {
            spiral(world, box, style, floor);
        }
        BlockState altar = MineviaElements.ALTAR.getDefaultState().with(AltarBlock.ELEMENT, element.ordinal());
        addBlock(world, altar, CENTER_X, floor + 3, CENTER_Z, box);
        addChest(world, box, random, CENTER_X - 15, floor + 1, CENTER_Z, LootTables.SIMPLE_DUNGEON_CHEST);
        addChest(world, box, random, CENTER_X + 15, floor + 1, CENTER_Z, LootTables.SIMPLE_DUNGEON_CHEST);
    }

    /** Круглый зал: купол выше в середине, кольцо колонн, канал стихии у стены и ступени к алтарю. */
    private void hall(StructureWorldAccess world, BlockBox box, Style style, int floor) {
        for (int x = 0; x < WIDTH; x++) {
            for (int z = HALL_END - 1; z < DEPTH; z++) {
                double distance = Math.hypot(x - CENTER_X, z - CENTER_Z);
                if (distance > RADIUS + 1.2) {
                    continue;
                }
                int roof = floor + 17 - (int) (distance * distance / (RADIUS * RADIUS) * 6);
                boolean wall = distance > RADIUS;
                if (element != Element.AIR) {
                    fillDownwards(world, style.base(), x, floor - 2, z, box);
                }
                addBlock(world, style.base(), x, floor - 1, z, box);
                addBlock(world, floorBlock(style, distance, x, z), x, floor, z, box);
                for (int y = floor + 1; y < roof; y++) {
                    boolean window = element == Element.AIR && wall && y > floor + 2 && y < floor + 9 && (x + z) % 5 < 2;
                    addBlock(world, wall ? window ? style.roof() : style.wall() : AIR, x, y, z, box);
                }
                addBlock(world, style.roof(), x, roof, z, box);
                if ((int) distance == RADIUS - 1 && !wall) {
                    addBlock(world, style.light(), x, roof, z, box);
                }
            }
        }
        for (int i = 0; i < 8; i++) {
            double angle = Math.PI * 2 * (i + 0.5) / 8;
            pillar(world, box, style, floor, CENTER_X + (int) Math.round(Math.cos(angle) * 12), CENTER_Z + (int) Math.round(Math.sin(angle) * 12));
        }
        for (int x = -4; x <= 4; x++) {
            for (int z = -4; z <= 4; z++) {
                double distance = Math.hypot(x, z);
                if (distance <= 4.4) {
                    addBlock(world, style.wall(), CENTER_X + x, floor + 1, CENTER_Z + z, box);
                }
                if (distance <= 2.9) {
                    addBlock(world, style.trim(), CENTER_X + x, floor + 2, CENTER_Z + z, box);
                }
            }
        }
    }

    private BlockState floorBlock(Style style, double distance, int x, int z) {
        if (distance > 16 && distance < 17.4) {
            return style.channel();
        }
        if ((int) distance % 6 == 5 && (x + z) % 2 == 0) {
            return style.trim();
        }
        return style.floor();
    }

    private void pillar(StructureWorldAccess world, BlockBox box, Style style, int floor, int x, int z) {
        for (int y = floor + 1; y < floor + 15; y++) {
            for (int dx = 0; dx < 2; dx++) {
                for (int dz = 0; dz < 2; dz++) {
                    addBlock(world, y % 5 == 0 ? style.light() : style.wall(), x + dx, y, z + dz, box);
                }
            }
        }
    }

    /** Коридор к залу. Пол в ловушках, а безопасная дорожка петляет от стены к стене. */
    private void corridor(StructureWorldAccess world, BlockBox box, Style style, int floor) {
        BlockState trap = MineviaElements.TRAP.getDefaultState().with(TrapBlock.ELEMENT, element.ordinal());
        BlockState stairs = style.stairs().with(StairsBlock.FACING, Direction.NORTH);
        for (int z = HALL_START; z < HALL_END; z++) {
            int level = floor + ramp(z);
            boolean step = ramp(z) != ramp(z - 1);
            for (int x = 15; x <= 25; x++) {
                boolean side = x == 15 || x == 25;
                if (element != Element.AIR) {
                    fillDownwards(world, style.base(), x, level - 1, z, box);
                } else {
                    addBlock(world, style.base(), x, level - 1, z, box);
                }
                addBlock(world, side ? style.wall() : step ? stairs : style.floor(), x, level, z, box);
                for (int y = level + 1; y < level + 6; y++) {
                    boolean lamp = side && y == level + 3 && z % 4 == 0;
                    addBlock(world, side ? lamp ? style.light() : style.wall() : AIR, x, y, z, box);
                }
                addBlock(world, style.roof(), x, level + 6, z, box);
            }
            if (ramp(z) == 0 && z > HALL_START + 1 && z < HALL_END - 2 && z % 2 == 0) {
                int gap = z % 4 == 0 ? 17 : 22;
                for (int x = 16; x <= 24; x++) {
                    if (x < gap || x > gap + 2) {
                        addBlock(world, trap, x, level, z, box);
                    }
                }
            }
        }
    }

    /** Храм земли уходит вниз лестницей от площадки на поверхности. */
    private int ramp(int z) {
        if (element != Element.EARTH) {
            return 0;
        }
        return Math.max(0, Math.min(BURIED, 18 - z));
    }

    private void plaza(StructureWorldAccess world, BlockBox box, Style style, int floor) {
        int top = floor + ramp(HALL_START);
        for (int x = 13; x <= 27; x++) {
            for (int z = 0; z < HALL_START; z++) {
                if (element != Element.AIR) {
                    fillDownwards(world, style.base(), x, top - 1, z, box);
                }
                addBlock(world, (x + z) % 4 == 0 ? style.trim() : style.floor(), x, top, z, box);
                for (int y = top + 1; y < top + 7; y++) {
                    addBlock(world, AIR, x, y, z, box);
                }
            }
        }
        for (int y = top + 1; y < top + 5; y++) {
            for (int x : new int[] {14, 26}) {
                addBlock(world, y == top + 4 ? style.light() : style.wall(), x, y, 1, box);
            }
        }
    }

    /** Храм воздуха висит над землёй: к нему ведёт винтовая лестница вокруг столба. */
    private void spiral(StructureWorldAccess world, BlockBox box, Style style, int floor) {
        int x0 = 20;
        int z0 = 4;
        for (int y = floor - 1; y >= 0; y--) {
            addBlock(world, style.trim(), x0, y, z0, box);
            double angle = (floor - y) * 0.62;
            for (int r = 1; r <= 3; r++) {
                addBlock(world, style.floor(), x0 + (int) Math.round(Math.cos(angle) * r), y, z0 + (int) Math.round(Math.sin(angle) * r), box);
            }
            for (int r = 1; r <= 3; r++) {
                double next = angle + 0.3;
                addBlock(world, style.floor(), x0 + (int) Math.round(Math.cos(next) * r), y, z0 + (int) Math.round(Math.sin(next) * r), box);
            }
        }
        // Проём в площадке над лестницей: иначе на неё не выйти.
        for (int x = x0 - 4; x <= x0 + 4; x++) {
            for (int z = z0 - 4; z <= z0 + 4; z++) {
                double distance = Math.hypot(x - x0, z - z0);
                if (distance > 0.9 && distance <= 3.6) {
                    addBlock(world, AIR, x, floor, z, box);
                }
            }
        }
        fillDownwards(world, style.base(), x0, -1, z0, box);
    }
}
