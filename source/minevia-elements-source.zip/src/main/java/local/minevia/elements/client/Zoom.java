package local.minevia.elements.client;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;

/**
 * Зум: пока держишь клавишу, камера плавно приближается, а колесо мыши меняет силу приближения.
 * Клавиша читается напрямую, потому что у игры на одной клавише работает только одно действие,
 * а C по умолчанию занята сохранением панели предметов.
 */
public final class Zoom {
    private static final double DEFAULT_LEVEL = 4;
    private static final double MIN_LEVEL = 2;
    private static final double MAX_LEVEL = 12;
    private static final double SPEED = 14;

    static KeyBinding key;
    private static double level = DEFAULT_LEVEL;
    private static double shown = 1;
    private static long lastFrame;

    private Zoom() {
    }

    private static boolean held() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (key == null || client.currentScreen != null || client.player == null) {
            return false;
        }
        InputUtil.Key bound = KeyBindingHelper.getBoundKeyOf(key);
        return bound.getCategory() == InputUtil.Type.KEYSYM
                ? InputUtil.isKeyPressed(client.getWindow().getHandle(), bound.getCode())
                : key.isPressed();
    }

    /** Угол обзора с учётом зума. Вызывается каждый кадр, поэтому приближение идёт плавно при любом FPS. */
    public static double apply(double fov) {
        long now = System.nanoTime();
        double seconds = Math.min(0.1, (now - lastFrame) / 1.0E9);
        lastFrame = now;
        double target = held() ? level : 1;
        shown += (target - shown) * Math.min(1, seconds * SPEED);
        if (target == 1 && shown < 1.01) {
            shown = 1;
            level = DEFAULT_LEVEL;
        }
        return fov / shown;
    }

    /** При сильном приближении мышь замедляется, иначе прицел прыгал бы по экрану. */
    public static double mouseScale() {
        return 1 / shown;
    }

    /** Колесо мыши при зажатом зуме. Вернёт true, если прокрутка потрачена на приближение. */
    public static boolean scroll(double amount) {
        if (!held() || amount == 0) {
            return false;
        }
        level = MathHelper.clamp(level * (amount > 0 ? 1.25 : 0.8), MIN_LEVEL, MAX_LEVEL);
        return true;
    }
}
