package local.minevia.elements;

import net.minecraft.entity.EntityData;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Difficulty;
import net.minecraft.world.Heightmap;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import org.jetbrains.annotations.Nullable;

/**
 * Дух стихии: живёт в своих биомах и нападает на игроков. Свою стихию почти не чувствует, а от противоположной
 * получает больше. Редкий старший дух крупнее, сильнее и даёт больше эссенции. Вся анимация это 3D-модель.
 */
public final class ElementMob extends HostileEntity {
    private static final TrackedData<Boolean> ELDER = DataTracker.registerData(ElementMob.class, TrackedDataHandlerRegistry.BOOLEAN);
    private static final float[] HEALTH = {22, 26, 40, 18};
    private static final double[] SPEED = {0.3, 0.26, 0.21, 0.3};
    private static final double[] MELEE = {3, 3, 6, 3};
    private static final float ELDER_CHANCE = 0.12F;
    private static final float ELDER_SIZE = 1.5F;
    private static final float ELDER_HEALTH = 2.2F;
    private static final float OWN_ELEMENT = 0.3F;
    private static final float OPPOSITE_ELEMENT = 1.7F;

    private int cooldown = 40;
    private int dive;
    private int wanderIn;
    private Vec3d wanderTo;

    public ElementMob(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        experiencePoints = 8;
        if (flies()) {
            setNoGravity(true);
        }
    }

    public static DefaultAttributeContainer.Builder attributes(Element element) {
        int i = element.ordinal();
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, HEALTH[i])
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, SPEED[i])
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, MELEE[i])
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 26)
                .add(EntityAttributes.GENERIC_ARMOR, element == Element.EARTH ? 6 : 0)
                .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, element == Element.EARTH ? 0.7 : 0);
    }

    /** Днём духи появляются редко, иначе заняли бы весь лимит монстров: обычные мобы при свете не спавнятся. */
    public static boolean canSpawn(EntityType<ElementMob> type, ServerWorldAccess world, SpawnReason reason, BlockPos pos, Random random) {
        return world.getDifficulty() != Difficulty.PEACEFUL && MobEntity.canMobSpawn(type, world, reason, pos, random)
                && (world.getLightLevel(pos) <= 7 || random.nextInt(6) == 0);
    }

    /** Стихия берётся из типа: конструктор моба вызывает initGoals раньше, чем успело бы заполниться поле. */
    public Element element() {
        EntityType<?> type = getType();
        for (Element element : Element.values()) {
            if (MineviaElements.SPIRITS[element.ordinal()] == type) {
                return element;
            }
        }
        return Element.FIRE;
    }

    private boolean flies() {
        Element element = element();
        return element == Element.FIRE || element == Element.AIR;
    }

    public boolean elder() {
        return dataTracker.get(ELDER);
    }

    private void makeElder() {
        dataTracker.set(ELDER, true);
        getAttributeInstance(EntityAttributes.GENERIC_SCALE).setBaseValue(ELDER_SIZE);
        var health = getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH);
        health.setBaseValue(health.getBaseValue() * ELDER_HEALTH);
        setHealth(getMaxHealth());
        var attack = getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE);
        attack.setBaseValue(attack.getBaseValue() * 1.5);
        experiencePoints = 25;
    }

    /** Во сколько раз меняется удар стихией: своя почти не действует, противоположная бьёт сильнее. */
    float factor(Element from) {
        Element own = element();
        if (from == own) {
            return OWN_ELEMENT;
        }
        return from == opposite(own) ? OPPOSITE_ELEMENT : 1;
    }

    static Element opposite(Element element) {
        return switch (element) {
            case FIRE -> Element.WATER;
            case WATER -> Element.FIRE;
            case EARTH -> Element.AIR;
            case AIR -> Element.EARTH;
        };
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(ELDER, false);
    }

    @Override
    protected void initGoals() {
        if (!flies()) {
            goalSelector.add(1, new SwimGoal(this));
            goalSelector.add(3, new MeleeAttackGoal(this, 1.1, false));
            goalSelector.add(6, new WanderAroundFarGoal(this, 0.8));
        }
        goalSelector.add(7, new LookAtEntityGoal(this, PlayerEntity.class, 12));
        goalSelector.add(8, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public EntityData initialize(ServerWorldAccess world, LocalDifficulty difficulty, SpawnReason reason, @Nullable EntityData data) {
        EntityData result = super.initialize(world, difficulty, reason, data);
        if (reason != SpawnReason.SPAWNER && world.getRandom().nextFloat() < ELDER_CHANCE) {
            makeElder();
        }
        return result;
    }

    @Override
    protected void mobTick() {
        super.mobTick();
        ServerWorld world = (ServerWorld) getWorld();
        LivingEntity target = getTarget();
        if (target != null && !target.isAlive()) {
            target = null;
        }
        if (flies()) {
            steer(world, target);
        }
        if (element() == Element.WATER && isTouchingWater() && age % 40 == 0) {
            heal(1);
        }
        if (target == null) {
            return;
        }
        if (flies()) {
            Vec3d to = target.getPos().subtract(getPos());
            float yaw = (float) Math.toDegrees(Math.atan2(-to.x, to.z));
            setYaw(yaw);
            setHeadYaw(yaw);
            setBodyYaw(yaw);
        }
        if (--cooldown <= 0 && canSee(target)) {
            cooldown = MobMoves.use(this, world, target);
        }
    }

    /** Полёт без поиска пути: дух сам держится над землёй и летит к своей точке. */
    private void steer(ServerWorld world, @Nullable LivingEntity target) {
        Vec3d spot;
        double speed = 0.2;
        if (target == null) {
            if (--wanderIn <= 0 || wanderTo == null) {
                wanderIn = 70 + random.nextInt(60);
                Vec3d near = getPos().add(random.nextDouble() * 14 - 7, 0, random.nextDouble() * 14 - 7);
                int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING, (int) Math.floor(near.x), (int) Math.floor(near.z));
                wanderTo = new Vec3d(near.x, top + 3 + random.nextDouble() * 2, near.z);
            }
            spot = wanderTo;
            speed = 0.1;
        } else if (dive > 0) {
            dive--;
            spot = target.getBoundingBox().getCenter();
            speed = 0.62;
            if (getBoundingBox().expand(0.7).intersects(target.getBoundingBox())) {
                MobMoves.diveHit(this, world, target);
                dive = 0;
            }
        } else if (element() == Element.AIR) {
            double angle = age * 0.06;
            spot = target.getPos().add(Math.cos(angle) * 6, 4 + Math.sin(age * 0.09), Math.sin(angle) * 6);
            speed = 0.3;
        } else {
            Vec3d back = getPos().subtract(target.getPos());
            Vec3d flat = new Vec3d(back.x, 0, back.z);
            Vec3d away = flat.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : flat.normalize();
            spot = target.getPos().add(away.multiply(7)).add(0, 2.5 + Math.sin(age * 0.1) * 0.5, 0);
        }
        Vec3d want = spot.subtract(getPos());
        double length = want.length();
        Vec3d step = length < 0.1 ? Vec3d.ZERO : want.multiply(Math.min(speed, length * 0.25) / length);
        setVelocity(getVelocity().lerp(step, 0.3));
        if (target == null && step.horizontalLengthSquared() > 0.001) {
            float yaw = (float) Math.toDegrees(Math.atan2(-step.x, step.z));
            setYaw(yaw);
            setBodyYaw(yaw);
        }
    }

    void startDive() {
        dive = 30;
    }

    @Override
    public void onDeath(DamageSource source) {
        if (getWorld() instanceof ServerWorld world && !dead) {
            MobMoves.burst(this, world);
            int count = elder() ? 2 + random.nextInt(2) : random.nextInt(4) == 0 ? 2 : 1;
            dropStack(new ItemStack(MineviaElements.ESSENCES[element().ordinal()], count));
            if (elder() && random.nextInt(8) == 0) {
                dropStack(new ItemStack(MineviaElements.ELEMENT_CORE));
            }
        }
        super.onDeath(source);
    }

    /** Обычный дымок смерти не показывается: дух разлетается своей моделью. */
    @Override
    protected void updatePostDeath() {
        if (!getWorld().isClient) {
            discard();
        }
    }

    @Override
    public Text getName() {
        return elder() && !hasCustomName() ? Text.translatable("entity.minevia_elements.elder", super.getName()) : super.getName();
    }

    /** Огненный дух боится воды и дождя, как блейз. */
    @Override
    public boolean hurtByWater() {
        return element() == Element.FIRE;
    }

    @Override
    public boolean handleFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    @Override
    public boolean doesRenderOnFire() {
        return false;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return switch (element()) {
            case FIRE -> Sounds.FIRE_CHARGE;
            case WATER -> Sounds.WATER_RISE;
            case EARTH -> Sounds.EARTH_RISE;
            case AIR -> Sounds.AIR_GUST;
        };
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return switch (element()) {
            case FIRE -> Sounds.FIRE_CAST;
            case WATER -> Sounds.WATER_HIT;
            case EARTH -> Sounds.EARTH_HIT;
            case AIR -> Sounds.AIR_DASH;
        };
    }

    @Override
    protected SoundEvent getDeathSound() {
        return getHurtSound(null);
    }

    @Override
    protected float getSoundVolume() {
        return 0.5F;
    }

    @Override
    public int getMinAmbientSoundDelay() {
        return 240;
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putBoolean("Elder", elder());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        // Размер и здоровье старшего духа уже лежат в его атрибутах, поэтому восстанавливается только отметка.
        dataTracker.set(ELDER, nbt.getBoolean("Elder"));
        if (elder()) {
            experiencePoints = 25;
        }
    }
}
