package local.minevia.elements.client;

import java.util.Locale;
import java.util.Optional;
import local.minevia.elements.MineviaElements;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

/**
 * Derivative считает свет отложенно и по глубине кадра, а полупрозрачные сущности глубину не пишут:
 * под ним модели выходили чёрными силуэтами. С этим шейдером они рисуются слоем с глубиной,
 * а прозрачность и свечение добавляет наша копия шейдера. Iris не обязателен, поэтому он ищется по имени.
 */
final class ShaderCompat {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private static final long CHECK_EVERY_MS = 2000;

    private static long checkedAt;
    private static boolean depthLayer;

    private ShaderCompat() {
    }

    static boolean needsDepth() {
        long now = System.currentTimeMillis();
        if (now - checkedAt > CHECK_EVERY_MS) {
            checkedAt = now;
            depthLayer = derivativeActive();
        }
        return depthLayer;
    }

    private static boolean derivativeActive() {
        try {
            Class<?> iris = Class.forName("net.irisshaders.iris.Iris");
            Object pack = iris.getMethod("getCurrentPack").invoke(null);
            String name = (String) iris.getMethod("getCurrentPackName").invoke(null);
            return pack instanceof Optional<?> present && present.isPresent()
                    && name != null && name.toLowerCase(Locale.ROOT).contains("derivative");
        } catch (ReflectiveOperationException | LinkageError missing) {
            return false;
        }
    }

    /** Слой для светящихся моделей: обычный, а под Derivative с записью глубины. */
    static RenderLayer glow() {
        return needsDepth() ? RenderLayer.getEntityCutoutNoCull(WHITE) : RenderLayer.getEntityTranslucentEmissive(WHITE);
    }
}
