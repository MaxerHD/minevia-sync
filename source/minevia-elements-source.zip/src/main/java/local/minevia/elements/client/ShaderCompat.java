package local.minevia.elements.client;

import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.util.Locale;
import java.util.Optional;
import local.minevia.elements.MineviaElements;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.util.Identifier;

/**
 * Derivative считает свет отложенно и по глубине кадра, а полупрозрачные сущности глубину не пишут:
 * под ним модели выходили чёрными силуэтами. С этим шейдером они рисуются слоем с глубиной,
 * а прозрачность и свечение добавляет наша копия шейдера. Iris не обязателен, поэтому он ищется по имени.
 */
final class ShaderCompat {
    private static final Identifier WHITE = Identifier.of(MineviaElements.MOD_ID, "textures/entity/white.png");
    private static final long CHECK_EVERY_MS = 2000;

    private static long checkedAt;
    private static boolean depthLayer;

    private ShaderCompat() {
    }

    static boolean needsDepth() {
        long now = System.currentTimeMillis();
        if (now - checkedAt > CHECK_EVERY_MS) {
            checkedAt = now;
            depthLayer = derivativeActive();
        }
        return depthLayer;
    }

    private static boolean derivativeActive() {
        try {
            Class<?> iris = Class.forName("net.irisshaders.iris.Iris");
            Object pack = iris.getMethod("getCurrentPack").invoke(null);
            String name = (String) iris.getMethod("getCurrentPackName").invoke(null);
            return pack instanceof Optional<?> present && present.isPresent()
                    && name != null && name.toLowerCase(Locale.ROOT).contains("derivative");
        } catch (ReflectiveOperationException | LinkageError missing) {
            return false;
        }
    }

    private static MethodHandle shadowPass;
    private static boolean shadowLookedUp;

    /**
     * Идёт ли сейчас проход теней шейдера. Заклинания и оружие в нём не рисуются: у светящихся моделей
     * тень не нужна, а тяжёлую модель пришлось бы считать на каждом кадре второй раз.
     */
    static boolean shadowPass() {
        if (!shadowLookedUp) {
            shadowLookedUp = true;
            try {
                Class<?> api = Class.forName("net.irisshaders.iris.api.v0.IrisApi");
                Object instance = api.getMethod("getInstance").invoke(null);
                shadowPass = MethodHandles.publicLookup().findVirtual(api, "isRenderingShadowPass", MethodType.methodType(boolean.class)).bindTo(instance);
            } catch (ReflectiveOperationException | LinkageError missing) {
                shadowPass = null;
            }
        }
        if (shadowPass == null) {
            return false;
        }
        try {
            return (boolean) shadowPass.invokeExact();
        } catch (Throwable broken) {
            shadowPass = null;
            return false;
        }
    }

    /** Слой для светящихся моделей: обычный, а под Derivative с записью глубины. */
    static RenderLayer glow() {
        return needsDepth() ? RenderLayer.getEntityCutoutNoCull(WHITE) : RenderLayer.getEntityTranslucentEmissive(WHITE);
    }
}
