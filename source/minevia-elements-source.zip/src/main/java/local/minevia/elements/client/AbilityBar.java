package local.minevia.elements.client;

import local.minevia.elements.Abilities;
import local.minevia.elements.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Панель навыков: короткое нажатие G ложится поверх хотбара, и цифры применяют навыки вместо смены предмета.
 * Панель ждёт следующий навык, поэтому цепочки делаются без лишних нажатий, а потом закрывается сама.
 */
final class AbilityBar {
    private static final int OPEN_TICKS = 70;
    private static final int STEP = 20;
    private static final int ICON = 16;

    private static int left;
    private static boolean zeroDown;

    private AbilityBar() {
    }

    static boolean isOpen() {
        return left > 0;
    }

    static void toggle() {
        left = isOpen() ? 0 : OPEN_TICKS;
        if (isOpen()) {
            zeroDown = true;
            MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(Sounds.WHEEL, 1.0F, 0.6F));
        }
    }

    static void close() {
        left = 0;
    }

    /** Идёт раньше обработки клавиш игры: цифра, забранная здесь, уже не переключит предмет в руке. */
    static void beforeInput(MinecraftClient client) {
        if (!isOpen()) {
            return;
        }
        if (client.currentScreen != null) {
            close();
            return;
        }
        left--;
        KeyBinding[] digits = client.options.hotbarKeys;
        for (int i = 0; i < digits.length; i++) {
            while (digits[i].wasPressed()) {
                pick(i);
            }
        }
        boolean zero = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_0);
        if (zero && !zeroDown) {
            pick(digits.length);
        }
        zeroDown = zero;
    }

    private static void pick(int index) {
        int[] slots = ElementsClient.slots();
        if (index < slots.length && ElementsClient.level >= Abilities.unlockLevel(slots[index])) {
            ElementsClient.cast(slots[index]);
            left = OPEN_TICKS;
        }
    }

    static void draw(DrawContext context) {
        if (!isOpen()) {
            return;
        }
        int[] slots = ElementsClient.slots();
        int x = context.getScaledWindowWidth() / 2 - 91;
        int y = context.getScaledWindowHeight() - 22;
        int color = 0xFF000000 | ElementsClient.element.color;
        int right = x + Math.max(182, slots.length * STEP + 2);
        context.fill(x, y, right, y + 22, 0xF00D1620);
        context.fill(x, y - 1, right, y, color);
        for (int index = 0; index < slots.length; index++) {
            int left = x + 3 + index * STEP;
            ElementsClient.drawSlot(context, slots[index], left, y + 3, ICON);
            String digit = String.valueOf((index + 1) % 10);
            ElementsClient.drawSmallText(context, digit, left + ICON - 3, y + ICON - 1, 0xFFFFF3DC, 0.7F);
        }
    }
}
