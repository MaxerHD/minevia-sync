package local.minevia.elements.client;

import local.minevia.elements.Abilities;
import local.minevia.elements.Combos;
import local.minevia.elements.Mastery;
import local.minevia.elements.Sounds;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Панель навыков работает как второй хотбар: короткое нажатие G ложится поверх обычного, колесо мыши выбирает навык,
 * правая кнопка его применяет, а цифры применяют сразу. После первого навыка цепочки следующий подсвечивается золотом.
 * Если ничего не нажимать, панель закрывается сама и возвращает обычный хотбар.
 */
final class AbilityBar {
    private static final int IDLE_TICKS = 240;
    private static final int CHAIN_TICKS = 80;
    private static final int STEP = 20;
    private static final int ICON = 16;
    private static final int GOLD = 0xFFFFD27A;

    private static int left;
    private static int selected;
    private static boolean zeroDown;
    private static int lastSlot = -1;
    private static int chainLeft;

    private AbilityBar() {
    }

    static boolean isOpen() {
        return left > 0;
    }

    private static void click(float pitch) {
        MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(Sounds.WHEEL, pitch, 0.5F));
    }

    static void toggle() {
        if (!ElementsClient.weaponReady(true)) return;
        left = isOpen() ? 0 : IDLE_TICKS;
        if (isOpen()) {
            zeroDown = true;
            click(1.0F);
        }
    }

    static void reset() {
        close();
        lastSlot = -1;
        chainLeft = 0;
    }

    static void close() {
        left = 0;
    }

    /** Колесо мыши листает навыки, а не предметы. Вернёт false, если панель закрыта. */
    static boolean scroll(double vertical) {
        if (!isOpen() || MinecraftClient.getInstance().currentScreen != null) {
            return false;
        }
        int count = ElementsClient.slots().length;
        selected = Math.floorMod(selected - (int) Math.signum(vertical), count);
        left = IDLE_TICKS;
        click(1.3F);
        return true;
    }

    /** Запоминает навык: если он первый в цепочке, начинается отсчёт на второй. */
    static void noteCast(int slot) {
        if (ElementsClient.COOLDOWN[slot] == 0 && ElementsClient.level >= Abilities.unlockLevel(slot)) {
            lastSlot = slot;
            chainLeft = CHAIN_TICKS;
        }
    }

    /** Цепочка, которую сейчас можно закончить, или null. */
    static Combos.Solo chain() {
        if (chainLeft <= 0 || ElementsClient.element == null) {
            return null;
        }
        for (Combos.Solo solo : Combos.Solo.values()) {
            if (solo.element == ElementsClient.element && solo.first == lastSlot && ElementsClient.level >= Abilities.unlockLevel(solo.second)
                    && ElementsClient.COOLDOWN[solo.second] <= CHAIN_TICKS) {
                return solo;
            }
        }
        return null;
    }

    /** Идёт раньше обработки клавиш игры: забранная здесь цифра не сменит предмет, а правая кнопка ничего не поставит. */
    static void beforeInput(MinecraftClient client) {
        if (chainLeft > 0) {
            chainLeft--;
        }
        if (!isOpen()) {
            return;
        }
        if (client.currentScreen != null || !ElementsClient.weaponReady(false)) {
            close();
            return;
        }
        left--;
        KeyBinding[] digits = client.options.hotbarKeys;
        for (int i = 0; i < digits.length; i++) {
            while (digits[i].wasPressed()) {
                pick(i);
            }
        }
        boolean zero = InputUtil.isKeyPressed(client.getWindow().getHandle(), GLFW.GLFW_KEY_0);
        if (zero && !zeroDown) {
            pick(digits.length);
        }
        zeroDown = zero;
        KeyBinding use = client.options.useKey;
        while (use.wasPressed()) {
            pick(selected);
        }
        use.setPressed(false);
    }

    private static void pick(int index) {
        int[] slots = ElementsClient.slots();
        if (index < slots.length && ElementsClient.level >= Abilities.unlockLevel(slots[index])) {
            selected = index;
            ElementsClient.cast(slots[index]);
            left = IDLE_TICKS;
        }
    }

    static int digit(int slot) {
        int[] slots = ElementsClient.slots();
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == slot) {
                return (i + 1) % 10;
            }
        }
        return -1;
    }

    static void draw(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        int center = context.getScaledWindowWidth() / 2;
        int height = context.getScaledWindowHeight();
        Combos.Solo chain = chain();
        if (chain != null) {
            Text hint = Text.translatable("hud.minevia_elements.chain", Text.translatable(chain.key()), digit(chain.second));
            context.drawCenteredTextWithShadow(client.textRenderer, hint, center, height - 86, GOLD);
            int bar = 80 * chainLeft / CHAIN_TICKS;
            context.fill(center - 40, height - 76, center + 40, height - 75, 0x80000000);
            context.fill(center - bar / 2, height - 76, center + bar / 2, height - 75, GOLD);
        }
        if (!isOpen()) {
            return;
        }
        int[] slots = ElementsClient.slots();
        selected = Math.min(selected, slots.length - 1);
        int x = center - 91;
        int y = height - 22;
        int color = 0xFF000000 | ElementsClient.element.color;
        int right = x + Math.max(182, slots.length * STEP + 2);
        context.fill(x, y, right, y + 22, 0xF00D1620);
        context.fill(x, y - 1, right, y, color);
        boolean pulse = System.currentTimeMillis() / 180 % 2 == 0;
        for (int index = 0; index < slots.length; index++) {
            int slot = slots[index];
            int cell = x + 3 + index * STEP;
            if (chain != null && chain.second == slot) {
                context.fill(cell - 2, y + 1, cell + ICON + 2, y + 21, pulse ? GOLD : 0xFFB07A14);
                context.fill(cell - 1, y + 2, cell + ICON + 1, y + 20, 0xFF0D1620);
            } else if (index == selected) {
                context.fill(cell - 2, y + 1, cell + ICON + 2, y + 21, color);
                context.fill(cell - 1, y + 2, cell + ICON + 1, y + 20, 0xFF16263A);
            }
            ElementsClient.drawSlot(context, slot, cell, y + 3, ICON);
            if (ElementsClient.COOLDOWN[slot] > 0 && ElementsClient.level >= Abilities.unlockLevel(slot)) {
                String seconds = String.valueOf(ElementsClient.COOLDOWN[slot] / 20 + 1);
                int width = client.textRenderer.getWidth(seconds);
                ElementsClient.drawSmallText(context, seconds, cell + (ICON - width) / 2, y + 7, 0xFFFFFFFF, 1.0F);
            }
            ElementsClient.drawSmallText(context, String.valueOf((index + 1) % 10), cell + ICON - 3, y + ICON - 1, 0xFFFFF3DC, 0.7F);
        }
        int slot = slots[selected];
        Text name = ElementsClient.abilityName(slot).copy().append(" ")
                .append(Text.translatable("screen.minevia_elements.skill_level", Mastery.level(ElementsClient.SKILL_XP[slot])));
        context.drawCenteredTextWithShadow(client.textRenderer, name, center, height - 56, color);
    }
}
