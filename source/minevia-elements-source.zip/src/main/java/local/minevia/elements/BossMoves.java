package local.minevia.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/** Приёмы стражей. У каждой стихии три, и почти все сначала показывают на земле, куда ударят. */
final class BossMoves {
    private static final int FIRE_RED = 0xFF5A20;
    private static final int ICE_BLUE = 0x7FD0FF;
    private static final int STONE = 0xB89A6A;
    private static final int WIND = 0xE4F0F6;

    private BossMoves() {
    }

    static void use(ElementBoss boss, ServerWorld world, PlayerEntity target, int element) {
        int move = world.random.nextInt(3);
        switch (element) {
            case 0 -> {
                if (move == 0) {
                    fireVolley(boss, world, target);
                } else if (move == 1) {
                    meteors(boss, world, target);
                } else {
                    flameWave(boss, world);
                }
            }
            case 1 -> {
                if (move == 0) {
                    waterVolley(boss, world, target);
                } else if (move == 1) {
                    iceTrap(boss, world, target);
                } else {
                    tide(boss, world, target);
                }
            }
            case 2 -> {
                if (move == 0) {
                    hurl(boss, world, target);
                } else if (move == 1) {
                    spikeLine(boss, world, target);
                } else {
                    stomp(boss, world);
                }
            }
            default -> {
                if (move == 0) {
                    saws(boss, world, target);
                } else if (move == 1) {
                    chasingTwister(boss, world, target);
                } else {
                    gale(boss, world);
                }
            }
        }
    }

    /** Предупреждение на земле: круг горит столько тиков, сколько осталось до удара. */
    private static void warn(ServerWorld world, Vec3d at, float radius, int ticks, int color, Runnable hit) {
        double ground = Spells.groundAt(world, at.add(0, 1.5, 0));
        Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
        SpellEntity.spawn(world, SpellKind.DANGER_RING, base.add(0, 0.06, 0), radius, ticks).tint(color);
        Effects.later(world, ticks, hit);
    }

    private static Vec3d ground(ServerWorld world, Vec3d at) {
        double ground = Spells.groundAt(world, at.add(0, 1.5, 0));
        return Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
    }

    private static void shoot(ElementBoss boss, ServerWorld world, SpellKind kind, Vec3d from, Vec3d to, double speed, float size,
            float damage, SpellKind burst, float burstSize) {
        Vec3d velocity = to.subtract(from).normalize().multiply(speed);
        SpellEntity shot = SpellEntity.spawn(world, kind, from, size, 70).facing(velocity);
        shot.setVelocity(velocity);
        Set<UUID> struck = new HashSet<>();
        shot.logic(self -> {
            Vec3d next = self.getPos().add(self.getVelocity());
            boolean blocked = !world.getBlockState(net.minecraft.util.math.BlockPos.ofFloored(next)).getCollisionShape(world,
                    net.minecraft.util.math.BlockPos.ofFloored(next)).isEmpty();
            self.setPosition(next);
            boolean hit = false;
            for (PlayerEntity player : ElementBoss.playersAt(world, next, 1.5 * size)) {
                if (struck.add(player.getUuid())) {
                    boss.strike(world, player, damage);
                    hit = true;
                }
            }
            if (blocked || hit || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, burst, next, burstSize, 17);
                self.discard();
            }
        });
    }

    private static void fireVolley(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Effects.repeat(world, 3, 9, step -> {
            if (!boss.isAlive() || !target.isAlive()) {
                return false;
            }
            Abilities.soundAt(world, boss.getPos(), Sounds.FIRE_CAST, 0.8F);
            shoot(boss, world, SpellKind.FIREBALL, boss.getEyePos(), target.getEyePos(), 0.75, 1.3F, 5, SpellKind.FIRE_BURST, 1.2F);
            return true;
        });
    }

    private static void meteors(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        for (int i = 0; i < 5; i++) {
            Vec3d at = i == 0 ? target.getPos()
                    : target.getPos().add(world.random.nextDouble() * 12 - 6, 0, world.random.nextDouble() * 12 - 6);
            Vec3d base = ground(world, at);
            warn(world, base, 2.6F, 26 + i * 4, FIRE_RED, () -> {
                if (!boss.isAlive()) {
                    return;
                }
                SpellEntity.spawn(world, SpellKind.FIRE_BURST, base.add(0, 0.5, 0), 1.6F, 17);
                Abilities.soundAt(world, base, Sounds.FIRE_BLAST, 0.9F);
                for (PlayerEntity player : ElementBoss.playersAt(world, base.add(0, 1, 0), 3.0)) {
                    boss.strike(world, player, 7);
                    player.setOnFireFor(4);
                }
            });
        }
    }

    /** Кольцо огня расходится от стража: через него надо перепрыгнуть или уйти за колонну. */
    private static void flameWave(ElementBoss boss, ServerWorld world) {
        Vec3d center = ground(world, boss.getPos());
        Abilities.soundAt(world, center, Sounds.FIRE_RING, 0.8F);
        Set<UUID> struck = new HashSet<>();
        SpellEntity.spawn(world, SpellKind.FLAME_RING, center, 1.0F, 34).logic(self -> {
            double radius = 1 + 15 * Math.min(1.0, self.age / 30.0);
            self.setSize((float) radius);
            for (PlayerEntity player : ElementBoss.playersAt(world, center.add(0, 1, 0), radius + 1)) {
                double distance = player.getPos().distanceTo(center);
                if (distance > radius - 1.4 && player.getY() < center.y + 1.3 && struck.add(player.getUuid())) {
                    boss.strike(world, player, 6);
                    player.setOnFireFor(4);
                }
            }
        });
    }

    private static void waterVolley(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Effects.repeat(world, 3, 8, step -> {
            if (!boss.isAlive() || !target.isAlive()) {
                return false;
            }
            Abilities.soundAt(world, boss.getPos(), Sounds.WATER_RISE, 1.2F);
            shoot(boss, world, SpellKind.WATER_BLOB, boss.getEyePos(), target.getEyePos(), 0.85, 1.1F, 5, SpellKind.WATER_SPLASH, 1.0F);
            return true;
        });
    }

    private static void iceTrap(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d base = ground(world, target.getPos());
        warn(world, base, 4.0F, 28, ICE_BLUE, () -> {
            if (!boss.isAlive()) {
                return;
            }
            Abilities.soundAt(world, base, Sounds.ICE_FORM, 0.9F);
            Spells.ring(world, SpellKind.ICE_SHARD, base, 2.2, 9, 60, 1.1F, 0xFFFFFF);
            for (PlayerEntity player : ElementBoss.playersAt(world, base.add(0, 1, 0), 4.4)) {
                boss.strike(world, player, 5);
                ElementBoss.slow(player, 70, 3);
            }
        });
    }

    private static void tide(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d start = ground(world, boss.getPos());
        Vec3d to = target.getPos().subtract(start);
        Vec3d forward = new Vec3d(to.x, 0, to.z).normalize();
        Abilities.soundAt(world, start, Sounds.WATER_WAVE, 0.9F);
        Set<UUID> struck = new HashSet<>();
        SpellEntity wave = SpellEntity.spawn(world, SpellKind.WATER_WAVE, start, 1.3F, 44).facing(forward);
        wave.setVelocity(forward.multiply(0.65));
        wave.logic(self -> {
            self.setPosition(self.getPos().add(forward.multiply(0.65)));
            for (PlayerEntity player : ElementBoss.playersAt(world, self.getPos().add(0, 1, 0), 3.8)) {
                if (struck.add(player.getUuid())) {
                    boss.strike(world, player, 6);
                    Abilities.push(player, forward.multiply(1.1).add(0, 0.4, 0));
                }
            }
        });
    }

    private static void hurl(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Abilities.soundAt(world, boss.getPos(), Sounds.EARTH_THROW, 0.8F);
        shoot(boss, world, SpellKind.BOULDER, boss.getEyePos(), target.getEyePos(), 0.85, 1.7F, 8, SpellKind.ROCK_BURST, 1.6F);
    }

    private static void spikeLine(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d start = ground(world, boss.getPos());
        Vec3d to = target.getPos().subtract(start);
        Vec3d forward = new Vec3d(to.x, 0, to.z).normalize();
        for (int i = 1; i <= 9; i++) {
            Vec3d point = ground(world, start.add(forward.multiply(i * 2.0)));
            warn(world, point, 1.4F, 18 + i * 3, STONE, () -> {
                if (!boss.isAlive()) {
                    return;
                }
                SpellEntity.spawn(world, SpellKind.STONE_SPIKE, point, 1.2F, 34).tint(0x8A7F70);
                Abilities.soundAt(world, point, Sounds.EARTH_SPIKE, 0.9F);
                for (PlayerEntity player : ElementBoss.playersAt(world, point.add(0, 1, 0), 1.9)) {
                    boss.strike(world, player, 6);
                    Abilities.push(player, new Vec3d(0, 0.8, 0));
                }
            });
        }
    }

    private static void stomp(ElementBoss boss, ServerWorld world) {
        Vec3d center = ground(world, boss.getPos());
        warn(world, center, 8.0F, 32, STONE, () -> {
            if (!boss.isAlive()) {
                return;
            }
            Abilities.soundAt(world, center, Sounds.EARTH_QUAKE, 0.9F);
            Spells.ring(world, SpellKind.GROUND_SLAB, center, 4.0, 12, 30, 1.2F, 0x8A7F70);
            Spells.ring(world, SpellKind.GROUND_SLAB, center, 7.0, 18, 30, 1.2F, 0x8A7F70);
            for (PlayerEntity player : ElementBoss.playersAt(world, center.add(0, 1, 0), 8.5)) {
                boss.strike(world, player, 8);
                Abilities.push(player, player.getPos().subtract(center).normalize().multiply(0.8).add(0, 0.7, 0));
            }
        });
    }

    private static void saws(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Abilities.soundAt(world, boss.getPos(), Sounds.AIR_SAW, 0.9F);
        Vec3d to = target.getEyePos().subtract(boss.getEyePos());
        double spread = 0.32;
        for (int i = -1; i <= 1; i++) {
            Vec3d turned = to.rotateY((float) (i * spread));
            shoot(boss, world, SpellKind.WIND_SAW, boss.getEyePos(), boss.getEyePos().add(turned), 0.95, 1.3F, 5, SpellKind.WIND_BURST, 1.2F);
        }
    }

    /** Смерч ползёт за игроком пять секунд и тянет его к себе. */
    private static void chasingTwister(ElementBoss boss, ServerWorld world, PlayerEntity target) {
        Vec3d start = ground(world, target.getPos().add(world.random.nextDouble() * 10 - 5, 0, world.random.nextDouble() * 10 - 5));
        Abilities.soundAt(world, start, Sounds.AIR_TORNADO, 0.9F);
        SpellEntity.spawn(world, SpellKind.TORNADO, start, 0.8F, 100).logic(self -> {
            if (!boss.isAlive()) {
                self.discard();
                return;
            }
            Vec3d to = target.getPos().subtract(self.getPos());
            Vec3d step = new Vec3d(to.x, 0, to.z).normalize().multiply(0.13);
            self.setVelocity(step);
            self.setPosition(self.getPos().add(step));
            for (PlayerEntity player : ElementBoss.playersAt(world, self.getPos().add(0, 1, 0), 5.0)) {
                Vec3d in = self.getPos().subtract(player.getPos());
                Abilities.push(player, player.getVelocity().add(new Vec3d(in.x, 0, in.z).normalize().multiply(0.06)));
                if (self.age % 15 == 0 && in.length() < 2.2) {
                    boss.strike(world, player, 4);
                }
            }
        });
    }

    private static void gale(ElementBoss boss, ServerWorld world) {
        Vec3d center = ground(world, boss.getPos());
        warn(world, center, 11.0F, 26, WIND, () -> {
            if (!boss.isAlive()) {
                return;
            }
            Abilities.soundAt(world, center, Sounds.AIR_GUST, 0.8F);
            SpellEntity.spawn(world, SpellKind.WIND_BURST, center.add(0, 1, 0), 9.0F, 14);
            for (PlayerEntity player : ElementBoss.playersAt(world, center.add(0, 1, 0), 11.5)) {
                boss.strike(world, player, 5);
                Abilities.push(player, player.getPos().subtract(center).normalize().multiply(1.6).add(0, 0.5, 0));
            }
        });
    }
}
