package local.minevia.elements;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/**
 * Способности стихий. Всё видимое здесь является 3D-моделями из {@link SpellEntity}.
 * Часть поведения и скоростей взята из открытого AvatarMod (GPL-3, авторы в CREDITS.md),
 * код написан заново под 1.21.1.
 */
final class Spells {
    private static final int DIRT = 0x8A6A48;

    /** Что делает снаряд при попадании. Вернуть true, если снаряд закончил полёт. */
    interface Hit {
        boolean at(Vec3d position, LivingEntity target);
    }

    private Spells() {
    }

    // ------------------------------------------------------------------ огонь

    static void fireball(ServerPlayerEntity player, int level) {
        Abilities.sound(player, Sounds.FIRE_CAST, 1.0F);
        // Помощь в прицеливании: шар летит в ближайшего к прицелу врага и слегка за ним доворачивает.
        LivingEntity locked = Abilities.aim(player, 40);
        Vec3d start = muzzle(player, 1.8);
        Vec3d velocity = crosshair(player, 40).subtract(start).normalize().multiply(0.8);
        SpellEntity ball = SpellEntity.spawn(player.getServerWorld(), SpellKind.FIREBALL, start, 1.2F, 70).charged(Element.FIRE, player);
        ball.facing(velocity).setVelocity(velocity);
        Set<UUID> struck = new HashSet<>();
        ball.logic(self -> {
            if (locked != null && locked.isAlive()) {
                Vec3d to = locked.getBoundingBox().getCenter().subtract(self.getPos()).normalize().multiply(0.8);
                self.setVelocity(self.getVelocity().lerp(to, 0.14));
            }
            flyFire(self, player, struck, 0.7, 2.6, 6 + level * 1.5F, 1.0F);
        });
    }

    /** Большой шар: сначала разгорается перед игроком, потом летит туда, куда он смотрит. */
    static void greatFireball(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_CHARGE, 1.0F);
        SpellEntity ball = SpellEntity.spawn(world, SpellKind.FIREBALL, muzzle(player, 2.6), 0.3F, 90).charged(Element.FIRE, player);
        Set<UUID> struck = new HashSet<>();
        float grown = 2.3F;
        ball.logic(self -> {
            if (self.age < 20) {
                self.setSize(0.3F + (grown - 0.3F) * self.age / 20.0F);
                self.facing(player.getRotationVector());
                hover(self, muzzle(player, 2.6));
                return;
            }
            if (self.age == 20) {
                Abilities.sound(player, Sounds.FIRE_CAST, 0.7F);
                self.setVelocity(crosshair(player, 40).subtract(self.getPos()).normalize().multiply(0.7));
            }
            flyFire(self, player, struck, 1.2, 3.5 + level * 0.5, 10 + level * 2, 2.1F);
        });
    }

    private static void flyFire(SpellEntity self, ServerPlayerEntity owner, Set<UUID> struck, double radius,
            double blast, float damage, float size) {
        boolean ended = fly(self, owner, radius, true, struck, (at, target) -> true);
        if (!ended && self.age < self.life() - 1) {
            return;
        }
        ServerWorld world = (ServerWorld) self.getWorld();
        Vec3d at = self.getPos();
        SpellEntity.spawn(world, SpellKind.FIRE_BURST, at, size * 1.3F, 17);
        Abilities.soundAt(world, at, Sounds.FIRE_BLAST, 1.0F);
        for (LivingEntity near : Abilities.livingAt(owner, at, blast)) {
            Abilities.hurt(owner, near, damage);
            near.setOnFireFor(5);
        }
        self.discard();
    }

    static void flameRing(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_RING, 1.0F);
        Vec3d center = player.getPos();
        Set<UUID> struck = new HashSet<>();
        SpellEntity.spawn(world, SpellKind.FLAME_RING, center, 1.0F, 20).charged(Element.FIRE, player).logic(self -> {
            double radius = 1 + 5.5 * Math.min(1.0, self.age / 16.0);
            self.setSize((float) radius);
            for (LivingEntity target : Abilities.monstersAt(player, center, radius)) {
                if (target.getPos().distanceTo(center) <= radius + 0.5 && struck.add(target.getUuid())) {
                    Abilities.hurt(player, target, 4 + level);
                    target.setOnFireFor(6);
                }
            }
        });
    }

    /** Пламенная броня: сила на 15 секунд, и всё, что подошло вплотную, загорается. */
    static void flameArmor(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.FIRE_ARMOR, 1.0F);
        Abilities.buff(player, StatusEffects.STRENGTH, 300, level >= 4 ? 1 : 0);
        Abilities.buff(player, StatusEffects.FIRE_RESISTANCE, 300, 0);
        SpellEntity.spawn(world, SpellKind.FLAME_AURA, player.getPos(), 0.8F, 300).owner(player).logic(self -> {
            self.setPosition(player.getPos());
            if (!player.isAlive()) {
                self.discard();
            } else if (self.age % 20 == 0) {
                for (LivingEntity target : Abilities.monstersAt(player, player.getPos().add(0, 1, 0), 2.6)) {
                    Abilities.hurt(player, target, 1 + level * 0.5F);
                    target.setOnFireFor(4);
                }
            }
        });
    }

    static void flamethrower(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        SpellEntity.spawn(world, SpellKind.FLAME_JET, player.getEyePos(), 1.0F, 60).owner(player).charged(Element.FIRE, player).logic(self -> {
            self.setPosition(player.getEyePos());
            if (!player.isAlive()) {
                self.discard();
                return;
            }
            if (self.age % 12 == 0) {
                Abilities.sound(player, Sounds.FLAME_LOOP, 1.0F);
            }
            if (self.age % 2 != 0) {
                return;
            }
            Vec3d look = player.getRotationVector();
            Vec3d eye = player.getEyePos();
            for (LivingEntity target : Abilities.livingAt(player, eye.add(look.multiply(4)), 4.5)) {
                Vec3d toTarget = target.getBoundingBox().getCenter().subtract(eye).normalize();
                if (toTarget.dotProduct(look) > 0.82) {
                    Abilities.hurt(player, target, 1.0F + level * 0.4F);
                    target.setOnFireFor(4);
                }
            }
        });
    }

    // ------------------------------------------------------------------ вода

    /**
     * Поток: игрок забирает воду из ближайшего водоёма, а если его нет, вытягивает из земли,
     * и ведёт её взглядом до врага. Из настоящего водоёма поток крупнее и бьёт сильнее.
     */
    static void waterFlow(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d pool = nearestWater(player);
        Vec3d source = pool != null ? pool : groundAhead(player, 2.5);
        float size = pool != null ? 1.2F : 0.95F;
        float damage = (pool != null ? 8 : 6) + level * 1.5F;
        Abilities.soundAt(world, source, Sounds.WATER_RISE, 1.0F);
        SpellEntity.spawn(world, SpellKind.WATER_SPLASH, source, 0.7F, 15);
        Set<UUID> struck = new HashSet<>();
        SpellEntity blob = SpellEntity.spawn(world, SpellKind.WATER_BLOB, source, size, 150).charged(Element.WATER, player);
        blob.logic(self -> {
            if (!player.isAlive() || player.isRemoved()) {
                self.discard();
                return;
            }
            boolean rising = self.age < 12;
            Vec3d aim = rising ? muzzle(player, 3.0) : crosshair(player, 28);
            Vec3d to = aim.subtract(self.getPos());
            double distance = to.length();
            Vec3d want = distance < 0.3 ? Vec3d.ZERO : to.multiply(Math.min(rising ? 0.9 : 1.25, distance * 0.5) / distance);
            self.setVelocity(self.getVelocity().lerp(want, 0.4));
            boolean ended = fly(self, player, 0.75 * size, !rising, struck, (at, target) -> {
                Abilities.hurt(player, target, damage);
                Abilities.debuff(target, StatusEffects.SLOWNESS, 80, 2);
                Abilities.push(target, self.getVelocity().multiply(0.7).add(0, 0.25, 0));
                return true;
            });
            if (ended || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, self.getPos(), 1.15F * size, 15);
                Abilities.soundAt(world, self.getPos(), Sounds.WATER_HIT, 1.0F);
                self.discard();
            }
        });
    }

    static void healing(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        float amount = 4 + level * 2;
        Abilities.sound(player, Sounds.WATER_HEAL, 1.0F);
        for (PlayerEntity ally : world.getEntitiesByClass(PlayerEntity.class, player.getBoundingBox().expand(8), PlayerEntity::isAlive)) {
            ally.heal(amount);
            ally.extinguish();
            SpellEntity.spawn(world, SpellKind.HEAL_SPIRAL, ally.getPos(), 1.0F, 34).owner(ally).tint(0x6FE3D2)
                    .logic(self -> self.setPosition(ally.getPos()));
        }
    }

    static void iceRing(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.ICE_FORM, 1.0F);
        Vec3d feet = player.getPos();
        double ground = groundAt(world, feet);
        Vec3d center = Double.isNaN(ground) ? feet : new Vec3d(feet.x, ground, feet.z);
        ring(world, SpellKind.ICE_SHARD, center, 2.6, 9, 70, 1.0F, 0xFFFFFF);
        Effects.later(world, 5, () -> {
            ring(world, SpellKind.ICE_SHARD, center, 5.0, 16, 66, 1.15F, 0xFFFFFF);
            Abilities.soundAt(world, center, Sounds.ICE_FORM, 0.8F);
        });
        for (LivingEntity target : Abilities.monstersAt(player, center, 6)) {
            Abilities.hurt(player, target, 3 + level);
            Abilities.debuff(target, StatusEffects.SLOWNESS, 120, 3);
            target.setFrozenTicks(160);
        }
    }

    /** Водяная плеть: хлещет цель на линии взгляда и подтаскивает её к игроку. */
    static void whip(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.WATER_WHIP, 1.0F);
        LivingEntity target = Abilities.aim(player, 20);
        Vec3d look = player.getRotationVector();
        SpellEntity whip = SpellEntity.spawn(world, SpellKind.WATER_WHIP, player.getPos(), 12.0F, 11).owner(player);
        whip.facing(look);
        if (target != null) {
            whip.target(target);
        }
        whip.logic(self -> {
            self.setPosition(player.getPos());
            if (self.age == 3 && target != null && target.isAlive()) {
                Abilities.hurt(player, target, 8 + level * 2);
                Abilities.debuff(target, StatusEffects.SLOWNESS, 60, 1);
                Vec3d pull = player.getPos().subtract(target.getPos());
                Abilities.push(target, pull.normalize().multiply(Math.min(2.0, pull.length() * 0.22)).add(0, 0.32, 0));
                SpellEntity.spawn(world, SpellKind.WATER_SPLASH, target.getBoundingBox().getCenter(), 0.6F, 15);
            }
        });
    }

    static void wave(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.WATER_WAVE, 1.0F);
        Vec3d forward = flatLook(player);
        Vec3d start = player.getPos().add(forward.multiply(2.0));
        Set<UUID> struck = new HashSet<>();
        double half = 2.6 + level * 0.4;
        float size = (float) (half / 3.0);
        SpellEntity wave = SpellEntity.spawn(world, SpellKind.WATER_WAVE, start, size, 36).facing(forward).charged(Element.WATER, player);
        wave.setVelocity(forward.multiply(0.6));
        wave.logic(self -> {
            Vec3d at = self.getPos();
            double ground = groundAt(world, at.add(0, 1, 0));
            double dy = Double.isNaN(ground) ? 0 : MathHelper.clamp(ground - at.y, -0.5, 0.5);
            self.setVelocity(forward.multiply(0.6).add(0, dy, 0));
            self.setPosition(at.add(self.getVelocity()));
            for (LivingEntity target : Abilities.monstersAt(player, self.getPos().add(0, 1, 0), half)) {
                Abilities.push(target, forward.multiply(0.8).add(0, 0.28, 0));
                if (struck.add(target.getUuid())) {
                    Abilities.hurt(player, target, 5 + level);
                }
            }
        });
    }

    // ------------------------------------------------------------------ земля

    /** Глыба: кусок земли вырывается из-под ног, зависает перед игроком и летит туда, куда он смотрит. */
    static void boulder(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d ground = groundAhead(player, 2.8);
        int tint = groundColor(world, ground);
        Abilities.soundAt(world, ground, Sounds.EARTH_RISE, 1.0F);
        SpellEntity.spawn(world, SpellKind.GROUND_RING, ground, 1.15F, 34).tint(tint);
        SpellEntity.spawn(world, SpellKind.DUST_PUFF, ground, 1.0F, 18).tint(tint);
        float size = 0.8F + level * 0.06F;
        Set<UUID> struck = new HashSet<>();
        int rise = 13;
        int release = 24;
        SpellKind kind = tint == DIRT ? SpellKind.EARTH_CHUNK : SpellKind.BOULDER;
        SpellEntity rock = SpellEntity.spawn(world, kind, ground.add(0, -1.1, 0), size, 110).tint(tint).charged(Element.EARTH, player);
        rock.logic(self -> {
            if (!player.isAlive() || player.isRemoved()) {
                self.discard();
                return;
            }
            if (self.age < release) {
                Vec3d aim = muzzle(player, 3.6).add(0, -0.75, 0);
                if (self.age < rise) {
                    float eased = 1 - (1 - self.age / (float) rise) * (1 - self.age / (float) rise);
                    aim = ground.add(0, -1.1, 0).lerp(aim, eased);
                }
                hover(self, aim);
                return;
            }
            if (self.age == release) {
                Abilities.sound(player, Sounds.EARTH_THROW, 1.0F);
                // Глыба висит ниже прицела, поэтому летит не вдоль взгляда, а прямо в точку прицела.
                self.setVelocity(crosshair(player, 40).subtract(self.getPos()).normalize().multiply(1.25));
            }
            self.setVelocity(self.getVelocity().add(0, -0.008, 0));
            boolean ended = fly(self, player, 0.9 * size, true, struck, (at, target) -> {
                Abilities.hurt(player, target, 7 + level * 2);
                Abilities.push(target, self.getVelocity().normalize().multiply(1.3).add(0, 0.4, 0));
                return true;
            });
            if (ended || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.ROCK_BURST, self.getPos(), size * 1.25F, 18).tint(tint);
                SpellEntity.spawn(world, SpellKind.DUST_PUFF, self.getPos(), size * 1.3F, 18).tint(tint);
                Abilities.soundAt(world, self.getPos(), Sounds.EARTH_HIT, 1.0F);
                if (self.infused() == Element.FIRE) {
                    Combos.magmaPool(player, self.getPos(), 7 + level);
                }
                for (LivingEntity near : Abilities.monstersAt(player, self.getPos(), 2.4)) {
                    if (struck.add(near.getUuid())) {
                        Abilities.hurt(player, near, 3 + level);
                    }
                }
                self.discard();
            }
        });
    }

    static void quake(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.EARTH_QUAKE, 1.0F);
        Vec3d feet = player.getPos();
        double ground = groundAt(world, feet.add(0, 0.5, 0));
        Vec3d center = Double.isNaN(ground) ? feet : new Vec3d(feet.x, ground, feet.z);
        int tint = groundColor(world, center);
        for (int ring = 0; ring < 3; ring++) {
            double radius = 2.0 + ring * 2.0;
            int count = 8 + ring * 6;
            Effects.later(world, ring * 3, () -> {
                ring(world, SpellKind.GROUND_SLAB, center, radius, count, 30, 1.0F, tint);
                SpellEntity.spawn(world, SpellKind.DUST_PUFF, center, (float) radius * 0.7F, 18).tint(tint);
            });
        }
        for (LivingEntity target : Abilities.monstersAt(player, center, 6)) {
            Abilities.hurt(player, target, 5 + level);
            Vec3d away = target.getPos().subtract(center).normalize().multiply(0.9);
            Abilities.push(target, away.add(0, 0.75, 0));
        }
    }

    static void stoneArmor(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.EARTH_ARMOR, 1.0F);
        Abilities.buff(player, StatusEffects.RESISTANCE, 300, level >= 4 ? 2 : 1);
        Abilities.buff(player, StatusEffects.ABSORPTION, 300, level >= 4 ? 2 : 1);
        int tint = groundColor(world, player.getPos());
        SpellEntity.spawn(world, SpellKind.STONE_PLATES, player.getPos(), 1.0F, 300).owner(player).tint(tint).logic(self -> {
            self.setPosition(player.getPos());
            if (!player.isAlive()) {
                self.discard();
            }
        });
    }

    static void spikes(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d forward = flatLook(player);
        Vec3d start = player.getPos();
        Set<UUID> struck = new HashSet<>();
        Effects.repeat(world, 12, 2, step -> {
            Vec3d at = start.add(forward.multiply(2 + step * 1.25));
            double ground = groundAt(world, at);
            if (Double.isNaN(ground)) {
                return false;
            }
            Vec3d point = new Vec3d(at.x, ground, at.z);
            int tint = groundColor(world, point);
            SpellEntity.spawn(world, SpellKind.STONE_SPIKE, point, 1.0F + world.random.nextFloat() * 0.3F, 34).tint(tint);
            Abilities.soundAt(world, point, Sounds.EARTH_SPIKE, 1.0F);
            for (LivingEntity target : Abilities.livingAt(player, point.add(0, 0.8, 0), 1.7)) {
                if (struck.add(target.getUuid())) {
                    Abilities.hurt(player, target, 7 + level * 2);
                    Abilities.push(target, new Vec3d(0, 0.9, 0));
                }
            }
            return true;
        });
    }

    /** Стена: видимые столбы поднимаются из земли, а внутри них появляются настоящие блоки. */
    static void wall(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.EARTH_WALL, 1.0F);
        Direction facing = player.getHorizontalFacing();
        Direction across = facing.rotateYClockwise();
        BlockPos center = player.getBlockPos().offset(facing, 3);
        int half = 2 + (level >= 5 ? 1 : 0);
        BlockState stone = Blocks.MOSSY_COBBLESTONE.getDefaultState();
        for (int s = -half; s <= half; s++) {
            BlockPos column = center.offset(across, s);
            int delay = Math.abs(s) * 2;
            Vec3d base = Vec3d.ofBottomCenter(column);
            int tint = groundColor(world, base);
            Effects.later(world, delay, () -> SpellEntity.spawn(world, SpellKind.STONE_WALL, base, 1.0F, 214).tint(tint));
            for (int y = 0; y < 4; y++) {
                Effects.temporaryBlock(world, column.up(y), stone, delay + 8 + y, 200);
            }
        }
    }

    // ------------------------------------------------------------------ воздух

    /** Рывок: игрок вихрем пролетает вперёд и бьёт всех, кого задел. */
    static void dash(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_DASH, 1.0F);
        Vec3d velocity = player.getRotationVector().multiply(1.75 + level * 0.1).add(0, 0.08, 0);
        SpellEntity.spawn(world, SpellKind.WIND_BURST, player.getPos().add(0, 0.9, 0), 2.2F, 14);
        SpellEntity tunnel = SpellEntity.spawn(world, SpellKind.WIND_TUNNEL, player.getPos(), 1.0F, 10).owner(player).facing(velocity);
        tunnel.logic(self -> self.setPosition(player.getPos()));
        Set<UUID> struck = new HashSet<>();
        Effects.repeat(world, 8, 1, step -> {
            if (!player.isAlive()) {
                return false;
            }
            Abilities.push(player, velocity);
            player.fallDistance = 0;
            for (LivingEntity target : Abilities.livingAt(player, player.getPos().add(0, 1, 0), 2.1)) {
                if (struck.add(target.getUuid())) {
                    Abilities.hurt(player, target, 5 + level * 1.5F);
                    Vec3d aside = target.getPos().subtract(player.getPos()).normalize().multiply(0.7);
                    Abilities.push(target, velocity.multiply(0.45).add(aside).add(0, 0.45, 0));
                }
            }
            return true;
        });
    }

    /** Воздушная пила: диск режет всех на пути, долетает до предела и возвращается в руку. */
    static void airSaw(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d out = crosshair(player, 30).subtract(muzzle(player, 2.0)).normalize().multiply(1.25);
        float damage = 5 + level * 1.5F;
        int turn = 18;
        Set<UUID> outward = new HashSet<>();
        Set<UUID> back = new HashSet<>();
        SpellEntity saw = SpellEntity.spawn(world, SpellKind.WIND_SAW, muzzle(player, 2.0), 1.5F, 80).facing(out).charged(Element.AIR, player);
        saw.setVelocity(out);
        saw.logic(self -> {
            if (self.age % 10 == 0) {
                Abilities.soundAt(world, self.getPos(), Sounds.AIR_SAW, 1.0F);
            }
            boolean returning = self.age > turn;
            if (returning) {
                Vec3d home = player.getEyePos().subtract(self.getPos());
                if (home.length() < 1.6 || !player.isAlive()) {
                    self.discard();
                    return;
                }
                self.setVelocity(self.getVelocity().lerp(home.normalize().multiply(1.4), 0.3));
            } else {
                self.setVelocity(out.multiply(1 - 0.75 * self.age / turn));
            }
            boolean ended = fly(self, player, 1.3, !returning, returning ? back : outward, (at, target) -> {
                Abilities.hurt(player, target, damage);
                return false;
            });
            if (ended || self.age >= self.life() - 1) {
                SpellEntity.spawn(world, SpellKind.WIND_BURST, self.getPos(), 1.4F, 14);
                self.discard();
            }
        });
    }

    static void updraft(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_GUST, 1.0F);
        Vec3d feet = player.getPos();
        SpellEntity.spawn(world, SpellKind.WIND_BURST, feet.add(0, 0.2, 0), 2.6F, 14);
        SpellEntity.spawn(world, SpellKind.TORNADO, feet, 0.6F, 26);
        Abilities.push(player, new Vec3d(0, 1.3 + level * 0.1, 0));
        Abilities.buff(player, StatusEffects.SLOW_FALLING, 200 + level * 20, 0);
        player.fallDistance = 0;
    }

    /** Смерч: идёт вперёд, затягивает монстров и крутит их в воздухе. */
    static void tornado(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Vec3d start = groundAhead(player, 3.0);
        SpellEntity storm = SpellEntity.spawn(world, SpellKind.TORNADO, start, 1.0F, 110).charged(Element.AIR, player);
        driveTornado(storm, player, flatLook(player).multiply(0.2), level);
    }

    /** Смерч идёт по земле и крутит монстров. Зажжённый комбо жжёт их, а с камнями бьёт и ослепляет. */
    static void driveTornado(SpellEntity storm, ServerPlayerEntity player, Vec3d step, int level) {
        ServerWorld world = player.getServerWorld();
        storm.setVelocity(step);
        storm.logic(self -> {
            Vec3d at = self.getPos();
            double ground = groundAt(world, at.add(0, 1.5, 0));
            double dy = Double.isNaN(ground) ? 0 : MathHelper.clamp(ground - at.y, -0.4, 0.4);
            self.setVelocity(step.add(0, dy, 0));
            self.setPosition(at.add(self.getVelocity()));
            if (self.age % 30 == 0) {
                Abilities.soundAt(world, at, Sounds.AIR_TORNADO, 1.0F);
            }
            Element infused = self.infused();
            for (LivingEntity target : Abilities.monstersAt(player, at.add(0, 2, 0), 6)) {
                Vec3d toCore = at.subtract(target.getPos());
                Vec3d flat = new Vec3d(toCore.x, 0, toCore.z);
                double distance = Math.max(0.5, flat.length());
                Vec3d around = new Vec3d(-flat.z, 0, flat.x).normalize().multiply(0.34);
                Abilities.push(target, flat.normalize().multiply(0.3).add(around).add(0, distance < 2.5 ? 0.36 : 0.08, 0));
                if (self.age % 10 == 0 && distance < 3) {
                    float damage = 2 + level * 0.8F;
                    if (infused == null) {
                        Abilities.hurt(player, target, damage);
                    } else {
                        Abilities.strike(player, target, damage * 2);
                        if (infused == Element.FIRE) {
                            target.setOnFireFor(5);
                        } else {
                            Abilities.debuff(target, StatusEffects.BLINDNESS, 60, 0);
                        }
                    }
                }
            }
        });
    }

    static void dome(ServerPlayerEntity player, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.sound(player, Sounds.AIR_DOME, 1.0F);
        double radius = 2.8 + level * 0.3;
        SpellEntity.spawn(world, SpellKind.WIND_DOME, player.getPos(), (float) radius, 160).owner(player).charged(Element.AIR, player).logic(self -> {
            self.setPosition(player.getPos());
            if (!player.isAlive()) {
                self.discard();
                return;
            }
            Vec3d center = player.getPos().add(0, 1, 0);
            for (LivingEntity target : Abilities.monstersAt(player, center, radius)) {
                Abilities.push(target, target.getPos().subtract(player.getPos()).normalize().multiply(0.8).add(0, 0.2, 0));
            }
            Box area = new Box(center, center).expand(radius);
            for (ProjectileEntity shot : world.getEntitiesByClass(ProjectileEntity.class, area, shot -> shot.getOwner() != player)) {
                Abilities.push(shot, shot.getVelocity().multiply(-0.6));
            }
        });
    }

    // ------------------------------------------------------------------ общее

    /** Двигает снаряд на шаг. Вернёт true, если он упёрся в блок или обработчик попадания закончил полёт. */
    static boolean fly(SpellEntity self, ServerPlayerEntity owner, double radius, boolean solid, Set<UUID> struck, Hit hit) {
        ServerWorld world = (ServerWorld) self.getWorld();
        Vec3d from = self.getPos();
        Vec3d next = from.add(self.getVelocity());
        BlockHitResult block = world.raycast(new RaycastContext(from, next,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, self));
        boolean blocked = solid && block.getType() != HitResult.Type.MISS;
        Vec3d end = blocked ? block.getPos() : next;

        Box sweep = new Box(from, end).expand(radius);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, sweep, entity -> Abilities.canHit(entity, owner))) {
            if (struck.add(target.getUuid()) && hit.at(target.getBoundingBox().getCenter(), target)) {
                self.setPosition(end);
                return true;
            }
        }
        self.setPosition(end);
        return blocked;
    }

    /** Круг из отдельных моделей: каждая стоит на своей земле и смотрит наружу. */
    static void ring(ServerWorld world, SpellKind kind, Vec3d center, double radius, int count, int life, float size, int tint) {
        double start = world.random.nextDouble() * Math.PI * 2;
        for (int i = 0; i < count; i++) {
            double angle = start + Math.PI * 2 * (i + world.random.nextDouble() * 0.5) / count;
            Vec3d out = new Vec3d(Math.cos(angle), 0, Math.sin(angle));
            Vec3d at = center.add(out.multiply(radius));
            double ground = groundAt(world, at.add(0, 1, 0));
            if (!Double.isNaN(ground)) {
                float scale = size * (0.8F + world.random.nextFloat() * 0.45F);
                SpellEntity.spawn(world, kind, new Vec3d(at.x, ground, at.z), scale, life).facing(out).tint(tint);
            }
        }
    }

    /** Подтягивает модель к точке, сообщая клиенту скорость, чтобы движение было плавным. */
    static void hover(SpellEntity self, Vec3d point) {
        Vec3d step = point.subtract(self.getPos()).multiply(0.5);
        self.setVelocity(step);
        self.setPosition(self.getPos().add(step));
    }

    /** Точка перед глазами игрока: модель у самых глаз закрыла бы весь экран. */
    static Vec3d muzzle(ServerPlayerEntity player, double distance) {
        return player.getEyePos().add(player.getRotationVector().multiply(distance));
    }

    static Vec3d flatLook(ServerPlayerEntity player) {
        Vec3d look = player.getRotationVector();
        Vec3d flat = new Vec3d(look.x, 0, look.z);
        return flat.lengthSquared() < 0.01 ? new Vec3d(1, 0, 0) : flat.normalize();
    }

    /** Куда направлен прицел: первый враг на линии взгляда или блок, с небольшим отступом от него. */
    static Vec3d crosshair(ServerPlayerEntity player, double range) {
        Vec3d eye = player.getEyePos();
        Vec3d look = player.getRotationVector();
        HitResult block = player.raycast(range, 1.0F, false);
        double reach = block.getType() == HitResult.Type.MISS ? range : block.getPos().distanceTo(eye) - 0.9;
        LivingEntity target = Abilities.aim(player, Math.max(1, reach));
        return target != null ? target.getBoundingBox().getCenter() : eye.add(look.multiply(Math.max(1, reach)));
    }

    private static Vec3d nearestWater(ServerPlayerEntity player) {
        ServerWorld world = player.getServerWorld();
        for (BlockPos pos : BlockPos.iterateOutwards(player.getBlockPos(), 8, 4, 8)) {
            if (world.getFluidState(pos).isIn(FluidTags.WATER)) {
                return Vec3d.ofCenter(pos);
            }
        }
        return null;
    }

    static Vec3d groundAhead(ServerPlayerEntity player, double distance) {
        Vec3d at = player.getPos().add(flatLook(player).multiply(distance));
        double ground = groundAt(player.getServerWorld(), at.add(0, 1, 0));
        return Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
    }

    static double groundAt(ServerWorld world, Vec3d at) {
        BlockPos.Mutable pos = BlockPos.ofFloored(at).mutableCopy().move(Direction.UP, 2);
        for (int i = 0; i < 8; i++) {
            pos.move(Direction.DOWN);
            if (world.getBlockState(pos).isSolidBlock(world, pos)) {
                return pos.getY() + 1.0;
            }
        }
        return Double.NaN;
    }

    /** Цвет грунта под точкой: глыба с песка песчаная, с камня серая, с травы становится куском дёрна. */
    static int groundColor(ServerWorld world, Vec3d at) {
        BlockPos pos = BlockPos.ofFloored(at).down();
        BlockState state = world.getBlockState(pos);
        int color = state.getMapColor(world, pos).color;
        return state.isAir() || state.isIn(BlockTags.DIRT) || color == 0 ? DIRT : color;
    }
}
