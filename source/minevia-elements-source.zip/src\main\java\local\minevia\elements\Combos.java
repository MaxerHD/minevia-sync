package local.minevia.elements;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Комбо двух стихий. Удар способностью оставляет на враге метку на шесть секунд, и удар другой стихией
 * по этой метке запускает комбо. Ещё комбо срабатывает, когда способности двух стихий сошлись рядом:
 * например, фаербол влетел в смерч. Одна стихия у игрока одна, поэтому комбо всегда работа двоих.
 */
final class Combos {
    /** Шесть пар из четырёх стихий. */
    enum Combo {
        STEAM(Element.FIRE, Element.WATER),
        FIRESTORM(Element.FIRE, Element.AIR),
        MAGMA(Element.FIRE, Element.EARTH),
        FROST(Element.WATER, Element.AIR),
        MUD(Element.WATER, Element.EARTH),
        SANDSTORM(Element.EARTH, Element.AIR);

        final Element first;
        final Element second;

        Combo(Element first, Element second) {
            this.first = first;
            this.second = second;
        }

        static Combo of(Element a, Element b) {
            for (Combo combo : values()) {
                if (combo.first == a && combo.second == b || combo.first == b && combo.second == a) {
                    return combo;
                }
            }
            return null;
        }

        String key() {
            return "combo.minevia_elements." + name().toLowerCase(java.util.Locale.ROOT);
        }
    }

    private record Mark(Element element, long until, SpellEntity orb) {
    }

    private static final int MARK_TICKS = 120;
    private static final int RESTING_TICKS = 40;
    private static final double NEAR = 3.2;
    private static final double SPELL_FINDS_SPELL = 7.0;

    private static final Map<UUID, Mark> MARKS = new HashMap<>();
    private static final Map<UUID, Long> RESTING = new HashMap<>();
    private static final List<SpellEntity> ACTIVE = new ArrayList<>();

    private Combos() {
    }

    static void track(SpellEntity spell) {
        ACTIVE.add(spell);
    }

    static void clear() {
        MARKS.clear();
        RESTING.clear();
        ACTIVE.clear();
    }

    /** Игрок ударил цель своей стихией: ставит метку или, если метка чужой стихии уже есть, запускает комбо. */
    static void hit(ServerPlayerEntity player, LivingEntity target, Element element) {
        long now = player.getServer().getTicks();
        UUID id = target.getUuid();
        if (RESTING.getOrDefault(id, 0L) > now) {
            return;
        }
        Mark mark = MARKS.get(id);
        if (mark != null && mark.until() > now && mark.element() != element) {
            MARKS.remove(id);
            mark.orb().discard();
            RESTING.put(id, now + RESTING_TICKS);
            trigger(Combo.of(mark.element(), element), player, target.getBoundingBox().getCenter(), target);
            return;
        }
        if (mark != null) {
            mark.orb().discard();
        }
        if (!target.isAlive()) {
            return;
        }
        ServerWorld world = player.getServerWorld();
        SpellEntity orb = SpellEntity.spawn(world, SpellKind.ELEMENT_MARK, target.getPos(), 0.55F, MARK_TICKS)
                .owner(target).tint(element.color);
        orb.logic(self -> {
            self.setPosition(target.getPos());
            if (!target.isAlive()) {
                self.discard();
            }
        });
        MARKS.put(id, new Mark(element, now + MARK_TICKS, orb));
    }

    /** Ищет способности разных стихий, которые сошлись рядом. Их всегда единицы, поэтому перебор дешёвый. */
    static void tick(MinecraftServer server) {
        long now = server.getTicks();
        MARKS.values().removeIf(mark -> mark.until() <= now);
        RESTING.values().removeIf(until -> until <= now);
        ACTIVE.removeIf(SpellEntity::isRemoved);
        if (now % 2 != 0) {
            return;
        }
        for (int i = 0; i < ACTIVE.size(); i++) {
            SpellEntity a = ACTIVE.get(i);
            for (int j = i + 1; j < ACTIVE.size(); j++) {
                SpellEntity b = ACTIVE.get(j);
                if (a.charge() != b.charge() && a.getWorld() == b.getWorld() && !a.isRemoved() && !b.isRemoved()
                        && a.getPos().distanceTo(b.getPos()) < reach(a, b)) {
                    meet(a, b);
                    return;
                }
            }
        }
    }

    /** Большие способности ловят другие на большем расстоянии, иначе в смерч пришлось бы попадать точно в ось. */
    private static double reach(SpellEntity a, SpellEntity b) {
        return NEAR + (wide(a) ? 1.6 : 0) + (wide(b) ? 1.6 : 0);
    }

    private static boolean wide(SpellEntity spell) {
        SpellKind kind = spell.kind();
        return kind == SpellKind.TORNADO || kind == SpellKind.WATER_WAVE || kind == SpellKind.WIND_DOME || kind == SpellKind.FLAME_RING;
    }

    private static void meet(SpellEntity a, SpellEntity b) {
        Combo combo = Combo.of(a.charge(), b.charge());
        ServerPlayerEntity player = b.caster() != null ? b.caster() : a.caster();
        Vec3d at = a.getPos().lerp(b.getPos(), 0.5);
        ACTIVE.remove(a);
        ACTIVE.remove(b);
        trigger(combo, player, at, null);
        // Снаряд, отдавший стихию, исчезает. Смерч, волна и глыба живут дальше с новым свойством.
        for (SpellEntity spell : List.of(a, b)) {
            SpellKind kind = spell.kind();
            if (kind == SpellKind.FIREBALL || kind == SpellKind.WATER_BLOB) {
                spell.discard();
            }
        }
    }

    private static void trigger(Combo combo, ServerPlayerEntity player, Vec3d at, LivingEntity target) {
        ServerWorld world = player.getServerWorld();
        int level = levelOf(player);
        Abilities.soundAt(world, at, Sounds.COMBO, 1.0F);
        switch (combo) {
            case STEAM -> steamCloud(player, at, level);
            case FIRESTORM -> storm(player, at, level, SpellKind.FIRE_TORNADO, Element.FIRE);
            case SANDSTORM -> storm(player, at, level, SpellKind.ROCK_TORNADO, Element.EARTH);
            case MAGMA -> molten(player, at, level);
            case FROST -> frost(player, at, level);
            case MUD -> mudPool(player, at, level);
        }
        Box area = new Box(at, at).expand(32);
        for (PlayerEntity near : world.getEntitiesByClass(PlayerEntity.class, area, PlayerEntity::isAlive)) {
            near.sendMessage(Text.translatable("message.minevia_elements.combo", Text.translatable(combo.key())), true);
        }
        ElementBoss.onCombo(world, at, combo.first, combo.second);
    }

    private static int levelOf(ServerPlayerEntity player) {
        ElementState.Data data = ElementState.get(player.getServer()).find(player.getUuid());
        return data != null ? data.level : 1;
    }

    private static SpellEntity nearest(SpellKind kind, ServerWorld world, Vec3d at) {
        for (SpellEntity spell : ACTIVE) {
            if (spell.kind() == kind && spell.getWorld() == world && spell.getPos().distanceTo(at) < SPELL_FINDS_SPELL) {
                return spell;
            }
        }
        return null;
    }

    /** Огненный смерч или песчаная буря: живой смерч рядом меняется, а если его нет, поднимается небольшой новый. */
    private static void storm(ServerPlayerEntity player, Vec3d at, int level, SpellKind look, Element infused) {
        ServerWorld world = player.getServerWorld();
        SpellEntity tornado = nearest(SpellKind.TORNADO, world, at);
        if (tornado != null) {
            tornado.infuse(infused, look);
            tornado.setLife(tornado.age + 90);
            return;
        }
        double ground = Spells.groundAt(world, at);
        Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
        SpellEntity small = SpellEntity.spawn(world, look, base, 1.0F, 90);
        small.infuse(infused, look);
        Spells.driveTornado(small, player, Vec3d.ZERO, level);
    }

    /** Облако пара: враги внутри слепнут, замедляются и получают ожоги. */
    static void steamCloud(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.soundAt(world, at, Sounds.STEAM, 1.0F);
        SpellEntity.spawn(world, SpellKind.STEAM_CLOUD, at.add(0, -0.5, 0), 3.2F, 130).logic(self -> {
            if (self.age % 10 == 0) {
                for (LivingEntity near : Abilities.monstersAt(player, at, 5.5)) {
                    Abilities.debuff(near, StatusEffects.BLINDNESS, 50, 0);
                    Abilities.debuff(near, StatusEffects.SLOWNESS, 50, 1);
                    Abilities.strike(player, near, 1 + level * 0.5F);
                }
            }
        });
    }

    /** Глыба рядом раскаляется, а если её нет, раскалённый камень падает с неба прямо в цель. */
    private static void molten(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        for (SpellKind kind : List.of(SpellKind.BOULDER, SpellKind.EARTH_CHUNK)) {
            SpellEntity rock = nearest(kind, world, at);
            if (rock != null) {
                rock.infuse(Element.FIRE, SpellKind.MAGMA_BOULDER);
                return;
            }
        }
        Vec3d fall = new Vec3d(0, -0.8, 0);
        SpellEntity stone = SpellEntity.spawn(world, SpellKind.MAGMA_BOULDER, at.add(0, 7, 0), 1.2F, 40);
        stone.setVelocity(fall);
        Set<UUID> struck = new HashSet<>();
        stone.logic(self -> {
            boolean ended = Spells.fly(self, player, 1.2, true, struck, (point, near) -> {
                Abilities.strike(player, near, 8 + level * 2);
                near.setOnFireFor(6);
                return false;
            });
            if (ended || self.getY() <= at.y - 1.5) {
                SpellEntity.spawn(world, SpellKind.FIRE_BURST, self.getPos(), 1.5F, 17);
                Abilities.soundAt(world, self.getPos(), Sounds.EARTH_HIT, 0.8F);
                magmaPool(player, self.getPos(), level + 5);
                self.discard();
            }
        });
    }

    /** Лужа магмы. Настоящей лавы нет, поэтому мир и база не пострадают. */
    static void magmaPool(ServerPlayerEntity player, Vec3d at, int power) {
        ServerWorld world = player.getServerWorld();
        double ground = Spells.groundAt(world, at.add(0, 1, 0));
        Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
        Abilities.soundAt(world, base, Sounds.MAGMA, 1.0F);
        SpellEntity.spawn(world, SpellKind.MAGMA_POOL, base, 3.4F, 130).logic(self -> {
            if (self.age % 10 == 0) {
                for (LivingEntity near : Abilities.monstersAt(player, base, 3.8)) {
                    Abilities.strike(player, near, 1 + power * 0.4F);
                    near.setOnFireFor(4);
                }
            }
        });
    }

    /** Заморозка: волна рядом застывает ледяной стеной, а цель вмерзает в кристаллы. */
    private static void frost(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        Abilities.soundAt(world, at, Sounds.ICE_FORM, 0.8F);
        SpellEntity wave = nearest(SpellKind.WATER_WAVE, world, at);
        Vec3d center = at;
        if (wave != null) {
            center = wave.getPos();
            Vec3d across = wave.getRotationVector().crossProduct(new Vec3d(0, 1, 0)).normalize();
            for (int i = -4; i <= 4; i++) {
                Vec3d point = center.add(across.multiply(i * 1.1));
                double ground = Spells.groundAt(world, point.add(0, 1, 0));
                if (!Double.isNaN(ground)) {
                    SpellEntity.spawn(world, SpellKind.ICE_SHARD, new Vec3d(point.x, ground, point.z), 1.3F, 90);
                }
            }
            wave.discard();
        } else {
            double ground = Spells.groundAt(world, at.add(0, 1, 0));
            Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
            Spells.ring(world, SpellKind.ICE_SHARD, base, 1.4, 7, 80, 1.1F, 0xFFFFFF);
        }
        for (LivingEntity near : Abilities.livingAt(player, center, 4.5)) {
            Abilities.strike(player, near, 6 + level * 1.5F);
            Abilities.debuff(near, StatusEffects.SLOWNESS, 100, 5);
            near.setFrozenTicks(240);
        }
    }

    /** Топь: враги вязнут и почти не могут идти. */
    static void mudPool(ServerPlayerEntity player, Vec3d at, int level) {
        ServerWorld world = player.getServerWorld();
        double ground = Spells.groundAt(world, at.add(0, 1, 0));
        Vec3d base = Double.isNaN(ground) ? at : new Vec3d(at.x, ground, at.z);
        Abilities.soundAt(world, base, Sounds.WATER_HIT, 0.6F);
        SpellEntity.spawn(world, SpellKind.MUD_POOL, base, 4.2F, 160).logic(self -> {
            if (self.age % 10 == 0) {
                for (LivingEntity near : Abilities.monstersAt(player, base, 4.6)) {
                    Abilities.debuff(near, StatusEffects.SLOWNESS, 30, 5);
                    Abilities.debuff(near, StatusEffects.WEAKNESS, 30, 1);
                    if (self.age % 20 == 0) {
                        Abilities.strike(player, near, 1 + level * 0.3F);
                    }
                }
            }
        });
    }
}
