package local.minevia.elements.net;

import local.minevia.elements.MineviaElements;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Действие из меню стихии: выбор пути или поиск ближайшего храма. */
public record MenuPayload(int action, int value) implements CustomPayload {
    public static final int CHOOSE_PATH = 0;
    public static final int FIND_TEMPLE = 1;

    public static final Id<MenuPayload> ID = new Id<>(Identifier.of(MineviaElements.MOD_ID, "menu"));
    public static final PacketCodec<RegistryByteBuf, MenuPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, MenuPayload::action,
            PacketCodecs.VAR_INT, MenuPayload::value,
            MenuPayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
