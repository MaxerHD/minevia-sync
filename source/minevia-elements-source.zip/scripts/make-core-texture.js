'use strict';
// Рисует текстуру Ядра стихии 16x16: кристалл из четырёх цветов.
const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');

const COLORS = {
  '.': [0, 0, 0, 0],
  k: [24, 20, 34, 255],
  f: [255, 138, 61, 255],
  w: [92, 200, 255, 255],
  e: [168, 212, 104, 255],
  a: [228, 240, 246, 255],
  s: [255, 250, 225, 255],
};
const ART = [
  '................',
  '.......kk.......',
  '......kffk......',
  '.....kfsfwk.....',
  '....kffsfwwk....',
  '...kfffsfwwwk...',
  '..kffffsswwwwk..',
  '..kfffsssswwwk..',
  '..keeesssaaaak..',
  '..keeeessaaaak..',
  '...keeesaaaak...',
  '....keesaaak....',
  '.....kesaak.....',
  '......keak......',
  '.......kk.......',
  '................',
];

function crc32(buffer) {
  let crc = ~0;
  for (const byte of buffer) {
    crc ^= byte;
    for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ (crc & 1 ? 0xedb88320 : 0);
  }
  return ~crc >>> 0;
}

function chunk(type, data) {
  const body = Buffer.concat([Buffer.from(type), data]);
  const length = Buffer.alloc(4);
  length.writeUInt32BE(data.length);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([length, body, crc]);
}

const raw = Buffer.alloc((16 * 4 + 1) * 16);
ART.forEach((row, y) => {
  [...row].forEach((pixel, x) => raw.set(COLORS[pixel], y * 65 + 1 + x * 4));
});

const header = Buffer.alloc(13);
header.writeUInt32BE(16, 0);
header.writeUInt32BE(16, 4);
header[8] = 8;
header[9] = 6;

const out = path.join(__dirname, '..', 'src', 'main', 'resources', 'assets', 'minevia_elements', 'textures', 'item', 'element_core.png');
fs.mkdirSync(path.dirname(out), { recursive: true });
fs.writeFileSync(out, Buffer.concat([
  Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]),
  chunk('IHDR', header),
  chunk('IDAT', zlib.deflateSync(raw)),
  chunk('IEND', Buffer.alloc(0)),
]));
console.log('Текстура записана');
