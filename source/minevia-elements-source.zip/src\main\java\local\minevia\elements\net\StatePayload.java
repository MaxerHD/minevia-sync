package local.minevia.elements.net;

import java.util.List;
import local.minevia.elements.MineviaElements;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Что показать игроку на экране: стихия, уровень, опыт, путь и оставшаяся перезарядка в тиках. */
public record StatePayload(int element, int level, int xp, int path, List<Integer> cooldowns)
        implements CustomPayload {
    public static final Id<StatePayload> ID = new Id<>(Identifier.of(MineviaElements.MOD_ID, "state"));
    public static final PacketCodec<RegistryByteBuf, StatePayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, StatePayload::element,
            PacketCodecs.VAR_INT, StatePayload::level,
            PacketCodecs.VAR_INT, StatePayload::xp,
            PacketCodecs.VAR_INT, StatePayload::path,
            PacketCodecs.VAR_INT.collect(PacketCodecs.toList()), StatePayload::cooldowns,
            StatePayload::new);

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
