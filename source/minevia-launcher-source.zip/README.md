Minevia launcher 0.4.4

Install dependencies: npm install
Run: npm start
Test: node --test checks/*.test.js
Build portable Windows launcher: npm run dist
