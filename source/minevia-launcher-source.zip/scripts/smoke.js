'use strict';
// Проверка ядра без интерфейса: node scripts/smoke.js <папка> <версия> [загрузчик] [секунд_игры]
const path = require('node:path');
const { prepare } = require('../src/core/install');
const { launch } = require('../src/core/launch');

const [dir, mc, loader = 'vanilla', seconds = '0'] = process.argv.slice(2);
const root = path.resolve(dir);

(async () => {
  const started = Date.now();
  let last = 0;
  const prepared = await prepare(root, { mc, loader }, {
    onProgress(p) {
      if (Date.now() - last < 5000 && p.phase !== 'loader') return;
      last = Date.now();
      console.log(JSON.stringify(p));
    },
  });
  console.log(`READY ${prepared.id} за ${((Date.now() - started) / 1000).toFixed(1)} с, java=${prepared.java}`);
  if (seconds === '0') return;

  const lines = [];
  const child = launch(root, prepared, { username: 'Shakhter', memoryMb: 3072, width: 854, height: 480 }, {
    onLine: (level, text) => lines.push(`[${level}] ${text}`),
    onExit(code) {
      console.log(`EXIT code=${code}, строк журнала: ${lines.length}`);
      console.log(lines.slice(0, 6).join('\n'));
      console.log('...');
      console.log(lines.slice(-12).join('\n'));
      process.exit(0);
    },
  });
  setTimeout(() => child.kill(), Number(seconds) * 1000);
})().catch((err) => {
  console.error('FAIL', err);
  process.exit(1);
});
