'use strict';
// Рисует build/icon.png из логотипа. Запуск: electron scripts/make-icon.js
const fs = require('node:fs');
const path = require('node:path');
const { app, BrowserWindow } = require('electron');

const SIZE = 1024;
const source = path.join(__dirname, '..', 'src', 'renderer', 'logo.svg');
const target = path.join(__dirname, '..', 'build', 'icon.png');

app.commandLine.appendSwitch('force-device-scale-factor', '1');
app.disableHardwareAcceleration();

app.whenReady().then(async () => {
  const win = new BrowserWindow({
    width: SIZE,
    height: SIZE,
    show: false,
    frame: false,
    transparent: true,
    useContentSize: true,
    webPreferences: { offscreen: true },
  });
  let frame = null;
  win.webContents.on('paint', (_event, _dirty, image) => {
    frame = image;
  });
  const svg = fs.readFileSync(source).toString('base64');
  const html = `<!doctype html><style>html,body{margin:0;background:transparent}img{display:block;width:${SIZE}px;height:${SIZE}px}</style><img src="data:image/svg+xml;base64,${svg}">`;
  await win.loadURL(`data:text/html;base64,${Buffer.from(html).toString('base64')}`);
  await new Promise((resolve) => setTimeout(resolve, 900));
  win.webContents.invalidate();
  await new Promise((resolve) => setTimeout(resolve, 400));
  if (!frame || frame.isEmpty()) throw new Error('Значок не отрисовался');
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, frame.toPNG());
  console.log(`Значок записан: ${target}, ${JSON.stringify(frame.getSize())}`);
  app.quit();
}).catch((err) => {
  console.error(err);
  app.exit(1);
});
