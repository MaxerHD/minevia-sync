'use strict';
// Каталог модов через открытый API Modrinth. Файлы проверяются по SHA-512.
const fs = require('node:fs');
const path = require('node:path');
const { getJson, download } = require('./net');

const API = 'https://api.modrinth.com/v2';

async function search({ query = '', mc, loader, offset = 0 }, signal) {
  const facets = JSON.stringify([['project_type:mod'], [`categories:${loader}`], [`versions:${mc}`]]);
  const params = new URLSearchParams({ query, facets, limit: '20', offset: String(offset), index: 'relevance' });
  const data = await getJson(`${API}/search?${params}`, { signal });
  return {
    total: data.total_hits,
    hits: data.hits.map((hit) => ({
      id: hit.project_id,
      title: hit.title,
      description: hit.description,
      downloads: hit.downloads,
      icon: hit.icon_url || null,
    })),
  };
}

async function latestVersion(projectId, mc, loader, signal) {
  const params = new URLSearchParams({
    loaders: JSON.stringify([loader]),
    game_versions: JSON.stringify([mc]),
  });
  const list = await getJson(`${API}/project/${encodeURIComponent(projectId)}/version?${params}`, { signal });
  return list[0] || null;
}

async function install({ projectId, versionId, mc, loader, modsDir }, signal, seen = new Set()) {
  const key = projectId || versionId;
  if (seen.has(key)) return [];
  seen.add(key);

  const version = versionId
    ? await getJson(`${API}/version/${encodeURIComponent(versionId)}`, { signal })
    : await latestVersion(projectId, mc, loader, signal);
  if (!version) throw new Error('У мода нет файла для этой версии игры');

  const file = version.files.find((f) => f.primary) || version.files[0];
  const name = path.basename(file.filename);
  await download(
    { url: file.url, dest: path.join(modsDir, name), sha512: file.hashes.sha512, size: file.size },
    { signal },
  );

  const installed = [name];
  for (const dep of version.dependencies || []) {
    if (dep.dependency_type !== 'required') continue;
    const next = { projectId: dep.project_id, versionId: dep.project_id ? null : dep.version_id, mc, loader, modsDir };
    installed.push(...(await install(next, signal, seen)));
  }
  return installed;
}

function list(modsDir) {
  if (!fs.existsSync(modsDir)) return [];
  return fs
    .readdirSync(modsDir)
    .filter((file) => /\.jar(\.disabled)?$/.test(file))
    .map((file) => ({ file, enabled: file.endsWith('.jar') }))
    .sort((a, b) => a.file.localeCompare(b.file));
}

function safeModPath(modsDir, file) {
  const target = path.join(modsDir, path.basename(file));
  if (!/\.jar(\.disabled)?$/.test(target)) throw new Error('Это не файл мода');
  return target;
}

async function toggle(modsDir, file) {
  const from = safeModPath(modsDir, file);
  const to = from.endsWith('.disabled') ? from.slice(0, -'.disabled'.length) : `${from}.disabled`;
  await fs.promises.rename(from, to);
}

module.exports = { search, install, list, toggle, safeModPath };
