'use strict';
// Первый запуск у нового игрока: настройки и шейдер уже выставлены, остаётся нажать «Играть».
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const AdmZip = require('adm-zip');
const net = require('./net');

const MARK_FILE = '.minevia-defaults.json';
const OPTION_KEY = /^[A-Za-z_]+$/;
const PACK_FILE = /^[^/\\:*?"<>|]+\.zip$/;
const SETTING = /^[A-Za-z0-9_]+=[A-Za-z0-9_.-]+$/;
const DERIVATIVE_SHA512 = '013159603c3be003';
const DERIVATIVE_NAME = 'Derivative Minevia.zip';
const FILM_SETTINGS = ['PURKINJE_SHIFT=true', 'COLOR_GRADING=true', 'SATURATION=0.9', 'WHITE_BALANCE=7200', 'VIGNETTE_ENABLED=true',
  'VIGNETTE_STRENGTH=3.0', 'VOLUMETRIC_FOG=true', 'TONEMAP=AgX_Minimal', 'CINEMATIC_EFFECT=true', 'DOF_ENABLED=false'];
// У Derivative по умолчанию туман, облака и тени тяжелее его же профиля Ultra. На уровне High картинка
// та же, а ноутбучной видеокарте достаётся заметно меньше работы.
const LIGHTER = ['VOLUMETRIC_FOG_SAMPLES=12', 'CLOUD_CUMULUS_SAMPLES=20', 'shadowDistance=128.0'];

function setOptions(gameDir, options) {
  const file = path.join(gameDir, 'options.txt');
  const lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split(/\r?\n/) : [];
  for (const [key, value] of Object.entries(options)) {
    if (!OPTION_KEY.test(key)) continue;
    const at = lines.findIndex((l) => l.startsWith(`${key}:`));
    if (at >= 0) lines[at] = `${key}:${value}`;
    else lines.unshift(`${key}:${value}`);
  }
  fs.writeFileSync(file, lines.join('\n'));
}

function irisFile(gameDir) {
  // На Forge шейдеры даёт Oculus, и свой выбор он хранит в oculus.properties.
  return path.join(gameDir, 'config', path.basename(gameDir).startsWith('forge-') ? 'oculus.properties' : 'iris.properties');
}

/** Шейдер игрока не заменяется: если он уже что-то выбрал и файл на месте, значит выбор сделан. */
function hasOwnShader(gameDir) {
  const file = irisFile(gameDir);
  if (!fs.existsSync(file)) return false;
  const name = fs.readFileSync(file, 'utf8').match(/^shaderPack=(.+)$/m)?.[1]?.trim();
  return Boolean(name) && fs.existsSync(path.join(gameDir, 'shaderpacks', name));
}

function activateShader(gameDir, name, settings) {
  const dir = path.join(gameDir, 'shaderpacks');
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.join(dir, `${name}.txt`), `${settings.join('\n')}\n`);
  const file = irisFile(gameDir);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  let text = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
  for (const [key, value] of [['enableShaders', 'true'], ['shaderPack', name]]) {
    const line = new RegExp(`^${key}=.*$`, 'm');
    text = line.test(text) ? text.replace(line, `${key}=${value}`) : `${text}${key}=${value}\n`;
  }
  fs.writeFileSync(file, text);
}

/** Выполняется один раз на каждую версию настроек: дальше игрок меняет всё сам, и лаунчер не спорит. */
async function apply(manifest, gameDir, { signal, deps = net } = {}) {
  const defaults = manifest.defaults;
  if (!defaults) return false;
  const mark = path.join(gameDir, MARK_FILE);
  let seen = 0;
  try {
    seen = JSON.parse(fs.readFileSync(mark, 'utf8')).version;
  } catch {
    seen = 0;
  }
  if (seen >= defaults.version) return false;
  fs.mkdirSync(gameDir, { recursive: true });
  setOptions(gameDir, defaults.options || {});
  const shader = defaults.shader;
  if (shader && PACK_FILE.test(shader.as) && !hasOwnShader(gameDir)) {
    const dest = path.join(gameDir, 'shaderpacks', shader.as);
    if (!(await deps.isValid({ dest, sha512: shader.sha512, size: shader.size }))) {
      await deps.download({ url: shader.url, dest, sha512: shader.sha512, size: shader.size }, { signal });
    }
    activateShader(gameDir, shader.as, (shader.settings || []).filter((line) => SETTING.test(line)));
  }
  fs.writeFileSync(mark, JSON.stringify({ version: defaults.version }));
  return true;
}

function change(zip, name, edit) {
  const entry = zip.getEntry(name);
  if (!entry) throw new Error(`В шейдере нет файла ${name}`);
  const before = entry.getData().toString('utf8');
  const after = edit(before);
  if (after === before) throw new Error(`Не вышло поправить ${name}`);
  zip.updateFile(entry, Buffer.from(after, 'utf8'));
}

/**
 * Derivative нельзя выкладывать: у него все права защищены. Поэтому файл автора выбирает сам игрок,
 * а здесь к нему применяются наши правки: модели мода светятся, а чёрные полосы становятся тоньше.
 */
function installDerivative(source, gameDir) {
  const data = fs.readFileSync(source);
  const hash = crypto.createHash('sha512').update(data).digest('hex');
  if (!hash.startsWith(DERIVATIVE_SHA512)) throw new Error('Это другой файл: нужен Derivative-Main-d24.4.4.zip');
  const zip = new AdmZip(data);
  change(zip, 'shaders/entity.properties', (t) =>
    t.replace('entity.10012 = lightning_bolt', 'entity.10012 = lightning_bolt\n\nentity.10037 = minevia_elements:spell minevia_elements:element_boss'));
  change(zip, 'shaders/program/Gbuffers/Entities.frag', (t) =>
    t
      .replace('colortex7Out.z = float(materialIDs + 0.1) * rcp(255.0);',
        'colortex7Out.z = float(materialIDs + 0.1) * rcp(255.0);\n\tif (materialIDs == 37) colortex7Out.z = (min(lightmap.x, lightmap.y) > 0.95 ? 36.1 : 0.1) * rcp(255.0);')
      .replace('if (materialIDs == 12) albedo = vec4(0.6, 0.5, 1.0, 1.0);',
        'if (materialIDs == 12) albedo = vec4(0.6, 0.5, 1.0, 1.0);\n\n\tif (materialIDs == 37) {\n\t\tif (albedo.a < bayer4(gl_FragCoord.xy)) { discard; return; }\n\t\talbedo.a = 1.0;\n\t}'));
  change(zip, 'shaders/program/Shadow/Shadow.vert', (t) =>
    t.replace('uniform int blockEntityId;', 'uniform int blockEntityId;\nuniform int entityId;').replace('if (blockEntityId == 10030) {', 'if (blockEntityId == 10030 || entityId == 10037) {'));
  change(zip, 'shaders/program/Post/Grade.glsl', (t) => t.replace('aspectRatio * (9.0 / 21.0)); // 21:9', 'aspectRatio * (9.0 / 18.0)); // 2:1'));
  const dir = path.join(gameDir, 'shaderpacks');
  fs.mkdirSync(dir, { recursive: true });
  zip.writeZip(path.join(dir, DERIVATIVE_NAME));
  activateShader(gameDir, DERIVATIVE_NAME, [...FILM_SETTINGS, ...LIGHTER]);
  return DERIVATIVE_NAME;
}

/** Дописывает облегчённые значения в настройки Derivative, не трогая то, что игрок выставил сам. */
function lightenDerivative(gameDir) {
  const file = path.join(gameDir, 'shaderpacks', `${DERIVATIVE_NAME}.txt`);
  if (!fs.existsSync(file)) return false;
  const text = fs.readFileSync(file, 'utf8');
  const missing = LIGHTER.filter((line) => !new RegExp(`^${line.split('=')[0]}=`, 'm').test(text));
  if (!missing.length) return false;
  const body = text.endsWith('\n') ? text : `${text}\n`;
  fs.writeFileSync(file, `${body}${missing.join('\n')}\n`);
  return true;
}

module.exports = { apply, installDerivative, lightenDerivative };
