'use strict';
// Сеть лаунчера: только HTTPS и только официальные домены.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Readable } = require('node:stream');

const USER_AGENT = 'minevia-launcher/0.3.0';
const ALLOWED_DOMAINS = [
  'mojang.com',
  'minecraft.net',
  'fabricmc.net',
  'minecraftforge.net',
  'neoforged.net',
  'modrinth.com',
  'githubusercontent.com',
];

function assertAllowed(rawUrl) {
  const url = new URL(rawUrl);
  const okHost = ALLOWED_DOMAINS.some((d) => url.hostname === d || url.hostname.endsWith('.' + d));
  if (url.protocol !== 'https:' || !okHost) {
    throw new Error(`Заблокирован адрес вне списка доверенных: ${url.origin}`);
  }
}

async function safeFetch(url, { signal } = {}) {
  let current = url;
  for (let hop = 0; hop < 6; hop++) {
    assertAllowed(current);
    const res = await fetch(current, {
      signal,
      redirect: 'manual',
      headers: { 'User-Agent': USER_AGENT },
    });
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      current = new URL(res.headers.get('location'), current).href;
      continue;
    }
    if (!res.ok) throw new Error(`HTTP ${res.status}: ${current}`);
    return res;
  }
  throw new Error(`Слишком много перенаправлений: ${url}`);
}

const getJson = async (url, opts) => (await safeFetch(url, opts)).json();
const getText = async (url, opts) => (await safeFetch(url, opts)).text();

function hashFile(file, algo = 'sha1') {
  return new Promise((resolve, reject) => {
    const hash = crypto.createHash(algo);
    fs.createReadStream(file)
      .on('error', reject)
      .on('data', (chunk) => hash.update(chunk))
      .on('end', () => resolve(hash.digest('hex')));
  });
}

// Файл годен, если совпали размер и контрольная сумма (когда они известны).
async function isValid({ dest, sha1, sha512, size }) {
  let stat;
  try {
    stat = await fs.promises.stat(dest);
  } catch {
    return false;
  }
  if (!stat.isFile() || (size && stat.size !== size)) return false;
  if (sha512) return (await hashFile(dest, 'sha512')) === sha512;
  if (sha1) return (await hashFile(dest, 'sha1')) === sha1;
  return true;
}

async function downloadOnce(task, { signal, onBytes }) {
  const { url, dest, sha1, sha512 } = task;
  await fs.promises.mkdir(path.dirname(dest), { recursive: true });
  const part = `${dest}.${process.pid}.part`;
  const res = await safeFetch(url, { signal });
  const hash = crypto.createHash(sha512 ? 'sha512' : 'sha1');
  const out = fs.createWriteStream(part);
  try {
    for await (const chunk of Readable.fromWeb(res.body)) {
      hash.update(chunk);
      if (!out.write(chunk)) await new Promise((r) => out.once('drain', r));
      onBytes?.(chunk.length);
    }
    await new Promise((resolve, reject) => out.end((e) => (e ? reject(e) : resolve())));
    const expected = sha512 || sha1;
    if (expected && hash.digest('hex') !== expected) {
      throw new Error(`Контрольная сумма не совпала: ${path.basename(dest)}`);
    }
    await fs.promises.rename(part, dest);
  } catch (err) {
    out.destroy();
    await fs.promises.rm(part, { force: true });
    throw err;
  }
}

async function download(task, { signal, onBytes } = {}) {
  let sent = 0;
  const count = (n) => {
    sent += n;
    onBytes?.(n);
  };
  for (let attempt = 1; ; attempt++) {
    try {
      return await downloadOnce(task, { signal, onBytes: count });
    } catch (err) {
      if (signal?.aborted || attempt >= 4) throw err;
      onBytes?.(-sent);
      sent = 0;
      await new Promise((r) => setTimeout(r, 400 * attempt));
    }
  }
}

async function pool(items, limit, worker, signal) {
  let next = 0;
  const run = async () => {
    while (next < items.length) {
      signal?.throwIfAborted();
      const index = next++;
      await worker(items[index], index);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
}

module.exports = { USER_AGENT, assertAllowed, safeFetch, getJson, getText, hashFile, isValid, download, pool };
