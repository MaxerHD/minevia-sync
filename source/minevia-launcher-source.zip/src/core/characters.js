'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { skinFile } = require('./sync');

// Персонажи, которые есть сразу. Новые приходят из общего списка и заменяют эти по совпадению id.
// В нике игры пробелов быть не может, поэтому показываемое имя и ник различаются.
const BUILT_IN = [
  { id: 'alither', title: 'Alither', username: 'Alither', skin: 'alither.png' },
  { id: 'niga', title: 'Niga', username: 'Niga', skin: 'niga.png' },
  { id: 'zlauka', title: 'Zlauka', username: 'Zlauka', skin: 'zlauka.png' },
  { id: 'master-of-slaves', title: 'Master of slaves', username: 'Master_of_slaves', skin: 'master_of_slaves.png' },
];

const SKINS_DIR = path.join(__dirname, '..', 'renderer', 'skins');

function skinPath(character, dataDir) {
  const synced = skinFile(dataDir, character.id);
  if (character.sha512 && fs.existsSync(synced)) return synced;
  const builtIn = BUILT_IN.find((c) => c.id === character.id);
  return builtIn ? path.join(SKINS_DIR, builtIn.skin) : null;
}

/** Встроенные и присланные персонажи вместе. Картинка идёт в окно готовыми данными, файлы ему недоступны. */
function listCharacters(manifest, dataDir) {
  const byId = new Map(BUILT_IN.map((c) => [c.id, c]));
  for (const character of manifest?.characters || []) byId.set(character.id, character);
  const result = [];
  for (const character of byId.values()) {
    const file = skinPath(character, dataDir);
    if (file) {
      const image = `data:image/png;base64,${fs.readFileSync(file).toString('base64')}`;
      result.push({ id: character.id, title: character.title, username: character.username, image });
    }
  }
  return result;
}

/** Кладёт скин персонажа туда, откуда его заберёт мод. Без персонажа файл убирается, и в игре обычный скин. */
function applySkin(gameDir, characterId, manifest, dataDir) {
  const file = path.join(gameDir, 'minevia', 'skin.png');
  const character = (manifest?.characters || []).find((c) => c.id === characterId) || BUILT_IN.find((c) => c.id === characterId);
  const source = character && skinPath(character, dataDir);
  if (!source) {
    fs.rmSync(file, { force: true });
    return;
  }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, fs.readFileSync(source));
}

module.exports = { listCharacters, applySkin };
