'use strict';
// Java берём из официального набора Mojang, поэтому игроку ничего ставить не нужно.
const fs = require('node:fs');
const path = require('node:path');
const { getJson } = require('./net');
const { OS_NAME } = require('./rules');

const RUNTIME_INDEX =
  'https://launchermeta.mojang.com/v1/products/java-runtime/2ec0cc96c44e5a76b9c8b7c39df7210883d12871/all.json';

function platformKey() {
  if (OS_NAME === 'windows') return { x64: 'windows-x64', ia32: 'windows-x86', arm64: 'windows-arm64' }[process.arch];
  if (OS_NAME === 'osx') return process.arch === 'arm64' ? 'mac-os-arm64' : 'mac-os';
  return process.arch === 'ia32' ? 'linux-i386' : 'linux';
}

function javaBinary(home) {
  if (OS_NAME === 'windows') return path.join(home, 'bin', 'javaw.exe');
  if (OS_NAME === 'osx') return path.join(home, 'jre.bundle', 'Contents', 'Home', 'bin', 'java');
  return path.join(home, 'bin', 'java');
}

// Возвращает список файлов рантайма или null, если для этой системы его нет.
async function runtimePlan(root, javaVersion, signal) {
  const component = javaVersion?.component || 'jre-legacy';
  const index = await getJson(RUNTIME_INDEX, { signal });
  const entry = index[platformKey()]?.[component]?.[0];
  if (!entry) return null;

  const home = path.join(root, 'runtime', component);
  const manifest = await getJson(entry.manifest.url, { signal });
  const tasks = [];
  const links = [];
  const executables = [];
  for (const [rel, file] of Object.entries(manifest.files)) {
    const dest = path.join(home, rel);
    if (file.type === 'directory') {
      await fs.promises.mkdir(dest, { recursive: true });
    } else if (file.type === 'link') {
      links.push({ dest, target: file.target });
    } else if (file.type === 'file') {
      const { url, sha1, size } = file.downloads.raw;
      tasks.push({ url, dest, sha1, size });
      if (file.executable) executables.push(dest);
    }
  }
  return { component, home, binary: javaBinary(home), tasks, links, executables };
}

async function finishRuntime(plan) {
  if (OS_NAME === 'windows') return;
  for (const { dest, target } of plan.links) {
    await fs.promises.rm(dest, { force: true });
    await fs.promises.symlink(target, dest);
  }
  for (const file of plan.executables) await fs.promises.chmod(file, 0o755);
}

module.exports = { runtimePlan, finishRuntime };
