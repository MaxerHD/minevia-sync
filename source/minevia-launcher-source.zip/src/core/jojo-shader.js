'use strict';
const fs = require('node:fs');
const path = require('node:path');
const shader = require('./jojo-shader.json');

/** Первый запуск JoJo включает выбранный шейдер High; затем выбор принадлежит игроку. */
async function apply(target, gameDir, { signal, onProgress, deps = require('./net') } = {}) {
  if (target.mode !== 'jojo') return false;
  if (target.mc !== '1.21.1' || target.loader !== 'fabric') throw new Error('Шейдер JoJo рассчитан на Fabric 1.21.1');
  const dest = path.join(gameDir, 'shaderpacks', shader.name);
  if (!(await deps.isValid({ dest, sha512: shader.sha512, size: shader.size }))) {
    onProgress?.({ phase: 'sync', name: shader.name, done: 0, total: 1 });
    await deps.download({ url: shader.url, dest, sha512: shader.sha512, size: shader.size }, { signal });
    onProgress?.({ phase: 'sync', name: shader.name, done: 1, total: 1 });
  }
  const mark = path.join(gameDir, '.minevia-jojo-shader.json');
  try {
    const seen = JSON.parse(fs.readFileSync(mark, 'utf8'));
    if (seen.version === shader.defaultsVersion && seen.name === shader.name) return false;
  } catch { /* Первый запуск или незавершённая установка. */ }
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.writeFileSync(`${dest}.txt`, `${shader.settings.join('\n')}\n`);
  const configFile = path.join(gameDir, 'config', 'iris.properties');
  fs.mkdirSync(path.dirname(configFile), { recursive: true });
  let text = fs.existsSync(configFile) ? fs.readFileSync(configFile, 'utf8') : '';
  for (const [key, value] of [['enableShaders', 'true'], ['shaderPack', shader.name]]) {
    const line = new RegExp(`^${key}=.*$`, 'm');
    if (line.test(text)) text = text.replace(line, `${key}=${value}`);
    else text += `${text && !text.endsWith('\n') ? '\n' : ''}${key}=${value}\n`;
  }
  fs.writeFileSync(configFile, text);
  fs.writeFileSync(mark, JSON.stringify({ version: shader.defaultsVersion, name: shader.name, profile: shader.profile }));
  return true;
}

module.exports = { apply };
