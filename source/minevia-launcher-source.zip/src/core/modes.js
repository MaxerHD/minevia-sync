'use strict';
// Режимы одной сборки: у каждого своя папка игры и свой список модов, поэтому миры и моды не смешиваются.
const fs = require('node:fs');
const path = require('node:path');

const MODES = {
  elements: { manifest: 'manifest.json', suffix: '' },
  chill: { manifest: 'manifest-chill.json', suffix: '-chill' },
  jojo: { manifest: 'manifest-chill.json', suffix: '-jojo', seedMode: 'chill' },
  // Для сервера FunTime: свой короткий список только из разрешённых сервером модов, без модов сборки.
  funtime: { manifest: 'manifest-funtime.json', suffix: '-funtime', seedMode: 'chill' },
};

const modeOf = (target) => (target && MODES[target.mode] ? target.mode : 'elements');

/** Адрес списка режима лежит рядом с основным списком. */
function manifestUrl(syncUrl, mode) {
  if (!syncUrl || mode === 'elements') return syncUrl;
  return new URL(MODES[mode].manifest, syncUrl).href;
}

// Настройки, шейдеры и паки переезжают из основной папки, а миры нет: в них блоки и существа модов другого режима.
const SEED = ['options.txt', 'servers.dat', '.minevia-defaults.json', 'config', 'shaderpacks', 'resourcepacks'];

/** При первом запуске режима переносит настройки игрока, чтобы не выставлять управление и шейдер заново. */
function seed(fromDir, toDir) {
  if (fs.existsSync(path.join(toDir, 'options.txt')) || !fs.existsSync(path.join(fromDir, 'options.txt'))) return false;
  fs.mkdirSync(toDir, { recursive: true });
  for (const name of SEED) {
    const from = path.join(fromDir, name);
    if (fs.existsSync(from)) fs.cpSync(from, path.join(toDir, name), { recursive: true, force: false, errorOnExist: false });
  }
  return true;
}

// JoJo наследует живой список уютной сборки: её обновления доступны и здесь.
const JOJO = require('./jojo-mod.json');
function extrasFor(target) {
  return modeOf(target) === 'jojo' ? [JOJO] : [];
}

function extendManifest(manifest, target) {
  const extras = extrasFor(target);
  if (!extras.length) return manifest;
  if (manifest.mc !== '1.21.1' || manifest.loader !== 'fabric') {
    throw new Error('Режим JoJo поддерживает только Fabric 1.21.1');
  }
  return { ...manifest, mods: [...manifest.mods.filter(m => !extras.some(e => e.name === m.name)), ...extras] };
}

// Локальные дополнения и отключённые моды тоже переходят в отдельную папку.
// Повторный запуск не перезаписывает изменения игрока и никогда не копирует миры.
function seedMods(fromDir, toDir) {
  const from = path.join(fromDir, 'mods');
  const to = path.join(toDir, 'mods');
  if (fs.existsSync(to) || !fs.existsSync(from)) return false;
  fs.cpSync(from, to, { recursive: true, force: false, errorOnExist: false });
  return true;
}

// При недоступности списка уютной сборки JoJo всё равно ставится поверх её локальной копии.
// Ошибка загрузки первого JoJo не должна выдавать обычное выживание за готовый режим.
async function ensureExtras(target, modsDir, { signal, onProgress, deps = require('./net') } = {}) {
  const extras = extrasFor(target);
  for (const mod of extras) {
    signal?.throwIfAborted();
    if (target.mc !== '1.21.1' || target.loader !== 'fabric') {
      throw new Error('Режим JoJo поддерживает только Fabric 1.21.1');
    }
    const dest = path.join(modsDir, mod.name);
    if (fs.existsSync(`${dest}.disabled`)) continue;
    if (!(await deps.isValid({ ...mod, dest }))) {
      onProgress?.({ phase: 'sync', name: mod.name, done: 0, total: 1 });
      await deps.download({ ...mod, dest }, { signal });
      onProgress?.({ phase: 'sync', name: mod.name, done: 1, total: 1 });
    }
  }
  if (modeOf(target) === 'jojo') {
    const compat = require('./jojo-compat.json');
    const dest = path.join(modsDir, compat.name);
    if (!fs.existsSync(`${dest}.disabled`) && !(await deps.isValid({ ...compat, dest }))) {
      fs.mkdirSync(modsDir, { recursive: true });
      fs.copyFileSync(path.join(__dirname, '..', 'bundled', compat.name), dest);
    }
  }
}

module.exports = { MODES, modeOf, manifestUrl, seed, seedMods, extrasFor, extendManifest, ensureExtras };
