'use strict';
// Общие моды и персонажи: лаунчер сверяется со списком в интернете и приводит папку к нему.
const fs = require('node:fs');
const path = require('node:path');
const net = require('./net');

const STATE_FILE = '.minevia-sync.json';
const CACHE_FILE = 'sync-manifest.json';
const SKINS_DIR = 'sync-skins';
const MOD_NAME = /^[^/\\:*?"<>|]+\.jar$/;
const PACK_NAME = /^[^/\\:*?"<>|]+\.zip$/;
const CHARACTER_ID = /^[a-z0-9_-]{1,32}$/;
const USERNAME = /^[A-Za-z0-9_]{3,16}$/;
const SHA512 = /^[0-9a-f]{128}$/;
// Наш мод обновляется сменой имени файла: две версии рядом не дадут игре запуститься.
const OWN_MOD = /^minevia-elements-.*\.jar$/;

/** Список проверяется целиком до того, как что-то скачается: мусор в нём не должен трогать файлы игрока. */
function validate(manifest) {
  if (manifest?.format !== 1 || !Array.isArray(manifest.mods) || !Array.isArray(manifest.characters)) {
    throw new Error('Список обновлений в неизвестном формате');
  }
  for (const mod of manifest.mods) {
    if (!MOD_NAME.test(mod.name) || !SHA512.test(mod.sha512) || typeof mod.url !== 'string') {
      throw new Error(`Плохая запись мода в списке: ${mod.name}`);
    }
  }
  for (const pack of manifest.packs || []) {
    if (!PACK_NAME.test(pack.name) || !SHA512.test(pack.sha512) || typeof pack.url !== 'string') {
      throw new Error(`Плохая запись пака в списке: ${pack.name}`);
    }
  }
  for (const character of manifest.characters) {
    if (!CHARACTER_ID.test(character.id) || !USERNAME.test(character.username) || !SHA512.test(character.sha512)) {
      throw new Error(`Плохая запись персонажа в списке: ${character.id}`);
    }
  }
  return manifest;
}

/** Адреса в списке могут быть относительными: файлы лежат рядом с ним. */
const resolve = (url, base) => new URL(url, base).href;

async function fetchManifest(url, dataDir, { signal, deps = net } = {}) {
  const manifest = validate(await deps.getJson(url, { signal }));
  await fs.promises.mkdir(dataDir, { recursive: true });
  await fs.promises.writeFile(path.join(dataDir, CACHE_FILE), JSON.stringify(manifest));
  return manifest;
}

/** Последний удачный список: без интернета лаунчер всё равно покажет персонажей. */
function cachedManifest(dataDir) {
  try {
    return validate(JSON.parse(fs.readFileSync(path.join(dataDir, CACHE_FILE), 'utf8')));
  } catch {
    return null;
  }
}

const skinFile = (dataDir, id) => path.join(dataDir, SKINS_DIR, `${id}.png`);

async function syncCharacters(manifest, baseUrl, dataDir, { signal, deps = net } = {}) {
  for (const character of manifest.characters) {
    const dest = skinFile(dataDir, character.id);
    if (!(await deps.isValid({ dest, sha512: character.sha512 }))) {
      await deps.download({ url: resolve(character.skin, baseUrl), dest, sha512: character.sha512 }, { signal });
    }
  }
}

function readState(dir, valid = MOD_NAME) {
  try {
    const { managed } = JSON.parse(fs.readFileSync(path.join(dir, STATE_FILE), 'utf8'));
    return new Set(managed.filter((name) => valid.test(name)));
  } catch {
    return new Set();
  }
}

/**
 * Докачивает моды из списка и убирает те, что лаунчер ставил сам и которых в списке больше нет.
 * Моды, добавленные игроком вручную, не трогаются, а отключённый игроком мод не включается обратно.
 */
async function syncMods(manifest, baseUrl, modsDir, { signal, onProgress, deps = net } = {}) {
  await fs.promises.mkdir(modsDir, { recursive: true });
  const managed = readState(modsDir);
  const wanted = new Set(manifest.mods.map((mod) => mod.name));
  const report = { added: [], removed: [] };

  for (const file of fs.readdirSync(modsDir)) {
    const name = file.replace(/\.disabled$/, '');
    if (!wanted.has(name) && (managed.has(name) || OWN_MOD.test(name))) {
      await fs.promises.rm(path.join(modsDir, file), { force: true });
      report.removed.push(name);
    }
  }

  let done = 0;
  for (const mod of manifest.mods) {
    signal?.throwIfAborted();
    done++;
    const dest = path.join(modsDir, mod.name);
    const disabled = fs.existsSync(`${dest}.disabled`);
    if (!disabled && !(await deps.isValid({ dest, sha512: mod.sha512, size: mod.size }))) {
      onProgress?.({ phase: 'sync', name: mod.name, done, total: manifest.mods.length });
      await deps.download({ url: resolve(mod.url, baseUrl), dest, sha512: mod.sha512, size: mod.size }, { signal });
      report.added.push(mod.name);
    }
  }

  await fs.promises.writeFile(path.join(modsDir, STATE_FILE), JSON.stringify({ managed: [...wanted] }));
  return report;
}

/** Правит только две строки настроек: остальное в файле принадлежит игроку. */
function writePackOptions(gameDir, change) {
  const file = path.join(gameDir, 'options.txt');
  const lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split(/\r?\n/) : [];
  const read = (key) => {
    const line = lines.find((l) => l.startsWith(`${key}:`));
    try {
      return line ? JSON.parse(line.slice(key.length + 1)) : null;
    } catch {
      return null;
    }
  };
  const write = (key, value) => {
    const text = `${key}:${JSON.stringify(value)}`;
    const at = lines.findIndex((l) => l.startsWith(`${key}:`));
    if (at >= 0) lines[at] = text;
    else lines.unshift(text);
  };
  const { enabled, incompatible } = change(read('resourcePacks') || ['vanilla', 'fabric'], read('incompatibleResourcePacks') || []);
  write('resourcePacks', enabled);
  write('incompatibleResourcePacks', incompatible);
  fs.mkdirSync(gameDir, { recursive: true });
  fs.writeFileSync(file, lines.join('\n'));
}

/**
 * Докачивает паки и включает только новые: пак, который игрок сам выключил, не включается обратно.
 * Паки из списка идут в порядке списка, от слабого к сильному, поверх того, что уже включено.
 */
async function syncPacks(manifest, baseUrl, gameDir, { signal, onProgress, deps = net } = {}) {
  const packs = manifest.packs || [];
  const dir = path.join(gameDir, 'resourcepacks');
  await fs.promises.mkdir(dir, { recursive: true });
  const managed = readState(dir, PACK_NAME);
  const wanted = new Set(packs.map((pack) => pack.name));
  const removed = [...managed].filter((name) => !wanted.has(name));
  for (const name of removed) await fs.promises.rm(path.join(dir, name), { force: true });

  let done = 0;
  for (const pack of packs) {
    signal?.throwIfAborted();
    done++;
    const dest = path.join(dir, pack.name);
    if (!(await deps.isValid({ dest, sha512: pack.sha512, size: pack.size }))) {
      onProgress?.({ phase: 'sync', name: pack.name, done, total: packs.length });
      await deps.download({ url: resolve(pack.url, baseUrl), dest, sha512: pack.sha512, size: pack.size }, { signal });
    }
  }

  const ids = (list) => list.map((name) => `file/${name}`);
  const fresh = packs.filter((pack) => !managed.has(pack.name));
  writePackOptions(gameDir, (enabled, incompatible) => ({
    enabled: [...enabled.filter((id) => !ids(removed).includes(id) && !ids(fresh.map((p) => p.name)).includes(id)), ...ids(fresh.map((p) => p.name))],
    incompatible: [...new Set([...incompatible.filter((id) => !ids(removed).includes(id)), ...ids(packs.filter((p) => p.incompatible).map((p) => p.name))])],
  }));
  await fs.promises.writeFile(path.join(dir, STATE_FILE), JSON.stringify({ managed: [...wanted] }));
  return { added: fresh.map((p) => p.name), removed };
}

module.exports = { syncPacks, validate, fetchManifest, cachedManifest, skinFile, syncCharacters, syncMods };
