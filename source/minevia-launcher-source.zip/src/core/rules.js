'use strict';
const os = require('node:os');

const OS_NAME = { win32: 'windows', darwin: 'osx', linux: 'linux' }[process.platform] || 'linux';
const ARCH = { x64: 'x86_64', ia32: 'x86', arm64: 'arm64' }[process.arch] || process.arch;

function matches(rule, features) {
  if (rule.os) {
    if (rule.os.name && rule.os.name !== OS_NAME) return false;
    if (rule.os.arch && rule.os.arch !== ARCH) return false;
    if (rule.os.version && !new RegExp(rule.os.version).test(os.release())) return false;
  }
  for (const [key, value] of Object.entries(rule.features || {})) {
    if (Boolean(features[key]) !== value) return false;
  }
  return true;
}

function allowed(rules, features = {}) {
  if (!rules?.length) return true;
  let result = false;
  for (const rule of rules) {
    if (matches(rule, features)) result = rule.action === 'allow';
  }
  return result;
}

// group:artifact:version[:classifier][@ext] -> путь внутри libraries/
function mavenPath(name) {
  const [coords, ext = 'jar'] = name.split('@');
  const [group, artifact, version, classifier] = coords.split(':');
  const file = `${artifact}-${version}${classifier ? `-${classifier}` : ''}.${ext}`;
  return [...group.split('.'), artifact, version, file].join('/');
}

function libraryKey(name) {
  const [group, artifact, , classifier] = name.split('@')[0].split(':');
  return `${group}:${artifact}:${classifier || ''}`;
}

module.exports = { OS_NAME, ARCH, allowed, mavenPath, libraryKey };
