'use strict';
const crypto = require('node:crypto');
const path = require('node:path');
const { spawn } = require('node:child_process');
const { allowed } = require('./rules');
const { resolveLibraries, clientJarPath } = require('./install');

const LAUNCHER_NAME = 'minevia';
const LAUNCHER_VERSION = '0.2.0';

// Тот же алгоритм, что UUID.nameUUIDFromBytes в самой игре для офлайн-режима.
function offlineUuid(name) {
  const bytes = crypto.createHash('md5').update(`OfflinePlayer:${name}`, 'utf8').digest();
  bytes[6] = (bytes[6] & 0x0f) | 0x30;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  return bytes.toString('hex');
}

function flatten(args, features) {
  const out = [];
  for (const arg of args) {
    if (typeof arg === 'string') out.push(arg);
    else if (allowed(arg.rules, features)) out.push(...[arg.value].flat());
  }
  return out;
}

function buildCommand(root, prepared, options) {
  const { id, profile, gameDir, nativesDir, gameAssets } = prepared;
  const { username, memoryMb = 2048, width, height, fullscreen, jvmArgs = '' } = options;

  const classpath = [];
  for (const lib of resolveLibraries(root, profile)) {
    if (lib.artifact) classpath.push(lib.artifact.dest);
  }
  classpath.push(clientJarPath(root, profile.jar));
  const separator = path.delimiter;

  const features = { has_custom_resolution: Boolean(width && height && !fullscreen) };
  const values = {
    auth_player_name: username,
    version_name: id,
    game_directory: gameDir,
    assets_root: path.join(root, 'assets'),
    game_assets: gameAssets,
    assets_index_name: profile.assetIndex.id,
    auth_uuid: offlineUuid(username),
    auth_access_token: '0',
    auth_session: '0',
    auth_xuid: '0',
    clientid: '0',
    user_type: 'legacy',
    user_properties: '{}',
    version_type: profile.type || 'release',
    natives_directory: nativesDir,
    launcher_name: LAUNCHER_NAME,
    launcher_version: LAUNCHER_VERSION,
    classpath: classpath.join(separator),
    classpath_separator: separator,
    library_directory: path.join(root, 'libraries'),
    resolution_width: String(width || ''),
    resolution_height: String(height || ''),
  };
  const fill = (text) => text.replace(/\$\{(\w+)\}/g, (all, key) => values[key] ?? all);

  const jvm = [`-Xmx${memoryMb}M`, `-Xms${Math.min(512, memoryMb)}M`];
  if (profile.arguments?.jvm?.length) {
    jvm.push(...flatten(profile.arguments.jvm, features).map(fill));
  } else {
    jvm.push(`-Djava.library.path=${nativesDir}`, '-cp', values.classpath);
  }
  const logging = profile.logging?.client;
  if (logging?.argument) {
    const config = path.join(root, 'assets', 'log_configs', logging.file.id);
    jvm.push(logging.argument.replace('${path}', config));
  }
  jvm.push(...jvmArgs.split(/\s+/).filter(Boolean));

  const game = profile.minecraftArguments
    ? profile.minecraftArguments.split(' ').map(fill)
    : flatten(profile.arguments?.game || [], features).map(fill);
  if (profile.minecraftArguments && features.has_custom_resolution) {
    game.push('--width', values.resolution_width, '--height', values.resolution_height);
  }
  if (fullscreen) game.push('--fullscreen');

  return [...jvm, profile.mainClass, ...game];
}

// Журнал игры приходит в XML (конфиг Mojang), превращаем его в обычные строки.
function createLogParser(onLine) {
  let buffer = '';
  const event =
    /<log4j:Event[^>]*level="(\w+)"[^>]*>[\s\S]*?<log4j:Message><!\[CDATA\[([\s\S]*?)\]\]><\/log4j:Message>[\s\S]*?<\/log4j:Event>/;
  const plain = (text) => {
    for (const line of text.split(/\r?\n/)) if (line.trim()) onLine('INFO', line);
  };
  return (chunk) => {
    buffer += chunk;
    for (let match = event.exec(buffer); match; match = event.exec(buffer)) {
      plain(buffer.slice(0, match.index));
      onLine(match[1], match[2]);
      buffer = buffer.slice(match.index + match[0].length);
    }
    if (buffer.includes('<log4j:Event')) {
      if (buffer.length > 1_000_000) buffer = '';
      return;
    }
    const end = buffer.lastIndexOf('\n');
    if (end >= 0) {
      plain(buffer.slice(0, end));
      buffer = buffer.slice(end + 1);
    }
  };
}

function launch(root, prepared, options, { onLine, onExit }) {
  const args = buildCommand(root, prepared, options);
  const child = spawn(prepared.java, args, { cwd: prepared.gameDir, windowsHide: true });
  const parse = createLogParser(onLine);
  child.stdout.setEncoding('utf8').on('data', parse);
  child.stderr.setEncoding('utf8').on('data', (text) => {
    for (const line of text.split(/\r?\n/)) if (line.trim()) onLine('ERROR', line);
  });
  child.on('error', (err) => onLine('ERROR', err.message));
  child.on('close', (code) => onExit(code));
  return child;
}

module.exports = { offlineUuid, buildCommand, createLogParser, launch };
