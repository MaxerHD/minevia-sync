'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { getJson } = require('./net');

const MANIFEST_URL = 'https://piston-meta.mojang.com/mc/game/version_manifest_v2.json';
const FABRIC_META = 'https://meta.fabricmc.net/v2/versions/loader';
const FORGE_PROMOS = 'https://files.minecraftforge.net/net/minecraftforge/forge/promotions_slim.json';
const NEOFORGE_LIST = 'https://maven.neoforged.net/api/maven/versions/releases/net/neoforged/neoforge';

const versionDir = (root, id) => path.join(root, 'versions', id);
const versionJsonPath = (root, id) => path.join(versionDir(root, id), `${id}.json`);

async function writeJson(file, data) {
  await fs.promises.mkdir(path.dirname(file), { recursive: true });
  await fs.promises.writeFile(file, JSON.stringify(data, null, 2));
}

const readJson = async (file) => JSON.parse(await fs.promises.readFile(file, 'utf8'));

// При обрыве сети берём последний сохранённый список: играть можно и офлайн.
async function getManifest(root, signal) {
  const cache = path.join(root, 'versions', 'manifest.json');
  try {
    const manifest = await getJson(MANIFEST_URL, { signal });
    await writeJson(cache, manifest);
    return manifest;
  } catch (err) {
    if (fs.existsSync(cache)) return readJson(cache);
    throw err;
  }
}

function installedIds(root) {
  const dir = path.join(root, 'versions');
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir).filter((id) => fs.existsSync(versionJsonPath(root, id)));
}

function neoforgePrefix(mc) {
  const old = /^1\.(\d+)(?:\.(\d+))?$/.exec(mc);
  return old ? `${old[1]}.${old[2] || 0}.` : `${mc}.`;
}

async function fabricLoader(mc, signal) {
  const list = await getJson(`${FABRIC_META}/${encodeURIComponent(mc)}`, { signal });
  return (list.find((item) => item.loader.stable) || list[0])?.loader.version || null;
}

async function forgeBuild(mc, signal) {
  const { promos } = await getJson(FORGE_PROMOS, { signal });
  return promos[`${mc}-recommended`] || promos[`${mc}-latest`] || null;
}

async function neoforgeBuild(mc, signal) {
  const { versions } = await getJson(NEOFORGE_LIST, { signal });
  const prefix = neoforgePrefix(mc);
  const matching = versions.filter((v) => v.startsWith(prefix));
  return matching.filter((v) => !v.includes('beta')).at(-1) || matching.at(-1) || null;
}

async function loadersFor(mc, signal) {
  const safe = (promise) => promise.catch(() => null);
  const [fabric, forge, neoforge] = await Promise.all([
    safe(fabricLoader(mc, signal)),
    safe(forgeBuild(mc, signal)),
    safe(neoforgeBuild(mc, signal)),
  ]);
  return { fabric, forge, neoforge };
}

// Собирает итоговый профиль: у Fabric/Forge он наследуется от ванильного.
async function resolveProfile(root, id) {
  const child = await readJson(versionJsonPath(root, id));
  if (!child.inheritsFrom) return { ...child, jar: child.jar || child.id };
  const parent = await resolveProfile(root, child.inheritsFrom);
  return {
    ...parent,
    ...child,
    jar: child.jar || child.id,
    libraries: [...(child.libraries || []), ...(parent.libraries || [])],
    arguments: {
      game: [...(parent.arguments?.game || []), ...(child.arguments?.game || [])],
      jvm: [...(parent.arguments?.jvm || []), ...(child.arguments?.jvm || [])],
    },
    minecraftArguments: child.minecraftArguments || parent.minecraftArguments,
    javaVersion: child.javaVersion || parent.javaVersion,
    assetIndex: child.assetIndex || parent.assetIndex,
    assets: child.assets || parent.assets,
    downloads: parent.downloads,
    logging: child.logging?.client ? child.logging : parent.logging,
  };
}

module.exports = {
  FABRIC_META,
  versionDir,
  versionJsonPath,
  writeJson,
  readJson,
  getManifest,
  installedIds,
  fabricLoader,
  forgeBuild,
  neoforgeBuild,
  loadersFor,
  resolveProfile,
};
