'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { MODES, modeOf } = require('./modes');
const { spawn } = require('node:child_process');
const AdmZip = require('adm-zip');
const { getJson, getText, isValid, download, pool } = require('./net');
const { OS_NAME, ARCH, allowed, mavenPath, libraryKey } = require('./rules');
const V = require('./versions');
const { runtimePlan, finishRuntime } = require('./java');

const ASSET_HOST = 'https://resources.download.minecraft.net';
const LIBRARY_HOST = 'https://libraries.minecraft.net/';

const INSTALLERS = {
  forge: {
    url: (mc, build) =>
      `https://maven.minecraftforge.net/net/minecraftforge/forge/${mc}-${build}/forge-${mc}-${build}-installer.jar`,
    flag: '--installClient',
    build: V.forgeBuild,
  },
  neoforge: {
    url: (mc, build) =>
      `https://maven.neoforged.net/releases/net/neoforged/neoforge/${build}/neoforge-${build}-installer.jar`,
    flag: '--install-client',
    build: V.neoforgeBuild,
  },
};

function resolveLibraries(root, profile) {
  const seen = new Set();
  const libs = [];
  for (const lib of profile.libraries || []) {
    if (!allowed(lib.rules)) continue;
    const key = libraryKey(lib.name);
    if (seen.has(key)) continue;
    seen.add(key);

    const entry = { artifact: null, native: null, extract: lib.extract };
    const artifact = lib.downloads?.artifact;
    if (artifact) {
      const rel = artifact.path || mavenPath(lib.name);
      entry.artifact = {
        url: artifact.url,
        dest: path.join(root, 'libraries', rel),
        sha1: artifact.sha1,
        size: artifact.size,
      };
    } else if (!lib.downloads && !lib.natives) {
      const rel = mavenPath(lib.name);
      const base = (lib.url || LIBRARY_HOST).replace(/\/?$/, '/');
      entry.artifact = {
        url: base + rel,
        dest: path.join(root, 'libraries', rel),
        sha1: lib.sha1,
        size: lib.size,
      };
    }
    const nativeName = lib.natives?.[OS_NAME]?.replace('${arch}', ARCH === 'x86' ? '32' : '64');
    const classifier = nativeName && lib.downloads?.classifiers?.[nativeName];
    if (classifier) {
      entry.native = {
        url: classifier.url,
        dest: path.join(root, 'libraries', classifier.path),
        sha1: classifier.sha1,
        size: classifier.size,
      };
    }
    libs.push(entry);
  }
  return libs;
}

const clientJarPath = (root, jarId) => path.join(V.versionDir(root, jarId), `${jarId}.jar`);

function libraryTasks(root, profile) {
  const tasks = [];
  for (const lib of resolveLibraries(root, profile)) {
    for (const file of [lib.artifact, lib.native]) {
      // Пустой url означает файл, созданный установщиком Forge локально.
      if (file?.url) tasks.push(file);
    }
  }
  return tasks;
}

async function assetIndex(root, profile, signal) {
  const { id, url, sha1, size } = profile.assetIndex;
  const dest = path.join(root, 'assets', 'indexes', `${id}.json`);
  const task = { url, dest, sha1, size };
  if (!(await isValid(task))) await download(task, { signal });
  return V.readJson(dest);
}

async function gameTasks(root, profile, signal) {
  const client = profile.downloads.client;
  const tasks = [
    { url: client.url, dest: clientJarPath(root, profile.id), sha1: client.sha1, size: client.size },
    ...libraryTasks(root, profile),
  ];
  const logging = profile.logging?.client?.file;
  if (logging) {
    tasks.push({
      url: logging.url,
      dest: path.join(root, 'assets', 'log_configs', logging.id),
      sha1: logging.sha1,
      size: logging.size,
    });
  }
  const index = await assetIndex(root, profile, signal);
  for (const { hash, size } of Object.values(index.objects)) {
    const prefix = hash.slice(0, 2);
    tasks.push({
      url: `${ASSET_HOST}/${prefix}/${hash}`,
      dest: path.join(root, 'assets', 'objects', prefix, hash),
      sha1: hash,
      size,
    });
  }
  return tasks;
}

async function fetchAll(tasks, { signal, report }) {
  const unique = [...new Map(tasks.map((t) => [t.dest, t])).values()];
  const missing = [];
  let checked = 0;
  await pool(
    unique,
    12,
    async (task) => {
      if (!(await isValid(task))) missing.push(task);
      report({ phase: 'verify', done: ++checked, total: unique.length });
    },
    signal,
  );
  if (!missing.length) return;

  const totalBytes = missing.reduce((sum, t) => sum + (t.size || 0), 0);
  let doneBytes = 0;
  let doneFiles = 0;
  await pool(
    missing,
    16,
    async (task) => {
      await download(task, {
        signal,
        onBytes: (n) => {
          doneBytes += n;
          report({ phase: 'download', done: doneBytes, total: totalBytes, files: doneFiles, fileTotal: missing.length });
        },
      });
      doneFiles++;
    },
    signal,
  );
}

async function ensureVanilla(root, mc, signal) {
  const file = V.versionJsonPath(root, mc);
  const manifest = await V.getManifest(root, signal).catch((err) => {
    if (fs.existsSync(file)) return null;
    throw err;
  });
  const entry = manifest?.versions.find((v) => v.id === mc);
  if (!entry && !fs.existsSync(file)) throw new Error(`Версия ${mc} не найдена`);
  if (entry) {
    const task = { url: entry.url, dest: file, sha1: entry.sha1 };
    if (!(await isValid(task))) await download(task, { signal });
  }
  return V.readJson(file);
}

async function ensureFabric(root, mc, signal) {
  const loader = await V.fabricLoader(mc, signal);
  if (!loader) throw new Error(`Fabric пока не поддерживает ${mc}`);
  const id = `fabric-loader-${loader}-${mc}`;
  const file = V.versionJsonPath(root, id);
  if (!fs.existsSync(file)) {
    const url = `${V.FABRIC_META}/${encodeURIComponent(mc)}/${encodeURIComponent(loader)}/profile/json`;
    await V.writeJson(file, await getJson(url, { signal }));
  }
  return id;
}

function runInstaller(java, jar, flag, root, signal, report) {
  return new Promise((resolve, reject) => {
    const tail = [];
    const child = spawn(java, ['-jar', jar, flag, root], { cwd: path.dirname(jar), windowsHide: true, signal });
    const onData = (data) => {
      for (const line of data.toString().split(/\r?\n/)) {
        if (!line.trim()) continue;
        tail.push(line);
        if (tail.length > 15) tail.shift();
        report({ phase: 'loader', line: line.slice(0, 120) });
      }
    };
    child.stdout.on('data', onData);
    child.stderr.on('data', onData);
    child.on('error', reject);
    child.on('close', (code) =>
      code === 0 ? resolve() : reject(new Error(`Установщик завершился с кодом ${code}\n${tail.join('\n')}`)),
    );
  });
}

// Forge и NeoForge собираются только своим установщиком, поэтому запускаем его без окна.
async function ensureInstallerLoader(root, loader, mc, java, { signal, report }) {
  const spec = INSTALLERS[loader];
  const build = await spec.build(mc, signal);
  if (!build) throw new Error(`Для ${mc} нет сборки ${loader}`);
  const url = spec.url(mc, build);
  const jar = path.join(root, 'cache', 'installers', path.basename(new URL(url).pathname));
  const sha1 = (await getText(`${url}.sha1`, { signal }).catch(() => '')).trim().slice(0, 40) || undefined;
  const task = { url, dest: jar, sha1 };
  if (!(await isValid(task))) {
    report({ phase: 'loader', line: `Скачиваю установщик ${loader}` });
    await download(task, { signal });
  }

  const versionEntry = new AdmZip(jar).getEntry('version.json');
  if (!versionEntry) throw new Error('Этот старый установщик Forge не поддерживается');
  const { id } = JSON.parse(versionEntry.getData().toString('utf8'));
  if (fs.existsSync(V.versionJsonPath(root, id))) return id;

  const profiles = path.join(root, 'launcher_profiles.json');
  if (!fs.existsSync(profiles)) await V.writeJson(profiles, { profiles: {} });
  await runInstaller(java, jar, spec.flag, root, signal, report);
  if (!fs.existsSync(V.versionJsonPath(root, id))) throw new Error('Установщик не создал профиль версии');
  return id;
}

// Старые версии держат dll внутри отдельных архивов.
async function extractNatives(root, id, profile) {
  const dir = path.join(V.versionDir(root, id), 'natives');
  await fs.promises.mkdir(dir, { recursive: true });
  for (const lib of resolveLibraries(root, profile)) {
    if (!lib.native) continue;
    const excluded = lib.extract?.exclude || [];
    for (const entry of new AdmZip(lib.native.dest).getEntries()) {
      if (entry.isDirectory || excluded.some((prefix) => entry.entryName.startsWith(prefix))) continue;
      const target = path.resolve(dir, entry.entryName);
      if (!target.startsWith(path.resolve(dir) + path.sep)) continue;
      await fs.promises.mkdir(path.dirname(target), { recursive: true });
      await fs.promises.writeFile(target, entry.getData());
    }
  }
  return dir;
}

async function linkLegacyAssets(root, profile, gameDir, signal) {
  const index = await assetIndex(root, profile, signal);
  if (!index.virtual && !index.map_to_resources) return path.join(root, 'assets');
  const base = index.map_to_resources
    ? path.join(gameDir, 'resources')
    : path.join(root, 'assets', 'virtual', profile.assetIndex.id);
  for (const [name, { hash }] of Object.entries(index.objects)) {
    const target = path.resolve(base, name);
    if (!target.startsWith(path.resolve(base) + path.sep) || fs.existsSync(target)) continue;
    await fs.promises.mkdir(path.dirname(target), { recursive: true });
    await fs.promises.copyFile(path.join(root, 'assets', 'objects', hash.slice(0, 2), hash), target);
  }
  return base;
}

// Сборки с модами живут в своих папках, чтобы моды разных версий не конфликтовали.
// Имя не зависит от сборки загрузчика, иначе его обновление «теряло» бы моды.
const gameDirFor = (root, target) => {
  const { mc, loader } = target;
  if (!loader || loader === 'vanilla') return path.join(root, 'game');
  return path.join(root, 'instances', `${loader}-${mc}${MODES[modeOf(target)].suffix}`);
};

async function prepare(root, target, { signal, onProgress, javaPath } = {}) {
  const report = onProgress || (() => {});
  const { mc, loader = 'vanilla' } = target;
  report({ phase: 'meta' });

  const vanilla = await ensureVanilla(root, mc, signal);
  const runtimes = new Map();
  const ensureJava = async (javaVersion) => {
    if (javaPath) return javaPath;
    const key = javaVersion?.component || 'jre-legacy';
    if (runtimes.has(key)) return runtimes.get(key);
    const plan = await runtimePlan(root, javaVersion, signal);
    if (!plan) throw new Error(`Mojang не выпускает Java ${key} для этой системы. Укажите Java в настройках.`);
    await fetchAll(plan.tasks, { signal, report });
    await finishRuntime(plan);
    runtimes.set(key, plan.binary);
    return plan.binary;
  };

  await fetchAll(await gameTasks(root, vanilla, signal), { signal, report });
  let java = await ensureJava(vanilla.javaVersion);

  let id = mc;
  if (loader === 'fabric') id = await ensureFabric(root, mc, signal);
  else if (INSTALLERS[loader]) id = await ensureInstallerLoader(root, loader, mc, java, { signal, report });

  const profile = await V.resolveProfile(root, id);
  if (id !== mc) {
    await fetchAll(libraryTasks(root, profile), { signal, report });
    java = await ensureJava(profile.javaVersion);
    // Forge исключает клиент из модулей по имени ${version_name}.jar,
    // поэтому, как и официальный лаунчер, кладём копию под именем сборки.
    const jar = clientJarPath(root, profile.jar);
    if (!fs.existsSync(jar)) await fs.promises.copyFile(clientJarPath(root, mc), jar);
  }

  const gameDir = gameDirFor(root, target);
  await fs.promises.mkdir(gameDir, { recursive: true });
  const nativesDir = await extractNatives(root, id, profile);
  const gameAssets = await linkLegacyAssets(root, profile, gameDir, signal);
  return { id, profile, java, gameDir, nativesDir, gameAssets };
}

module.exports = { prepare, resolveLibraries, clientJarPath, gameDirFor };
