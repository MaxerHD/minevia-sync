'use strict';
/* Объёмная фигурка из развёртки скина: каждая часть тела это коробка из шести нарисованных граней. */
(function () {
  const PARTS = [
    { name: 'head', size: [8, 8, 8], uv: [0, 0], layer: [32, 0], at: [0, -10, 0] },
    { name: 'body', size: [8, 12, 4], uv: [16, 16], layer: [16, 32], at: [0, 0, 0] },
    { name: 'arm-r', size: [4, 12, 4], uv: [40, 16], layer: [40, 32], at: [-6, 0, 0] },
    { name: 'arm-l', size: [4, 12, 4], uv: [32, 48], layer: [48, 48], at: [6, 0, 0] },
    { name: 'leg-r', size: [4, 12, 4], uv: [0, 16], layer: [0, 32], at: [-2, 12, 0] },
    { name: 'leg-l', size: [4, 12, 4], uv: [16, 48], layer: [0, 48], at: [2, 12, 0] },
  ];

  function face(image, sx, sy, sw, sh, width, height, transform) {
    // Развёртка размечена в пикселях обычного скина 64x64: у HD-скина 128x128 каждый такой пиксель вдвое крупнее.
    const k = image.naturalWidth / 64;
    const canvas = document.createElement('canvas');
    canvas.width = sw * k;
    canvas.height = sh * k;
    const context = canvas.getContext('2d');
    context.imageSmoothingEnabled = false;
    context.drawImage(image, sx * k, sy * k, sw * k, sh * k, 0, 0, sw * k, sh * k);
    canvas.className = 'skin-face';
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    canvas.style.marginLeft = `${-width / 2}px`;
    canvas.style.marginTop = `${-height / 2}px`;
    canvas.style.transform = transform;
    return canvas;
  }

  function box(image, [w, h, d], [u, v], scale, grow) {
    const node = document.createElement('div');
    node.className = 'skin-box';
    const W = w * scale * grow;
    const H = h * scale * grow;
    const D = d * scale * grow;
    node.append(
      face(image, u + d, v + d, w, h, W, H, `translateZ(${D / 2}px)`),
      face(image, u + d + w + d, v + d, w, h, W, H, `rotateY(180deg) translateZ(${D / 2}px)`),
      face(image, u, v + d, d, h, D, H, `rotateY(-90deg) translateZ(${W / 2}px)`),
      face(image, u + d + w, v + d, d, h, D, H, `rotateY(90deg) translateZ(${W / 2}px)`),
      face(image, u + d, v, w, d, W, D, `rotateX(90deg) translateZ(${H / 2}px)`),
      face(image, u + d + w, v, w, d, W, D, `rotateX(-90deg) translateZ(${H / 2}px)`),
    );
    return node;
  }

  function build(image, scale) {
    const model = document.createElement('div');
    model.className = 'skin-model';
    for (const part of PARTS) {
      const holder = document.createElement('div');
      holder.className = `skin-part skin-${part.name}`;
      const [x, y, z] = part.at;
      holder.style.transform = `translate3d(${x * scale}px, ${y * scale}px, ${z * scale}px)`;
      const swing = document.createElement('div');
      swing.className = 'skin-swing';
      swing.style.transformOrigin = `0 ${(-part.size[1] / 2) * scale}px`;
      swing.append(box(image, part.size, part.uv, scale, 1), box(image, part.size, part.layer, scale, 1.09));
      holder.append(swing);
      model.append(holder);
    }
    return model;
  }

  window.SkinModel = {
    /** Картинка грузится один раз, а готовая фигурка добавляется в stage. */
    show(stage, url, scale) {
      const image = new Image();
      image.onload = () => stage.replaceChildren(build(image, scale));
      image.src = url;
    },
  };
})();
