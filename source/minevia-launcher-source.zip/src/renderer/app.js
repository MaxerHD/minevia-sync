'use strict';
const api = window.minevia;
const $ = (id) => document.getElementById(id);

const LOADER_NAMES = { vanilla: 'Без модов', fabric: 'Fabric', forge: 'Forge', neoforge: 'NeoForge' };
// Режимы общей сборки друзей. У каждого своя папка: миры и моды одного не попадают в другой.
const MODES = {
  elements: { title: 'Четыре начала', text: 'Магия стихий, хоррор, боссы' },
  chill: { title: 'Уютное выживание', text: 'Музыка, атмосфера, шейдеры. Без магии и хоррора' },
  jojo: { title: 'JoJo: Уютное приключение', text: 'Вся уютная сборка + стенды, способности и боссы JoJo' },
  funtime: { title: 'FunTime', text: 'Для сервера: только разрешённые моды, графика и FPS' },
};
const TYPE_NAMES = { release: 'Релиз', snapshot: 'Снапшот', old_beta: 'Бета', old_alpha: 'Альфа' };
const MAX_LOG_LINES = 3000;
const STAGGER_LIMIT = 24;

const state = {
  config: null,
  versions: [],
  installed: new Set(),
  latest: null,
  loaders: {},
  status: 'idle',
  modOffset: 0,
  shared: null,
};

/** Режим есть только у версии друзей: для остальных версий папка игры прежняя. */
const isShared = () => Boolean(state.shared?.mc) && state.config.mc === state.shared.mc && state.config.loader === state.shared.loader;
const target = () => ({
  mc: state.config.mc,
  loader: state.config.loader,
  mode: isShared() && MODES[state.config.mode] ? state.config.mode : 'elements',
});

function renderModes() {
  const box = $('modes');
  box.hidden = !isShared();
  const current = target().mode;
  document.documentElement.dataset.mode = current;
  box.replaceChildren(
    ...Object.entries(MODES).map(([key, mode]) => {
      const button = el('button', { className: `mode mode-${key}` }, el('b', { textContent: mode.title }), el('small', { textContent: mode.text }));
      button.setAttribute('role', 'radio');
      button.setAttribute('aria-checked', String(current === key));
      button.disabled = state.status !== 'idle';
      button.addEventListener('click', async () => {
        if (state.config.mode === key) return;
        await saveConfig({ mode: key });
        renderModes();
        renderHero();
        refreshMods();
      });
      return button;
    }),
  );
}

function el(tag, props = {}, ...children) {
  const node = Object.assign(document.createElement(tag), props);
  node.append(...children);
  return node;
}

const stagger = (node, index) => node.style.setProperty('--i', String(Math.min(index, STAGGER_LIMIT)));

let toastTimer;
function toast(message) {
  const node = $('toast');
  node.textContent = message;
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (node.hidden = true), 9000);
}

async function saveConfig(patch) {
  Object.assign(state.config, patch);
  await api.setConfig(patch);
}

/* Вкладки: подсветка скользит к выбранной */
function moveGlider() {
  const tab = document.querySelector('.tab.is-active');
  const glider = $('tabGlider');
  glider.style.width = `${tab.offsetWidth}px`;
  glider.style.transform = `translateX(${tab.offsetLeft}px)`;
}

/* Прогресс: полоска в панели и рассвет над долиной */
function setProgress(fraction) {
  $('bar').hidden = fraction === null;
  if (fraction !== null) $('barFill').style.width = `${Math.round(fraction * 100)}%`;
  window.Scene.setProgress(fraction);
}

const megabytes = (bytes) => (bytes / 1048576).toFixed(0);

function showProgress(p) {
  const title = $('statusTitle');
  const detail = $('statusDetail');
  if (p.phase === 'meta') {
    title.textContent = 'Читаю описание версии';
    detail.textContent = '';
    setProgress(0.02);
  } else if (p.phase === 'verify') {
    title.textContent = 'Проверяю файлы';
    detail.textContent = `${p.done} из ${p.total}`;
    setProgress((p.done / p.total) * 0.15);
  } else if (p.phase === 'download') {
    const percent = p.total ? Math.min(100, Math.round((p.done / p.total) * 100)) : 0;
    title.textContent = `Скачиваю игру, ${percent}%`;
    detail.textContent = `${megabytes(p.done)} из ${megabytes(p.total)} МБ · файлов ${p.files} из ${p.fileTotal}`;
    setProgress(0.15 + (percent / 100) * 0.8);
  } else if (p.phase === 'sync') {
    title.textContent = `Обновляю файлы: ${p.done} из ${p.total}`;
    detail.textContent = p.name;
    setProgress(p.done / p.total);
  } else if (p.phase === 'loader') {
    title.textContent = `Устанавливаю ${LOADER_NAMES[state.config.loader]}`;
    detail.textContent = p.line;
  }
}

function applyStatus({ status, detail }) {
  state.status = status;
  const play = $('playBtn');
  const label = $('playLabel');
  $('cancelBtn').hidden = status !== 'installing';
  play.classList.toggle('is-stop', status === 'running');
  play.disabled = status === 'installing';
  $('nick').disabled = status !== 'idle';
  if (state.config) renderModes();
  window.Scene.setPaused(status === 'running');

  if (status === 'installing') {
    label.textContent = 'Подождите';
    setProgress(0);
  } else if (status === 'running') {
    label.textContent = 'Закрыть игру';
    $('statusTitle').textContent = 'Игра запущена';
    $('statusDetail').textContent = detail?.id || '';
    $('bar').hidden = true;
  } else {
    label.textContent = 'Играть';
    setProgress(null);
    if (detail?.crashed) {
      $('statusTitle').textContent = `Игра упала с кодом ${detail.code}`;
      $('statusDetail').textContent = 'Причина обычно видна в конце журнала';
      $('logDot').hidden = false;
    } else {
      $('statusTitle').textContent = 'Всё готово к игре';
      $('statusDetail').textContent = 'Файлы приходят с серверов Mojang';
    }
    refreshVersions();
  }
}

/* Версии */
function visibleVersions(query) {
  const { showSnapshots, showOld } = state.config;
  return state.versions.filter(({ id, type }) => {
    if (query) return id.toLowerCase().includes(query);
    if (type === 'release') return true;
    if (type === 'snapshot') return showSnapshots;
    return showOld;
  });
}

function renderVersionList() {
  const query = $('versionSearch').value.trim().toLowerCase();
  const list = $('versionList');
  list.replaceChildren(
    ...visibleVersions(query).map((version, index) => {
      const row = el('button', { className: 'version' }, el('b', { textContent: version.id }));
      stagger(row, index);
      row.classList.toggle('is-selected', version.id === state.config.mc);
      row.append(el('small', { textContent: TYPE_NAMES[version.type] || version.type }));
      if (state.installed.has(version.id)) {
        row.append(el('i', { title: 'Уже скачана' }));
      }
      row.addEventListener('click', () => {
        selectVersion(version.id);
        togglePicker(false);
      });
      return row;
    }),
  );
  if (!list.children.length) list.append(el('p', { className: 'quiet', textContent: 'Ничего не найдено' }));
}

function togglePicker(open) {
  $('picker').classList.toggle('is-open', open);
  $('picker').setAttribute('aria-hidden', String(!open));
  $('scrim').classList.toggle('is-open', open);
  if (open) {
    $('versionSearch').value = '';
    renderVersionList();
    $('versionSearch').focus();
  }
}

function renderHero() {
  const { mc } = state.config;
  const version = state.versions.find((v) => v.id === mc);
  const label = $('heroVersion');
  if (label.textContent !== (mc || '—')) {
    label.textContent = mc || '—';
    label.classList.remove('is-swapping');
    void label.offsetWidth;
    label.classList.add('is-swapping');
  }
  const type = version ? TYPE_NAMES[version.type] || version.type : '';
  const isLatest = state.latest?.release === mc;
  $('heroType').textContent = [type, isLatest ? 'самая новая' : ''].filter(Boolean).join(' · ');
  $('heroNote').textContent = target().mode === 'jojo'
    ? 'Получи стенд стрелой или диском. Меню способностей: /trigger svm.jj.menu'
    : target().mode === 'funtime'
    ? 'Только моды из списка разрешённых FunTime. Свои моды сюда не добавляй: на проверке за них банят'
    : state.installed.has(mc) ? 'Скачана, запустится быстро' : 'Скачается при первом запуске, примерно 700 МБ';
}

function renderLoaders() {
  const box = $('loaders');
  box.replaceChildren(
    ...Object.entries(LOADER_NAMES).map(([key, name]) => {
      const available = key === 'vanilla' || Boolean(state.loaders[key]);
      const button = el('button', { className: 'loader', textContent: name, disabled: !available });
      button.setAttribute('role', 'radio');
      button.setAttribute('aria-checked', String(state.config.loader === key));
      button.addEventListener('click', async () => {
        await saveConfig({ loader: key });
        renderLoaders();
        renderModes();
        renderHero();
        refreshMods();
      });
      return button;
    }),
  );
}

let loaderRequest = 0;
async function selectVersion(mc) {
  await saveConfig({ mc });
  renderHero();
  state.loaders = {};
  renderLoaders();
  const request = ++loaderRequest;
  const loaders = await api.loadersFor(mc).catch(() => ({}));
  if (request !== loaderRequest) return;
  state.loaders = loaders;
  if (state.config.loader !== 'vanilla' && !loaders[state.config.loader]) {
    await saveConfig({ loader: 'vanilla' });
  }
  renderLoaders();
  renderModes();
  refreshMods();
}

async function refreshVersions() {
  try {
    const data = await api.listVersions();
    state.versions = data.versions;
    state.latest = data.latest;
    state.installed = new Set(data.installed);
    if (state.config) renderHero();
    return data;
  } catch (err) {
    $('heroType').textContent = 'Нет связи с серверами Mojang';
    toast(err.message);
    return null;
  }
}

/* Моды */
function modCard(mod, index) {
  const icon = mod.icon ? el('img', { src: mod.icon, alt: '', loading: 'lazy' }) : el('div', { className: 'mod-noicon' });
  const button = el('button', { className: 'ghost', textContent: 'Установить' });
  button.addEventListener('click', async () => {
    button.disabled = true;
    button.textContent = 'Качаю';
    try {
      await api.installMod(target(), mod.id);
      button.textContent = 'Готово';
      button.classList.add('is-done');
      renderInstalledMods();
    } catch (err) {
      button.disabled = false;
      button.textContent = 'Установить';
      toast(err.message);
    }
  });
  const text = el('div', {}, el('h3', { textContent: mod.title }), el('p', { textContent: mod.description }));
  const card = el('article', { className: 'mod' }, icon, text, button);
  stagger(card, index);
  return card;
}

async function loadMods(reset) {
  const { mc, loader } = state.config;
  if (reset) {
    state.modOffset = 0;
    $('modResults').replaceChildren();
  }
  try {
    const query = $('modSearch').value.trim();
    const { hits, total } = await api.searchMods({ query, mc, loader, offset: state.modOffset });
    state.modOffset += hits.length;
    $('modResults').append(...hits.map(modCard));
    $('modMore').hidden = state.modOffset >= total;
    if (!total) $('modResults').append(el('p', { className: 'quiet', textContent: 'Для этой версии ничего не нашлось' }));
  } catch (err) {
    toast(err.message);
  }
}

async function renderInstalledMods() {
  const box = $('modInstalled');
  const items = await api.listMods(target()).catch(() => []);
  box.replaceChildren(
    ...items.map(({ file, enabled }) => {
      const row = el('div', { className: `installed-mod${enabled ? '' : ' is-off'}` });
      const name = el('span', { textContent: file.replace(/\.jar(\.disabled)?$/, ''), title: file });
      const toggle = el('button', { textContent: enabled ? 'выкл' : 'вкл' });
      const remove = el('button', { textContent: '×', title: 'В корзину' });
      toggle.addEventListener('click', () => api.toggleMod(target(), file).then(renderInstalledMods, (e) => toast(e.message)));
      remove.addEventListener('click', () => api.removeMod(target(), file).then(renderInstalledMods, (e) => toast(e.message)));
      row.append(name, toggle, remove);
      return row;
    }),
  );
  if (!items.length) box.append(el('p', { className: 'quiet', textContent: 'Пока пусто' }));
}

function refreshMods() {
  const { mc, loader } = state.config;
  const vanilla = loader === 'vanilla';
  $('modsNeedLoader').hidden = !vanilla;
  $('modsLayout').hidden = vanilla;
  $('modsFolder').hidden = vanilla;
  const mode = isShared() ? ` · ${MODES[target().mode].title}` : '';
  $('modsContext').textContent = vanilla ? '' : `${LOADER_NAMES[loader]} для ${mc}${mode}`;
  if (!vanilla && $('page-mods').classList.contains('is-active')) {
    loadMods(true);
    renderInstalledMods();
  }
}

/* Скины: карточка персонажа задаёт и ник, и скин */
const SKIN_SCALE = 9;

function markCharacter() {
  for (const card of $('characters').children) {
    const chosen = card.dataset.id === state.config.character;
    card.classList.toggle('is-chosen', chosen);
    card.setAttribute('aria-checked', String(chosen));
  }
}

async function chooseCharacter(character) {
  if (state.status !== 'idle') return toast('Сменить персонажа можно, когда игра закрыта');
  $('nick').value = character.username;
  $('nick').classList.remove('is-bad');
  await saveConfig({ username: character.username, character: character.id });
  markCharacter();
}

function renderCharacters(characters) {
  $('characters').replaceChildren(
    ...characters.map((character, index) => {
      const stage = el('div', { className: 'character-stage' });
      const card = el(
        'button',
        { className: 'character' },
        stage,
        el('strong', { textContent: character.title }),
        el('small', { textContent: `Ник: ${character.username}` }),
      );
      card.dataset.id = character.id;
      card.setAttribute('role', 'radio');
      stagger(card, index);
      card.addEventListener('click', () => chooseCharacter(character));
      window.SkinModel.show(stage, character.image, SKIN_SCALE);
      return card;
    }),
  );
  markCharacter();
}

/* Журнал */
function appendLog({ level, text }) {
  const box = $('log');
  const stick = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
  box.append(el('div', { className: level, textContent: text }));
  while (box.childElementCount > MAX_LOG_LINES) box.firstChild.remove();
  if (stick) box.scrollTop = box.scrollHeight;
}

/* Настройки */
function renderSettings(totalMemoryMb, version) {
  const c = state.config;
  const memory = $('memory');
  memory.max = String(Math.max(2048, Math.floor((totalMemoryMb - 1024) / 256) * 256));
  memory.value = String(c.memoryMb);
  const showMemory = () => ($('memoryOut').textContent = `${(Number(memory.value) / 1024).toFixed(2).replace(/0$/, '')} ГБ`);
  showMemory();
  memory.addEventListener('input', showMemory);
  memory.addEventListener('change', () => saveConfig({ memoryMb: Number(memory.value) }));

  for (const key of ['width', 'height']) {
    $(key).value = c[key];
    $(key).addEventListener('change', (e) => saveConfig({ [key]: Number(e.target.value) || 0 }));
  }
  for (const key of ['fullscreen', 'hideOnLaunch', 'showSnapshots', 'showOld']) {
    $(key).checked = c[key];
    $(key).addEventListener('change', (e) => saveConfig({ [key]: e.target.checked }));
  }
  $('pickDerivative').addEventListener('click', async () => {
    try {
      const name = await api.pickDerivative(target());
      if (name) $('derivativeState').value = `Готово: ${name} включён`;
    } catch (err) {
      toast(err.message);
    }
  });
  $('syncUrl').value = c.syncUrl;
  $('syncUrl').addEventListener('change', (e) => saveConfig({ syncUrl: e.target.value.trim() }));
  $('jvmArgs').value = c.jvmArgs;
  $('jvmArgs').addEventListener('change', (e) => saveConfig({ jvmArgs: e.target.value.trim() }));
  $('dataDir').value = c.dataDir;
  $('javaPath').value = c.javaPath;

  $('pickData').addEventListener('click', async () => {
    const dir = await api.pickFolder();
    if (!dir) return;
    await saveConfig({ dataDir: dir });
    $('dataDir').value = dir;
    refreshVersions();
  });
  $('openData').addEventListener('click', () => api.openFolder('data'));
  $('pickJava').addEventListener('click', async () => {
    const file = await api.pickJava();
    if (!file) return;
    await saveConfig({ javaPath: file });
    $('javaPath').value = file;
  });
  $('clearJava').addEventListener('click', async () => {
    await saveConfig({ javaPath: '' });
    $('javaPath').value = '';
  });
  $('about').textContent =
    `Minevia ${version}. Без рекламы и телеметрии. Файлы приходят только с серверов Mojang, Fabric, Forge, NeoForge и Modrinth и проверяются по контрольным суммам. Не связан с Mojang и Microsoft.`;
}

function bindUi() {
  document.querySelectorAll('.tab').forEach((tab) => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('is-active', t === tab));
      document.querySelectorAll('.page').forEach((p) => p.classList.toggle('is-active', p.id === `page-${tab.dataset.page}`));
      moveGlider();
      if (tab.dataset.page === 'mods') refreshMods();
      if (tab.dataset.page === 'log') $('logDot').hidden = true;
    });
  });
  $('winMin').addEventListener('click', () => api.minimize());
  $('winClose').addEventListener('click', () => api.close());
  $('openPicker').addEventListener('click', () => togglePicker(true));
  $('closePicker').addEventListener('click', () => togglePicker(false));
  $('scrim').addEventListener('click', () => togglePicker(false));
  document.addEventListener('keydown', (e) => e.key === 'Escape' && togglePicker(false));
  $('versionSearch').addEventListener('input', renderVersionList);

  const nick = $('nick');
  nick.addEventListener('input', () => {
    nick.classList.remove('is-bad');
    // Свой ник значит свой герой: скин выбранного персонажа больше не подходит.
    saveConfig({ username: nick.value, character: '' }).then(markCharacter);
  });

  $('playBtn').addEventListener('click', async () => {
    if (state.status === 'running') return api.stop();
    if (!/^[A-Za-z0-9_]{3,16}$/.test(nick.value)) {
      nick.classList.remove('is-bad');
      void nick.offsetWidth;
      nick.classList.add('is-bad');
      nick.focus();
      return toast('Ник: от 3 до 16 латинских букв, цифр или _');
    }
    if (!state.config.mc) return toast('Сначала выберите версию');
    $('log').replaceChildren();
    try {
      await api.play(target());
    } catch (err) {
      toast(err.message);
      appendLog({ level: 'ERROR', text: err.message });
    }
  });
  $('cancelBtn').addEventListener('click', () => api.cancel());

  let searchTimer;
  $('modSearch').addEventListener('input', () => {
    clearTimeout(searchTimer);
    searchTimer = setTimeout(() => loadMods(true), 300);
  });
  $('modMore').addEventListener('click', () => loadMods(false));
  $('modsFolder').addEventListener('click', () => api.openFolder('mods', target()));
  $('logClear').addEventListener('click', () => $('log').replaceChildren());
  $('logCopy').addEventListener('click', () => navigator.clipboard.writeText($('log').innerText));

  api.onStatus(applyStatus);
  api.onProgress(showProgress);
  api.onLog(appendLog);
  window.addEventListener('resize', moveGlider);
  document.fonts.ready.then(moveGlider);
}

async function start() {
  const { config, totalMemoryMb, version } = await api.getConfig();
  state.config = config;
  $('nick').value = config.username;
  renderSettings(totalMemoryMb, version);
  bindUi();
  moveGlider();
  renderLoaders();
  const shared = await api.listCharacters().catch(() => ({ characters: [] }));
  state.shared = { mc: shared.mc, loader: shared.loader };
  renderCharacters(shared.characters);
  // Новый игрок сразу попадает на версию друзей.
  if (!config.mc && shared.mc) await saveConfig({ loader: shared.loader });
  const data = await refreshVersions();
  if (data) await selectVersion(config.mc || shared.mc || data.latest.release);
}

start();
