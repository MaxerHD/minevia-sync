'use strict';
// Живой пейзаж за интерфейсом. Время суток берётся из часов компьютера,
// а пока игра скачивается, над долиной наступает рассвет.
(() => {
  const canvas = document.getElementById('scene');
  const ctx = canvas.getContext('2d');
  const PIXEL = 3;
  const BLOCK = 5;
  const FRAME_MS = 1000 / 30;
  const SUNRISE = 0.29;
  const calm = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const SKY = [
    { t: 0.0, top: '#0a1228', low: '#1a2748', glow: '#26305a' },
    { t: 0.2, top: '#0e1733', low: '#27305e', glow: '#4a3f70' },
    { t: 0.27, top: '#27305f', low: '#c26b7c', glow: '#ffb26b' },
    { t: 0.34, top: '#43709c', low: '#f3c79b', glow: '#ffe0a8' },
    { t: 0.5, top: '#3f7da8', low: '#b9d8d6', glow: '#f5ecc8' },
    { t: 0.68, top: '#3d6a97', low: '#f0bd8d', glow: '#ffd08a' },
    { t: 0.76, top: '#2a2f62', low: '#d9667a', glow: '#ff9a5c' },
    { t: 0.84, top: '#111a3a', low: '#2c2f5f', glow: '#51406f' },
    { t: 1.0, top: '#0a1228', low: '#1a2748', glow: '#26305a' },
  ];
  const LAYERS = [
    { night: '#1b2a4a', day: '#7ea6b8', base: 0.56, rough: 26, speed: 0.012, seed: 11 },
    { night: '#142238', day: '#5c9186', base: 0.66, rough: 22, speed: 0.024, seed: 23 },
    { night: '#0e1a2a', day: '#3f7b5e', base: 0.76, rough: 16, speed: 0.04, seed: 37 },
    { night: '#08121c', day: '#2b5c43', base: 0.87, rough: 9, speed: 0.07, seed: 53 },
  ];

  const rgb = (hex) => [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16));
  const mix = (a, b, k) => a.map((v, i) => v + (b[i] - v) * k);
  const css = (c, alpha = 1) => `rgba(${c[0] | 0},${c[1] | 0},${c[2] | 0},${alpha})`;
  const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));

  function random(seed) {
    let s = seed;
    return () => {
      s = (s * 1664525 + 1013904223) % 4294967296;
      return s / 4294967296;
    };
  }

  function clockPhase() {
    const now = new Date();
    return (now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds()) / 86400;
  }

  function skyAt(phase) {
    let i = 0;
    while (i < SKY.length - 2 && phase > SKY[i + 1].t) i++;
    const a = SKY[i];
    const b = SKY[i + 1];
    const k = clamp((phase - a.t) / (b.t - a.t));
    return {
      top: mix(rgb(a.top), rgb(b.top), k),
      low: mix(rgb(a.low), rgb(b.low), k),
      glow: mix(rgb(a.glow), rgb(b.glow), k),
    };
  }

  // 0 ночью, 1 днём
  const daylight = (phase) => clamp(Math.sin((phase - 0.25) * Math.PI * 2) * 1.8 + 0.35);

  let W = 0;
  let H = 0;
  let ridges = [];
  let stars = [];
  let clouds = [];
  let trees = [];
  let flies = [];
  const smoke = [];
  let cabin = null;
  let meteor = null;

  function ridgeHeight(layer, column, rnd) {
    const a = rnd.a;
    const wave =
      Math.sin(column * 0.11 + a) * 0.6 + Math.sin(column * 0.043 + a * 2) + Math.sin(column * 0.27 + a * 3) * 0.22;
    return Math.round((H * layer.base - wave * layer.rough) / BLOCK) * BLOCK;
  }

  function build() {
    W = Math.ceil(window.innerWidth / PIXEL);
    H = Math.ceil(window.innerHeight / PIXEL);
    canvas.width = W;
    canvas.height = H;

    ridges = LAYERS.map((layer) => {
      const rnd = { a: random(layer.seed)() * 10 };
      const columns = Math.ceil((W + 120) / BLOCK) + 2;
      return Array.from({ length: columns }, (_, c) => ridgeHeight(layer, c, rnd));
    });

    const r = random(7);
    stars = Array.from({ length: Math.round((W * H) / 420) }, () => ({
      x: r() * W,
      y: r() * H * 0.62,
      size: r() < 0.14 ? 2 : 1,
      speed: 0.6 + r() * 2.4,
      offset: r() * 6.28,
    }));
    clouds = Array.from({ length: 7 }, () => ({
      x: r() * (W + 120),
      y: H * (0.06 + r() * 0.3),
      speed: 1 + r() * 2.4,
      blocks: Array.from({ length: 4 + Math.floor(r() * 5) }, (_, i) => ({
        dx: i * BLOCK * 2,
        dy: Math.round((r() - 0.5) * 2) * BLOCK,
        w: BLOCK * (2 + Math.floor(r() * 3)),
      })),
    }));

    trees = [];
    [2, 3].forEach((index) => {
      const columns = ridges[index];
      for (let c = 2; c < columns.length - 2; c++) {
        if (r() > (index === 3 ? 0.13 : 0.2)) continue;
        trees.push({ layer: index, column: c, tall: 3 + Math.floor(r() * 3), offset: r() * 6.28 });
      }
    });

    const nearest = ridges[3];
    const cabinColumn = Math.round((W * 0.72 + 60) / BLOCK);
    cabin = { column: cabinColumn, ground: nearest[cabinColumn] };
    trees = trees.filter((t) => t.layer !== 3 || Math.abs(t.column - cabinColumn) > 7);

    flies = Array.from({ length: 26 }, () => ({
      x: r() * W,
      y: H * (0.58 + r() * 0.34),
      a: r() * 6.28,
      b: r() * 6.28,
      speed: 0.3 + r() * 0.7,
    }));
  }

  const state = {
    progress: null,
    phase: clockPhase(),
    start: 0,
    paused: false,
    mouseX: 0,
    mouseY: 0,
    viewX: 0,
    viewY: 0,
  };

  function drawSky(sky, light, time) {
    const gradient = ctx.createLinearGradient(0, 0, 0, H * 0.82);
    gradient.addColorStop(0, css(sky.top));
    gradient.addColorStop(1, css(sky.low));
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, W, H);

    const night = 1 - light;
    if (night > 0.02) {
      for (const star of stars) {
        const twinkle = 0.55 + Math.sin(time * star.speed + star.offset) * 0.45;
        ctx.fillStyle = `rgba(255,243,220,${(twinkle * night).toFixed(3)})`;
        ctx.fillRect(star.x | 0, star.y | 0, star.size, star.size);
      }
    }
  }

  function drawMeteor(light, time, dt) {
    if (light > 0.3 || calm) return;
    if (!meteor && Math.random() < dt * 0.05) {
      meteor = { x: W * (0.3 + Math.random() * 0.6), y: H * Math.random() * 0.25, life: 0 };
    }
    if (!meteor) return;
    meteor.life += dt;
    meteor.x -= dt * 150;
    meteor.y += dt * 70;
    for (let i = 0; i < 14; i++) {
      ctx.fillStyle = `rgba(255,243,220,${(0.75 - i * 0.05) * (1 - meteor.life)})`;
      ctx.fillRect((meteor.x + i * 2) | 0, (meteor.y - i) | 0, 1, 1);
    }
    if (meteor.life > 0.9) meteor = null;
  }

  function drawOrb(phase, sky, light) {
    const isDay = phase > 0.23 && phase < 0.77;
    const k = isDay ? (phase - 0.23) / 0.54 : ((phase + 0.23) % 1) / 0.46;
    const x = W * (0.92 - k * 0.8) + state.viewX * 3;
    const y = H * 0.74 - Math.sin(k * Math.PI) * H * 0.62;
    const size = isDay ? 13 : 10;
    const color = isDay ? mix(rgb('#fff1c0'), sky.glow, 0.4) : rgb('#f4ecd8');
    const halo = ctx.createRadialGradient(x, y, 1, x, y, size * 6);
    halo.addColorStop(0, css(color, isDay ? 0.55 : 0.3));
    halo.addColorStop(1, css(color, 0));
    ctx.fillStyle = halo;
    ctx.fillRect(x - size * 6, y - size * 6, size * 12, size * 12);
    // Круг по пикселям. Ночью из него вырезается второй круг, и выходит серп.
    const radius = size / 2 + 1;
    const cx = x | 0;
    const cy = y | 0;
    ctx.fillStyle = css(color);
    for (let dy = -radius; dy <= radius; dy++) {
      for (let dx = -radius; dx <= radius; dx++) {
        if (dx * dx + dy * dy > radius * radius) continue;
        const bite = (dx - 3) * (dx - 3) + (dy + 1) * (dy + 1);
        if (!isDay && bite < radius * radius * 0.72) continue;
        ctx.fillRect(cx + dx, cy + dy, 1, 1);
      }
    }
  }

  function drawClouds(sky, light, dt) {
    const color = mix(mix(sky.low, rgb('#fff6e6'), 0.35 + light * 0.4), sky.glow, 0.2);
    ctx.fillStyle = css(color, 0.18 + light * 0.4);
    for (const cloud of clouds) {
      cloud.x -= cloud.speed * dt;
      if (cloud.x < -120) cloud.x = W + 40;
      for (const block of cloud.blocks) {
        ctx.fillRect((cloud.x + block.dx) | 0, (cloud.y + block.dy) | 0, block.w, BLOCK);
      }
    }
  }

  function layerColor(layer, sky, light) {
    const base = mix(rgb(layer.night), rgb(layer.day), light);
    return mix(base, sky.glow, 0.1 + (1 - Math.abs(light - 0.5) * 2) * 0.12);
  }

  function shift(index) {
    return Math.round(state.viewX * LAYERS[index].speed * 900) + 60;
  }

  function drawTree(tree, color, light, time) {
    const x = tree.column * BLOCK - shift(tree.layer);
    if (x < -20 || x > W + 20) return;
    const ground = ridges[tree.layer][tree.column];
    ctx.fillStyle = css(mix(color, rgb('#000000'), 0.28));
    ctx.fillRect(x + 1, ground - BLOCK, 3, BLOCK);
    const sway = calm ? 0 : Math.round(Math.sin(time * 0.9 + tree.offset) * 0.7);
    ctx.fillStyle = css(mix(color, rgb('#000000'), 0.12));
    for (let i = 0; i < tree.tall; i++) {
      const half = (tree.tall - i) * 2 + 1;
      const offset = i >= tree.tall - 2 ? sway : 0;
      ctx.fillRect(x + 2 - half + offset, ground - BLOCK * (i + 2), half * 2 + 1, BLOCK);
    }
  }

  function drawCabin(color, light, time, dt) {
    const x = cabin.column * BLOCK - shift(3);
    const ground = cabin.ground;
    const wall = mix(color, rgb('#3a2a22'), 0.55 + light * 0.2);
    const roof = mix(color, rgb('#1c1412'), 0.55);
    ctx.fillStyle = css(wall);
    ctx.fillRect(x - 12, ground - 16, 26, 16);
    ctx.fillStyle = css(roof);
    for (let i = 0; i < 4; i++) ctx.fillRect(x - 15 + i * 3, ground - 19 - i * 3, 32 - i * 6, 3);
    ctx.fillRect(x + 7, ground - 30, 4, 11);

    const flicker = calm ? 1 : 0.86 + Math.sin(time * 7) * 0.05 + Math.sin(time * 13.1) * 0.05;
    const lit = (1 - light * 0.75) * flicker;
    const warm = rgb('#ffc765');
    const halo = ctx.createRadialGradient(x - 4, ground - 9, 1, x - 4, ground - 9, 42);
    halo.addColorStop(0, css(warm, 0.5 * lit));
    halo.addColorStop(1, css(warm, 0));
    ctx.fillStyle = halo;
    ctx.fillRect(x - 48, ground - 52, 88, 88);
    ctx.fillStyle = css(mix(wall, warm, lit));
    ctx.fillRect(x - 8, ground - 12, 7, 7);
    ctx.fillRect(x + 3, ground - 12, 7, 7);
    ctx.fillStyle = css(roof);
    ctx.fillRect(x - 5, ground - 12, 1, 7);
    ctx.fillRect(x + 6, ground - 12, 1, 7);

    if (calm) return;
    if (Math.random() < dt * 3.2) smoke.push({ x: x + 8, y: ground - 31, life: 0, drift: Math.random() * 6.28 });
    for (let i = smoke.length - 1; i >= 0; i--) {
      const puff = smoke[i];
      puff.life += dt * 0.28;
      puff.y -= dt * 7;
      puff.x += Math.sin(time + puff.drift) * dt * 3 + dt * 2;
      if (puff.life >= 1) {
        smoke.splice(i, 1);
        continue;
      }
      const size = 2 + Math.round(puff.life * 3);
      ctx.fillStyle = `rgba(230,225,215,${(0.32 * (1 - puff.life)).toFixed(3)})`;
      ctx.fillRect(puff.x | 0, puff.y | 0, size, size);
    }
  }

  function drawLand(sky, light, time, dt) {
    LAYERS.forEach((layer, index) => {
      const color = layerColor(layer, sky, light);
      const offset = shift(index);
      ctx.fillStyle = css(color);
      ridges[index].forEach((top, column) => {
        ctx.fillRect(column * BLOCK - offset, top, BLOCK, H - top);
      });
      if (index >= 2) {
        ctx.fillStyle = css(mix(color, rgb('#b8e0a0'), 0.1 + light * 0.16));
        ridges[index].forEach((top, column) => ctx.fillRect(column * BLOCK - offset, top, BLOCK, 2));
        for (const tree of trees) if (tree.layer === index) drawTree(tree, color, light, time);
      }
      if (index === 3) drawCabin(color, light, time, dt);
    });
  }

  function drawFlies(light, time, dt) {
    const strength = clamp((0.75 - light) * 1.6);
    if (strength <= 0.02) return;
    const cursorX = ((state.mouseX + 1) / 2) * W;
    const cursorY = ((state.mouseY + 1) / 2) * H;
    for (const fly of flies) {
      fly.a += dt * fly.speed;
      fly.b += dt * fly.speed * 0.7;
      fly.x += Math.cos(fly.a) * dt * 9 + (cursorX - fly.x) * dt * 0.035;
      fly.y += Math.sin(fly.b) * dt * 6 + (cursorY - fly.y) * dt * 0.02;
      if (fly.x < -4) fly.x = W;
      if (fly.x > W + 4) fly.x = 0;
      fly.y = clamp(fly.y, H * 0.45, H - 8);
      const pulse = (0.5 + Math.sin(time * 2 * fly.speed + fly.b) * 0.5) * strength;
      const fx = fly.x | 0;
      const fy = fly.y | 0;
      ctx.fillStyle = `rgba(255,200,100,${(pulse * 0.3).toFixed(3)})`;
      ctx.fillRect(fx - 1, fy, 3, 1);
      ctx.fillRect(fx, fy - 1, 1, 3);
      ctx.fillStyle = `rgba(255,236,170,${pulse.toFixed(3)})`;
      ctx.fillRect(fx, fy, 1, 1);
    }
  }

  function targetPhase() {
    const now = clockPhase();
    if (state.progress === null) return now;
    const dawn = state.start > SUNRISE ? SUNRISE + 1 : SUNRISE;
    return state.start + (dawn - state.start) * state.progress;
  }

  function render(time, dt) {
    const wanted = targetPhase();
    let delta = wanted - state.phase;
    if (state.progress === null && Math.abs(delta) > 0.5) delta -= Math.sign(delta);
    state.phase += delta * clamp(dt * 2.4);
    const phase = ((state.phase % 1) + 1) % 1;

    state.viewX += (state.mouseX - state.viewX) * clamp(dt * 3);
    state.viewY += (state.mouseY - state.viewY) * clamp(dt * 3);

    const sky = skyAt(phase);
    const light = daylight(phase);
    drawSky(sky, light, time);
    drawMeteor(light, time, dt);
    drawOrb(phase, sky, light);
    drawClouds(sky, light, dt);
    drawLand(sky, light, time, dt);
    drawFlies(light, time, dt);
    document.documentElement.style.setProperty('--sky-light', light.toFixed(3));
  }

  let last = 0;
  let running = false;
  function loop(now) {
    if (!running) return;
    requestAnimationFrame(loop);
    if (now - last < FRAME_MS) return;
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;
    render(now / 1000, dt);
  }

  function sync() {
    const active = !state.paused && !document.hidden && !calm;
    if (active === running) return;
    running = active;
    if (active) {
      last = performance.now();
      requestAnimationFrame(loop);
    }
  }

  window.addEventListener('resize', () => {
    build();
    render(performance.now() / 1000, 0);
  });
  window.addEventListener('mousemove', (event) => {
    state.mouseX = (event.clientX / window.innerWidth) * 2 - 1;
    state.mouseY = (event.clientY / window.innerHeight) * 2 - 1;
  });
  document.addEventListener('visibilitychange', sync);

  window.Scene = {
    // Доля от 0 до 1 ведёт время к рассвету, null возвращает настоящие часы.
    setProgress(value) {
      if (value !== null && state.progress === null) state.start = ((state.phase % 1) + 1) % 1;
      state.progress = value === null ? null : clamp(value);
      if (calm) render(performance.now() / 1000, 1);
    },
    // Пока идёт игра, видеокарта нужна ей, поэтому пейзаж замирает.
    setPaused(value) {
      state.paused = value;
      sync();
    },
  };

  build();
  render(performance.now() / 1000, 0.03);
  sync();
})();
