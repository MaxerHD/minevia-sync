'use strict';
const { contextBridge, ipcRenderer } = require('electron');

async function call(channel, ...args) {
  const result = await ipcRenderer.invoke(channel, ...args);
  if (!result.ok) throw new Error(result.error);
  return result.value;
}

const listen = (channel) => (callback) => {
  ipcRenderer.on(channel, (_event, payload) => callback(payload));
};

contextBridge.exposeInMainWorld('minevia', {
  getConfig: () => call('config:get'),
  setConfig: (patch) => call('config:set', patch),
  listCharacters: () => call('characters:list'),
  listVersions: () => call('versions:list'),
  loadersFor: (mc) => call('versions:loaders', mc),
  play: (target) => call('game:play', target),
  cancel: () => call('game:cancel'),
  stop: () => call('game:stop'),
  searchMods: (query) => call('mods:search', query),
  listMods: (target) => call('mods:list', target),
  installMod: (target, id) => call('mods:install', target, id),
  toggleMod: (target, file) => call('mods:toggle', target, file),
  removeMod: (target, file) => call('mods:remove', target, file),
  openFolder: (kind, target) => call('folder:open', kind, target),
  pickFolder: () => call('dialog:folder'),
  pickJava: () => call('dialog:java'),
  pickDerivative: (target) => call('shader:derivative', target),
  minimize: () => call('window:minimize'),
  close: () => call('window:close'),
  onStatus: listen('status'),
  onProgress: listen('progress'),
  onLog: listen('log'),
});
