'use strict';
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { app, BrowserWindow, dialog, ipcMain, shell } = require('electron');
const { prepare, gameDirFor } = require('../core/install');
const { launch } = require('../core/launch');
const versions = require('../core/versions');
const mods = require('../core/mods');
const { listCharacters, applySkin } = require('../core/characters');
const sync = require('../core/sync');
const defaults = require('../core/defaults');
const modes = require('../core/modes');

const CONFIG_FILE = path.join(app.getPath('userData'), 'config.json');
const DEFAULT_MEMORY = Math.min(4096, Math.floor(os.totalmem() / 1048576 / 2 / 256) * 256);

const DEFAULTS = {
  username: '',
  character: '',
  syncUrl: 'https://raw.githubusercontent.com/MaxerHD/minevia-sync/main/manifest.json',
  mc: null,
  loader: 'vanilla',
  mode: 'elements',
  dataDir: path.join(app.getPath('appData'), '.minevia'),
  memoryMb: DEFAULT_MEMORY,
  width: 1280,
  height: 720,
  fullscreen: false,
  javaPath: '',
  jvmArgs: '',
  showSnapshots: false,
  showOld: false,
  hideOnLaunch: false,
};

let win = null;
let config = loadConfig();
let abort = null;
let game = null;
let manifest = null;

function loadConfig() {
  try {
    return { ...DEFAULTS, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
  } catch {
    return { ...DEFAULTS };
  }
}

function saveConfig() {
  fs.mkdirSync(path.dirname(CONFIG_FILE), { recursive: true });
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

const send = (channel, payload) => {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
};

function setStatus(status, detail) {
  send('status', { status, detail });
}

const modsDirFor = (target) => path.join(gameDirFor(config.dataDir, target), 'mods');
const currentTarget = () => ({ mc: config.mc, loader: config.loader, mode: config.mode });

async function play(target) {
  if (abort || game) throw new Error('Игра уже запускается');
  if (!/^[A-Za-z0-9_]{3,16}$/.test(config.username)) {
    throw new Error('Ник: от 3 до 16 латинских букв, цифр или _');
  }
  abort = new AbortController();
  setStatus('installing');
  try {
    if (modes.modeOf(target) !== 'elements') {
      const gameDir = gameDirFor(config.dataDir, target);
      const sourceMode = modes.MODES[modes.modeOf(target)].seedMode || 'elements';
      const sourceDir = gameDirFor(config.dataDir, { ...target, mode: sourceMode });
      if (modes.modeOf(target) === 'jojo') modes.seedMods(sourceDir, gameDir);
      if (modes.seed(sourceDir, gameDir)) {
        send('log', { level: 'INFO', text: `Первый запуск режима: настройки, шейдер и паки перенесены из ${sourceMode === 'chill' ? '«Уютного выживания»' : 'основной игры'}` });
      }
    }
    const prepared = await prepare(config.dataDir, target, {
      signal: abort.signal,
      javaPath: config.javaPath || undefined,
      onProgress: throttle((progress) => send('progress', progress)),
    });
    await updateMods(target, abort.signal);
    await modes.ensureExtras(target, modsDirFor(target), {
      signal: abort.signal,
      onProgress: (progress) => send('progress', progress),
    });
    abort = null;
    applySkin(gameDirFor(config.dataDir, target), config.character, manifest, config.dataDir);
    const started = Date.now();
    game = launch(config.dataDir, prepared, config, {
      onLine: (level, text) => send('log', { level, text }),
      onExit(code) {
        game = null;
        if (config.hideOnLaunch) win?.show();
        const crashed = code !== 0 && code !== null;
        setStatus('idle', crashed ? { crashed: true, code, seconds: Math.round((Date.now() - started) / 1000) } : undefined);
      },
    });
    setStatus('running', { id: prepared.id });
    if (config.hideOnLaunch) win?.hide();
  } catch (err) {
    const cancelled = abort?.signal.aborted;
    abort = null;
    setStatus('idle');
    if (!cancelled) throw err;
  }
}

/** Без связи игра всё равно запускается с тем, что уже скачано: обновление не должно мешать поиграть. */
async function updateMods(target, signal) {
  if (!config.syncUrl) return;
  try {
    const url = modes.manifestUrl(config.syncUrl, modes.modeOf(target));
    manifest = await sync.fetchManifest(url, config.dataDir, { signal });
    if (manifest.mc !== target.mc || manifest.loader !== target.loader) return;
    manifest = modes.extendManifest(manifest, target);
    const report = await sync.syncMods(manifest, url, modsDirFor(target), {
      signal,
      onProgress: (progress) => send('progress', progress),
    });
    const packs = await sync.syncPacks(manifest, url, gameDirFor(config.dataDir, target), {
      signal,
      onProgress: (progress) => send('progress', progress),
    });
    report.added.push(...packs.added);
    report.removed.push(...packs.removed);
    await defaults.apply(manifest, gameDirFor(config.dataDir, target), { signal });
    if (defaults.lightenDerivative(gameDirFor(config.dataDir, target))) {
      send('log', { level: 'INFO', text: 'Настройки шейдера облегчены: туман, облака и тени на уровне High' });
    }
    await sync.syncCharacters(manifest, url, config.dataDir, { signal });
    if (report.added.length || report.removed.length) {
      send('log', { level: 'INFO', text: `Обновление: добавлено ${report.added.length}, убрано ${report.removed.length}` });
    }
  } catch (err) {
    if (signal.aborted) throw err;
    send('log', { level: 'WARN', text: `Обновление не вышло, играем с тем, что есть: ${err.message}` });
  }
}

/** Персонажи для вкладки. Новые скины докачиваются при открытии лаунчера, а без сети берутся из прошлого списка. */
async function refreshCharacters() {
  manifest = sync.cachedManifest(config.dataDir);
  if (config.syncUrl) {
    try {
      manifest = await sync.fetchManifest(config.syncUrl, config.dataDir);
      await sync.syncCharacters(manifest, config.syncUrl, config.dataDir);
    } catch (err) {
      send('log', { level: 'WARN', text: `Список обновлений недоступен: ${err.message}` });
    }
  }
  return { characters: listCharacters(manifest, config.dataDir), mc: manifest?.mc, loader: manifest?.loader };
}

function throttle(fn) {
  let last = 0;
  return (value) => {
    const now = Date.now();
    if (now - last >= 80 || value.phase === 'loader') {
      last = now;
      fn(value);
    }
  };
}

function handle(channel, fn) {
  ipcMain.handle(channel, async (_event, ...args) => {
    try {
      return { ok: true, value: await fn(...args) };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  });
}

function registerIpc() {
  handle('config:get', () => ({
    config,
    totalMemoryMb: Math.floor(os.totalmem() / 1048576),
    version: app.getVersion(),
  }));
  handle('characters:list', refreshCharacters);
  handle('shader:derivative', async (target) => {
    const result = await dialog.showOpenDialog(win, { properties: ['openFile'], filters: [{ name: 'Шейдер', extensions: ['zip'] }] });
    if (result.canceled) return null;
    return defaults.installDerivative(result.filePaths[0], gameDirFor(config.dataDir, target || currentTarget()));
  });
  handle('config:set', (patch) => {
    const allowedKeys = Object.keys(DEFAULTS);
    for (const [key, value] of Object.entries(patch)) {
      if (allowedKeys.includes(key)) config[key] = value;
    }
    saveConfig();
    return config;
  });
  handle('versions:list', async () => {
    const manifest = await versions.getManifest(config.dataDir);
    return {
      latest: manifest.latest,
      versions: manifest.versions.map(({ id, type, releaseTime }) => ({ id, type, releaseTime })),
      installed: versions.installedIds(config.dataDir),
    };
  });
  handle('versions:loaders', (mc) => versions.loadersFor(mc));
  handle('game:play', play);
  handle('game:cancel', () => abort?.abort());
  handle('game:stop', () => game?.kill());
  handle('mods:search', (query) => mods.search(query));
  handle('mods:list', (target) => mods.list(modsDirFor(target)));
  handle('mods:install', (target, projectId) =>
    mods.install({ projectId, mc: target.mc, loader: target.loader, modsDir: modsDirFor(target) }),
  );
  handle('mods:toggle', (target, file) => mods.toggle(modsDirFor(target), file));
  handle('mods:remove', (target, file) => shell.trashItem(mods.safeModPath(modsDirFor(target), file)));
  handle('folder:open', async (kind, target) => {
    const dir = kind === 'data' ? config.dataDir : modsDirFor(target);
    fs.mkdirSync(dir, { recursive: true });
    return shell.openPath(dir);
  });
  handle('dialog:folder', async () => {
    const result = await dialog.showOpenDialog(win, { properties: ['openDirectory', 'createDirectory'] });
    return result.canceled ? null : result.filePaths[0];
  });
  handle('dialog:java', async () => {
    const filters = process.platform === 'win32' ? [{ name: 'Java', extensions: ['exe'] }] : [];
    const result = await dialog.showOpenDialog(win, { properties: ['openFile'], filters });
    return result.canceled ? null : result.filePaths[0];
  });
  handle('window:minimize', () => win.minimize());
  handle('window:close', () => win.close());
}

function createWindow() {
  win = new BrowserWindow({
    width: 1120,
    height: 700,
    minWidth: 980,
    minHeight: 620,
    frame: false,
    backgroundColor: '#0b1420',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });
  win.once('ready-to-show', () => win.show());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.webContents.on('will-navigate', (event) => event.preventDefault());
  win.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));
}

app.whenReady().then(() => {
  registerIpc();
  createWindow();
});

app.on('window-all-closed', () => {
  abort?.abort();
  app.quit();
});
