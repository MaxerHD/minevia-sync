const {test}=require('node:test');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const os=require('node:os');
const path=require('node:path');
const shader=require('../src/core/jojo-shader');
const spec=require('../src/core/jojo-shader.json');
const target={mc:'1.21.1',loader:'fabric',mode:'jojo'};
function folder(t){const p=fs.mkdtempSync(path.join(os.tmpdir(),'minevia-shader-'));t.after(()=>fs.rmSync(p,{recursive:true,force:true}));return p;}
test('JoJo enables MakeUp High once and retains the cozy controls, packs, and other Iris settings',async t=>{
 const dir=folder(t);fs.mkdirSync(path.join(dir,'config'));fs.mkdirSync(path.join(dir,'shaderpacks'));
 fs.writeFileSync(path.join(dir,'options.txt'),'key_key.forward:key.keyboard.w\nresourcePacks:["file/cozy.zip"]');
 const options=fs.readFileSync(path.join(dir,'options.txt'));
 fs.writeFileSync(path.join(dir,'shaderpacks','cozy.zip'),'cozy');
 fs.writeFileSync(path.join(dir,'config','iris.properties'),'enableShaders=false\nshaderPack=cozy.zip\ncolorSpace=SRGB');
 let downloads=0;const deps={isValid:async({dest})=>fs.existsSync(dest),download:async({dest})=>{downloads++;fs.mkdirSync(path.dirname(dest),{recursive:true});fs.writeFileSync(dest,'shader');}};
 assert.equal(await shader.apply(target,dir,{deps}),true);
 const iris=fs.readFileSync(path.join(dir,'config','iris.properties'),'utf8');
 assert.match(iris,/enableShaders=true/);assert.ok(iris.includes('shaderPack='+spec.name));assert.match(iris,/colorSpace=SRGB/);
 const preset=fs.readFileSync(path.join(dir,'shaderpacks',spec.name+'.txt'),'utf8');
 assert.match(preset,/SHADOW_QTY_SLIDER=3/);assert.match(preset,/SHADOW_DISTANCE_SLIDER=2/);assert.match(preset,/COLORED_SHADOW=true/);
 assert.deepEqual(fs.readFileSync(path.join(dir,'options.txt')),options);
 assert.equal(fs.readFileSync(path.join(dir,'shaderpacks','cozy.zip'),'utf8'),'cozy');
 fs.writeFileSync(path.join(dir,'config','iris.properties'),'enableShaders=false\nshaderPack=custom.zip\n');
 assert.equal(await shader.apply(target,dir,{deps}),false);
 assert.equal(fs.readFileSync(path.join(dir,'config','iris.properties'),'utf8'),'enableShaders=false\nshaderPack=custom.zip\n');
 assert.equal(downloads,1);
});
test('other modes remain untouched and failed downloads never activate the shader',async t=>{
 const dir=folder(t);let calls=0;const deps={isValid:async()=>{calls++;return false;},download:async()=>{throw Error('offline');}};
 assert.equal(await shader.apply({...target,mode:'chill'},dir,{deps}),false);assert.equal(calls,0);assert.deepEqual(fs.readdirSync(dir),[]);
 await assert.rejects(shader.apply({...target,mc:'1.20.1'},dir,{deps}),/1.21.1/);
 await assert.rejects(shader.apply(target,dir,{deps}),/offline/);
 assert.equal(fs.existsSync(path.join(dir,'.minevia-jojo-shader.json')),false);
 assert.equal(fs.existsSync(path.join(dir,'config','iris.properties')),false);
});
