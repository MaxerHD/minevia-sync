const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const modes = require('../src/core/modes');
const sync = require('../src/core/sync');
const target = { mc: '1.21.1', loader: 'fabric', mode: 'jojo' };
const base = { format: 1, mc: '1.21.1', loader: 'fabric', characters: [], mods: [{ name: 'cozy.jar', url: 'https://cdn.modrinth.com/cozy.jar', sha512: 'a'.repeat(128) }] };
const temp = t => { const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'minevia-jojo-')); t.after(() => fs.rmSync(dir, { recursive: true, force: true })); return dir; };

test('JoJo uses the cozy manifest, its own instance, and preserves existing mode paths', () => {
  const { gameDirFor } = require('../src/core/install');
  const dirs = ['elements', 'chill', 'jojo'].map(mode => gameDirFor('root', { ...target, mode }));
  assert.equal(new Set(dirs).size, 3);
  assert.ok(dirs[0].endsWith('fabric-1.21.1'));
  assert.ok(dirs[1].endsWith('fabric-1.21.1-chill'));
  assert.ok(dirs[2].endsWith('fabric-1.21.1-jojo'));
  assert.equal(modes.manifestUrl('https://example.com/manifest.json', 'jojo'), 'https://example.com/manifest-chill.json');
  assert.equal(modes.MODES.jojo.seedMode, 'chill');
});

test('all cozy mod records survive composition, JoJo is present once, base is unchanged', () => {
  const full = JSON.parse(fs.readFileSync(path.join(__dirname, 'manifest-chill.json'), 'utf8'));
  const before = JSON.stringify(full);
  const jojo = modes.extendManifest(full, target);
  assert.equal(JSON.stringify(full), before);
  assert.deepEqual(jojo.mods.slice(0, -1), full.mods);
  assert.equal(jojo.mods.length, full.mods.length + 1);
  assert.equal(modes.extendManifest(jojo, target).mods.length, jojo.mods.length);
  assert.deepEqual(jojo.packs, full.packs);
  assert.deepEqual(jojo.defaults, full.defaults);
  assert.strictEqual(modes.extendManifest(full, { mode: 'chill' }), full);
  sync.validate(jojo);
  assert.throws(() => modes.extendManifest({ ...full, mc: '1.20.1' }, target));
});

test('first run clones settings and every mod including disabled files, never worlds', t => {
  const dir = temp(t), from = path.join(dir, 'chill'), to = path.join(dir, 'jojo');
  fs.mkdirSync(path.join(from, 'mods'), { recursive: true });
  fs.mkdirSync(path.join(from, 'config'));
  fs.mkdirSync(path.join(from, 'resourcepacks'));
  fs.mkdirSync(path.join(from, 'shaderpacks'));
  fs.mkdirSync(path.join(from, 'saves', 'owner-world'), { recursive: true });
  fs.writeFileSync(path.join(from, 'mods', 'cozy.jar'), 'cozy');
  fs.writeFileSync(path.join(from, 'mods', 'disabled.jar.disabled'), 'disabled');
  fs.writeFileSync(path.join(from, 'mods', '.minevia-sync.json'), '{"managed":["cozy.jar"]}');
  fs.writeFileSync(path.join(from, 'options.txt'), 'resourcePacks:["vanilla"]');
  fs.writeFileSync(path.join(from, 'config', 'cozy.json'), '{"setting":true}');
  fs.writeFileSync(path.join(from, 'config', 'iris.properties'), 'enableShaders=true');
  fs.writeFileSync(path.join(from, 'resourcepacks', 'local-pack.zip'), 'local pack');
  fs.writeFileSync(path.join(from, 'shaderpacks', 'local-shader.zip'), 'local shader');
  fs.writeFileSync(path.join(from, 'shaderpacks', 'local-shader.zip.txt'), 'BLOOM=true');
  assert.equal(modes.seedMods(from, to), true);
  assert.equal(modes.seed(from, to), true);
  assert.deepEqual(fs.readdirSync(path.join(to, 'mods')), fs.readdirSync(path.join(from, 'mods')));
  assert.equal(fs.existsSync(path.join(to, 'saves')), false);
  for (const name of ['config/cozy.json', 'config/iris.properties', 'resourcepacks/local-pack.zip',
      'shaderpacks/local-shader.zip', 'shaderpacks/local-shader.zip.txt', 'options.txt']) {
    assert.deepEqual(fs.readFileSync(path.join(to,name)), fs.readFileSync(path.join(from,name)));
  }
  fs.writeFileSync(path.join(to, 'options.txt'), 'custom');
  fs.writeFileSync(path.join(to, 'mods', 'cozy.jar'), 'custom');
  assert.equal(modes.seedMods(from, to), false);
  assert.equal(modes.seed(from, to), false);
  assert.equal(fs.readFileSync(path.join(to, 'mods', 'cozy.jar'), 'utf8'), 'custom');
  assert.equal(fs.readFileSync(path.join(to, 'options.txt'), 'utf8'), 'custom');
});

test('repeated sync retains JoJo, local extras, and disabled cozy mods', async t => {
  const dir = temp(t);
  fs.writeFileSync(path.join(dir, 'local.jar'), 'local');
  fs.writeFileSync(path.join(dir, 'cozy.jar.disabled'), 'disabled');
  let downloads = 0;
  const deps = { isValid: async ({ dest }) => fs.existsSync(dest), download: async ({ dest }) => { downloads++; fs.writeFileSync(dest, 'download'); } };
  const manifest = modes.extendManifest(base, target);
  await sync.syncMods(manifest, 'https://example.com/manifest-chill.json', dir, { deps });
  await sync.syncMods(manifest, 'https://example.com/manifest-chill.json', dir, { deps });
  assert.equal(downloads, 1);
  assert.ok(fs.existsSync(path.join(dir, modes.extrasFor(target)[0].name)));
  assert.ok(fs.existsSync(path.join(dir, 'local.jar')));
  assert.ok(fs.existsSync(path.join(dir, 'cozy.jar.disabled')));
});

test('offline base still installs JoJo and failed first download blocks launch', async t => {
  const dir = temp(t); let downloads = 0;
  const deps = { isValid: async ({ dest }) => fs.existsSync(dest), download: async ({ dest }) => { downloads++; fs.writeFileSync(dest, 'jojo'); } };
  await modes.ensureExtras(target, dir, { deps });
  await modes.ensureExtras(target, dir, { deps });
  assert.equal(downloads, 1);
  await assert.rejects(modes.ensureExtras(target, path.join(dir, 'missing'), { deps: { isValid: async () => false, download: async () => { throw Error('offline'); } } }), /offline/);
  await assert.rejects(modes.ensureExtras({ ...target, mc: '1.20.1' }, dir, { deps }), /1.21.1/);
});

test('FunTime has its own manifest and instance and never gets the JoJo extras', () => {
  const { gameDirFor } = require('../src/core/install');
  const ft = { mc: '1.21.1', loader: 'fabric', mode: 'funtime' };
  assert.ok(gameDirFor('root', ft).endsWith('fabric-1.21.1-funtime'));
  assert.equal(modes.manifestUrl('https://example.com/manifest.json', 'funtime'), 'https://example.com/manifest-funtime.json');
  assert.deepEqual(modes.extrasFor(ft), []);
  const list = { format: 1, mc: '1.21.1', loader: 'fabric', mods: [] };
  assert.strictEqual(modes.extendManifest(list, ft), list);
});

test('FunTime runs its own game version and seeds settings from the cozy 1.21.1 instance', () => {
  const { gameDirFor } = require('../src/core/install');
  assert.equal(modes.MODES.funtime.mc, '1.21.11');
  assert.equal(modes.MODES.funtime.seedMc, '1.21.1');
  assert.ok(gameDirFor('root', { mc: '1.21.11', loader: 'fabric', mode: 'funtime' }).endsWith('fabric-1.21.11-funtime'));
  assert.ok(gameDirFor('root', { mc: modes.MODES.funtime.seedMc, loader: 'fabric', mode: 'chill' }).endsWith('fabric-1.21.1-chill'));
});

test('Freestyle Battle is a Forge 1.20.1 mode with its own folder and no cross-version seeding', () => {
  const { gameDirFor } = require('../src/core/install');
  const f = modes.MODES.freestyle;
  assert.equal(f.loader, 'forge');
  assert.equal(f.seed, false);
  assert.ok(gameDirFor('root', { mc: f.mc, loader: f.loader, mode: 'freestyle' }).endsWith('forge-1.20.1-freestyle'));
  assert.equal(modes.manifestUrl('https://example.com/manifest.json', 'freestyle'), 'https://example.com/manifest-freestyle.json');
});
