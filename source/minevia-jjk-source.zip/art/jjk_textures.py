# Текстуры божественных псов для мода «Проклятые техники»: белый и чёрный пёс на развёртке модели волка 64x32.
# Запуск: python art/jjk_textures.py
import os

import numpy as np
from PIL import Image

OUT = r"D:\Rudnik\jjk-mod\src\main\resources\assets\minevia_jjk\textures\entity"


def box(u, v, w, h, d):
    """Грани кубика на развёртке Minecraft: (x, y, ширина, высота) для top, bottom, right, front, left, back."""
    return {
        "top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d),
        "right": (u, v + d, d, h), "front": (u + d, v + d, w, h),
        "left": (u + d + w, v + d, d, h), "back": (u + d + w + d, v + d, w, h),
    }


HEAD = box(0, 0, 6, 6, 4)
SNOUT = box(0, 10, 3, 3, 4)
EAR = box(16, 14, 2, 2, 1)
MANE = box(21, 0, 8, 6, 7)
BODY = box(18, 14, 6, 9, 6)
LEG = box(0, 18, 2, 8, 2)
TAIL = box(9, 18, 2, 8, 2)
PARTS = [HEAD, SNOUT, EAR, MANE, BODY, LEG, TAIL]


def fur(seed, base, shade):
    rng = np.random.default_rng(seed)
    img = np.zeros((32, 64, 4))
    small = rng.random((8, 16))
    big = np.kron(small, np.ones((4, 4)))
    fine = rng.random((32, 64))
    k = 0.55 * big + 0.45 * fine
    color = np.array(base)[None, None, :] * (1 - shade) + np.array(base)[None, None, :] * shade * (0.75 + 0.5 * k[..., None])
    for part in PARTS:
        for name, (x, y, w, h) in part.items():
            region = color[y:y + h, x:x + w].copy()
            if name == "bottom":
                region *= 0.78
            elif name in ("right", "left", "front", "back") and h > 2:
                # Низ боков темнее: свет падает сверху.
                region *= (1.0 - 0.18 * np.linspace(0, 1, h))[:, None, None]
            img[y:y + h, x:x + w, :3] = region
            img[y:y + h, x:x + w, 3] = 1
    return img


def paint(img, points, color):
    for x, y in points:
        img[y, x, :3] = color
        img[y, x, 3] = 1


def dog(name, seed, base, shade, mark, eye, nose):
    img = fur(seed, base, shade)
    fx, fy, _, _ = HEAD["front"]
    # Знаки над глазами — две короткие брови и точка на лбу, как у шикигами.
    paint(img, [(fx, fy + 1), (fx + 1, fy + 1), (fx + 4, fy + 1), (fx + 5, fy + 1), (fx + 2, fy), (fx + 3, fy)], mark)
    paint(img, [(fx + 1, fy + 2), (fx + 4, fy + 2)], eye)
    paint(img, [(fx, fy + 2), (fx + 5, fy + 2)], np.array(base) * 0.5)
    sx, sy, _, _ = SNOUT["front"]
    paint(img, [(sx, sy), (sx + 1, sy), (sx + 2, sy)], nose)
    tx, ty, _, _ = SNOUT["top"]
    paint(img, [(tx + 1, ty), (tx + 1, ty + 1)], mark)
    # Полосы на гриве по бокам и на спине.
    for side in ("right", "left"):
        x, y, w, h = MANE[side]
        paint(img, [(x + 1, y + 4), (x + 2, y + 3), (x + 3, y + 2), (x + 4, y + 1),
                    (x + 3, y + 5), (x + 4, y + 4), (x + 5, y + 3)], mark)
    x, y, w, h = MANE["top"]
    paint(img, [(x + 3, y + 1), (x + 4, y + 1), (x + 3, y + 3), (x + 4, y + 3), (x + 3, y + 5), (x + 4, y + 5)], mark)
    for side in ("right", "left"):
        x, y, w, h = BODY[side]
        paint(img, [(x + 1, y + 5), (x + 2, y + 4), (x + 3, y + 3), (x + 4, y + 2)], mark)
    # Кончик хвоста и лапы в цвет знаков.
    for face, (x, y, w, h) in TAIL.items():
        if face in ("right", "left", "front", "back"):
            img[y + h - 2:y + h, x:x + w, :3] = mark
    for face, (x, y, w, h) in LEG.items():
        if face in ("right", "left", "front", "back"):
            img[y + h - 1:y + h, x:x + w, :3] = np.array(mark) * 0.8 + np.array(base) * 0.2
    # Внутренняя сторона ушей.
    x, y, w, h = EAR["front"]
    img[y:y + h, x:x + w, :3] = np.array(base) * 0.6 + np.array(mark) * 0.4
    os.makedirs(OUT, exist_ok=True)
    Image.fromarray((np.clip(img, 0, 1) * 255).astype(np.uint8), "RGBA").save(os.path.join(OUT, name + ".png"))
    print(name)


dog("shadow_dog_white", 5, (0.88, 0.88, 0.9), 0.35, (0.07, 0.06, 0.09), (0.12, 0.1, 0.16), (0.1, 0.08, 0.1))
dog("shadow_dog_black", 9, (0.12, 0.11, 0.14), 0.5, (0.86, 0.86, 0.9), (0.95, 0.85, 0.45), (0.04, 0.03, 0.05))
