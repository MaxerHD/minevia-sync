# 3D-модели приёмов мода «Проклятые техники» (jjk-mod). Формат .mesh тот же, что у моделей стихий (art/spells.py).
# Запуск обычным Python с numpy: python art/jjk_spells.py [имена моделей]
# Ось +Z — вперёд по полёту, +Y — вверх. У всех кадров одна топология, игра плавно смешивает соседние кадры.
import gzip
import math
import os
import struct
import sys

import numpy as np

OUT = r"D:\Rudnik\jjk-mod\src\main\resources\assets\minevia_jjk\mesh"
TAU = math.tau


class Flow:
    """Плавный шум из синусоид: целое число оборотов по времени даёт идеальную петлю."""

    def __init__(self, seed, freq=1.6, octaves=4, gain=0.55, speed=1):
        rng = np.random.default_rng(seed)
        waves = []
        amp = 1.0
        for octave in range(octaves):
            for _ in range(3):
                k = rng.normal(size=3)
                k = k / np.linalg.norm(k) * freq * 1.9 ** octave
                cycles = int(rng.integers(1, 2 + octave)) * speed * (1 if rng.random() < 0.5 else -1)
                waves.append((k, rng.uniform(0, TAU), cycles, amp))
            amp *= gain
        self.waves = waves
        self.norm = sum(w[3] for w in waves) ** 0.5 * 1.4

    def __call__(self, p, t):
        total = np.zeros(len(p))
        for k, phase, cycles, amp in self.waves:
            total += amp * np.sin(p @ k + phase + TAU * cycles * t)
        return np.clip(total / self.norm, -1.0, 1.0)


def ramp(h, stops):
    h = np.asarray(h, dtype=float)
    xs = [s[0] for s in stops]
    return np.stack([np.interp(h, xs, [s[1][c] for s in stops]) for c in range(3)], axis=1)


def rgba(rgb, alpha):
    alpha = np.broadcast_to(np.asarray(alpha, dtype=float), (len(rgb),))
    return np.concatenate([rgb, np.clip(alpha, 0, 1)[:, None]], axis=1)


def grid(nu, nv, wrap=True):
    quads = []
    columns = nu if wrap else nu - 1
    for v in range(nv - 1):
        for u in range(columns):
            a = v * nu + u
            b = v * nu + (u + 1) % nu
            quads.append((a, b, b + nu, a + nu))
    return np.array(quads, dtype=np.int32)


def sphere(nu, nv):
    """Единичная сфера: полюса на оси Y. Возвращает направления, грани, долготу и широту."""
    theta = np.linspace(0, TAU, nu, endpoint=False)
    phi = np.linspace(0, math.pi, nv)
    t, f = np.meshgrid(theta, phi)
    dirs = np.stack([(np.sin(f) * np.cos(t)).ravel(), np.cos(f).ravel(), (np.sin(f) * np.sin(t)).ravel()], axis=1)
    return dirs, grid(nu, nv), t.ravel(), f.ravel()


def disc(nu, nr):
    """Плоский круг в плоскости XZ: кольца от центра к краю. Возвращает точки, грани, угол и радиус 0..1."""
    theta = np.linspace(0, TAU, nu, endpoint=False)
    r = np.linspace(0.0, 1.0, nr) ** 0.85
    t, rr = np.meshgrid(theta, r)
    pos = np.stack([(rr * np.cos(t)).ravel(), np.zeros(t.size), (rr * np.sin(t)).ravel()], axis=1)
    return pos, grid(nu, nr), t.ravel(), rr.ravel()


def normals(pos, quads):
    a, b, c, d = (pos[quads[:, i]] for i in range(4))
    face = np.cross(c - a, d - b)
    out = np.zeros_like(pos)
    for i in range(4):
        np.add.at(out, quads[:, i], face)
    length = np.linalg.norm(out, axis=1, keepdims=True)
    return out / np.maximum(length, 1e-9)


def save(name, frames, quads):
    """frames: список пар (позиции Nx3, цвет Nx4). Записывает сжатый файл для игры."""
    verts = len(frames[0][0])
    assert verts < 65536, name
    extent = max(float(np.abs(f[0]).max()) for f in frames) or 1.0
    body = bytearray(struct.pack(">iiiif", 0x4D4D5348, verts, len(quads), len(frames), extent))
    body += np.asarray(quads, dtype=">u2").tobytes()
    for pos, col in frames:
        assert len(pos) == verts and len(col) == verts, name
        body += np.round(pos / extent * 32767).astype(">i2").tobytes()
        body += np.round(normals(pos, quads) * 127).astype(np.int8).tobytes()
        body += np.round(np.clip(col, 0, 1) * 255).astype(np.uint8).tobytes()
    os.makedirs(OUT, exist_ok=True)
    path = os.path.join(OUT, name + ".mesh")
    with gzip.GzipFile(path, "wb", compresslevel=9, mtime=0) as out:
        out.write(bytes(body))
    print(f"{name}: {verts} вершин, {len(quads)} граней, {len(frames)} кадров, {os.path.getsize(path) // 1024} КБ")


class Model:
    """Набор частей с общей топологией: каждая часть каждый кадр отдаёт свои позиции и цвета."""

    def __init__(self):
        self.quads = []
        self.count = 0

    def add(self, quads, verts):
        self.quads.append(np.asarray(quads) + self.count)
        self.count += verts
        return self

    def all_quads(self):
        return np.concatenate(self.quads)


def rotation(axis, angle):
    axis = np.asarray(axis, dtype=float)
    axis = axis / np.linalg.norm(axis)
    x, y, z = axis
    c, s = math.cos(angle), math.sin(angle)
    k = np.array([[0, -z, y], [z, 0, -x], [-y, x, 0]])
    return np.eye(3) * c + s * k + (1 - c) * np.outer(axis, axis)


def smooth(x):
    x = np.clip(x, 0, 1)
    return x * x * (3 - 2 * x)


def ribbon(path, side, width):
    """Лента вдоль кривой: path Nx3, side Nx3 — направление ширины, width N. Три вершины поперёк: край, середина, край."""
    n = len(path)
    w = np.asarray(width)[:, None]
    pos = np.concatenate([path - side * w, path, path + side * w])
    quads = []
    for i in range(n - 1):
        for row in range(2):
            a = row * n + i
            b = (row + 1) * n + i
            quads.append((a, a + 1, b + 1, b))
    return pos, np.array(quads, dtype=np.int32)


def ribbon_order(n):
    """Какая вершина ленты — середина (1) или край (0)."""
    return np.concatenate([np.zeros(n), np.ones(n), np.zeros(n)])


def tube(path, radius, sides=5):
    """Трубка вдоль кривой: для молний."""
    n = len(path)
    tangent = np.gradient(path, axis=0)
    tangent /= np.maximum(np.linalg.norm(tangent, axis=1, keepdims=True), 1e-9)
    helper = np.where(np.abs(tangent[:, 1:2]) > 0.9, np.array([[1.0, 0, 0]]), np.array([[0, 1.0, 0]]))
    u = np.cross(tangent, helper)
    u /= np.maximum(np.linalg.norm(u, axis=1, keepdims=True), 1e-9)
    v = np.cross(tangent, u)
    ring = []
    for k in range(sides):
        a = TAU * k / sides
        ring.append(path + (u * math.cos(a) + v * math.sin(a)) * np.asarray(radius)[:, None])
    pos = np.stack(ring, axis=1).reshape(-1, 3)
    quads = []
    for i in range(n - 1):
        for k in range(sides):
            a = i * sides + k
            b = i * sides + (k + 1) % sides
            quads.append((a, b, b + sides, a + sides))
    return pos, np.array(quads, dtype=np.int32)


# Палитры.
BLUE = [(0.0, (0.02, 0.08, 0.35)), (0.45, (0.05, 0.35, 0.95)), (0.75, (0.35, 0.75, 1.0)), (1.0, (0.92, 0.98, 1.0))]
RED = [(0.0, (0.30, 0.0, 0.02)), (0.45, (0.85, 0.04, 0.06)), (0.8, (1.0, 0.35, 0.25)), (1.0, (1.0, 0.92, 0.85))]
PURPLE = [(0.0, (0.12, 0.0, 0.25)), (0.45, (0.48, 0.08, 0.85)), (0.8, (0.85, 0.45, 1.0)), (1.0, (1.0, 0.95, 1.0))]
FIRE = [(0.0, (0.25, 0.02, 0.0)), (0.35, (0.75, 0.12, 0.01)), (0.65, (0.98, 0.42, 0.05)), (1.0, (1.0, 0.85, 0.45))]
SHADOW = [(0.0, (0.0, 0.0, 0.01)), (0.6, (0.05, 0.02, 0.10)), (1.0, (0.28, 0.16, 0.45))]
CUT = [(0.0, (0.35, 0.0, 0.03)), (0.6, (0.95, 0.12, 0.12)), (1.0, (1.0, 0.96, 0.94))]


# ---------------------------------------------------------------- Безграничность

def blue_orb(frames=24):
    """Синий: яркое ядро и спирали пространства, которые закручиваются внутрь."""
    flow = Flow(11, freq=2.4)
    core_dirs, core_q, _, _ = sphere(26, 16)
    shell_dirs, shell_q, _, shell_phi = sphere(30, 18)
    arms, n = 5, 28
    model = Model().add(core_q, len(core_dirs)).add(shell_q, len(shell_dirs))
    arm_q = []
    for _ in range(arms):
        _, q = ribbon(np.zeros((n, 3)), np.zeros((n, 3)), np.zeros(n))
        arm_q.append(q)
        model.add(q, n * 3)
    out = []
    for f in range(frames):
        t = f / frames
        n1 = flow(core_dirs * 1.3, t)
        core = core_dirs * (0.42 + 0.05 * n1)[:, None]
        core_col = rgba(ramp(0.72 + 0.28 * n1, BLUE), 0.95)
        n2 = flow(shell_dirs * 0.8 + 3, t)
        shell = shell_dirs * (0.95 + 0.04 * n2)[:, None]
        bands = 0.5 + 0.5 * np.sin(shell_phi * 9 + n2 * 3 + TAU * t * 2)
        shell_col = rgba(ramp(0.45 + 0.35 * bands, BLUE), 0.06 + 0.16 * bands ** 3)
        pos, col = [core, shell], [core_col, shell_col]
        for a in range(arms):
            tilt = rotation((math.cos(a * 1.3), 0.6, math.sin(a * 1.7)), 0.5 + a * 0.4)
            s = np.linspace(0, 1, n)
            angle = a * TAU / arms + TAU * t + s * TAU * 0.9
            r = 1.25 * (1 - s) + 0.4 * s
            path = np.stack([np.cos(angle) * r, 0.06 * np.sin(s * 9 + TAU * t), np.sin(angle) * r], axis=1) @ tilt.T
            side = np.tile(tilt @ np.array([0, 1.0, 0]), (n, 1))
            width = 0.11 * (1 - s) ** 0.7 + 0.015
            p, _ = ribbon(path, side, width)
            mid = ribbon_order(n)
            sv = np.tile(s, 3)
            pos.append(p)
            col.append(rgba(ramp(0.5 + 0.5 * sv * (0.5 + 0.5 * mid), BLUE), (0.15 + 0.75 * sv) * (0.35 + 0.65 * mid)))
        out.append((np.concatenate(pos), np.concatenate(col)))
    save("blue_orb", out, model.all_quads())


def red_orb(frames=12):
    """Красный: плотный горячий шар с рваным ореолом наружу."""
    flow = Flow(23, freq=2.8)
    core_dirs, core_q, _, _ = sphere(24, 14)
    halo_dirs, halo_q, _, _ = sphere(28, 16)
    model = Model().add(core_q, len(core_dirs)).add(halo_q, len(halo_dirs))
    out = []
    for f in range(frames):
        t = f / frames
        n1 = flow(core_dirs, t)
        core = core_dirs * (0.45 + 0.04 * n1)[:, None]
        n2 = flow(halo_dirs * 1.5 + 5, t)
        spikes = np.maximum(n2, 0) ** 1.5
        halo = halo_dirs * (0.7 + 0.45 * spikes)[:, None]
        out.append((np.concatenate([core, halo]),
                    np.concatenate([rgba(ramp(0.75 + 0.25 * n1, RED), 0.97), rgba(ramp(0.4 + 0.5 * spikes, RED), 0.12 + 0.35 * (1 - spikes))])))
    save("red_orb", out, model.all_quads())


def red_burst(frames=12):
    """Взрыв Красного: расходящаяся оболочка и тонкое кольцо по экватору."""
    flow = Flow(31, freq=2.2)
    dirs, sq, _, _ = sphere(30, 18)
    nu = 48
    ring_t = np.linspace(0, TAU, nu, endpoint=False)
    ring_q = grid(nu, 3)
    model = Model().add(sq, len(dirs)).add(ring_q, nu * 3)
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        grow = 1 - (1 - k) ** 2.5
        n = flow(dirs, k * 0.5)
        shell = dirs * (0.25 + 0.85 * grow + 0.06 * n)[:, None]
        shell_col = rgba(ramp(0.9 - 0.5 * k + 0.1 * n, RED), (0.85 * (1 - k) ** 1.4) * (0.6 + 0.4 * n))
        r = 0.3 + 1.25 * grow
        rows = []
        for row, dr in enumerate((-0.12, 0.0, 0.12)):
            rows.append(np.stack([np.cos(ring_t) * (r + dr), np.zeros(nu) + 0.02 * row, np.sin(ring_t) * (r + dr)], axis=1))
        ring = np.concatenate(rows)
        mid = np.concatenate([np.zeros(nu), np.ones(nu), np.zeros(nu)])
        ring_col = rgba(ramp(0.6 + 0.4 * mid, RED), (0.9 * (1 - k)) * mid + 0.1 * (1 - k))
        out.append((np.concatenate([shell, ring]), np.concatenate([shell_col, ring_col])))
    save("red_burst", out, model.all_quads())


def purple_orb(frames=20):
    """Пурпурный: большой шар, по поверхности бегут светлые разряды, вокруг тонкий ореол."""
    flow = Flow(41, freq=3.0, octaves=5)
    dirs, q, theta, phi = sphere(40, 24)
    halo_dirs, hq, _, _ = sphere(30, 18)
    model = Model().add(q, len(dirs)).add(hq, len(halo_dirs))
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs, t)
        veins = np.exp(-(n * 6) ** 2)
        swirl = 0.5 + 0.5 * np.sin(theta * 3 + phi * 4 + TAU * t + n * 2)
        body = dirs * (1.0 + 0.03 * n)[:, None]
        col = rgba(ramp(0.45 + 0.25 * swirl + 0.35 * veins, PURPLE), 0.82 + 0.15 * veins)
        n2 = flow(halo_dirs * 0.7 + 9, t)
        halo = halo_dirs * (1.22 + 0.06 * n2)[:, None]
        hcol = rgba(ramp(0.55 + 0.2 * n2, PURPLE), 0.10 + 0.08 * n2)
        out.append((np.concatenate([body, halo]), np.concatenate([col, hcol])))
    save("purple_orb", out, model.all_quads())


def infinity_shell(frames=40):
    """Бесконечность: почти прозрачная оболочка, по которой текут бледные кольца."""
    flow = Flow(53, freq=1.4)
    dirs, q, theta, phi = sphere(36, 22)
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs, t)
        band = 0.5 + 0.5 * np.sin(phi * 10 - TAU * t * 2 + n * 2.5)
        band = band ** 3
        pos = dirs * (1.0 + 0.015 * n)[:, None]
        col = rgba(ramp(0.7 + 0.3 * band, BLUE), 0.06 + 0.32 * band)
        out.append((pos, col))
    save("infinity_shell", out, q)


def void_dome(frames=40):
    """Бесконечная пустота: тёмный купол, по нему текут светлые полосы, у земли светится кольцо."""
    flow = Flow(61, freq=2.0, octaves=5)
    nu, nv = 56, 20
    theta = np.linspace(0, TAU, nu, endpoint=False)
    phi = np.linspace(0, math.pi * 0.5 + 0.08, nv)
    t_, f_ = np.meshgrid(theta, phi)
    dirs = np.stack([(np.sin(f_) * np.cos(t_)).ravel(), np.cos(f_).ravel(), (np.sin(f_) * np.sin(t_)).ravel()], axis=1)
    q = grid(nu, nv)
    ring_rows = 3
    ring_q = grid(nu, ring_rows)
    model = Model().add(q, len(dirs)).add(ring_q, nu * ring_rows)
    height = f_.ravel()
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs * 1.5, t)
        streak = np.exp(-((n - 0.25) * 9) ** 2)
        stars = np.maximum(flow(dirs * 7 + 2, t * 0.5) - 0.55, 0) * 4
        light = np.clip(streak * 0.8 + stars, 0, 1)
        dome = dirs * 1.0
        col = rgba(ramp(0.06 + 0.9 * light, [(0.0, (0.0, 0.0, 0.02)), (0.3, (0.02, 0.03, 0.12)),
                                             (0.7, (0.45, 0.6, 1.0)), (1.0, (1.0, 1.0, 1.0))]), 0.9 + 0.1 * light)
        rows = []
        for row, r in enumerate((0.96, 1.0, 1.04)):
            rows.append(np.stack([np.cos(theta) * r, np.full(nu, 0.02), np.sin(theta) * r], axis=1))
        pulse = 0.6 + 0.4 * math.sin(TAU * t)
        mid = np.concatenate([np.zeros(nu), np.ones(nu), np.zeros(nu)])
        rcol = rgba(ramp(0.7 + 0.3 * mid, BLUE), (0.15 + 0.8 * mid) * pulse)
        out.append((np.concatenate([dome] + rows), np.concatenate([col, rcol])))
    save("void_dome", out, model.all_quads())


# ---------------------------------------------------------------- Святилище

def slash_wave(frames=6):
    """Рассечение: тонкий серп поперёк полёта, белая кромка и красный след."""
    n = 36
    s = np.linspace(-1, 1, n)
    out = []
    model = Model()
    _, q1 = ribbon(np.zeros((n, 3)), np.zeros((n, 3)), np.zeros(n))
    model.add(q1, n * 3).add(q1, n * 3)
    for f in range(frames):
        t = f / frames
        angle = s * math.radians(70)
        shimmer = 1 + 0.04 * math.sin(TAU * t)
        path = np.stack([np.sin(angle), np.cos(angle) - 0.85, -0.35 * s ** 2], axis=1) * shimmer
        side = np.tile(np.array([0, 0, 1.0]), (n, 1))
        width = 0.11 * (1 - s ** 2) ** 0.8 + 0.004
        core, _ = ribbon(path, side, width * 0.45)
        trail_path = path + np.array([0, 0, -0.12])
        trail, _ = ribbon(trail_path, side, width * 1.8)
        mid = ribbon_order(n)
        fade = np.tile(1 - s ** 2, 3)
        core_col = rgba(ramp(0.75 + 0.25 * mid, CUT), (0.5 + 0.5 * mid) * fade)
        trail_col = rgba(ramp(0.45 + 0.2 * mid, CUT), 0.35 * mid * fade)
        out.append((np.concatenate([core, trail]), np.concatenate([core_col, trail_col])))
    save("slash_wave", out, model.all_quads())


def cleave_cuts(frames=10):
    """Расщепление: три параллельных разреза появляются друг за другом и тают."""
    n = 16
    model = Model()
    _, q = ribbon(np.zeros((n, 3)), np.zeros((n, 3)), np.zeros(n))
    for _ in range(3):
        model.add(q, n * 3)
    out = []
    direction = np.array([math.cos(math.radians(40)), math.sin(math.radians(40)), 0])
    across = np.array([-direction[1], direction[0], 0])
    for f in range(frames):
        pos, col = [], []
        for i in range(3):
            start = i * 1.6
            k = np.clip((f - start) / 3.0, 0, 1)
            gone = np.clip((f - start - 4) / 4.0, 0, 1)
            s = np.linspace(-1, 1, n)
            length = 0.9 * (1 - (1 - k) ** 2)
            path = np.outer(s * length, direction) + across * (i - 1) * 0.28 + np.array([0, 0, 0.05 * (i - 1)])
            width = (0.05 * (1 - s ** 2) + 0.003) * (1 - gone)
            side = np.tile(across, (n, 1))
            p, _ = ribbon(path, side, width)
            mid = ribbon_order(n)
            pos.append(p)
            col.append(rgba(ramp(0.6 + 0.4 * mid, CUT), (0.25 + 0.75 * mid) * (1 - gone) * (k > 0)))
        out.append((np.concatenate(pos), np.concatenate(col)))
    save("cleave_cuts", out, model.all_quads())


def flame_arrow(frames=16):
    """Огненная стрела: острый наконечник впереди, языки пламени сдуваются назад."""
    flow = Flow(71, freq=2.6)
    dirs, q, theta, phi = sphere(26, 22)
    core_dirs, cq, _, _ = sphere(18, 12)
    model = Model().add(q, len(dirs)).add(cq, len(core_dirs))
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs * 1.5 + np.array([0, 0, t * 0]), t)
        z = dirs[:, 2]
        back = np.clip(-z, 0, 1)
        front = np.clip(z, 0, 1)
        stretch = np.where(z < 0, 0.6 + 1.6 * back * (0.75 + 0.25 * n), 0.6 + 0.5 * front)
        pinch = 1 - 0.75 * front ** 2
        pos = np.stack([dirs[:, 0] * 0.32 * pinch * (1 + 0.2 * n * back), dirs[:, 1] * 0.32 * pinch * (1 + 0.2 * n * back), z * stretch], axis=1)
        heat = np.clip(0.95 - back * 0.6 + 0.15 * n, 0, 1)
        col = rgba(ramp(heat, FIRE), 0.9 * (1 - back ** 3) + 0.05)
        cn = flow(core_dirs * 2 + 4, t)
        core = np.stack([core_dirs[:, 0] * 0.14, core_dirs[:, 1] * 0.14, core_dirs[:, 2] * 0.55 + 0.15], axis=1)
        ccol = rgba(ramp(0.9 + 0.1 * cn, FIRE), 0.95)
        out.append((np.concatenate([pos, core]), np.concatenate([col, ccol])))
    save("flame_arrow", out, model.all_quads())


def flame_burst(frames=14):
    """Взрыв пламени: клуб огня растёт, темнеет и тает, по земле расходится огненное кольцо."""
    flow = Flow(83, freq=2.0)
    dirs, q, _, _ = sphere(30, 18)
    pos0, dq, dt, dr = disc(48, 6)
    model = Model().add(q, len(dirs)).add(dq, len(pos0))
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        grow = 1 - (1 - k) ** 2
        n = flow(dirs, k * 0.6)
        lumps = 0.75 + 0.35 * n
        ball = dirs * ((0.3 + 0.75 * grow) * lumps)[:, None] + np.array([0, 0.35 * grow, 0])
        heat = np.clip(1.0 - 0.75 * k + 0.2 * n, 0, 1)
        col = rgba(ramp(heat, FIRE), (0.95 * (1 - k ** 1.6)) * (0.55 + 0.45 * lumps))
        rr = 0.3 + 1.3 * grow
        ring = pos0 * rr + np.array([0, 0.03, 0])
        edge = np.exp(-((dr - 0.92) * 9) ** 2)
        rcol = rgba(ramp(0.5 + 0.5 * edge, FIRE), edge * 0.9 * (1 - k))
        out.append((np.concatenate([ball, ring]), np.concatenate([col, rcol])))
    save("flame_burst", out, model.all_quads())


def shrine_ring(frames=24):
    """Гробница зла: тёмно-красный круг по земле, по нему вспыхивают тонкие разрезы, край светится."""
    rng = np.random.default_rng(97)
    flow = Flow(97, freq=2.0, octaves=3)
    pos0, q, theta, r = disc(72, 10)
    count, n = 22, 8
    model = Model().add(q, len(pos0))
    _, cq = ribbon(np.zeros((n, 3)), np.zeros((n, 3)), np.zeros(n))
    cuts = []
    for _ in range(count):
        model.add(cq, n * 3)
        at = rng.uniform(0.12, 0.88)
        angle = rng.uniform(0, TAU)
        centre = np.array([math.cos(angle) * at, 0.0, math.sin(angle) * at])
        heading = rng.uniform(0, TAU)
        cuts.append((centre, np.array([math.cos(heading), 0.0, math.sin(heading)]), rng.uniform(0.12, 0.3), rng.uniform(0, 1)))
    dark = [(0.0, (0.05, 0.0, 0.01)), (0.5, (0.22, 0.01, 0.03)), (1.0, (0.95, 0.15, 0.12))]
    out = []
    for f in range(frames):
        t = f / frames
        noise = flow(pos0 * 1.5, t)
        edge = np.exp(-((r - 0.97) * 22) ** 2)
        col = rgba(ramp(np.clip(0.3 + 0.1 * noise + 0.7 * edge, 0, 1), dark),
                   (0.38 + 0.08 * noise + 0.45 * edge) * smooth((1.02 - r) * 12 + 0.6))
        pos, cols = [pos0.copy()], [col]
        for centre, direction, length, offset in cuts:
            # Каждый разрез вспыхивает в свою треть круга анимации и гаснет.
            phase = (t - offset) % 1.0
            on = smooth(phase * 12) * (1 - smooth((phase - 0.12) * 8))
            s = np.linspace(-1, 1, n)
            path = centre + np.outer(s * length * (0.4 + 0.6 * smooth(phase * 8)), direction) + np.array([0, 0.01, 0])
            side = np.tile(np.array([-direction[2], 0.0, direction[0]]), (n, 1))
            p, _ = ribbon(path, side, (0.012 * (1 - s ** 2) + 0.001) * (0.3 + 0.7 * on))
            mid = ribbon_order(n)
            pos.append(p)
            cols.append(rgba(ramp(0.6 + 0.4 * mid, CUT), on * (0.3 + 0.7 * mid)))
        out.append((np.concatenate(pos), np.concatenate(cols)))
    save("shrine_ring", out, model.all_quads())


# ---------------------------------------------------------------- Десять теней

def nue(frames=12):
    """Нуэ: тёмная птица-шикигами. Тело, голова с клювом, широкие крылья машут, по краям крыльев бледный ток."""
    body_dirs, bq, _, _ = sphere(16, 10)
    head_dirs, hq, _, _ = sphere(12, 8)
    span, chord = 14, 5
    wq = grid(span, chord, wrap=False)
    tail_n = 7
    tq = grid(tail_n, 3, wrap=False)
    model = Model().add(bq, len(body_dirs)).add(hq, len(head_dirs)).add(wq, span * chord).add(wq, span * chord).add(tq, tail_n * 3)
    out = []
    for f in range(frames):
        t = f / frames
        flap = math.sin(TAU * t)
        body = body_dirs * np.array([0.22, 0.2, 0.55])
        bcol = rgba(ramp(0.25 + 0.2 * (body_dirs[:, 1] + 1) * 0.5, SHADOW), 1.0)
        head = head_dirs * 0.17 + np.array([0, 0.08, 0.58])
        beak = np.clip(head_dirs[:, 2], 0, 1) ** 3
        head = head + np.stack([np.zeros(len(head)), -0.03 * beak, 0.22 * beak], axis=1)
        eyes = (np.abs(np.abs(head_dirs[:, 0]) - 0.55) < 0.2) & (np.abs(head_dirs[:, 1] - 0.3) < 0.2) & (head_dirs[:, 2] > 0.4)
        hcol = rgba(ramp(np.where(eyes, 1.0, 0.3), [(0.0, (0.0, 0.0, 0.01)), (0.5, (0.06, 0.03, 0.12)), (1.0, (0.75, 0.9, 1.0))]), 1.0)
        pos, col = [body, head], [bcol, hcol]
        for sign in (-1, 1):
            u = np.linspace(0, 1, span)
            v = np.linspace(0, 1, chord)
            uu, vv = np.meshgrid(u, v)
            uu, vv = uu.ravel(), vv.ravel()
            lift = flap * 0.75 * uu ** 1.2 + 0.12 * math.sin(TAU * t - 1.0) * uu ** 3
            width = 0.55 * (1 - 0.7 * uu ** 1.5)
            x = sign * (0.15 + 1.45 * uu)
            z = 0.25 - vv * width - 0.25 * uu ** 2
            y = lift + 0.05 * np.sin(vv * math.pi)
            w = np.stack([x, y, z], axis=1)
            edge = np.maximum(vv, uu ** 3)
            spark = np.clip((edge - 0.82) * 6, 0, 1)
            wcol = rgba(ramp(0.2 + 0.25 * (1 - vv) + 0.55 * spark, [(0.0, (0.0, 0.0, 0.01)), (0.4, (0.08, 0.04, 0.16)), (0.7, (0.3, 0.25, 0.55)), (1.0, (0.8, 0.92, 1.0))]), 1.0)
            pos.append(w)
            col.append(wcol)
        tu = np.linspace(-1, 1, tail_n)
        rows = []
        for row in range(3):
            length = 0.3 + row * 0.22
            rows.append(np.stack([tu * (0.08 + row * 0.12), np.full(tail_n, 0.02 * math.sin(TAU * t)), np.full(tail_n, -0.45 - length)], axis=1))
        tail = np.concatenate(rows)
        tcol = rgba(ramp(np.repeat([0.25, 0.35, 0.6], tail_n), SHADOW), 1.0)
        pos.append(tail)
        col.append(tcol)
        out.append((np.concatenate(pos), np.concatenate(col)))
    save("nue", out, model.all_quads())


def nue_strike(frames=10):
    """Удар Нуэ: столб тока сверху в землю и кольцо по земле."""
    rng = np.random.default_rng(7)
    n = 22
    height = 7.0
    sides = 5
    _, tq = tube(np.stack([np.zeros(n), np.linspace(height, 0, n), np.zeros(n)], axis=1), np.full(n, 0.1), sides)
    pos0, dq, _, dr = disc(40, 5)
    branches = 3
    bn = 8
    _, bq = tube(np.zeros((bn, 3)) + np.linspace(0, 1, bn)[:, None], np.full(bn, 0.05), 4)
    model = Model().add(tq, n * sides).add(dq, len(pos0))
    for _ in range(branches):
        model.add(bq, bn * 4)
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        on = 1 - k ** 1.5
        y = np.linspace(height, 0, n)
        jitter = rng.normal(size=(n, 2)) * 0.28 * np.sin(np.linspace(0, math.pi, n))[:, None]
        path = np.stack([jitter[:, 0], y, jitter[:, 1]], axis=1)
        bolt, _ = tube(path, np.full(n, 0.09 * on + 0.01), sides)
        bcol = rgba(ramp(np.full(len(bolt), 0.95), BLUE), np.full(len(bolt), on))
        grow = 1 - (1 - k) ** 2
        ring = pos0 * (0.3 + 1.4 * grow) + np.array([0, 0.03, 0])
        edge = np.exp(-((dr - 0.95) * 8) ** 2)
        rcol = rgba(ramp(0.6 + 0.4 * edge, BLUE), edge * (1 - k))
        pos, col = [bolt, ring], [bcol, rcol]
        for b in range(branches):
            start = path[rng.integers(5, n - 4)]
            direction = rng.normal(size=3)
            direction[1] = -abs(direction[1])
            direction /= np.linalg.norm(direction)
            s = np.linspace(0, 1, bn)
            bpath = start + np.outer(s, direction) * 1.4 + rng.normal(size=(bn, 3)) * 0.12 * s[:, None]
            branch, _ = tube(bpath, np.full(bn, 0.04 * on + 0.005), 4)
            pos.append(branch)
            col.append(rgba(ramp(np.full(len(branch), 0.85), BLUE), np.full(len(branch), on * 0.8)))
        out.append((np.concatenate(pos), np.concatenate(col)))
    save("nue_strike", out, model.all_quads())


def shadow_pool(frames=16):
    """Лужа тени: чёрный круг с фиолетовым отливом раскрывается, по нему бегут кольца, потом смыкается."""
    flow = Flow(103, freq=3.0)
    pos0, q, theta, r = disc(40, 9)
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        size = smooth(k * 4) * (1 - smooth((k - 0.72) * 3.6))
        size = max(size, 0.02)
        p3 = pos0.copy()
        n = flow(p3 * 2, k)
        ripple = 0.5 + 0.5 * np.sin(r * 18 - k * 20 + n * 2)
        p3 = p3 * size
        p3[:, 1] = 0.02 * ripple * size
        col = rgba(ramp(0.2 + 0.6 * ripple * r, SHADOW), (0.92 - 0.9 * r ** 3) * min(1.0, size * 1.5))
        out.append((p3, col))
    save("shadow_pool", out, q)


def shadow_garden(frames=30):
    """Сад теней: большой тёмный круг, по нему медленно ходят кольца и тёмные пятна."""
    flow = Flow(109, freq=4.0, octaves=4)
    pos0, q, theta, r = disc(72, 16)
    out = []
    for f in range(frames):
        t = f / frames
        p3 = pos0.copy()
        n = flow(p3, t)
        ripple = (0.5 + 0.5 * np.sin(r * 30 - TAU * t * 2 + n * 3)) ** 3
        p3[:, 1] = 0.03 * ripple
        col = rgba(ramp(0.15 + 0.5 * ripple + 0.15 * n, SHADOW), (0.8 - 0.2 * n) * smooth((1.02 - r) * 8 + 0.3))
        out.append((p3, col))
    save("shadow_garden", out, q)


# ---------------------------------------------------------------- чёрная вспышка

def black_flash(frames=10):
    """Чёрная вспышка: рваные чёрные молнии с красной кромкой разлетаются из точки удара."""
    rng = np.random.default_rng(13)
    bolts, n = 9, 12
    model = Model()
    _, q = ribbon(np.zeros((n, 3)), np.zeros((n, 3)), np.zeros(n))
    for _ in range(bolts):
        model.add(q, n * 3)
    core_dirs, cq, _, _ = sphere(14, 9)
    model.add(cq, len(core_dirs))
    plans = []
    for b in range(bolts):
        d = rng.normal(size=3)
        d[2] = abs(d[2]) * 0.4 - 0.2
        d /= np.linalg.norm(d)
        up = np.cross(d, rng.normal(size=3))
        up /= np.linalg.norm(up)
        plans.append((d, up, rng.normal(size=(n, 3)) * 0.13, 0.7 + 0.6 * rng.random()))
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        reach = 1 - (1 - min(1.0, k * 2.5)) ** 3
        fade = 1 - smooth((k - 0.35) * 1.6)
        pos, col = [], []
        for d, up, jag, length in plans:
            s = np.linspace(0, 1, n)
            path = np.outer(s * length * reach, d) + jag * s[:, None] * reach
            side = np.tile(up, (n, 1))
            width = (0.09 * (1 - s) + 0.01) * fade
            p, _ = ribbon(path, side, width)
            mid = ribbon_order(n)
            pos.append(p)
            col.append(rgba(ramp(0.0 + 0.85 * (1 - mid), [(0.0, (0.0, 0.0, 0.0)), (0.5, (0.35, 0.0, 0.02)), (1.0, (1.0, 0.1, 0.12))]), fade * 0.98))
        core = core_dirs * (0.05 + 0.09 * reach) * fade
        pos.append(core)
        col.append(rgba(ramp(np.full(len(core), 0.05), [(0.0, (0.0, 0.0, 0.0)), (1.0, (0.4, 0.0, 0.02))]), 0.95 * fade))
        out.append((np.concatenate(pos), np.concatenate(col)))
    save("black_flash", out, model.all_quads())


# Аниме-стиль: заменяет часть моделей выше и добавляет искры ударов и язык жабы.
exec(compile(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "jjk_spells_anime.py"), encoding="utf-8").read(), "jjk_spells_anime.py", "exec"))

MODELS = [blue_orb, red_orb, red_burst, purple_orb, infinity_shell, void_dome,
          slash_wave, cleave_cuts, flame_arrow, flame_burst, shrine_ring,
          nue, nue_strike, shadow_pool, shadow_garden, black_flash, impact, tongue]
MODELS = [globals()[m.__name__] for m in MODELS]

wanted = sys.argv[1:]
for model in MODELS:
    if not wanted or model.__name__ in wanted:
        model()
print("Модели готовы")
