# Аниме-стиль для моделей «Проклятых техник»: плотные цвета в 2-4 ступени (как заливка в аниме), резкие формы
# и тёмный контур. Контур — отдельная модель <имя>_line: та же форма, раздутая по нормалям и вывернутая наизнанку.
# Игра рисует её с отсечением задних граней, поэтому видна только кайма вокруг силуэта.
# Файл выполняется из jjk_spells.py после основных моделей и заменяет одноимённые.


def bands(h, steps=3):
    """Ступенчатая заливка: плавное значение 0..1 превращается в несколько чётких тонов."""
    h = np.clip(np.asarray(h, dtype=float), 0, 0.999)
    return (np.floor(h * steps) + 0.5) / steps


def hull(pos, quads, push):
    """Контур: точки отодвинуты наружу по нормалям, грани вывернуты (видна только изнанка)."""
    return pos + normals(pos, quads) * push, quads[:, ::-1].copy()


def save_lined(name, frames, quads, push, line=(0.02, 0.02, 0.04), line_alpha=1.0, mask=None):
    """Сохраняет модель и её контур. mask — какие грани обводить (по умолчанию все)."""
    save(name, frames, quads)
    q = quads if mask is None else quads[mask]
    used = np.unique(q)
    remap = -np.ones(len(frames[0][0]), dtype=np.int64)
    remap[used] = np.arange(len(used))
    lq = remap[q]
    out = []
    for pos, col in frames:
        p, rq = hull(pos[used], lq, push)
        c = np.tile(np.array([*line, line_alpha]), (len(used), 1))
        c[:, 3] *= np.where(col[used, 3] > 0.35, 1.0, 0.0)
        out.append((p, c))
    save(name + "_line", out, rq)


def blue_orb(frames=24):
    """Синий: плотный голубой шар с белым ядром и тремя кольцами, которые крутятся вокруг."""
    flow = Flow(11, freq=2.0)
    dirs, q, _, phi = sphere(30, 18)
    ring_n, ring_m = 40, 6
    rq = grid(ring_n, ring_m)
    model = Model().add(q, len(dirs))
    for _ in range(3):
        model.add(rq, ring_n * ring_m)
    quads = model.all_quads()
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs, t)
        light = 0.55 + 0.45 * dirs[:, 1] * 0.6 + 0.25 * n
        core = dirs * (0.55 + 0.03 * n)[:, None]
        col = rgba(ramp(bands(light, 3), [(0.0, (0.05, 0.25, 0.85)), (0.5, (0.25, 0.65, 1.0)), (1.0, (0.92, 0.98, 1.0))]), 1.0)
        pos, cols = [core], [col]
        for i in range(3):
            tilt = rotation((math.cos(i * 2.1), 0.4, math.sin(i * 2.1)), 0.9 + i * 0.5)
            a = np.linspace(0, TAU, ring_n, endpoint=False) + TAU * t * (1 if i % 2 == 0 else -1) * (i + 1)
            b = np.linspace(0, TAU, ring_m, endpoint=False)
            aa, bb = np.meshgrid(a, b)
            r = 0.85 + 0.08 * i
            tube_r = 0.045
            x = (r + tube_r * np.cos(bb)) * np.cos(aa)
            z = (r + tube_r * np.cos(bb)) * np.sin(aa)
            y = tube_r * np.sin(bb)
            ring = np.stack([x.ravel(), y.ravel(), z.ravel()], axis=1) @ tilt.T
            pos.append(ring)
            glow = 0.5 + 0.5 * np.cos(aa.ravel() * 2)
            cols.append(rgba(ramp(bands(0.5 + 0.5 * glow, 2), BLUE), 1.0))
        out.append((np.concatenate(pos), np.concatenate(cols)))
    save_lined("blue_orb", out, quads, 0.05, line=(0.01, 0.05, 0.2))


def red_orb(frames=12):
    """Красный: плотный алый шар с белой серединой и острыми лучами-шипами по кругу."""
    flow = Flow(23, freq=2.4)
    dirs, q, theta, phi = sphere(26, 16)
    spikes = 10
    sq = []
    model = Model().add(q, len(dirs))
    for _ in range(spikes):
        model.add(np.array([[0, 1, 2, 3]]), 4)
    quads = model.all_quads()
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs, t)
        core = dirs * (0.5 + 0.03 * n)[:, None]
        light = 0.6 + 0.35 * dirs[:, 1] + 0.2 * n
        col = rgba(ramp(bands(light, 3), [(0.0, (0.55, 0.0, 0.05)), (0.5, (0.95, 0.12, 0.15)), (1.0, (1.0, 0.85, 0.8))]), 1.0)
        pos, cols = [core], [col]
        for i in range(spikes):
            a = TAU * i / spikes + TAU * t / spikes
            length = 0.95 + 0.25 * math.sin(TAU * t * 2 + i * 1.7)
            d = np.array([math.cos(a), math.sin(a), 0.0])
            side = np.array([-d[1], d[0], 0.0]) * 0.09
            base = d * 0.45
            tip = d * length
            pos.append(np.array([base - side, base + side, tip + side * 0.05, tip - side * 0.05]))
            cols.append(rgba(ramp(np.array([0.55, 0.55, 0.9, 0.9]), RED), 1.0))
        out.append((np.concatenate(pos), np.concatenate(cols)))
    save_lined("red_orb", out, quads, 0.04, line=(0.18, 0.0, 0.02), mask=np.arange(len(quads)) < len(q))


def purple_orb(frames=20):
    """Пурпурный: огромный фиолетовый шар, по нему крутятся светлые полосы, ядро почти белое."""
    flow = Flow(41, freq=2.6, octaves=4)
    dirs, q, theta, phi = sphere(40, 24)
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs, t)
        swirl = 0.5 + 0.5 * np.sin(theta * 2 + phi * 5 - TAU * t + n * 1.5)
        light = 0.35 + 0.35 * swirl + 0.25 * dirs[:, 1]
        body = dirs * (1.0 + 0.025 * n)[:, None]
        col = rgba(ramp(bands(light, 4), [(0.0, (0.22, 0.02, 0.45)), (0.4, (0.55, 0.1, 0.9)), (0.75, (0.85, 0.5, 1.0)), (1.0, (1.0, 0.95, 1.0))]), 1.0)
        out.append((body, col))
    save_lined("purple_orb", out, q, 0.05, line=(0.08, 0.0, 0.15))


def slash_wave(frames=6):
    """Рассечение: острый белый серп с красной каймой."""
    n = 36
    s = np.linspace(-1, 1, n)
    _, q = ribbon(np.zeros((n, 3)), np.zeros((n, 3)), np.zeros(n))
    out = []
    for f in range(frames):
        t = f / frames
        angle = s * math.radians(75)
        path = np.stack([np.sin(angle), np.cos(angle) - 0.85, -0.3 * s ** 2], axis=1) * (1 + 0.03 * math.sin(TAU * t))
        side = np.tile(np.array([0, 0.25, 1.0]) / np.linalg.norm([0, 0.25, 1.0]), (n, 1))
        width = 0.16 * (1 - s ** 2) ** 1.2 + 0.002
        p, _ = ribbon(path, side, width)
        mid = ribbon_order(n)
        col = rgba(np.where(mid[:, None] > 0.5, np.array([[1.0, 0.97, 0.95]]), np.array([[0.9, 0.08, 0.1]])), 1.0)
        out.append((p, col))
    save("slash_wave", out, q)


def cleave_cuts(frames=10):
    """Расщепление: три параллельных белых разреза с тёмно-красной каймой, появляются по очереди."""
    n = 14
    model = Model()
    _, q = ribbon(np.zeros((n, 3)), np.zeros((n, 3)), np.zeros(n))
    for _ in range(3):
        model.add(q, n * 3)
    direction = np.array([math.cos(math.radians(40)), math.sin(math.radians(40)), 0])
    across = np.array([-direction[1], direction[0], 0])
    out = []
    for f in range(frames):
        pos, col = [], []
        for i in range(3):
            start = i * 1.4
            k = np.clip((f - start) / 2.0, 0, 1)
            gone = np.clip((f - start - 4) / 3.0, 0, 1)
            s = np.linspace(-1, 1, n)
            path = np.outer(s * 0.95 * (1 - (1 - k) ** 2), direction) + across * (i - 1) * 0.3
            width = (0.075 * (1 - s ** 2) ** 1.2 + 0.002) * (1 - gone)
            p, _ = ribbon(path, np.tile(across, (n, 1)), width)
            mid = ribbon_order(n)
            pos.append(p)
            c = np.where(mid[:, None] > 0.5, np.array([[1.0, 0.98, 0.96]]), np.array([[0.55, 0.0, 0.05]]))
            col.append(rgba(c, np.full(len(p), 1.0 if k > 0 and gone < 1 else 0.0)))
        out.append((np.concatenate(pos), np.concatenate(col)))
    save("cleave_cuts", out, model.all_quads())


def flame_arrow(frames=16):
    """Огненная стрела: вытянутое пламя с острым наконечником, заливка в три тона, тёмный контур."""
    flow = Flow(71, freq=2.4)
    dirs, q, theta, phi = sphere(24, 20)
    out = []
    for f in range(frames):
        t = f / frames
        n = flow(dirs * 1.4, t)
        z = dirs[:, 2]
        back = np.clip(-z, 0, 1)
        front = np.clip(z, 0, 1)
        stretch = np.where(z < 0, 0.5 + 1.9 * back * (0.8 + 0.25 * n), 0.55 + 0.6 * front)
        pinch = 1 - 0.85 * front ** 1.5
        wobble = 1 + 0.25 * n * back
        pos = np.stack([dirs[:, 0] * 0.3 * pinch * wobble, dirs[:, 1] * 0.3 * pinch * wobble, z * stretch], axis=1)
        heat = np.clip(1.0 - back * 0.75 + 0.15 * n, 0, 1)
        col = rgba(ramp(bands(heat, 3), [(0.0, (0.75, 0.12, 0.02)), (0.5, (1.0, 0.5, 0.05)), (1.0, (1.0, 0.95, 0.7))]), 1.0)
        out.append((pos, col))
    save_lined("flame_arrow", out, q, 0.04, line=(0.25, 0.03, 0.0))


def flame_burst(frames=14):
    """Взрыв пламени: клуб огня из чётких слоёв цвета, растёт и опадает, по краю тёмный контур."""
    flow = Flow(83, freq=2.0)
    dirs, q, _, _ = sphere(30, 18)
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        grow = 1 - (1 - k) ** 2.2
        shrink = 1 - max(0.0, (k - 0.6) / 0.4) ** 2
        n = flow(dirs, k * 0.6)
        lumps = 0.78 + 0.32 * n
        ball = dirs * ((0.3 + 0.8 * grow) * shrink * lumps)[:, None] + np.array([0, 0.3 * grow, 0])
        heat = np.clip(0.95 - 0.55 * k + 0.25 * n + 0.15 * dirs[:, 1], 0, 1)
        col = rgba(ramp(bands(heat, 3), [(0.0, (0.6, 0.08, 0.02)), (0.5, (1.0, 0.45, 0.05)), (1.0, (1.0, 0.93, 0.6))]), 1.0)
        out.append((ball, col))
    save_lined("flame_burst", out, q, 0.04, line=(0.2, 0.02, 0.0))


def red_burst(frames=12):
    """Взрыв Красного: алая вспышка-звезда и расходящееся плотное кольцо."""
    rays = 12
    nu = 48
    ring_t = np.linspace(0, TAU, nu, endpoint=False)
    ring_q = grid(nu, 2)
    model = Model().add(ring_q, nu * 2)
    for _ in range(rays):
        model.add(np.array([[0, 1, 2, 3]]), 4)
    rng = np.random.default_rng(3)
    lengths = 0.8 + 0.6 * rng.random(rays)
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        grow = 1 - (1 - k) ** 3
        r = 0.3 + 1.3 * grow
        width = 0.18 * (1 - k)
        ring = np.concatenate([np.stack([np.cos(ring_t) * rr, np.zeros(nu), np.sin(ring_t) * rr], axis=1) for rr in (r - width, r)])
        alpha = 1.0 if k < 0.85 else 0.0
        pos, col = [ring], [rgba(ramp(np.full(nu * 2, 0.75), RED), alpha)]
        for i in range(rays):
            a = TAU * i / rays
            d = rotation((0, 1, 0), a) @ np.array([1.0, 0.0, 0.0])
            up = np.array([0, 1.0, 0])
            tilt = rotation(np.cross(d, up), (i % 3 - 1) * 0.5) @ d
            side = np.cross(tilt, up)
            side = side / max(np.linalg.norm(side), 1e-6) * 0.08 * (1 - k)
            tip = tilt * lengths[i] * grow * (1 - 0.6 * k)
            pos.append(np.array([-side, side, tip, tip]))
            col.append(rgba(ramp(np.array([0.95, 0.95, 0.6, 0.6]), RED), alpha))
        out.append((np.concatenate(pos), np.concatenate(col)))
    save("red_burst", out, model.all_quads())


def impact(frames=8):
    """Искра удара как в аниме: острая звезда из лучей, вспыхивает и исчезает. Четыре вида по variant."""
    looks = [
        ("impact_0", 8, 0.7, (1.0, 1.0, 1.0), (0.1, 0.1, 0.12)),
        ("impact_1", 12, 1.0, (1.0, 0.95, 0.75), (0.2, 0.08, 0.0)),
        ("impact_2", 10, 0.9, (1.0, 0.85, 0.3), (0.3, 0.15, 0.0)),
        ("impact_3", 10, 0.8, (0.7, 0.9, 1.0), (0.02, 0.1, 0.3)),
    ]
    for name, rays, size, color, edge in looks:
        rng = np.random.default_rng(len(name) + rays)
        lengths = 0.6 + 0.6 * rng.random(rays)
        model = Model()
        for _ in range(rays):
            model.add(np.array([[0, 1, 2, 3]]), 4)
        ring_n = 32
        model.add(grid(ring_n, 2), ring_n * 2)
        ring_t = np.linspace(0, TAU, ring_n, endpoint=False)
        out = []
        for f in range(frames):
            k = f / (frames - 1)
            pop = min(1.0, k * 4) * (1 - k ** 2)
            pos, col = [], []
            for i in range(rays):
                a = TAU * i / rays + 0.2 * rng.standard_normal() * 0
                d = np.array([math.cos(a), math.sin(a), 0.0])
                side = np.array([-d[1], d[0], 0.0]) * 0.07 * size
                inner = d * 0.15 * size
                tip = d * lengths[i] * size * (0.4 + 0.6 * pop)
                pos.append(np.array([inner - side, inner + side, tip, tip]) * (1 if pop > 0.02 else 0.01))
                tip_col = tuple(0.75 * a + 0.25 * b for a, b in zip(color, edge))
                col.append(rgba(np.array([color, color, tip_col, tip_col]), 1.0 if pop > 0.05 else 0.0))
            r = (0.25 + 0.75 * k) * size
            ring = np.concatenate([np.stack([np.cos(ring_t) * rr, np.sin(ring_t) * rr, np.zeros(ring_n)], axis=1) for rr in (r * 0.9, r)])
            pos.append(ring)
            col.append(rgba(np.tile(color, (ring_n * 2, 1)), 1.0 if 0.1 < k < 0.8 else 0.0))
            out.append((np.concatenate(pos), np.concatenate(col)))
        save(name, out, model.all_quads())


def tongue(frames=8):
    """Язык жабы: розово-красная трубка от рта вперёд на один блок (игра растягивает её до цели)."""
    n = 16
    path0 = np.stack([np.zeros(n), np.zeros(n), np.linspace(0, 1, n)], axis=1)
    _, q = tube(path0, np.full(n, 0.07), 6)
    out = []
    for f in range(frames):
        k = f / (frames - 1)
        reach = min(1.0, k * 3) * (1 - max(0.0, (k - 0.5) * 2))
        s = np.linspace(0, 1, n)
        path = np.stack([0.03 * np.sin(s * 9 + k * 6), 0.05 * np.sin(s * math.pi), s * max(reach, 0.02)], axis=1)
        radius = 0.06 + 0.04 * s ** 4
        p, _ = tube(path, radius, 6)
        shade = np.repeat(0.5 + 0.5 * np.cos(np.linspace(0, TAU, 6, endpoint=False)), 1)
        light = np.tile(shade, n)
        col = rgba(ramp(bands(0.4 + 0.5 * light, 2), [(0.0, (0.55, 0.12, 0.2)), (1.0, (0.95, 0.45, 0.55))]), 1.0)
        out.append((p, col))
    save_lined("tongue", out, q, 0.02, line=(0.15, 0.0, 0.05))
