# Сторонние материалы

- Звуки в `assets/minevia_jjk/sounds` сделаны в ElevenLabs Sound Effects (тариф Starter: использование в своих проектах разрешено).
- Распознавание голоса: [Vosk](https://alphacephei.com/vosk/) 0.3.45 (Alpha Cephei, Apache-2.0) и модель
  `vosk-model-small-ru-0.22` (Apache-2.0). В jar вложены классы Vosk и его библиотеки для Windows, модель — архивом.
- Для сборки нужна папка `libs`: `vosk-0.3.45-win.jar` (jar с Maven Central без папок `linux-x86-64` и `darwin`),
  `vosk-model-small-ru-0.22.zip` (alphacephei.com/vosk/models) и `voicechat-api-compile.jar` — классы
  `de/maxhenkel/voicechat/api` из мода Simple Voice Chat 1.21.1 (только для сборки, в мод не входят).
