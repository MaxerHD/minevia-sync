package local.minevia.jjk;

import java.util.List;

/**
 * Герои и их приёмы. В режиме боя (G): навыки на 1, 2, 3, 4, особый навык для комбо на R, ульта на J.
 * Общий для сервера и клиента: меню и панель берут отсюда названия и цвета.
 * J с полной шкалой включает ульту на 40 секунд: у Годжо открывается Пурпурный, Итадори становится Сукуной,
 * и один раз за ульту J открывает территорию. Сукуна не выбирается: это облик Итадори во время ульты.
 */
public enum Technique {
    LIMITLESS("limitless", "Годжо Сатору", "Безграничность", 0xFF7FC8FF, 0xFF5CC8FF, true,
            "Пространство слушается тебя: Синий притягивает, Красный отбрасывает, Бесконечность не подпускает.",
            List.of(
                    new Move("Синий", 25, 100),
                    new Move("Красный", 30, 120),
                    new Move("Шквал ударов", 30, 160),
                    new Move("Красный в упор", 35, 220),
                    new Move("Телепорт", 15, 60),
                    new Move("Ульта", 0, 1200)),
            new Move("Пурпурный", 40, 300), "Бесконечная пустота"),
    ITADORI("itadori", "Итадори Юдзи", "Рукопашный бой", 0xFFFF6B6B, 0xFFE0313B, true,
            "Кулаки и проклятая энергия с задержкой. Ульта отдаёт тело Сукуне, и у тебя его приёмы.",
            List.of(
                    new Move("Дивергентный кулак", 15, 60),
                    new Move("Рывок с ударом", 15, 80),
                    new Move("Серия с пинком", 25, 140),
                    new Move("Чёрная вспышка", 40, 300),
                    new Move("Бросок", 10, 80),
                    new Move("Сукуна", 0, 1200)),
            null, "Гробница зла"),
    SUKUNA("sukuna", "Рёмен Сукуна", "Святилище", 0xFFFF4A4A, 0xFF8B0E14, false,
            "Невидимые разрезы режут всё вокруг, пламя добивает устоявших.",
            List.of(
                    new Move("Рассечение", 20, 60),
                    new Move("Расщепление", 30, 140),
                    new Move("Веер разрезов", 40, 200),
                    new Move("Огненная стрела", 50, 300),
                    new Move("Прыжок к цели", 15, 80),
                    new Move("Гробница зла", 0, 1200)),
            null, "Гробница зла"),
    SHADOWS("shadows", "Мегуми Фушигуро", "Десять теней", 0xFFB48CFF, 0xFF16141C, true,
            "Из твоей тени выходят шикигами: псы, птица Нуэ и жаба.",
            List.of(
                    new Move("Божественные псы", 35, 400),
                    new Move("Нуэ", 30, 140),
                    new Move("Теневой шаг", 20, 80),
                    new Move("Гроза Нуэ", 55, 300),
                    new Move("Жаба", 15, 80),
                    new Move("Ульта", 0, 1200)),
            new Move("Махорага", 50, 400), "Сад теней"),
    NAOYA("naoya", "Наоя Зенин", "Проекция", 0xFFF0D060, 0xFFE8C547, true,
            "Двадцать четыре кадра в секунду: рывки быстрее глаза, а кого коснулся — застывает в кадре.",
            List.of(
                    new Move("Проекция", 15, 60),
                    new Move("Застывший кадр", 25, 160),
                    new Move("Очередь кадров", 30, 160),
                    new Move("Сверхзвук", 45, 260),
                    new Move("Рывок за спину", 10, 60),
                    new Move("Ульта", 0, 1200)),
            new Move("24 кадра", 45, 360), "Дворец лунных клеток");

    /** cost — проклятая энергия, cooldown — перезарядка в тиках. */
    public record Move(String name, int cost, int cooldown) {
    }

    /** Кого можно выбрать в меню, по порядку карточек. */
    public static final List<Technique> PICKABLE = List.of(LIMITLESS, ITADORI, SHADOWS, NAOYA);

    public static final String[] KEYS = {"1", "2", "3", "4", "R", "J"};
    public static final int SPECIAL = 4;
    public static final int DOMAIN = 5;
    public static final int SLOTS = 6;
    /** С какого класса открывается приём: 1 и R сразу, 2 с 3-го, 3 и ульта со 2-го, 4 с 1-го класса. */
    private static final int[] UNLOCK = {0, 1, 2, 3, 0, 2};

    public static final String[] RANKS = {"4-й класс", "3-й класс", "2-й класс", "1-й класс", "Особый класс"};
    /** Сколько опыта нужно для каждого класса. */
    public static final int[] RANK_XP = {0, 150, 450, 1000, 2000};
    public static final int[] MAX_ENERGY = {100, 130, 160, 200, 250};

    private final String id;
    private final String title;
    private final String art;
    private final int color;
    private final int bar;
    private final boolean pickable;
    private final String about;
    private final List<Move> moves;
    private final Move ultMove;
    private final String domain;

    Technique(String id, String title, String art, int color, int bar, boolean pickable, String about, List<Move> moves,
              Move ultMove, String domain) {
        this.id = id;
        this.title = title;
        this.art = art;
        this.color = color;
        this.bar = bar;
        this.pickable = pickable;
        this.about = about;
        this.moves = moves;
        this.ultMove = ultMove;
        this.domain = domain;
    }

    public String id() {
        return id;
    }

    /** Имя героя. */
    public String title() {
        return title;
    }

    /** Название техники. */
    public String art() {
        return art;
    }

    /** Цвет текста героя. */
    public int color() {
        return color;
    }

    /** Цвет шкалы ульты на панели боя. */
    public int bar() {
        return bar;
    }

    public boolean pickable() {
        return pickable;
    }

    public String about() {
        return about;
    }

    public Move move(int slot) {
        return moves.get(slot);
    }

    /**
     * Приём с учётом ульты. Во время ульты на 4 может стоять особый приём (у Годжо — Пурпурный),
     * а J один раз открывает территорию.
     */
    public Move move(int slot, boolean ult) {
        if (ult && slot == 3 && ultMove != null) {
            return ultMove;
        }
        if (ult && slot == DOMAIN) {
            return new Move(domain, 0, 1200);
        }
        return moves.get(slot);
    }

    public boolean hasUltMove() {
        return ultMove != null;
    }

    /** Название территории героя. */
    public String domain() {
        return domain;
    }

    public static Technique byId(String id) {
        for (Technique technique : values()) {
            if (technique.id.equals(id)) {
                return technique;
            }
        }
        // Святилище было отдельной техникой до 0.4.0: теперь это Итадори.
        return "shrine".equals(id) ? ITADORI : null;
    }

    /** Класс по опыту: 0 — 4-й класс, 4 — особый. */
    public static int rank(int xp) {
        int rank = 0;
        for (int i = 0; i < RANK_XP.length; i++) {
            if (xp >= RANK_XP[i]) {
                rank = i;
            }
        }
        return rank;
    }

    public static int unlockRank(int slot) {
        return UNLOCK[slot];
    }

    public static boolean unlocked(int slot, int rank) {
        return rank >= UNLOCK[slot];
    }
}
