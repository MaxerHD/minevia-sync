package local.minevia.jjk.client;

import local.minevia.jjk.MineviaJjk;
import local.minevia.jjk.ShadowDog;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.WolfEntityModel;
import net.minecraft.util.Identifier;

/** Божественные псы: модель волка с нашими текстурами, без ошейника. Белый и чёрный пёс. */
final class ShadowDogRenderer extends MobEntityRenderer<ShadowDog, WolfEntityModel<ShadowDog>> {
    private static final Identifier WHITE = Identifier.of(MineviaJjk.MOD_ID, "textures/entity/shadow_dog_white.png");
    private static final Identifier BLACK = Identifier.of(MineviaJjk.MOD_ID, "textures/entity/shadow_dog_black.png");

    ShadowDogRenderer(EntityRendererFactory.Context context) {
        super(context, new WolfEntityModel<>(context.getPart(EntityModelLayers.WOLF)), 0.5F);
    }

    @Override
    protected float getAnimationProgress(ShadowDog dog, float delta) {
        return dog.getTailAngle();
    }

    @Override
    public Identifier getTexture(ShadowDog dog) {
        return dog.white() ? WHITE : BLACK;
    }
}
