package local.minevia.jjk.mixin;

import local.minevia.jjk.client.JjkHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Режим боя (G): на месте хотбара панель приёмов. Хотбар, полоска опыта и название предмета прячутся,
 * сердечки и еда поднимаются над панелью.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    private void minevia$hideHotbar(DrawContext context, RenderTickCounter counter, CallbackInfo ci) {
        if (JjkHud.panelShown()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderExperienceBar", at = @At("HEAD"), cancellable = true)
    private void minevia$hideExperience(DrawContext context, int x, CallbackInfo ci) {
        if (JjkHud.panelShown()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderExperienceLevel", at = @At("HEAD"), cancellable = true)
    private void minevia$hideLevel(DrawContext context, RenderTickCounter counter, CallbackInfo ci) {
        if (JjkHud.panelShown()) {
            ci.cancel();
        }
    }

    @Inject(method = "renderHeldItemTooltip", at = @At("HEAD"), cancellable = true)
    private void minevia$hideItemName(DrawContext context, CallbackInfo ci) {
        if (JjkHud.panelShown()) {
            ci.cancel();
        }
    }

    /** Надпись над хотбаром (сообщения приёмов) тоже поднимается, чтобы не наезжать на сердечки. */
    @Inject(method = "renderOverlayMessage", at = @At("HEAD"))
    private void minevia$liftOverlay(DrawContext context, RenderTickCounter counter, CallbackInfo ci) {
        context.getMatrices().push();
        if (JjkHud.panelShown()) {
            context.getMatrices().translate(0, -JjkHud.LIFT - 12, 0);
        }
    }

    @Inject(method = "renderOverlayMessage", at = @At("RETURN"))
    private void minevia$liftOverlayEnd(DrawContext context, RenderTickCounter counter, CallbackInfo ci) {
        context.getMatrices().pop();
    }

    @Inject(method = {"renderStatusBars", "renderMountHealth"}, at = @At("HEAD"))
    private void minevia$liftBars(DrawContext context, CallbackInfo ci) {
        context.getMatrices().push();
        if (JjkHud.panelShown()) {
            context.getMatrices().translate(0, -JjkHud.LIFT, 0);
        }
    }

    @Inject(method = {"renderStatusBars", "renderMountHealth"}, at = @At("RETURN"))
    private void minevia$liftBarsEnd(DrawContext context, CallbackInfo ci) {
        context.getMatrices().pop();
    }
}
