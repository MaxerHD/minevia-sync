package local.minevia.jjk.mixin;

import net.minecraft.client.option.KeyBinding;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Счётчик нажатий привязки: нужен, чтобы отдать нажатие G или J тому моду, чьё начало выбрано. */
@Mixin(KeyBinding.class)
public interface KeyBindingAccessor {
    @Accessor("timesPressed")
    int minevia$getTimesPressed();

    @Accessor("timesPressed")
    void minevia$setTimesPressed(int times);
}
