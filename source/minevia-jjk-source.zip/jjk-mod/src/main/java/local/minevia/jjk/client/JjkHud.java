package local.minevia.jjk.client;

import java.util.List;
import local.minevia.jjk.Payloads;
import local.minevia.jjk.Technique;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/**
 * Панель боя на месте хотбара, только в режиме боя (G). Сверху вниз: имя героя, шкала ульты цвета героя (J),
 * под ней проклятая энергия и перезарядка особого навыка R, ниже четыре плитки приёмов 1-4.
 */
public final class JjkHud {
    /** На сколько точек поднимаются сердечки и еда, пока панель на экране. */
    public static final int LIFT = 34;

    private static final int TILE_W = 46;
    private static final int TILE_H = 31;
    private static final int GAP = 4;
    private static final int WIDTH = TILE_W * 4 + GAP * 3;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int GRAY = 0xFF8A8A8A;
    private static final int TILE = 0xD00D1018;
    private static final int TRACK = 0xE0161A24;
    private static final int FRAME = 0xFF3A4050;
    private static final int ENERGY = 0xFF2848C8;
    private static final int ENERGY_EDGE = 0xFF7C95FF;
    private static final int SPECIAL = 0xFFFF5FA2;
    private static final int SPECIAL_EDGE = 0xFFFFB6D4;
    private static final String[] SHORT_RANKS = {"4 кл.", "3 кл.", "2 кл.", "1 кл.", "особ."};

    private static Payloads.Hud state;
    /** Энергия и ульта на экране догоняют настоящие плавно, а не скачками раз в пять тиков. */
    private static float shownEnergy;
    private static float shownUlt;

    private JjkHud() {
    }

    static boolean hasTechnique() {
        return state != null && !state.technique().isEmpty();
    }

    /** Панель видна: выбран герой и включён режим боя. Тогда хотбар прячется. */
    public static boolean panelShown() {
        MinecraftClient client = MinecraftClient.getInstance();
        return JjkClient.combat() && hasTechnique() && client.player != null && !client.player.isSpectator();
    }

    static void update(Payloads.Hud hud) {
        state = hud;
    }

    static void draw(DrawContext context, float delta) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!panelShown() || client.options.hudHidden) {
            return;
        }
        Technique hero = Technique.byId(state.technique());
        if (hero == null) {
            return;
        }
        TextRenderer text = client.textRenderer;
        int left = (context.getScaledWindowWidth() - WIDTH) / 2;
        int bottom = context.getScaledWindowHeight() - 3;
        int tilesTop = bottom - TILE_H;
        int barsTop = tilesTop - 6;
        int ultTop = barsTop - 10;
        int nameTop = ultTop - 11;
        float ease = Math.min(1, 0.25F * (1 + delta));

        // Имя героя и счёт серии ударов.
        context.drawCenteredTextWithShadow(text, hero.title(), left + WIDTH / 2, nameTop, hero.color());
        if (state.combo() > 0) {
            String hits = state.combo() + " удар" + (state.combo() == 1 ? "" : "а");
            context.drawTextWithShadow(text, hits, left + WIDTH - text.getWidth(hits), nameTop, state.combo() == 4 ? 0xFFFFE070 : WHITE);
        }

        // Шкала ульты: копится в бою. В облике Сукуны тает — столько облику осталось.
        shownUlt += (state.ult() - shownUlt) * ease;
        boolean full = state.awakened() || state.ult() >= 100 && Technique.unlocked(Technique.DOMAIN, state.rank());
        frame(context, left, ultTop, left + WIDTH, ultTop + 7, full ? hero.color() : FRAME);
        int ultFill = left + Math.round(WIDTH * MathHelper.clamp(shownUlt / 100F, 0, 1));
        int ultColor = hero.bar();
        context.fill(left, ultTop, ultFill, ultTop + 7, ultColor);
        // Светлая кромка сверху, чтобы и чёрная шкала Мегуми читалась на тёмном.
        context.fill(left, ultTop, ultFill, ultTop + 1, lighter(ultColor));
        if (full && (System.currentTimeMillis() / 300) % 2 == 0) {
            context.fill(left, ultTop, ultFill, ultTop + 7, 0x30FFFFFF);
        }
        small(context, text, "J", left - 7, ultTop, full ? hero.color() : GRAY);
        if (state.domain() > 0) {
            String rest = (state.domain() + 19) / 20 + " с";
            small(context, text, rest, left + WIDTH + 3, ultTop, hero.color());
        }

        // Проклятая энергия слева, перезарядка R справа (полная — особый навык готов).
        int half = (WIDTH - GAP) / 2;
        shownEnergy += (state.energy() - shownEnergy) * ease;
        float energy = state.maxEnergy() <= 0 ? 0 : MathHelper.clamp(shownEnergy / state.maxEnergy(), 0, 1);
        bar(context, left, barsTop, half, energy, ENERGY, ENERGY_EDGE);
        Technique.Move special = hero.move(Technique.SPECIAL, state.awakened());
        int specialLeft = state.cooldowns()[Technique.SPECIAL];
        float ready = special.cooldown() <= 0 ? 1 : 1 - MathHelper.clamp(specialLeft / (float) special.cooldown(), 0, 1);
        bar(context, left + half + GAP, barsTop, WIDTH - half - GAP, ready, SPECIAL, SPECIAL_EDGE);
        small(context, text, "R", left + WIDTH + 3, barsTop - 2, specialLeft == 0 ? SPECIAL : GRAY);

        // Плитки приёмов 1-4.
        for (int slot = 0; slot < 4; slot++) {
            tile(context, text, hero, slot, left + slot * (TILE_W + GAP), tilesTop);
        }
    }

    private static void tile(DrawContext context, TextRenderer text, Technique hero, int slot, int x, int y) {
        Technique.Move move = hero.move(slot, state.awakened());
        boolean locked = !Technique.unlocked(slot, state.rank());
        int cooldown = state.cooldowns()[slot];
        boolean ready = !locked && cooldown == 0 && state.energy() >= move.cost();
        frame(context, x, y, x + TILE_W, y + TILE_H, ready ? hero.color() : FRAME);
        context.fill(x, y, x + TILE_W, y + TILE_H, TILE);
        if (ready) {
            context.fill(x, y, x + TILE_W, y + 1, hero.color());
        }
        // Приём, открытый ультой (Пурпурный), подсвечен цветом шкалы.
        if (state.awakened() && slot == 3 && hero.hasUltMove()) {
            context.fill(x, y + TILE_H - 2, x + TILE_W, y + TILE_H, hero.bar());
        }
        // Номер клавиши крупно.
        context.getMatrices().push();
        context.getMatrices().translate(x + TILE_W / 2F, y + 2, 0);
        context.getMatrices().scale(1.5F, 1.5F, 1);
        String key = Technique.KEYS[slot];
        context.drawTextWithShadow(text, key, -text.getWidth(key) / 2, 0, locked ? GRAY : WHITE);
        context.getMatrices().pop();
        // Название приёма мелко, в две строки.
        context.getMatrices().push();
        context.getMatrices().translate(x + TILE_W / 2F, y + 16, 0);
        context.getMatrices().scale(0.6F, 0.6F, 1);
        List<OrderedText> lines = text.wrapLines(Text.literal(move.name()), (int) ((TILE_W - 4) / 0.6F));
        for (int i = 0; i < Math.min(2, lines.size()); i++) {
            OrderedText line = lines.get(i);
            context.drawTextWithShadow(text, line, -text.getWidth(line) / 2, i * 10, locked ? GRAY : ready ? 0xFFE6E9F0 : 0xFFA0A6B4);
        }
        context.getMatrices().pop();
        if (locked) {
            context.fill(x, y, x + TILE_W, y + TILE_H, 0x90000000);
            small(context, text, SHORT_RANKS[Technique.unlockRank(slot)], x + TILE_W / 2 - smallWidth(text, SHORT_RANKS[Technique.unlockRank(slot)]) / 2,
                    y + 11, GRAY);
        } else if (cooldown > 0) {
            // Тень перезарядки сходит сверху вниз.
            int shade = Math.round(TILE_H * MathHelper.clamp(cooldown / (float) Math.max(1, move.cooldown()), 0, 1));
            context.fill(x, y + TILE_H - shade, x + TILE_W, y + TILE_H, 0xA0000000);
            String seconds = String.valueOf((cooldown + 19) / 20);
            context.drawTextWithShadow(text, seconds, x + TILE_W - 3 - text.getWidth(seconds), y + 2, hero.color());
        }
    }

    private static void bar(DrawContext context, int x, int y, int width, float part, int color, int edge) {
        frame(context, x, y, x + width, y + 3, FRAME);
        context.fill(x, y, x + width, y + 3, TRACK);
        int filled = x + Math.round(width * part);
        context.fill(x, y, filled, y + 3, color);
        context.fill(x, y, filled, y + 1, edge);
    }

    private static void frame(DrawContext context, int x1, int y1, int x2, int y2, int color) {
        context.fill(x1 - 1, y1 - 1, x2 + 1, y2 + 1, color);
        context.fill(x1, y1, x2, y2, TRACK);
    }

    private static void small(DrawContext context, TextRenderer text, String value, int x, int y, int color) {
        context.getMatrices().push();
        context.getMatrices().translate(x, y, 0);
        context.getMatrices().scale(0.75F, 0.75F, 1);
        context.drawTextWithShadow(text, value, 0, 0, color);
        context.getMatrices().pop();
    }

    private static int smallWidth(TextRenderer text, String value) {
        return Math.round(text.getWidth(value) * 0.75F);
    }

    private static int lighter(int color) {
        int r = Math.min(255, ((color >> 16) & 0xFF) + 70);
        int g = Math.min(255, ((color >> 8) & 0xFF) + 70);
        int b = Math.min(255, (color & 0xFF) + 70);
        return 0xFF000000 | r << 16 | g << 8 | b;
    }
}
