package local.minevia.jjk;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

/** Техника и опыт каждого игрока. Хранится в мире, поэтому у каждого мира свой прогресс. */
public final class JjkState extends PersistentState {
    public static final class Data {
        /** Пустая строка — техника ещё не выбрана. */
        public String technique = "";
        /** Опыт по техникам: сменишь технику — прогресс старой сохранится. */
        public final Map<String, Integer> xp = new HashMap<>();
        /** Время мира, когда технику меняли в последний раз. */
        public long changedAt = Long.MIN_VALUE / 2;

        public int xp() {
            return xp.getOrDefault(technique, 0);
        }
    }

    private static final Type<JjkState> TYPE = new Type<>(JjkState::new, JjkState::read, null);
    private final Map<UUID, Data> players = new HashMap<>();

    public static JjkState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, MineviaJjk.MOD_ID);
    }

    public Data of(UUID id) {
        return players.computeIfAbsent(id, key -> new Data());
    }

    private static JjkState read(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        JjkState state = new JjkState();
        NbtCompound all = nbt.getCompound("players");
        for (String key : all.getKeys()) {
            NbtCompound entry = all.getCompound(key);
            Data data = new Data();
            data.technique = entry.getString("technique");
            data.changedAt = entry.getLong("changedAt");
            NbtCompound xp = entry.getCompound("xp");
            for (String technique : xp.getKeys()) {
                data.xp.put(technique, xp.getInt(technique));
            }
            try {
                state.players.put(UUID.fromString(key), data);
            } catch (IllegalArgumentException ignored) {
                // Испорченную запись пропускаем, остальное читаем.
            }
        }
        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        NbtCompound all = new NbtCompound();
        players.forEach((id, data) -> {
            NbtCompound entry = new NbtCompound();
            entry.putString("technique", data.technique);
            entry.putLong("changedAt", data.changedAt);
            NbtCompound xp = new NbtCompound();
            data.xp.forEach(xp::putInt);
            entry.put("xp", xp);
            all.put(id.toString(), entry);
        });
        nbt.put("players", all);
        return nbt;
    }
}
