package local.minevia.jjk;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.boss.WitherEntity;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

/**
 * Мод «Проклятые техники»: три техники по мотивам «Магической битвы», проклятая энергия, классы от 4-го до особого,
 * чёрная вспышка и расширение территории. G — режим боя: навыки на 1-4, R — особый навык, J — ульта, Q — рывок, F — блок.
 */
public final class MineviaJjk implements ModInitializer {
    public static final String MOD_ID = "minevia_jjk";
    public static final RegistryKey<DamageType> TECHNIQUE_DAMAGE = RegistryKey.of(RegistryKeys.DAMAGE_TYPE, Identifier.of(MOD_ID, "technique"));
    /** Смена техники не чаще раза в 10 минут. */
    private static final long CHANGE_WAIT = 20 * 60 * 10;
    /** Сколько длится ульта: 40 секунд. */
    static final int ULT_TICKS = 20 * 40;

    public static final EntityType<CursedFx> FX = Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "fx"),
            EntityType.Builder.<CursedFx>create(CursedFx::new, SpawnGroup.MISC).dimensions(0.5F, 0.5F).maxTrackingRange(8)
                    .trackingTickInterval(1).makeFireImmune().disableSummon().disableSaving().build("fx"));
    public static final EntityType<ShadowDog> SHADOW_DOG = Registry.register(Registries.ENTITY_TYPE, Identifier.of(MOD_ID, "shadow_dog"),
            EntityType.Builder.<ShadowDog>create(ShadowDog::new, SpawnGroup.CREATURE).dimensions(0.6F, 0.85F).maxTrackingRange(10)
                    .disableSummon().disableSaving().build("shadow_dog"));

    private static final Map<UUID, Sorcerer> SORCERERS = new HashMap<>();
    private static volatile MinecraftServer SERVER;
    private static final Set<UUID> FORCED_FLASH = new HashSet<>();

    @Override
    public void onInitialize() {
        Sounds.init();
        FabricDefaultAttributeRegistry.register(SHADOW_DOG, WolfEntity.createWolfAttributes());

        PayloadTypeRegistry.playC2S().register(Payloads.Cast.ID, Payloads.Cast.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.Open.ID, Payloads.Open.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.Pick.ID, Payloads.Pick.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.Dash.ID, Payloads.Dash.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.Block.ID, Payloads.Block.CODEC);
        PayloadTypeRegistry.playS2C().register(Payloads.Hud.ID, Payloads.Hud.CODEC);
        PayloadTypeRegistry.playS2C().register(Payloads.Menu.ID, Payloads.Menu.CODEC);
        PayloadTypeRegistry.playS2C().register(Payloads.Flash.ID, Payloads.Flash.CODEC);
        PayloadTypeRegistry.playS2C().register(Payloads.Anim.ID, Payloads.Anim.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(Payloads.Cast.ID, (payload, context) -> {
            if (payload.slot() >= 0 && payload.slot() < Technique.SLOTS) {
                cast(context.player(), payload.slot());
            }
        });
        // Сказать в чат «расширение территории» — и территория раскрывается, если ульта готова.
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String said = message.getSignedContent().toLowerCase(java.util.Locale.ROOT).replace('ё', 'е');
            if (said.contains("расширение территории") && technique(sender) != null) {
                sender.getServer().execute(() -> cast(sender, Technique.DOMAIN));
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(Payloads.Open.ID, (payload, context) -> sendMenu(context.player(), true));
        ServerPlayNetworking.registerGlobalReceiver(Payloads.Pick.ID, (payload, context) -> pick(context.player(), payload.index()));
        ServerPlayNetworking.registerGlobalReceiver(Payloads.Dash.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            if (technique(p) != null && p.isAlive()) {
                Combat.dash(p, sorcerer(p), payload.forward(), payload.sideways(), p.getServer().getTicks());
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(Payloads.Block.ID, (payload, context) -> {
            ServerPlayerEntity p = context.player();
            Combat.block(p, sorcerer(p), payload.active() && technique(p) != null, p.getServer().getTicks());
        });

        ServerTickEvents.END_SERVER_TICK.register(MineviaJjk::tick);
        // Фраза голосом (Simple Voice Chat): то же, что J во время ульты.
        local.minevia.jjk.voice.VoiceListen.onPhrase((id, said) -> {
            MinecraftServer server = SERVER;
            if (server != null) {
                server.execute(() -> {
                    ServerPlayerEntity p = server.getPlayerManager().getPlayer(id);
                    if (p != null && technique(p) != null && inUlt(p) && !sorcerer(p).ultDomainUsed) {
                        cast(p, Technique.DOMAIN);
                    }
                });
            }
        });
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STARTED.register(server -> SERVER = server);
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(server -> SERVER = null);
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity player = handler.getPlayer();
            sendHud(player);
            if (data(player).technique.isEmpty() && !ElementsLink.active()) {
                player.sendMessage(Text.literal("В тебе проснулась проклятая энергия. Нажми J и выбери технику.").withColor(0xFFB48CFF));
            }
        });
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            Moves.dismissDogs(handler.getPlayer());
            SORCERERS.remove(handler.getPlayer().getUuid());
        });

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (Combat.DEBUG && player instanceof ServerPlayerEntity dbg && !world.isClient()) {
                Combat.LOGGER.info("[jjk-test] замах по {}: откат {}, неуязвим ещё {}", entity.getName().getString(),
                        dbg.getAttackCooldownProgress(0.5F), entity instanceof LivingEntity l ? l.timeUntilRegen : -1);
            }
            // Серия ударов как в файтингах: быстрые удары не теряются из-за неуязвимости после прошлого удара.
            if (!world.isClient() && player instanceof ServerPlayerEntity fighter && entity instanceof LivingEntity living
                    && technique(fighter) != null && fighter.getAttackCooldownProgress(0.5F) >= 0.3F) {
                living.timeUntilRegen = 0;
            }
            if (!world.isClient() && player instanceof ServerPlayerEntity sp && entity instanceof LivingEntity && technique(sp) != null
                    && sp.getAttackCooldownProgress(0.5F) > 0.9F) {
                int rank = Technique.rank(data(sp).xp());
                boolean forced = FORCED_FLASH.remove(sp.getUuid());
                if (forced || sp.getRandom().nextFloat() < 0.04F + 0.012F * rank) {
                    Sorcerer s = sorcerer(sp);
                    s.flashTarget = entity.getId();
                    s.flashTick = sp.getServer().getTicks();
                }
            }
            return ActionResult.PASS;
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof ServerPlayerEntity blocker && technique(blocker) != null
                    && Combat.absorb(blocker, sorcerer(blocker), source, amount, blocker.getServer().getTicks())) {
                return false;
            }
            if (entity instanceof ServerPlayerEntity p && sorcerer(p).infinityUntil > p.getServer().getTicks()
                    && !source.isIn(DamageTypeTags.BYPASSES_INVULNERABILITY)
                    && (source.getAttacker() != null || source.getSource() != null || source.isIn(DamageTypeTags.IS_EXPLOSION))) {
                if (source.getAttacker() instanceof LivingEntity attacker && attacker != p && attacker.squaredDistanceTo(p) < 25) {
                    Vec3d away = attacker.getPos().subtract(p.getPos());
                    if (away.lengthSquared() > 1.0E-4) {
                        away = away.normalize().multiply(0.8);
                        attacker.addVelocity(away.x, 0.2, away.z);
                        attacker.velocityModified = true;
                    }
                }
                return false;
            }
            return true;
        });
        ServerLivingEntityEvents.AFTER_DAMAGE.register((entity, source, baseDamage, damageTaken, blocked) -> {
            if (entity instanceof ServerPlayerEntity hurt && technique(hurt) != null && damageTaken > 0) {
                Sorcerer victim = sorcerer(hurt);
                if (victim.ultUntil == 0) {
                    victim.ult = Math.min(100, victim.ult + damageTaken);
                }
            }
            if (!(source.getAttacker() instanceof ServerPlayerEntity p) || entity == p || technique(p) == null) {
                return;
            }
            Sorcerer s = sorcerer(p);
            long now = p.getServer().getTicks();
            if (Combat.DEBUG) {
                Combat.LOGGER.info("[jjk-test] урон {} по {}: {} ({}), тик {}", source.getName(), entity.getName().getString(), damageTaken, baseDamage, now);
            }
            if (damageTaken > 0 && s.ultUntil == 0) {
                float before = s.ult;
                s.ult = Math.min(100, s.ult + damageTaken * 1.5F);
                if (before < 100 && s.ult >= 100 && Technique.unlocked(Technique.DOMAIN, Technique.rank(data(p).xp()))) {
                    p.sendMessage(Text.literal("Ульта готова: J").withColor(technique(p).color()), true);
                }
            }
            boolean melee = source.getSource() == p && source.isOf(net.minecraft.entity.damage.DamageTypes.PLAYER_ATTACK);
            if (melee && !(s.flashTarget == entity.getId() && s.flashTick == now) && s.flashTarget != -2) {
                Combat.meleeHit(p, s, entity, now);
            }
            if (s.flashTarget == entity.getId() && s.flashTick == now && source.getSource() == p) {
                s.flashTarget = -2;
                Combat.meleeHit(p, s, entity, now);
                Moves.blackFlash(p, entity, damageTaken);
                s.flashTarget = -1;
                s.energy = Math.min(maxEnergy(p), s.energy + 40);
                addXp(p, 15);
                p.sendMessage(Text.literal("Чёрная вспышка!").withColor(0xFFFF3B3B), true);
                if (ServerPlayNetworking.canSend(p, Payloads.Flash.ID)) {
                    ServerPlayNetworking.send(p, new Payloads.Flash());
                }
            }
            if (damageTaken > 0 && now - s.lastXpTick >= 8) {
                s.lastXpTick = now;
                addXp(p, 1);
            }
        });
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, killer, killed) -> {
            ServerPlayerEntity p = killer instanceof ServerPlayerEntity player ? player
                    : killer instanceof ShadowDog dog && dog.getOwner() instanceof ServerPlayerEntity owner ? owner : null;
            if (p == null || technique(p) == null || killed == p) {
                return;
            }
            int xp = killed instanceof PlayerEntity ? 25
                    : killed instanceof EnderDragonEntity || killed instanceof WitherEntity || killed instanceof WardenEntity ? 150
                    : killed instanceof Monster ? 10 : 2;
            addXp(p, xp);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registry, environment) -> dispatcher.register(
                CommandManager.literal("jjk").requires(source -> source.hasPermissionLevel(2))
                        .then(CommandManager.literal("xp").then(CommandManager.argument("amount", IntegerArgumentType.integer(-100000, 100000))
                                .executes(c -> {
                                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                    addXp(p, IntegerArgumentType.getInteger(c, "amount"));
                                    c.getSource().sendFeedback(() -> Text.literal("Опыт техники: " + data(p).xp()), false);
                                    return 1;
                                })))
                        .then(CommandManager.literal("technique").then(CommandManager.argument("id", StringArgumentType.word())
                                .suggests((c, b) -> CommandSource.suggestMatching(Technique.PICKABLE.stream().map(Technique::id), b))
                                .executes(c -> {
                                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                    Technique t = Technique.byId(StringArgumentType.getString(c, "id"));
                                    if (t == null) {
                                        c.getSource().sendError(Text.literal("Нет такой техники"));
                                        return 0;
                                    }
                                    setTechnique(p, t);
                                    return 1;
                                })))
                        .then(CommandManager.literal("energy").executes(c -> {
                            ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                            Sorcerer s = sorcerer(p);
                            s.energy = maxEnergy(p);
                            s.ult = 100;
                            s.dashReady = 0;
                            java.util.Arrays.fill(s.readyAt, 0);
                            sendHud(p);
                            return 1;
                        }))
                        .then(CommandManager.literal("flash").executes(c -> {
                            FORCED_FLASH.add(c.getSource().getPlayerOrThrow().getUuid());
                            return 1;
                        }))
                        .then(CommandManager.literal("voice").then(CommandManager.argument("wav", StringArgumentType.greedyString())
                                .executes(c -> {
                                    ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                    java.nio.file.Path wav = java.nio.file.Path.of(StringArgumentType.getString(c, "wav"));
                                    MinecraftServer server = c.getSource().getServer();
                                    local.minevia.jjk.voice.VoiceListen.test(p.getUuid(), wav, (text, match) -> server.execute(() ->
                                            p.sendMessage(Text.literal("Голос: «" + text + "»" + (match ? " — фраза узнана" : " — не то")), false)));
                                    return 1;
                                })))
                        .then(CommandManager.literal("cast").then(CommandManager.argument("slot", IntegerArgumentType.integer(0, Technique.SLOTS - 1))
                                .executes(c -> {
                                    cast(c.getSource().getPlayerOrThrow(), IntegerArgumentType.getInteger(c, "slot"));
                                    return 1;
                                })))));
    }

    // ------------------------------------------------------------------ состояние

    /** Показать движение игрока ему самому и всем, кто его видит. */
    static void anim(ServerPlayerEntity p, int kind) {
        Payloads.Anim payload = new Payloads.Anim(p.getId(), kind);
        if (ServerPlayNetworking.canSend(p, Payloads.Anim.ID)) {
            ServerPlayNetworking.send(p, payload);
        }
        for (ServerPlayerEntity other : PlayerLookup.tracking(p)) {
            if (other != p && ServerPlayNetworking.canSend(other, Payloads.Anim.ID)) {
                ServerPlayNetworking.send(other, payload);
            }
        }
    }

    private static JjkState.Data data(ServerPlayerEntity p) {
        return JjkState.get(p.getServer()).of(p.getUuid());
    }

    private static Technique technique(ServerPlayerEntity p) {
        return Technique.byId(data(p).technique);
    }

    static Sorcerer sorcerer(ServerPlayerEntity p) {
        return SORCERERS.computeIfAbsent(p.getUuid(), id -> new Sorcerer());
    }

    private static int maxEnergy(ServerPlayerEntity p) {
        return Technique.MAX_ENERGY[Technique.rank(data(p).xp())];
    }

    private static void tick(MinecraftServer server) {
        long now = server.getTicks();
        Combat.flush(now);
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (technique(p) == null) {
                continue;
            }
            // «12 начал»: игрок выбрал стихию или стиль — техника откладывается.
            if (now % 10 == 0 && ElementsLink.active() && !ElementsLink.elementKey(p).isEmpty()) {
                dropTechnique(p);
                continue;
            }
            Sorcerer s = sorcerer(p);
            if (s.domainTechnique == null) {
                s.energy = Math.min(maxEnergy(p), s.energy + 0.25F);
            }
            if (s.infinityUntil > now) {
                Moves.infinityTick(p);
            }
            if (s.ultUntil != 0 && now >= s.ultUntil) {
                endUlt(p, s);
            }
            Combat.tick(p, s, now);
            Moves.domainTick(p, s, now);
            if (now % 10 == 0) {
                // Голос слушаем только во время ульты, пока территория не открыта.
                local.minevia.jjk.voice.VoiceListen.listen(p.getUuid(), s.ultUntil > now && !s.ultDomainUsed);
            }
            if (now % 5 == 0) {
                sendHud(p);
            }
        }
    }

    /** Чьи приёмы сейчас у игрока: у Итадори во время ульты — Сукуны. */
    static Technique form(ServerPlayerEntity p) {
        Technique t = technique(p);
        if (t == Technique.ITADORI && inUlt(p)) {
            return Technique.SUKUNA;
        }
        return t;
    }

    static boolean inUlt(ServerPlayerEntity p) {
        return sorcerer(p).ultUntil > p.getServer().getTicks();
    }

    /** Ульта: 40 секунд особого состояния. У Итадори телом владеет Сукуна, у Годжо открыт Пурпурный. */
    static void startUlt(ServerPlayerEntity p, Sorcerer s, long now) {
        s.ultStart = now;
        s.ultUntil = now + ULT_TICKS;
        s.ultDomainUsed = false;
        java.util.Arrays.fill(s.readyAt, 0, Technique.DOMAIN, 0);
        p.addStatusEffect(Moves.effect(net.minecraft.entity.effect.StatusEffects.STRENGTH, ULT_TICKS, 1));
        p.addStatusEffect(Moves.effect(net.minecraft.entity.effect.StatusEffects.RESISTANCE, ULT_TICKS, 0));
        Technique hero = technique(p);
        Text title = hero == Technique.ITADORI ? Text.literal("Сукуна взял тело").withColor(Technique.SUKUNA.color())
                : Text.literal(hero.title() + ": ульта. J — " + hero.domain()).withColor(hero.color());
        for (ServerPlayerEntity other : p.getServerWorld().getPlayers(o -> o.squaredDistanceTo(p) < 48 * 48)) {
            other.sendMessage(title, true);
        }
    }

    private static void endUlt(ServerPlayerEntity p, Sorcerer s) {
        s.ultUntil = 0;
        java.util.Arrays.fill(s.readyAt, 0, Technique.DOMAIN, 0);
        p.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.STRENGTH);
        p.removeStatusEffect(net.minecraft.entity.effect.StatusEffects.RESISTANCE);
        Technique hero = technique(p);
        p.sendMessage(hero == Technique.ITADORI ? Text.literal("Итадори вернул себе тело").withColor(hero.color())
                : Text.literal("Ульта закончилась").withColor(hero.color()), true);
        sendHud(p);
    }

    private static void cast(ServerPlayerEntity p, int slot) {
        if (p.isSpectator() || !p.isAlive()) {
            return;
        }
        Technique t = form(p);
        if (t == null) {
            p.sendMessage(Text.literal("Сначала выбери технику: J"), true);
            return;
        }
        int rank = Technique.rank(data(p).xp());
        boolean ult = inUlt(p);
        Technique.Move move = t.move(slot, ult);
        if (!Technique.unlocked(slot, rank)) {
            p.sendMessage(Text.literal("«" + move.name() + "» откроется: " + Technique.RANKS[Technique.unlockRank(slot)]), true);
            return;
        }
        Sorcerer s = sorcerer(p);
        long now = p.getServer().getTicks();
        if (s.readyAt[slot] > now) {
            return;
        }
        int max = maxEnergy(p);
        // Территория — только во время ульты и один раз за ульту.
        boolean ultDomain = slot == Technique.DOMAIN && ult;
        if (ultDomain) {
            if (s.ultDomainUsed) {
                p.sendMessage(Text.literal("Территория уже открывалась в эту ульту"), true);
                return;
            }
        } else if (slot == Technique.DOMAIN) {
            if (s.ult < 100) {
                p.sendMessage(Text.literal("Ульта ещё не готова: " + (int) s.ult + "%. Она копится, когда бьёшь и когда бьют тебя"), true);
                return;
            }
        } else if (s.energy < move.cost()) {
            p.sendMessage(Text.literal("Мало проклятой энергии"), true);
            return;
        }
        if (Moves.run(p, t, slot, s, now, ult)) {
            if (ultDomain) {
                s.ultDomainUsed = true;
            } else if (slot == Technique.DOMAIN) {
                s.ult = 0;
            } else {
                s.energy -= move.cost();
            }
            // У J нет перезарядки: ульту ограничивает шкала, территорию — один раз за ульту.
            s.readyAt[slot] = slot == Technique.DOMAIN ? 0 : now + move.cooldown();
            sendHud(p);
        }
    }

    private static void addXp(ServerPlayerEntity p, int amount) {
        JjkState state = JjkState.get(p.getServer());
        JjkState.Data d = state.of(p.getUuid());
        if (d.technique.isEmpty()) {
            return;
        }
        int before = Technique.rank(d.xp());
        d.xp.put(d.technique, Math.max(0, d.xp() + amount));
        state.markDirty();
        int after = Technique.rank(d.xp());
        if (after > before) {
            StringBuilder opened = new StringBuilder();
            Technique t = Technique.byId(d.technique);
            for (int slot = 0; slot < Technique.SLOTS; slot++) {
                if (Technique.unlockRank(slot) > before && Technique.unlockRank(slot) <= after) {
                    opened.append(opened.isEmpty() ? "" : ", ").append("«").append(t.move(slot).name()).append("»");
                }
            }
            p.sendMessage(Text.literal("Теперь ты маг: " + Technique.RANKS[after] + (opened.isEmpty() ? "" : ". Открыто: " + opened)).withColor(t.color()));
            p.playSoundToPlayer(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, net.minecraft.sound.SoundCategory.PLAYERS, 0.7F, 1.2F);
        }
        sendHud(p);
    }

    private static void setTechnique(ServerPlayerEntity p, Technique t) {
        if (ElementsLink.clearElement(p)) {
            p.sendMessage(Text.literal("Стихия снята: теперь твоё начало — проклятая техника.").withColor(0xFFB48CFF));
        }
        JjkState state = JjkState.get(p.getServer());
        JjkState.Data d = state.of(p.getUuid());
        d.technique = t.id();
        d.changedAt = p.getServer().getOverworld().getTime();
        state.markDirty();
        Sorcerer s = sorcerer(p);
        s.infinityUntil = 0;
        s.domainTechnique = null;
        s.ultUntil = 0;
        java.util.Arrays.fill(s.readyAt, 0);
        s.energy = Math.min(s.energy, maxEnergy(p));
        Moves.dismissDogs(p);
        p.sendMessage(Text.literal("Твой герой: " + t.title() + " (" + t.art() + ")").withColor(t.color()));
        sendHud(p);
        sendMenu(p, false);
    }

    /** Техника уступает место стихии. Опыт техники остаётся: вернёшься к ней — продолжишь с того же класса. */
    private static void dropTechnique(ServerPlayerEntity p) {
        JjkState state = JjkState.get(p.getServer());
        JjkState.Data d = state.of(p.getUuid());
        d.technique = "";
        state.markDirty();
        Sorcerer s = sorcerer(p);
        s.infinityUntil = 0;
        s.domainTechnique = null;
        s.ultUntil = 0;
        s.blocking = false;
        java.util.Arrays.fill(s.readyAt, 0);
        Moves.dismissDogs(p);
        p.sendMessage(Text.literal("Проклятая техника отложена, опыт её сохранён. Вернуть можно в меню на J.").withColor(0xFFB48CFF));
        sendHud(p);
        sendMenu(p, false);
    }

    private static void pick(ServerPlayerEntity p, int index) {
        java.util.List<Technique> all = Technique.PICKABLE;
        if (index < 0 || index >= all.size()) {
            return;
        }
        JjkState.Data d = data(p);
        if (d.technique.equals(all.get(index).id())) {
            return;
        }
        int wait = waitSeconds(p, d);
        if (wait > 0) {
            p.sendMessage(Text.literal("Сменить технику можно через " + (wait + 59) / 60 + " мин."), true);
            sendMenu(p, false);
            return;
        }
        setTechnique(p, all.get(index));
    }

    private static int waitSeconds(ServerPlayerEntity p, JjkState.Data d) {
        if (d.technique.isEmpty()) {
            return 0;
        }
        long left = d.changedAt + CHANGE_WAIT - p.getServer().getOverworld().getTime();
        return left <= 0 ? 0 : (int) Math.min(Integer.MAX_VALUE, (left + 19) / 20);
    }

    private static void sendMenu(ServerPlayerEntity p, boolean open) {
        if (!ServerPlayNetworking.canSend(p, Payloads.Menu.ID)) {
            return;
        }
        JjkState.Data d = data(p);
        ServerPlayNetworking.send(p, new Payloads.Menu(d.technique, d.xp(), Technique.rank(d.xp()), waitSeconds(p, d), open,
                ElementsLink.elementKey(p), ElementsLink.active()));
    }

    private static void sendHud(ServerPlayerEntity p) {
        if (!ServerPlayNetworking.canSend(p, Payloads.Hud.ID)) {
            return;
        }
        JjkState.Data d = data(p);
        Sorcerer s = sorcerer(p);
        long now = p.getServer().getTicks();
        int[] cooldowns = new int[Technique.SLOTS];
        for (int i = 0; i < cooldowns.length; i++) {
            cooldowns[i] = (int) Math.max(0, s.readyAt[i] - now);
        }
        int domain = s.domainTechnique == null ? 0 : (int) Math.max(0, s.domainUntil - now);
        int combo = now - s.comboTick <= Combat.COMBO_GAP ? s.combo : 0;
        // В облике Сукуны шкала ульты показывает, сколько облику осталось.
        Technique shown = form(p);
        boolean awakened = s.ultUntil > now;
        int ult = awakened ? (int) Math.max(0, (s.ultUntil - now) * 100 / ULT_TICKS) : (int) s.ult;
        ServerPlayNetworking.send(p, new Payloads.Hud(shown == null ? d.technique : shown.id(), Technique.rank(d.xp()), (int) s.energy, maxEnergy(p), cooldowns, domain, combo, ult, awakened));
    }
}
