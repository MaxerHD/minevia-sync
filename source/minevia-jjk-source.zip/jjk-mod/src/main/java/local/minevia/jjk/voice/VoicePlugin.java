package local.minevia.jjk.voice;

import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.opus.OpusDecoder;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Подключение к Simple Voice Chat. Голосовой чат сам находит этот класс (точка входа «voicechat» в fabric.mod.json),
 * без него класс никогда не загружается. Отсюда только звук: что с ним делать, решает {@link VoiceListen}.
 */
public final class VoicePlugin implements VoicechatPlugin {
    private VoicechatApi api;
    /** Декодер у каждого говорящего свой; трогается только из потока распознавания. */
    private final Map<UUID, OpusDecoder> decoders = new ConcurrentHashMap<>();

    @Override
    public String getPluginId() {
        return "minevia_jjk";
    }

    @Override
    public void initialize(VoicechatApi api) {
        this.api = api;
        VoiceListen.enable();
    }

    @Override
    public void registerEvents(EventRegistration registration) {
        registration.registerEvent(MicrophonePacketEvent.class, this::onMicrophone);
    }

    private void onMicrophone(MicrophonePacketEvent event) {
        VoicechatConnection sender = event.getSenderConnection();
        if (sender == null || api == null) {
            return;
        }
        UUID id = sender.getPlayer().getUuid();
        if (!VoiceListen.listening(id)) {
            return;
        }
        byte[] opus = event.getPacket().getOpusEncodedData();
        VoiceListen.feed(id, () -> {
            OpusDecoder decoder = decoders.computeIfAbsent(id, key -> api.createDecoder());
            if (opus == null || opus.length == 0) {
                decoder.resetState();
                return null;
            }
            return decoder.decode(opus);
        });
    }
}
