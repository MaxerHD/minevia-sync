package local.minevia.jjk.client;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import local.minevia.jjk.Payloads;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Свои движения бойца поверх обычной анимации игрока: удары левой и правой по очереди, апперкот, пинок,
 * рывок с наклоном, жест приёма и блок со скрещёнными руками. Сервер присылает, кто и что делает.
 */
public final class PlayerAnims {
    private record Active(int kind, long start) {
    }

    private static final Map<Integer, Active> ACTIVE = new HashMap<>();
    private static final Set<Integer> BLOCKING = new HashSet<>();

    private PlayerAnims() {
    }

    static void start(int entity, int kind) {
        if (kind == Payloads.Anim.BLOCK_ON) {
            BLOCKING.add(entity);
        } else if (kind == Payloads.Anim.BLOCK_OFF) {
            BLOCKING.remove(entity);
        } else {
            ACTIVE.put(entity, new Active(kind, System.currentTimeMillis()));
        }
    }

    private static long length(int kind) {
        return switch (kind) {
            case Payloads.Anim.PUNCH_LEFT, Payloads.Anim.PUNCH_RIGHT -> 220;
            case Payloads.Anim.UPPERCUT -> 320;
            case Payloads.Anim.KICK -> 380;
            case Payloads.Anim.DASH -> 300;
            case Payloads.Anim.PURPLE -> 1350;
            default -> 350;
        };
    }

    /** Вызывается в конце обычной анимации. Для руки в кадре от первого лица игра передаёт нулевое время — там не трогаем. */
    public static void pose(PlayerEntityModel<?> model, LivingEntity entity, float animationProgress) {
        if (animationProgress <= 0 || ACTIVE.isEmpty() && BLOCKING.isEmpty() || entity.isSleeping() || entity.isFallFlying()) {
            return;
        }
        int id = entity.getId();
        boolean changed = false;
        if (BLOCKING.contains(id)) {
            model.rightArm.pitch = -1.45F;
            model.rightArm.yaw = -0.75F;
            model.leftArm.pitch = -1.55F;
            model.leftArm.yaw = 0.75F;
            changed = true;
        }
        Active active = ACTIVE.get(id);
        if (active != null) {
            float t = (System.currentTimeMillis() - active.start()) / (float) length(active.kind());
            if (t >= 1) {
                ACTIVE.remove(id);
            } else {
                if (active.kind() == Payloads.Anim.PURPLE) {
                    purple(model, t);
                } else {
                    // Быстро вперёд, плавнее назад.
                    float k = t < 0.35F ? t / 0.35F : 1 - (t - 0.35F) / 0.65F;
                    k = k * k * (3 - 2 * k);
                    apply(model, active.kind(), k);
                }
                changed = true;
            }
        }
        if (changed) {
            model.leftSleeve.copyTransform(model.leftArm);
            model.rightSleeve.copyTransform(model.rightArm);
            model.leftPants.copyTransform(model.leftLeg);
            model.rightPants.copyTransform(model.rightLeg);
            model.jacket.copyTransform(model.body);
        }
    }

    private static void apply(PlayerEntityModel<?> model, int kind, float k) {
        switch (kind) {
            case Payloads.Anim.PUNCH_RIGHT -> punch(model.rightArm, model.leftArm, model, k, 1);
            case Payloads.Anim.PUNCH_LEFT -> punch(model.leftArm, model.rightArm, model, k, -1);
            case Payloads.Anim.UPPERCUT -> {
                model.rightArm.pitch = MathHelper.lerp(k, 0.6F, -2.9F);
                model.rightArm.yaw = -0.2F * k;
                model.leftArm.pitch = 0.5F * k;
                model.body.yaw = 0.3F * k;
            }
            case Payloads.Anim.KICK -> {
                model.rightLeg.pitch = MathHelper.lerp(k, model.rightLeg.pitch, -1.65F);
                model.rightLeg.yaw = -0.15F * k;
                model.leftLeg.pitch = 0.25F * k;
                model.rightArm.roll = 0.9F * k;
                model.leftArm.roll = -0.9F * k;
                model.rightArm.pitch = 0.3F * k;
                model.leftArm.pitch = 0.3F * k;
            }
            case Payloads.Anim.DASH -> {
                model.rightArm.pitch = 1.1F * k;
                model.leftArm.pitch = 1.1F * k;
                model.rightArm.roll = 0.25F * k;
                model.leftArm.roll = -0.25F * k;
            }
            case Payloads.Anim.CAST -> {
                model.rightArm.pitch = MathHelper.lerp(k, model.rightArm.pitch, model.head.pitch - 1.5F);
                model.rightArm.yaw = MathHelper.lerp(k, model.rightArm.yaw, model.head.yaw - 0.1F);
                model.leftArm.pitch = MathHelper.lerp(k, model.leftArm.pitch, -0.5F);
            }
            default -> {
            }
        }
    }

    /**
     * Пурпурный: руки расходятся в стороны ладонями вверх (в левой синий, в правой красный), сходятся перед грудью,
     * правая выстреливает вперёд, потом поза отпускается.
     */
    private static void purple(PlayerEntityModel<?> model, float t) {
        // Ключевые позы: [питч правой, яв правой, ролл правой, питч левой, яв левой, ролл левой, поворот корпуса].
        float[][] keys = {
                {0, 0, 0, 0, 0, 0, 0},
                {-0.35F, 0, 1.35F, -0.35F, 0, -1.35F, 0},
                {-1.45F, -0.45F, 0, -1.45F, 0.45F, 0, 0},
                {model.head.pitch - 1.6F, 0, 0, 0.45F, 0, -0.2F, 0.4F},
                {0, 0, 0, 0, 0, 0, 0}};
        float[] times = {0, 0.3F, 0.65F, 0.8F, 1};
        int i = 0;
        while (i < times.length - 2 && t > times[i + 1]) {
            i++;
        }
        float k = MathHelper.clamp((t - times[i]) / (times[i + 1] - times[i]), 0, 1);
        k = k * k * (3 - 2 * k);
        float[] a = keys[i];
        float[] b = keys[i + 1];
        model.rightArm.pitch = MathHelper.lerp(k, a[0], b[0]);
        model.rightArm.yaw = MathHelper.lerp(k, a[1], b[1]);
        model.rightArm.roll = MathHelper.lerp(k, a[2], b[2]);
        model.leftArm.pitch = MathHelper.lerp(k, a[3], b[3]);
        model.leftArm.yaw = MathHelper.lerp(k, a[4], b[4]);
        model.leftArm.roll = MathHelper.lerp(k, a[5], b[5]);
        model.body.yaw = MathHelper.lerp(k, a[6], b[6]);
    }

    /** Удар: рука выстреливает вперёд, корпус доворачивается, вторая рука уходит к груди. */
    private static void punch(ModelPart hit, ModelPart other, PlayerEntityModel<?> model, float k, int side) {
        hit.pitch = MathHelper.lerp(k, hit.pitch, model.head.pitch - 1.55F);
        hit.yaw = MathHelper.lerp(k, hit.yaw, -0.15F * side);
        other.pitch = MathHelper.lerp(k, other.pitch, -0.9F);
        other.yaw = MathHelper.lerp(k, other.yaw, 0.5F * side);
        model.body.yaw = 0.35F * side * k;
    }
}
