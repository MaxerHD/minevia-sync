package local.minevia.jjk.client;

import java.util.Set;
import local.minevia.jjk.MineviaJjk;
import local.minevia.jjk.Payloads;
import local.minevia.jjk.Technique;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.resource.ResourceType;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Управление как в файтингах: G включает режим боя. В нём 1-4 — навыки, R — особый навык, J — ульта,
 * Q — рывок, F (держать) — блок. Вне режима боя клавиши работают как обычно, J открывает меню техник.
 */
public final class JjkClient implements ClientModInitializer {
    private static final String CATEGORY = "key.categories.minevia_jjk";
    private static boolean combat;
    private static boolean blocking;

    static boolean combat() {
        return combat;
    }

    @Override
    public void onInitializeClient() {
        ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES).registerReloadListener(new FxMesh.Loader());
        EntityRendererRegistry.register(MineviaJjk.FX, FxRenderer::new);
        EntityRendererRegistry.register(MineviaJjk.SHADOW_DOG, ShadowDogRenderer::new);

        KeyBinding combatKey = key("combat", GLFW.GLFW_KEY_G);
        KeyBinding menu = key("menu", GLFW.GLFW_KEY_J);
        KeyBinding special = key("special", GLFW.GLFW_KEY_R);
        ClientLifecycleEvents.CLIENT_STARTED.register(client -> KeyConflicts.resolve(client, Set.of(combatKey, menu, special)));
        ElementsBridge.init();
        // Самым первым: G и J общие с модом стихий, нажатие уходит тому, чьё начало выбрано.
        ClientTickEvents.START_CLIENT_TICK.register(client -> ElementsBridge.route(client, combatKey, menu));

        // В начале тика, раньше игры: в режиме боя забираем себе нажатия 1-4, Q и F, чтобы не менялся слот,
        // не выпадал предмет и не менялись руки.
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            if (!combat || client.player == null || client.currentScreen != null || !ClientPlayNetworking.canSend(Payloads.Cast.ID)) {
                return;
            }
            for (int i = 0; i < 4; i++) {
                while (client.options.hotbarKeys[i].wasPressed()) {
                    ClientPlayNetworking.send(new Payloads.Cast(i));
                }
            }
            while (client.options.dropKey.wasPressed()) {
                ClientPlayNetworking.send(new Payloads.Dash(client.player.input.movementForward, client.player.input.movementSideways));
            }
            while (client.options.swapHandsKey.wasPressed()) {
                // F занята блоком: руки не меняем.
            }
        });
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ElementsBridge.closeExtraSelection(client);
            if (client.player == null || !ClientPlayNetworking.canSend(Payloads.Cast.ID)) {
                combat = false;
                blocking = false;
                return;
            }
            boolean ready = JjkHud.hasTechnique();
            while (combatKey.wasPressed()) {
                if (!ready) {
                    client.inGameHud.setOverlayMessage(Text.literal("Сначала выбери технику: J"), false);
                    continue;
                }
                combat = !combat;
                client.inGameHud.setOverlayMessage(Text.literal(combat ? "Режим боя включён" : "Режим боя выключен"), false);
            }
            if (!ready) {
                combat = false;
            }
            while (menu.wasPressed()) {
                ClientPlayNetworking.send(combat ? new Payloads.Cast(Technique.DOMAIN) : new Payloads.Open());
            }
            while (special.wasPressed()) {
                if (combat) {
                    ClientPlayNetworking.send(new Payloads.Cast(Technique.SPECIAL));
                }
            }
            boolean block = combat && client.currentScreen == null && client.options.swapHandsKey.isPressed();
            if (block != blocking) {
                blocking = block;
                ClientPlayNetworking.send(new Payloads.Block(block));
            }
        });
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Hud.ID, (payload, context) -> JjkHud.update(payload));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Flash.ID, (payload, context) -> FlashEffect.start());
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Anim.ID, (payload, context) -> PlayerAnims.start(payload.entity(), payload.kind()));
        ClientPlayNetworking.registerGlobalReceiver(Payloads.Menu.ID, (payload, context) -> {
            if (context.client().currentScreen instanceof JjkScreen screen) {
                screen.update(payload);
            } else if (payload.open()) {
                context.client().setScreen(new JjkScreen(payload));
            }
        });
        HudRenderCallback.EVENT.register((context, tickCounter) -> {
            float delta = tickCounter.getTickDelta(false);
            FlashEffect.draw(context, delta);
            JjkHud.draw(context, delta);
        });
    }

    private static KeyBinding key(String name, int code) {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding("key.minevia_jjk." + name, InputUtil.Type.KEYSYM, code, CATEGORY));
    }
}
