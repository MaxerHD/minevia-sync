package local.minevia.jjk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

/** Приёмы героев и расширения территории. Всё считается на сервере, клиент только рисует модели. */
public final class Moves {
    private Moves() {
    }

    /** Запускает приём. false — приём не сработал (например, некого бить), тогда энергия не тратится. */
    static boolean run(ServerPlayerEntity p, Technique technique, int slot, Sorcerer s, long now, boolean ult) {
        ServerWorld w = p.getServerWorld();
        if (slot == Technique.DOMAIN) {
            return ult ? domain(p, w, s, technique, now) : awaken(p, w, s, now, technique);
        }
        if (ult && slot == 3 && technique.hasUltMove()) {
            return switch (technique) {
                case LIMITLESS -> purpleCharge(p, w);
                case SHADOWS -> mahoraga(p, w);
                default -> twentyFourFrames(p, w);
            };
        }
        boolean done = switch (technique) {
            case LIMITLESS -> switch (slot) {
                case 0 -> blue(p, w, false);
                case 1 -> red(p, w);
                case 2 -> gojoBarrage(p, w);
                case 3 -> redPointBlank(p, w);
                default -> teleport(p, w);
            };
            case ITADORI -> switch (slot) {
                case 0 -> divergentFist(p, w);
                case 1 -> rushStrike(p, w);
                case 2 -> flurryKick(p, w);
                case 3 -> blackFlashStrike(p, w);
                default -> grabThrow(p, w);
            };
            case NAOYA -> switch (slot) {
                case 0 -> projection(p, w);
                case 1 -> freezeFrame(p, w);
                case 2 -> frameBarrage(p, w);
                case 3 -> sonicBoom(p, w);
                default -> teleport(p, w);
            };
            case SUKUNA -> switch (slot) {
                case 0 -> dismantle(p, w, false);
                case 1 -> cleave(p, w, false);
                case 2 -> dismantle(p, w, true);
                case 3 -> flameArrow(p, w, true);
                default -> leap(p, w);
            };
            case SHADOWS -> switch (slot) {
                case 0 -> dogs(p, w, false);
                case 1 -> nue(p, w, false);
                case 2 -> shadowStep(p, w, false);
                case 3 -> nue(p, w, true);
                default -> toad(p, w);
            };
        };
        // У рукопашных приёмов свои движения рук: жест приёма им не нужен.
        if (done && technique != Technique.ITADORI && technique != Technique.NAOYA) {
            MineviaJjk.anim(p, Payloads.Anim.CAST);
        }
        return done;
    }

    // ------------------------------------------------------------------ Безграничность

    /**
     * Синий: точка притяжения перед Годжо стягивает врагов к нему, а когда они долетели — Годжо бьёт ногой,
     * и они улетают вперёд. Подброшенных можно добить пинком в воздухе или телепортом на R.
     */
    private static boolean blue(ServerPlayerEntity p, ServerWorld w, boolean strong) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d flat = Vec3d.fromPolar(0, p.getYaw());
        Vec3d at = p.getEyePos().add(flat.multiply(2.2)).add(0, -0.5, 0);
        float radius = strong ? 11 : 8;
        int pull = 16;
        int life = pull + 6;
        CursedFx fx = CursedFx.create(w, FxKind.BLUE, at, strong ? 1.4F : 1.0F, life, p);
        fx.behavior(f -> {
            Vec3d center = f.getPos();
            if (f.age < pull) {
                for (LivingEntity e : targets(w, center, radius, p)) {
                    Vec3d to = center.subtract(e.getBoundingBox().getCenter());
                    double distance = to.length();
                    if (distance > 0.6) {
                        e.setVelocity(to.multiply(Math.min(0.9, 0.25 + distance * 0.06) / distance));
                        e.velocityModified = true;
                    }
                    if (f.age % 8 == 0 && distance < 2.5) {
                        e.timeUntilRegen = 0;
                        f.hurt(e, 1.5F);
                    }
                }
            } else if (f.age == pull) {
                // Притянул — пинок: всех, кто рядом с точкой, отправляет вперёд и вверх.
                boolean kicked = false;
                for (LivingEntity e : targets(w, center, 3.2, p)) {
                    e.timeUntilRegen = 0;
                    f.hurt(e, strong ? 9 : 6);
                    Combat.push(e, new Vec3d(look.x * 2.0, 0.55, look.z * 2.0));
                    Combat.launched(e, w.getServer().getTicks());
                    w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, e.getBoundingBox().getCenter(), 1.3F, 6, p).variant(1));
                    kicked = true;
                }
                MineviaJjk.anim(p, Payloads.Anim.KICK);
                w.spawnEntity(kickArc(w, p));
                sound(w, center, kicked ? Sounds.KICK : Sounds.DASH, 1.3F, kicked ? 0.9F : 1.2F);
            }
        });
        w.spawnEntity(fx);
        sound(w, at, Sounds.BLUE, 1.3F, 1.0F);
        return true;
    }

    private static boolean red(ServerPlayerEntity p, ServerWorld w) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d start = p.getEyePos().add(look.multiply(1.1)).add(0, -0.2, 0);
        CursedFx fx = CursedFx.create(w, FxKind.RED, start, 0.75F, 30, p).velocity(look.multiply(1.6));
        fx.behavior(f -> {
            if (impact(w, f, p, 0.9) || f.age >= f.life()) {
                Vec3d at = f.getPos();
                w.spawnEntity(CursedFx.create(w, FxKind.RED_BURST, at, 1.6F, 12, p));
                for (LivingEntity e : targets(w, at, 4.5, p)) {
                    f.hurt(e, 9);
                    Vec3d away = e.getBoundingBox().getCenter().subtract(at);
                    away = away.lengthSquared() < 1.0E-4 ? look : away.normalize();
                    e.addVelocity(away.x * 2.0, 0.55, away.z * 2.0);
                    e.velocityModified = true;
                }
                sound(w, at, Sounds.RED_BOOM, 1.4F, 1.0F);
                f.discard();
            }
        });
        w.spawnEntity(fx);
        sound(w, p.getPos(), Sounds.RED_SHOT, 1.0F, 1.0F);
        return true;
    }

    /**
     * Пурпурный (только в ульте): синий загорается в левой руке, красный в правой, руки сходятся перед грудью,
     * шары сливаются — и Годжо выпускает пурпурный. Пока заряжает, почти стоит на месте.
     */
    private static boolean purpleCharge(ServerPlayerEntity p, ServerWorld w) {
        int spread = 14;
        int merge = 28;
        int fire = 36;
        CursedFx blue = CursedFx.create(w, FxKind.HAND_BLUE, hand(p, -1, 0), 1.0F, merge + 1, p);
        CursedFx red = CursedFx.create(w, FxKind.HAND_RED, hand(p, 1, 0), 1.0F, merge + 1, p);
        red.behavior(f -> f.setPosition(hand(p, 1, Math.max(0, f.age - spread) / (float) (merge - spread))));
        blue.behavior(f -> {
            f.setPosition(hand(p, -1, Math.max(0, f.age - spread) / (float) (merge - spread)));
            if (f.age == merge) {
                CursedFx charge = CursedFx.create(w, FxKind.PURPLE, hand(p, 0, 1), 0.9F, fire - merge + 1, p);
                charge.behavior(c -> {
                    c.setPosition(hand(p, 0, 1));
                    if (c.age == fire - merge) {
                        purple(p, w);
                        MineviaJjk.anim(p, Payloads.Anim.PUNCH_RIGHT);
                        c.discard();
                    }
                });
                w.spawnEntity(charge);
                sound(w, f.getPos(), Sounds.INFINITY, 1.4F, 0.6F);
            }
        });
        w.spawnEntity(blue);
        w.spawnEntity(red);
        p.addStatusEffect(effect(StatusEffects.SLOWNESS, fire, 4));
        MineviaJjk.anim(p, Payloads.Anim.PURPLE);
        sound(w, p.getPos(), Sounds.BLUE, 1.0F, 1.2F);
        sound(w, p.getPos(), Sounds.RED_SHOT, 0.8F, 0.7F);
        return true;
    }

    /** Точка у руки мага: side -1 левая, 1 правая, 0 перед грудью; together 0..1 — насколько руки сведены вперёд. */
    private static Vec3d hand(ServerPlayerEntity p, int side, float together) {
        Vec3d front = Vec3d.fromPolar(0, p.getYaw());
        Vec3d right = new Vec3d(-front.z, 0, front.x);
        float k = MathHelper.clamp(together, 0, 1);
        double out = side * 0.95 * (1 - k);
        double ahead = 0.25 + 0.75 * k;
        return p.getPos().add(right.multiply(out)).add(front.multiply(ahead)).add(0, 1.25 + 0.1 * k, 0);
    }

    private static boolean purple(ServerPlayerEntity p, ServerWorld w) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d start = p.getEyePos().add(look.multiply(1.6));
        CursedFx fx = CursedFx.create(w, FxKind.PURPLE, start, 2.6F, 80, p).velocity(look.multiply(0.85));
        fx.behavior(f -> {
            for (LivingEntity e : targets(w, f.getPos(), 3.6, p)) {
                if (f.hit.add(e.getId())) {
                    e.timeUntilRegen = 0;
                    f.hurt(e, 24);
                }
            }
        });
        w.spawnEntity(fx);
        sound(w, start, Sounds.PURPLE, 2.0F, 1.0F);
        return true;
    }

    /** Красный в упор: взрыв отталкивания прямо перед ладонью, всех впереди отбрасывает далеко. */
    private static boolean redPointBlank(ServerPlayerEntity p, ServerWorld w) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d at = p.getEyePos().add(look.multiply(1.3)).add(0, -0.25, 0);
        w.spawnEntity(CursedFx.create(w, FxKind.RED_BURST, at, 1.2F, 10, p));
        for (LivingEntity e : ahead(p, 4.5, 0.6)) {
            e.timeUntilRegen = 0;
            e.damage(source(p, p), 8);
            Combat.push(e, new Vec3d(look.x * 2.6, 0.6, look.z * 2.6));
            Combat.launched(e, w.getServer().getTicks());
        }
        sound(w, at, Sounds.RED_BOOM, 1.3F, 1.1F);
        return true;
    }

    private static boolean infinity(ServerPlayerEntity p, ServerWorld w, Sorcerer s, long now, boolean strong) {
        int life = strong ? 220 : 100;
        s.infinityUntil = now + life;
        CursedFx fx = CursedFx.create(w, FxKind.INFINITY, p.getPos(), 1.0F, life, p);
        fx.behavior(f -> f.setPosition(p.getPos()));
        w.spawnEntity(fx);
        sound(w, p.getPos(), Sounds.INFINITY, 1.0F, 1.0F);
        return true;
    }

    /** Пока горит Бесконечность: снаряды разворачиваются, враги вплотную отлетают. */
    static void infinityTick(ServerPlayerEntity p) {
        ServerWorld w = p.getServerWorld();
        Box near = p.getBoundingBox().expand(3);
        for (Entity e : w.getOtherEntities(p, near, e -> e instanceof net.minecraft.entity.projectile.ProjectileEntity pr && pr.getOwner() != p)) {
            Vec3d v = e.getVelocity();
            Vec3d toMe = p.getBoundingBox().getCenter().subtract(e.getPos());
            if (v.dotProduct(toMe) > 0) {
                e.setVelocity(v.multiply(-0.25));
                e.velocityModified = true;
            }
        }
        for (LivingEntity e : targets(w, p.getBoundingBox().getCenter(), 1.8, p)) {
            Vec3d away = e.getPos().subtract(p.getPos());
            if (away.lengthSquared() > 1.0E-4) {
                away = away.normalize().multiply(0.35);
                e.addVelocity(away.x, 0.05, away.z);
                e.velocityModified = true;
            }
        }
    }

    // ------------------------------------------------------------------ Святилище

    private static boolean dismantle(ServerPlayerEntity p, ServerWorld w, boolean strong) {
        if (strong) {
            for (int i = -2; i <= 2; i++) {
                slash(p, w, i * 16, 6);
            }
        } else {
            slash(p, w, 0, 7);
        }
        sound(w, p.getPos(), Sounds.SLASH, 1.1F, strong ? 0.85F : 1.0F);
        return true;
    }

    private static void slash(ServerPlayerEntity p, ServerWorld w, float yawOffset, float damage) {
        Vec3d look = Vec3d.fromPolar(p.getPitch(), p.getYaw() + yawOffset);
        Vec3d start = p.getEyePos().add(look.multiply(1.2)).add(0, -0.3, 0);
        CursedFx fx = CursedFx.create(w, FxKind.SLASH, start, 1.5F, 9, p).velocity(look.multiply(1.8)).variant(w.random.nextInt(3));
        fx.setYaw(p.getYaw() + yawOffset);
        fx.behavior(f -> {
            Vec3d now = f.getPos();
            Vec3d before = now.subtract(f.getVelocity());
            for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(before, now).expand(1.4), e -> enemy(e, p))) {
                if (f.hit.add(e.getId())) {
                    f.hurt(e, damage);
                }
            }
            if (blocked(w, before, now, f) != null) {
                f.discard();
            }
        });
        w.spawnEntity(fx);
    }

    private static boolean cleave(ServerPlayerEntity p, ServerWorld w, boolean strong) {
        List<LivingEntity> victims = new ArrayList<>();
        if (strong) {
            victims.addAll(ahead(p, 6, 0.45));
        } else {
            LivingEntity one = aimed(p, 5);
            if (one == null) {
                List<LivingEntity> near = ahead(p, 4.5, 0.6);
                if (!near.isEmpty()) {
                    one = near.get(0);
                }
            }
            if (one != null) {
                victims.add(one);
            }
        }
        if (victims.isEmpty()) {
            p.sendMessage(Text.literal("Рядом некого рассечь"), true);
            return false;
        }
        for (LivingEntity v : victims) {
            float share = v instanceof PlayerEntity ? 0.12F : 0.22F;
            float damage = Math.min(22, 4 + share * v.getMaxHealth());
            v.timeUntilRegen = 0;
            v.damage(source(p, p), damage);
            CursedFx cut = CursedFx.create(w, FxKind.CLEAVE, v.getBoundingBox().getCenter(), v.getHeight() * 0.8F + 0.5F, 10, p)
                    .variant(w.random.nextInt(3));
            w.spawnEntity(cut);
        }
        sound(w, victims.get(0).getPos(), Sounds.CLEAVE, 1.3F, 1.0F);
        return true;
    }

    private static boolean flameArrow(ServerPlayerEntity p, ServerWorld w, boolean strong) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d start = p.getEyePos().add(look.multiply(1.2)).add(0, -0.2, 0);
        float radius = strong ? 6.5F : 4;
        float damage = strong ? 12 : 8;
        CursedFx fx = CursedFx.create(w, FxKind.FLAME_ARROW, start, strong ? 1.3F : 0.9F, 40, p).velocity(look.multiply(1.3));
        fx.behavior(f -> {
            if (impact(w, f, p, 0.8) || f.age >= f.life()) {
                Vec3d at = f.getPos();
                w.spawnEntity(CursedFx.create(w, FxKind.FLAME_BURST, at, strong ? 2.2F : 1.4F, 14, p));
                for (LivingEntity e : targets(w, at, radius, p)) {
                    f.hurt(e, damage);
                    e.setOnFireFor(5);
                }
                sound(w, at, Sounds.FLAME_BOOM, 1.4F, strong ? 0.85F : 1.0F);
                f.discard();
            }
        });
        w.spawnEntity(fx);
        sound(w, p.getPos(), Sounds.FLAME_SHOT, 1.0F, 1.0F);
        return true;
    }

    // ------------------------------------------------------------------ Десять теней

    private static boolean dogs(ServerPlayerEntity p, ServerWorld w, boolean strong) {
        dismissDogs(p);
        LivingEntity target = aimed(p, 24);
        if (target == null) {
            target = w.getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(12), e -> e instanceof Monster && enemy(e, p))
                    .stream().min(Comparator.comparingDouble(e -> e.squaredDistanceTo(p))).orElse(null);
        }
        int count = strong ? 4 : 2;
        for (int i = 0; i < count; i++) {
            ShadowDog dog = MineviaJjk.SHADOW_DOG.create(w);
            if (dog == null) {
                continue;
            }
            float side = (i % 2 == 0 ? -1 : 1) * (60 + 20 * (i / 2));
            Vec3d at = p.getPos().add(Vec3d.fromPolar(0, p.getYaw() + side).multiply(1.6 + 0.8 * (i / 2)));
            dog.refreshPositionAndAngles(at.x, at.y, at.z, p.getYaw(), 0);
            if (!w.isSpaceEmpty(dog)) {
                dog.refreshPositionAndAngles(p.getX(), p.getY(), p.getZ(), p.getYaw(), 0);
            }
            dog.setup(p, strong ? 800 : 600, strong);
            w.spawnEntity(dog);
            if (target != null) {
                dog.setTarget(target);
            }
            w.spawnEntity(CursedFx.create(w, FxKind.SHADOW_POOL, dog.getPos(), 1.0F, 16, p));
        }
        sound(w, p.getPos(), SoundEvents.ENTITY_WOLF_GROWL, 1.0F, 0.7F);
        sound(w, p.getPos(), Sounds.DOGS, 1.0F, 1.0F);
        return true;
    }

    static void dismissDogs(ServerPlayerEntity p) {
        for (ShadowDog dog : p.getServerWorld().getEntitiesByClass(ShadowDog.class, p.getBoundingBox().expand(64),
                d -> p.getUuid().equals(d.getOwnerUuid()))) {
            dog.vanish();
        }
    }

    private static boolean nue(ServerPlayerEntity p, ServerWorld w, boolean strong) {
        LivingEntity target = aimedOrAhead(p, 28);
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d at = target != null ? target.getPos() : ground(w, aimPoint(p, 24));
        Vec3d top = at.add(-look.x * 4, 7, -look.z * 4);
        int dive = 10;
        float radius = strong ? 4.5F : 1.8F;
        float damage = strong ? 10 : 8;
        CursedFx fx = CursedFx.create(w, FxKind.NUE, top, 1.5F, 26, p);
        fx.setYaw(p.getYaw());
        fx.from = top;
        fx.to = at.add(0, 0.8, 0);
        fx.behavior(f -> {
            if (f.age < dive) {
                if (target != null && target.isAlive()) {
                    f.to = target.getPos().add(0, 0.8, 0);
                }
                double k = f.age / (double) dive;
                f.setPosition(f.from.lerp(f.to, k * k));
            } else if (f.age == dive) {
                f.setPosition(f.to);
                Vec3d ground = f.to.add(0, -0.8, 0);
                w.spawnEntity(CursedFx.create(w, FxKind.NUE_STRIKE, ground, strong ? 1.6F : 1.0F, 10, p));
                for (LivingEntity e : targets(w, f.to, radius, p)) {
                    f.hurt(e, damage);
                    e.addStatusEffect(effect(StatusEffects.SLOWNESS, 60, 2), p);
                }
                sound(w, ground, Sounds.THUNDER, 1.4F, strong ? 0.85F : 1.0F);
            } else {
                int after = f.age - dive;
                f.setPosition(f.to.add(look.x * after * 0.9, after * 0.7, look.z * after * 0.9));
            }
        });
        w.spawnEntity(fx);
        sound(w, top, Sounds.NUE, 1.3F, 1.0F);
        return true;
    }

    private static boolean shadowStep(ServerPlayerEntity p, ServerWorld w, boolean strong) {
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d flat = new Vec3d(look.x, Math.max(-0.3, Math.min(0.3, look.y)), look.z);
        if (flat.lengthSquared() < 1.0E-4) {
            return false;
        }
        flat = flat.normalize();
        double max = strong ? 14 : 8;
        Vec3d start = p.getPos();
        Vec3d best = start;
        // Тень стелется по земле: на уступ в блок поднимается, с уступа спускается, в стену не идёт.
        for (double d = 0.5; d <= max; d += 0.5) {
            Vec3d ahead = best.add(flat.multiply(0.5));
            Vec3d found = null;
            for (double up : new double[] {0, 1, -1}) {
                Vec3d candidate = ahead.add(0, up, 0);
                if (w.isSpaceEmpty(p, p.getBoundingBox().offset(candidate.subtract(start)))) {
                    found = candidate;
                    break;
                }
            }
            if (found == null) {
                break;
            }
            best = found;
        }
        if (best.squaredDistanceTo(start) < 1) {
            p.sendMessage(Text.literal("Тени некуда вести"), true);
            return false;
        }
        w.spawnEntity(CursedFx.create(w, FxKind.SHADOW_POOL, start, 1.1F, 16, p));
        w.spawnEntity(CursedFx.create(w, FxKind.SHADOW_POOL, best, 1.1F, 16, p));
        if (strong) {
            for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(start, best).expand(1.2, 1.5, 1.2), e -> enemy(e, p))) {
                e.damage(source(p, p), 6);
            }
        }
        p.requestTeleport(best.x, best.y, best.z);
        p.fallDistance = 0;
        p.setVelocity(flat.multiply(0.3));
        p.velocityModified = true;
        p.addStatusEffect(effect(StatusEffects.INVISIBILITY, 20, 0));
        sound(w, start, Sounds.SHADOW_STEP, 1.0F, 1.0F);
        sound(w, best, Sounds.SHADOW_STEP, 0.7F, 1.15F);
        return true;
    }

    /** Шквал ударов Годжо: семь быстрых ударов с синими вспышками и пинок, отбрасывающий вверх. */
    private static boolean gojoBarrage(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = melee(p, 4.5);
        if (target == null) {
            p.sendMessage(Text.literal("Некого бить"), true);
            return false;
        }
        CursedFx fists = CursedFx.create(w, FxKind.GOJO_BARRAGE, p.getEyePos().add(0, -0.4, 0), 1.0F, 16, p);
        fists.setYaw(p.getYaw());
        fists.setPitch(p.getPitch());
        w.spawnEntity(fists);
        CursedFx fx = CursedFx.create(w, FxKind.IMPACT, target.getBoundingBox().getCenter(), 0.6F, 22, p).variant(2);
        fx.behavior(f -> {
            if (!target.isAlive() || target.squaredDistanceTo(p) > 36) {
                f.discard();
                return;
            }
            f.setPosition(target.getBoundingBox().getCenter());
            if (f.age % 2 == 0 && f.age <= 14) {
                target.timeUntilRegen = 0;
                f.hurt(target, 1.5F);
                Combat.push(target, Vec3d.ZERO);
                w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, target.getBoundingBox().getCenter(), 0.7F, 4, p).variant(2));
                MineviaJjk.anim(p, f.age % 4 == 0 ? Payloads.Anim.PUNCH_LEFT : Payloads.Anim.PUNCH_RIGHT);
                sound(w, target.getPos(), Sounds.HIT_LIGHT, 0.9F, 1.1F + f.age * 0.02F);
            } else if (f.age == 18) {
                Vec3d look = p.getRotationVec(1.0F);
                target.timeUntilRegen = 0;
                f.hurt(target, 5);
                Combat.push(target, new Vec3d(look.x * 1.6, 0.9, look.z * 1.6));
                Combat.launched(target, w.getServer().getTicks());
                MineviaJjk.anim(p, Payloads.Anim.KICK);
                w.spawnEntity(kickArc(w, p));
                sound(w, target.getPos(), Sounds.KICK, 1.2F, 1.0F);
            }
        });
        w.spawnEntity(fx);
        return true;
    }

    // ------------------------------------------------------------------ Итадори

    /** Враг для удара рукой: под прицелом, а если мимо — ближайший впереди. */
    private static LivingEntity melee(ServerPlayerEntity p, double reach) {
        LivingEntity target = aimedOrAhead(p, reach);
        if (target == null) {
            List<LivingEntity> near = ahead(p, reach, 0.5);
            target = near.isEmpty() ? null : near.get(0);
        }
        return target;
    }

    private static Vec3d fist(ServerPlayerEntity p) {
        return p.getEyePos().add(p.getRotationVec(1.0F).multiply(1.0)).add(0, -0.35, 0);
    }

    private static CursedFx kickArc(ServerWorld w, ServerPlayerEntity p) {
        CursedFx arc = CursedFx.create(w, FxKind.KICK_ARC, p.getPos().add(Vec3d.fromPolar(0, p.getYaw()).multiply(0.8)).add(0, 0.9, 0), 1.0F, 10, p);
        arc.setYaw(p.getYaw());
        return arc;
    }

    /** Дивергентный кулак: удар, а через треть секунды по тому же месту второй — проклятая энергия догоняет кулак. */
    private static boolean divergentFist(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = melee(p, 4.5);
        Vec3d look = p.getRotationVec(1.0F);
        CursedFx fx = CursedFx.create(w, FxKind.DIVERGENT, fist(p), 1.0F, 16, p);
        fx.setYaw(p.getYaw());
        fx.setPitch(p.getPitch());
        fx.behavior(f -> {
            if (target == null || !target.isAlive()) {
                return;
            }
            if (f.age == 1) {
                target.timeUntilRegen = 0;
                f.hurt(target, 5);
                Combat.push(target, look.multiply(0.15));
            } else if (f.age == 7) {
                target.timeUntilRegen = 0;
                f.hurt(target, 6);
                Combat.push(target, new Vec3d(look.x * 1.3, 0.35, look.z * 1.3));
                w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, target.getBoundingBox().getCenter(), 1.2F, 6, p).variant(2));
                sound(w, target.getPos(), Sounds.HIT_HEAVY, 1.2F, 0.8F);
            }
        });
        w.spawnEntity(fx);
        MineviaJjk.anim(p, Payloads.Anim.PUNCH_RIGHT);
        sound(w, p.getPos(), Sounds.HIT_LIGHT, 1.0F, 0.9F);
        return true;
    }

    /** Рывок с ударом: бросок вперёд, первого встречного сбивает. */
    private static boolean rushStrike(ServerPlayerEntity p, ServerWorld w) {
        Vec3d dir = Vec3d.fromPolar(0, p.getYaw());
        p.setVelocity(dir.x * 2.1, 0.12, dir.z * 2.1);
        p.velocityModified = true;
        CursedFx trail = CursedFx.create(w, FxKind.DASH_TRAIL, p.getPos().add(0, 0.9, 0), 1.0F, 12, p);
        trail.setYaw(p.getYaw());
        trail.behavior(f -> {
            f.setPosition(p.getPos().add(0, 0.9, 0));
            if (!f.hit.isEmpty() || f.age > 8) {
                return;
            }
            for (LivingEntity e : targets(w, p.getBoundingBox().getCenter(), 1.8, p)) {
                f.hit.add(e.getId());
                e.timeUntilRegen = 0;
                e.damage(source(p, p), 6);
                Combat.push(e, new Vec3d(dir.x * 1.5, 0.4, dir.z * 1.5));
                w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, e.getBoundingBox().getCenter(), 1.1F, 6, p).variant(0));
                sound(w, e.getPos(), Sounds.HIT_HEAVY, 1.1F, 1.0F);
                MineviaJjk.anim(p, Payloads.Anim.PUNCH_LEFT);
                p.setVelocity(p.getVelocity().multiply(0.2));
                p.velocityModified = true;
                break;
            }
        });
        w.spawnEntity(trail);
        MineviaJjk.anim(p, Payloads.Anim.DASH);
        sound(w, p.getPos(), Sounds.DASH, 1.0F, 0.9F);
        return true;
    }

    /** Серия: четыре быстрых удара держат врага, пинок в конце подбрасывает его. */
    private static boolean flurryKick(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = melee(p, 4.0);
        if (target == null) {
            p.sendMessage(Text.literal("Некого бить"), true);
            return false;
        }
        CursedFx fx = CursedFx.create(w, FxKind.IMPACT, target.getBoundingBox().getCenter(), 0.7F, 16, p).variant(0);
        fx.behavior(f -> {
            if (!target.isAlive() || target.squaredDistanceTo(p) > 36) {
                f.discard();
                return;
            }
            f.setPosition(target.getBoundingBox().getCenter());
            if (f.age % 3 == 0 && f.age <= 9) {
                target.timeUntilRegen = 0;
                f.hurt(target, 2);
                Combat.push(target, Vec3d.ZERO);
                MineviaJjk.anim(p, f.age % 6 == 0 ? Payloads.Anim.PUNCH_LEFT : Payloads.Anim.PUNCH_RIGHT);
                sound(w, target.getPos(), Sounds.HIT_LIGHT, 0.9F, 1.0F + f.age * 0.02F);
            } else if (f.age == 13) {
                Vec3d look = p.getRotationVec(1.0F);
                target.timeUntilRegen = 0;
                f.hurt(target, 4);
                Combat.push(target, new Vec3d(look.x * 0.9, 1.0, look.z * 0.9));
                Combat.launched(target, w.getServer().getTicks());
                MineviaJjk.anim(p, Payloads.Anim.KICK);
                w.spawnEntity(kickArc(w, p));
                sound(w, target.getPos(), Sounds.KICK, 1.2F, 1.0F);
            }
        });
        w.spawnEntity(fx);
        return true;
    }

    /** Чёрная вспышка по своей воле: удар в упор с искажением, урон в разы больше. */
    private static boolean blackFlashStrike(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = melee(p, 4.5);
        if (target == null) {
            p.sendMessage(Text.literal("Некого бить"), true);
            return false;
        }
        Vec3d look = p.getRotationVec(1.0F);
        target.timeUntilRegen = 0;
        target.damage(source(p, p), 6);
        blackFlash(p, target, 6);
        Combat.push(target, new Vec3d(look.x * 2.2, 0.5, look.z * 2.2));
        MineviaJjk.anim(p, Payloads.Anim.PUNCH_RIGHT);
        if (ServerPlayNetworking.canSend(p, Payloads.Flash.ID)) {
            ServerPlayNetworking.send(p, new Payloads.Flash());
        }
        return true;
    }

    /** Бросок на R: хватает врага перед собой и подкидывает — дальше пинок в воздухе. */
    private static boolean grabThrow(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = melee(p, 3.5);
        if (target == null) {
            p.sendMessage(Text.literal("Некого схватить"), true);
            return false;
        }
        Vec3d look = Vec3d.fromPolar(0, p.getYaw());
        target.timeUntilRegen = 0;
        target.damage(source(p, p), 3);
        Combat.push(target, new Vec3d(look.x * 0.35, 1.05, look.z * 0.35));
        Combat.launched(target, w.getServer().getTicks());
        w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, target.getBoundingBox().getCenter(), 1.0F, 6, p).variant(0));
        MineviaJjk.anim(p, Payloads.Anim.UPPERCUT);
        sound(w, target.getPos(), Sounds.HIT_HEAVY, 1.0F, 1.2F);
        return true;
    }

    /** Ульта: у Итадори Сукуна берёт тело, у остальных — всплеск силы. Шкала тает, пока ульта держится. */
    private static boolean awaken(ServerPlayerEntity p, ServerWorld w, Sorcerer s, long now, Technique technique) {
        MineviaJjk.startUlt(p, s, now);
        if (technique == Technique.ITADORI) {
            w.spawnEntity(CursedFx.create(w, FxKind.SUKUNA_AWAKEN, p.getPos(), 1.0F, 30, p));
            sound(w, p.getPos(), Sounds.BLACK_FLASH, 1.2F, 0.6F);
        } else {
            w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, p.getPos().add(0, 1, 0), 2.2F, 10, p).variant(2));
        }
        sound(w, p.getPos(), Sounds.DOMAIN, 1.6F, 1.3F);
        MineviaJjk.anim(p, Payloads.Anim.CAST);
        return true;
    }

    // ------------------------------------------------------------------ Наоя

    /** Проекция: рывок на огромной скорости, все на пути получают удар. */
    private static boolean projection(ServerPlayerEntity p, ServerWorld w) {
        Vec3d dir = Vec3d.fromPolar(0, p.getYaw());
        p.setVelocity(dir.x * 3.8, 0.1, dir.z * 3.8);
        p.velocityModified = true;
        p.fallDistance = 0;
        MineviaJjk.sorcerer(p).invulnUntil = w.getServer().getTicks() + 14;
        CursedFx trail = CursedFx.create(w, FxKind.SPEED_RIBBONS, p.getPos().add(0, 0.9, 0), 1.0F, 14, p);
        trail.setYaw(p.getYaw());
        trail.behavior(f -> {
            f.setPosition(p.getPos().add(0, 0.9, 0));
            if (f.age > 11) {
                return;
            }
            for (LivingEntity e : targets(w, p.getBoundingBox().getCenter(), 2.2, p)) {
                if (f.hit.add(e.getId())) {
                    e.timeUntilRegen = 0;
                    e.damage(source(p, p), 4);
                    Combat.push(e, new Vec3d(dir.x * 0.6, 0.3, dir.z * 0.6));
                    w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, e.getBoundingBox().getCenter(), 0.9F, 5, p).variant(3));
                    sound(w, e.getPos(), Sounds.HIT_LIGHT, 1.0F, 1.3F);
                }
            }
        });
        w.spawnEntity(trail);
        MineviaJjk.anim(p, Payloads.Anim.DASH);
        sound(w, p.getPos(), Sounds.DASH, 1.1F, 1.4F);
        return true;
    }

    /** Застывший кадр: кого Наоя коснулся, застывает в плоской рамке на две секунды, а потом рамка лопается. */
    private static boolean freezeFrame(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = melee(p, 9.0);
        if (target == null) {
            p.sendMessage(Text.literal("Некого запереть в кадре"), true);
            return false;
        }
        Vec3d hold = target.getPos();
        int life = 40;
        CursedFx frame = CursedFx.create(w, FxKind.PROJECTION_FRAME, target.getPos(), Math.max(1.0F, target.getHeight() / 1.8F), life, p);
        frame.setYaw(p.getYaw());
        frame.behavior(f -> {
            if (!target.isAlive()) {
                f.discard();
                return;
            }
            target.setVelocity(Vec3d.ZERO);
            target.velocityModified = true;
            if (target instanceof ServerPlayerEntity player) {
                if (player.squaredDistanceTo(hold) > 0.04) {
                    player.requestTeleport(hold.x, hold.y, hold.z);
                }
            } else {
                target.setPosition(hold);
                if (target instanceof MobEntity mob) {
                    mob.getNavigation().stop();
                }
            }
            if (f.age == life - 1) {
                target.timeUntilRegen = 0;
                f.hurt(target, 6);
                sound(w, target.getPos(), Sounds.PARRY, 1.2F, 0.7F);
            }
        });
        target.timeUntilRegen = 0;
        target.damage(source(p, p), 2);
        target.addStatusEffect(effect(StatusEffects.SLOWNESS, life, 9), p);
        w.spawnEntity(frame);
        MineviaJjk.anim(p, Payloads.Anim.PUNCH_RIGHT);
        sound(w, target.getPos(), Sounds.TELEPORT, 1.2F, 1.5F);
        return true;
    }

    /** Очередь кадров: шесть ударов за полсекунды с разных сторон. */
    private static boolean frameBarrage(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = melee(p, 9.0);
        if (target == null) {
            p.sendMessage(Text.literal("Некого бить"), true);
            return false;
        }
        CursedFx fx = CursedFx.create(w, FxKind.SPEED_RIBBONS, target.getBoundingBox().getCenter(), 0.8F, 14, p);
        fx.behavior(f -> {
            if (!target.isAlive()) {
                f.discard();
                return;
            }
            f.setPosition(target.getBoundingBox().getCenter());
            f.setYaw(f.getYaw() + 60);
            if (f.age % 2 == 0 && f.age <= 12) {
                target.timeUntilRegen = 0;
                f.hurt(target, 2);
                Combat.push(target, Vec3d.ZERO);
                w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, target.getBoundingBox().getCenter(), 0.8F, 4, p).variant(f.age % 4 == 0 ? 0 : 3));
                MineviaJjk.anim(p, f.age % 4 == 0 ? Payloads.Anim.PUNCH_LEFT : Payloads.Anim.PUNCH_RIGHT);
                sound(w, target.getPos(), Sounds.HIT_LIGHT, 0.9F, 1.2F + f.age * 0.03F);
            }
        });
        w.spawnEntity(fx);
        return true;
    }

    /** Сверхзвук: удар быстрее звука, ударная волна сносит всех в конусе впереди. */
    private static boolean sonicBoom(ServerPlayerEntity p, ServerWorld w) {
        Vec3d look = p.getRotationVec(1.0F);
        CursedFx boom = CursedFx.create(w, FxKind.SONIC_BOOM, p.getEyePos().add(look.multiply(1.4)).add(0, -0.3, 0), 1.0F, 12, p);
        boom.setYaw(p.getYaw());
        boom.setPitch(p.getPitch());
        w.spawnEntity(boom);
        for (LivingEntity e : ahead(p, 10, 0.75)) {
            e.timeUntilRegen = 0;
            e.damage(source(p, p), 9);
            Combat.push(e, new Vec3d(look.x * 2.4, 0.45, look.z * 2.4));
            Combat.launched(e, w.getServer().getTicks());
        }
        MineviaJjk.anim(p, Payloads.Anim.PUNCH_RIGHT);
        sound(w, p.getPos(), Sounds.RED_BOOM, 1.3F, 1.4F);
        sound(w, p.getPos(), Sounds.HIT_HEAVY, 1.3F, 0.8F);
        return true;
    }

    // ------------------------------------------------------------------ особые удары ульты

    /**
     * Махорага (ульта Мегуми): огромный шикигами встаёт из тени за спиной, заносит меч и рубит всё впереди.
     * Сам по миру не ходит: появился, ударил, ушёл в тень.
     */
    private static boolean mahoraga(ServerPlayerEntity p, ServerWorld w) {
        Vec3d front = Vec3d.fromPolar(0, p.getYaw());
        Vec3d at = p.getPos().subtract(front.multiply(1.5));
        CursedFx giant = CursedFx.create(w, FxKind.MAHORAGA, at, 1.0F, 60, p);
        giant.setYaw(p.getYaw());
        giant.behavior(f -> {
            if (f.age == 28) {
                Vec3d look = p.getRotationVec(1.0F);
                for (LivingEntity e : ahead(p, 9, 0.55)) {
                    e.timeUntilRegen = 0;
                    f.hurt(e, 14);
                    Combat.push(e, new Vec3d(look.x * 2.4, 0.7, look.z * 2.4));
                    Combat.launched(e, w.getServer().getTicks());
                    w.spawnEntity(CursedFx.create(w, FxKind.CLEAVE, e.getBoundingBox().getCenter(), e.getHeight() + 0.6F, 10, p)
                            .variant(w.random.nextInt(3)));
                }
                sound(w, p.getPos(), Sounds.HIT_HEAVY, 2.0F, 0.5F);
                sound(w, p.getPos(), Sounds.CLEAVE, 1.6F, 0.6F);
            }
        });
        w.spawnEntity(giant);
        w.spawnEntity(CursedFx.create(w, FxKind.SHADOW_POOL, at, 2.4F, 60, p));
        sound(w, at, Sounds.SHADOW_STEP, 1.6F, 0.5F);
        sound(w, at, Sounds.DOMAIN, 1.2F, 0.6F);
        return true;
    }

    /**
     * 24 кадра (ульта Наои): за мгновение Наоя проходит через всех врагов рядом, каждый застывает в кадре,
     * а через полторы секунды все кадры лопаются разом.
     */
    private static boolean twentyFourFrames(ServerPlayerEntity p, ServerWorld w) {
        List<LivingEntity> victims = targets(w, p.getPos(), 12, p);
        victims.removeIf(e -> !p.canSee(e));
        if (victims.isEmpty()) {
            p.sendMessage(Text.literal("Некого запереть в кадре"), true);
            return false;
        }
        int life = 60;
        for (int i = 0; i < Math.min(12, victims.size()); i++) {
            LivingEntity target = victims.get(i);
            Vec3d hold = target.getPos();
            CursedFx frame = CursedFx.create(w, FxKind.PROJECTION_FRAME, hold, Math.max(1.0F, target.getHeight() / 1.8F), life, p);
            frame.setYaw(p.getYaw() + i * 37);
            frame.behavior(f -> {
                if (!target.isAlive()) {
                    f.discard();
                    return;
                }
                target.setVelocity(Vec3d.ZERO);
                target.velocityModified = true;
                if (!(target instanceof ServerPlayerEntity)) {
                    target.setPosition(hold);
                }
                if (f.age == life - 1) {
                    target.timeUntilRegen = 0;
                    f.hurt(target, 16);
                    w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, target.getBoundingBox().getCenter(), 1.2F, 6, p).variant(3));
                }
            });
            target.addStatusEffect(effect(StatusEffects.SLOWNESS, life, 9), p);
            w.spawnEntity(frame);
            CursedFx trail = CursedFx.create(w, FxKind.SPEED_RIBBONS, hold.add(0, 0.9, 0), 0.9F, 10, p);
            trail.setYaw(p.getYaw() + i * 53);
            w.spawnEntity(trail);
        }
        // Наоя оказывается за спиной последнего.
        LivingEntity last = victims.get(Math.min(12, victims.size()) - 1);
        Vec3d away = last.getPos().subtract(p.getPos());
        Vec3d to = last.getPos().add(away.lengthSquared() < 1.0E-4 ? Vec3d.ZERO : away.normalize().multiply(1.2));
        if (w.isSpaceEmpty(p, p.getBoundingBox().offset(to.subtract(p.getPos())))) {
            p.teleport(w, to.x, to.y, to.z, java.util.Set.of(), p.getYaw() + 180, p.getPitch());
        }
        sound(w, p.getPos(), Sounds.TELEPORT, 1.4F, 1.6F);
        sound(w, p.getPos(), Sounds.PARRY, 1.2F, 0.6F);
        MineviaJjk.anim(p, Payloads.Anim.DASH);
        return true;
    }

    // ------------------------------------------------------------------ особые навыки (R)

    /** Безграничность: мгновенно за спину врагу под прицелом, даже в воздух к подброшенному, — и сразу бить. */
    private static boolean teleport(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = aimedOrAhead(p, 24);
        if (target == null) {
            // Подброшенный враг часто выше прицела: берём ближайшего рядом.
            target = targets(w, p.getEyePos(), 8, p).stream().filter(p::canSee)
                    .min(Comparator.comparingDouble(e -> e.squaredDistanceTo(p))).orElse(null);
        }
        Vec3d start = p.getPos();
        Vec3d to;
        float yaw = p.getYaw();
        float pitch = p.getPitch();
        if (target != null) {
            Vec3d flat = new Vec3d(target.getX() - p.getX(), 0, target.getZ() - p.getZ());
            flat = flat.lengthSquared() < 1.0E-4 ? Vec3d.fromPolar(0, p.getYaw()) : flat.normalize();
            to = target.getPos().add(flat.multiply(target.getWidth() * 0.5 + 0.9));
            if (!w.isSpaceEmpty(p, p.getBoundingBox().offset(to.subtract(start)))) {
                to = target.getPos().subtract(flat.multiply(target.getWidth() * 0.5 + 0.9));
            }
            Vec3d look = target.getBoundingBox().getCenter().subtract(to.add(0, p.getStandingEyeHeight(), 0));
            yaw = (float) Math.toDegrees(Math.atan2(-look.x, look.z));
            pitch = (float) -Math.toDegrees(Math.atan2(look.y, look.horizontalLength()));
        } else {
            Vec3d point = aimPoint(p, 12);
            to = point.subtract(0, p.getStandingEyeHeight() * 0.5, 0);
        }
        if (!w.isSpaceEmpty(p, p.getBoundingBox().offset(to.subtract(start)))) {
            p.sendMessage(Text.literal("Туда не переместиться"), true);
            return false;
        }
        w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, start.add(0, 1, 0), 1.0F, 6, p).variant(3));
        p.teleport(w, to.x, to.y, to.z, java.util.Set.of(), yaw, pitch);
        p.setVelocity(Vec3d.ZERO);
        p.velocityModified = true;
        p.fallDistance = 0;
        w.spawnEntity(CursedFx.create(w, FxKind.IMPACT, to.add(0, 1, 0), 1.0F, 6, p).variant(3));
        sound(w, start, Sounds.TELEPORT, 1.0F, 1.0F);
        sound(w, to, Sounds.TELEPORT, 1.0F, 1.2F);
        return true;
    }

    /** Святилище: прыжок к врагу под прицелом, на подлёте удар, который подбрасывает его вверх. */
    private static boolean leap(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = aimedOrAhead(p, 16);
        Vec3d dir;
        if (target != null) {
            Vec3d between = target.getPos().subtract(p.getPos());
            double flat = Math.max(0.01, Math.sqrt(between.x * between.x + between.z * between.z));
            dir = new Vec3d(between.x / flat, 0, between.z / flat).multiply(Math.min(1.9, 0.35 + flat * 0.11));
        } else {
            dir = Vec3d.fromPolar(0, p.getYaw()).multiply(1.3);
        }
        Vec3d push = dir;
        p.setVelocity(push.x, 0.55, push.z);
        p.velocityModified = true;
        p.fallDistance = 0;
        CursedFx fx = CursedFx.create(w, FxKind.IMPACT, p.getPos(), 0.6F, 18, p).variant(0);
        fx.behavior(f -> {
            f.setPosition(p.getPos());
            if (!f.hit.isEmpty()) {
                return;
            }
            for (LivingEntity e : targets(w, p.getBoundingBox().getCenter(), 2.2, p)) {
                f.hit.add(e.getId());
                e.timeUntilRegen = 0;
                e.damage(source(p, p), 6);
                e.setVelocity(push.x * 0.2, 0.95, push.z * 0.2);
                e.velocityModified = true;
                Combat.launched(e, w.getServer().getTicks());
                w.spawnEntity(CursedFx.create(w, FxKind.CLEAVE, e.getBoundingBox().getCenter(), e.getHeight() * 0.8F + 0.5F, 10, p)
                        .variant(w.random.nextInt(3)));
                sound(w, e.getPos(), Sounds.CLEAVE, 1.2F, 1.1F);
                p.setVelocity(p.getVelocity().multiply(0.3, 0.5, 0.3));
                p.velocityModified = true;
                break;
            }
        });
        w.spawnEntity(fx);
        sound(w, p.getPos(), Sounds.DASH, 1.0F, 0.8F);
        return true;
    }

    /** Десять теней: жаба из тени хватает врага языком и подтаскивает к тебе — под серию ударов. */
    private static boolean toad(ServerPlayerEntity p, ServerWorld w) {
        LivingEntity target = aimedOrAhead(p, 20);
        if (target == null) {
            p.sendMessage(Text.literal("Жабе некого схватить"), true);
            return false;
        }
        Vec3d front = Vec3d.fromPolar(0, p.getYaw());
        Vec3d mouth = p.getPos().add(front.multiply(0.8)).add(0, 0.9, 0);
        Vec3d to = target.getBoundingBox().getCenter().subtract(mouth);
        CursedFx tongue = CursedFx.create(w, FxKind.TONGUE, mouth, 1.0F, 8, p).variant((int) Math.min(120, Math.ceil(to.length())));
        tongue.setYaw((float) Math.toDegrees(Math.atan2(-to.x, to.z)));
        tongue.setPitch((float) -Math.toDegrees(Math.atan2(to.y, to.horizontalLength())));
        w.spawnEntity(tongue);
        w.spawnEntity(CursedFx.create(w, FxKind.SHADOW_POOL, p.getPos().add(front.multiply(0.8)), 0.9F, 16, p));
        Vec3d pull = to.multiply(-1).normalize();
        double speed = Math.min(2.2, 0.4 + to.length() * 0.16);
        target.setVelocity(pull.x * speed, 0.3, pull.z * speed);
        target.velocityModified = true;
        target.damage(source(p, p), 2);
        target.addStatusEffect(effect(StatusEffects.SLOWNESS, 20, 3), p);
        sound(w, mouth, Sounds.TOAD, 1.2F, 1.0F);
        return true;
    }

    // ------------------------------------------------------------------ расширение территории

    /** Территория держится 18 секунд. */
    static final int DOMAIN_TICKS = 20 * 18;

    private static boolean domain(ServerPlayerEntity p, ServerWorld w, Sorcerer s, Technique technique, long now) {
        if (s.domainTechnique != null) {
            return false;
        }
        int duration;
        float radius;
        FxKind kind;
        switch (technique) {
            case LIMITLESS -> {
                radius = 12;
                duration = DOMAIN_TICKS;
                kind = FxKind.VOID_DOME;
            }
            case SUKUNA, ITADORI -> {
                radius = 16;
                duration = DOMAIN_TICKS;
                kind = FxKind.SHRINE_POOL;
            }
            case NAOYA -> {
                radius = 12;
                duration = DOMAIN_TICKS;
                kind = FxKind.NAOYA_DOMAIN;
            }
            default -> {
                radius = 14;
                duration = DOMAIN_TICKS;
                kind = FxKind.SHADOW_GARDEN;
            }
        }
        s.domainTechnique = technique;
        s.domainCenter = p.getPos();
        s.domainWorld = w.getRegistryKey();
        s.domainRadius = radius;
        s.domainStart = now;
        s.domainUntil = now + duration;
        w.spawnEntity(CursedFx.create(w, kind, p.getPos(), radius, duration, p));
        if (kind == FxKind.SHRINE_POOL) {
            // Под ногами красная гладь, за спиной Сукуны — сама Гробница.
            Vec3d back = Vec3d.fromPolar(0, p.getYaw()).multiply(-6);
            CursedFx shrine = CursedFx.create(w, FxKind.SHRINE, ground(w, p.getPos().add(back).add(0, 1, 0)), radius, duration, p);
            shrine.setYaw(p.getYaw());
            w.spawnEntity(shrine);
        }
        if (technique == Technique.SHADOWS) {
            dogs(p, w, false);
        }
        Text name = Text.translatable("minevia_jjk.msg.domain", Text.translatable("minevia_jjk.domain." + technique.id())).withColor(technique.color());
        for (ServerPlayerEntity other : w.getPlayers(o -> o.squaredDistanceTo(s.domainCenter) < (radius + 16) * (radius + 16))) {
            other.sendMessage(name, true);
        }
        sound(w, p.getPos(), Sounds.DOMAIN, 3.0F, 1.0F);
        return true;
    }

    static void domainTick(ServerPlayerEntity p, Sorcerer s, long now) {
        if (s.domainTechnique == null) {
            return;
        }
        if (now >= s.domainUntil || p.getWorld().getRegistryKey() != s.domainWorld) {
            s.domainTechnique = null;
            return;
        }
        ServerWorld w = p.getServerWorld();
        long t = now - s.domainStart;
        // Пустоте враги нужны каждый тик, Гробнице раз в 8 тиков, Саду раз в 20: зря по миру не ищем.
        boolean needed = switch (s.domainTechnique) {
            case LIMITLESS -> true;
            case SUKUNA, ITADORI -> t % 8 == 0;
            case SHADOWS, NAOYA -> t % 10 == 0;
        };
        if (!needed) {
            return;
        }
        List<LivingEntity> inside = targets(w, s.domainCenter, s.domainRadius, p);
        boolean ownerInside = p.squaredDistanceTo(s.domainCenter) < s.domainRadius * s.domainRadius;
        switch (s.domainTechnique) {
            case LIMITLESS -> {
                for (LivingEntity e : inside) {
                    e.setVelocity(0, Math.min(0, e.getVelocity().y), 0);
                    e.velocityModified = true;
                    if (e instanceof MobEntity mob) {
                        mob.getNavigation().stop();
                    }
                    if (t % 20 == 0) {
                        e.addStatusEffect(effect(StatusEffects.SLOWNESS, 30, 9), p);
                        e.addStatusEffect(effect(StatusEffects.MINING_FATIGUE, 30, 3), p);
                        e.addStatusEffect(effect(StatusEffects.WEAKNESS, 30, 3), p);
                    }
                }
                if (ownerInside && t % 20 == 0) {
                    p.addStatusEffect(effect(StatusEffects.STRENGTH, 30, 1));
                }
            }
            case SUKUNA, ITADORI -> {
                if (t % 8 == 0) {
                    int shown = 0;
                    for (LivingEntity e : inside) {
                        e.timeUntilRegen = 0;
                        e.damage(source(p, p), 1.5F);
                        if (shown++ < 8) {
                            w.spawnEntity(CursedFx.create(w, FxKind.SHRINE_CUT, e.getBoundingBox().getCenter(), e.getHeight() * 0.7F + 0.4F, 6, p)
                                    .variant(w.random.nextInt(3)));
                        }
                    }
                    if (!inside.isEmpty()) {
                        sound(w, inside.get(0).getPos(), Sounds.SLASH, 0.9F, 0.85F + w.random.nextFloat() * 0.3F);
                    }
                }
            }
            case NAOYA -> {
                // Дворец лунных клеток: внутри всё движется по кадрам, кроме Наои.
                for (LivingEntity e : inside) {
                    e.addStatusEffect(effect(StatusEffects.SLOWNESS, 20, 5), p);
                    e.timeUntilRegen = 0;
                    e.damage(source(p, p), 1);
                }
                if (ownerInside) {
                    p.addStatusEffect(effect(StatusEffects.SPEED, 20, 2));
                }
            }
            case SHADOWS -> {
                if (t % 20 == 0) {
                    for (LivingEntity e : inside) {
                        e.addStatusEffect(effect(StatusEffects.SLOWNESS, 30, 3), p);
                        e.addStatusEffect(effect(StatusEffects.WEAKNESS, 30, 1), p);
                    }
                    if (ownerInside) {
                        p.addStatusEffect(effect(StatusEffects.SPEED, 30, 1));
                        p.addStatusEffect(effect(StatusEffects.STRENGTH, 30, 0));
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ чёрная вспышка

    static void blackFlash(ServerPlayerEntity p, LivingEntity target, float dealt) {
        ServerWorld w = p.getServerWorld();
        float extra = Math.max(3, dealt * 1.5F);
        target.timeUntilRegen = 0;
        target.damage(p.getDamageSources().playerAttack(p), extra);
        Vec3d center = target.getBoundingBox().getCenter();
        Vec3d at = center.add(p.getEyePos().subtract(center).normalize().multiply(target.getWidth() * 0.5));
        CursedFx fx = CursedFx.create(w, FxKind.BLACK_FLASH, at, 1.4F, 10, p);
        fx.setYaw(p.getYaw());
        w.spawnEntity(fx);
        sound(w, at, Sounds.BLACK_FLASH, 1.5F, 1.0F);
    }

    // ------------------------------------------------------------------ общее

    static DamageSource source(Entity direct, ServerPlayerEntity caster) {
        RegistryEntry<net.minecraft.entity.damage.DamageType> type = direct.getWorld().getRegistryManager()
                .get(RegistryKeys.DAMAGE_TYPE).entryOf(MineviaJjk.TECHNIQUE_DAMAGE);
        return new DamageSource(type, direct, caster);
    }

    /** Можно ли задеть: не сам маг, не его питомцы и псы, не игроки в творческом и не друзья при выключенном PvP. */
    static boolean enemy(LivingEntity e, ServerPlayerEntity caster) {
        if (e == caster || !e.isAlive() || e.isSpectator() || e instanceof ArmorStandEntity) {
            return false;
        }
        if (caster == null) {
            return true;
        }
        if (e instanceof TameableEntity pet && caster.getUuid().equals(pet.getOwnerUuid())) {
            return false;
        }
        if (e instanceof PlayerEntity player) {
            return !player.isCreative() && caster.shouldDamagePlayer(player);
        }
        return true;
    }

    static List<LivingEntity> targets(ServerWorld w, Vec3d center, double radius, ServerPlayerEntity caster) {
        Box box = new Box(center, center).expand(radius);
        return w.getEntitiesByClass(LivingEntity.class, box, e -> {
            double reach = radius + e.getWidth() * 0.5;
            return enemy(e, caster) && e.getBoundingBox().getCenter().squaredDistanceTo(center) <= reach * reach;
        });
    }

    /** Враги впереди в конусе, ближние первыми. cos — косинус половины угла конуса. */
    private static List<LivingEntity> ahead(ServerPlayerEntity p, double reach, double cos) {
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0F);
        List<LivingEntity> found = new ArrayList<>(targets(p.getServerWorld(), eye, reach, p));
        found.removeIf(e -> {
            Vec3d to = e.getBoundingBox().getCenter().subtract(eye);
            return to.lengthSquared() > 1.0E-4 && to.normalize().dotProduct(look) < cos;
        });
        found.sort(Comparator.comparingDouble(e -> e.squaredDistanceTo(eye)));
        return found;
    }

    /** Враг под прицелом, если до него не мешают блоки. */
    static LivingEntity aimed(ServerPlayerEntity p, double reach) {
        Vec3d eye = p.getEyePos();
        Vec3d end = eye.add(p.getRotationVec(1.0F).multiply(reach));
        BlockHitResult block = p.getWorld().raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        if (block.getType() != HitResult.Type.MISS) {
            end = block.getPos();
        }
        Box box = p.getBoundingBox().stretch(end.subtract(eye)).expand(1.5);
        EntityHitResult hit = ProjectileUtil.raycast(p, eye, end, box, e -> e instanceof LivingEntity living && enemy(living, p), eye.squaredDistanceTo(end));
        return hit != null && hit.getEntity() instanceof LivingEntity living ? living : null;
    }

    /** Враг под прицелом, а если прицел чуть мимо — ближайший видимый враг в узком конусе впереди. */
    static LivingEntity aimedOrAhead(ServerPlayerEntity p, double reach) {
        LivingEntity exact = aimed(p, reach);
        if (exact != null) {
            return exact;
        }
        for (LivingEntity e : ahead(p, reach, 0.9)) {
            if (p.canSee(e)) {
                return e;
            }
        }
        return null;
    }

    /** Точка под прицелом: стена или пол, куда смотрит игрок, либо точка в воздухе на нужном расстоянии. */
    private static Vec3d aimPoint(ServerPlayerEntity p, double reach) {
        Vec3d eye = p.getEyePos();
        Vec3d look = p.getRotationVec(1.0F);
        Vec3d end = eye.add(look.multiply(reach));
        BlockHitResult block = p.getWorld().raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p));
        return block.getType() == HitResult.Type.MISS ? end : block.getPos().subtract(look.multiply(0.8));
    }

    private static Vec3d ground(ServerWorld w, Vec3d at) {
        BlockHitResult down = w.raycast(new RaycastContext(at, at.add(0, -8, 0), RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE,
                net.minecraft.block.ShapeContext.absent()));
        return down.getType() == HitResult.Type.MISS ? at : down.getPos();
    }

    private static BlockHitResult blocked(ServerWorld w, Vec3d from, Vec3d to, Entity fx) {
        BlockHitResult hit = w.raycast(new RaycastContext(from, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, fx));
        return hit.getType() == HitResult.Type.MISS ? null : hit;
    }

    /** Снаряд во что-то попал: в стену (тогда он встаёт у стены) или во врага. */
    private static boolean impact(ServerWorld w, CursedFx f, ServerPlayerEntity caster, double radius) {
        Vec3d now = f.getPos();
        Vec3d before = now.subtract(f.getVelocity());
        BlockHitResult wall = blocked(w, before, now, f);
        if (wall != null) {
            f.setPosition(wall.getPos());
            return true;
        }
        return !w.getEntitiesByClass(LivingEntity.class, new Box(before, now).expand(radius), e -> enemy(e, caster)).isEmpty();
    }

    static StatusEffectInstance effect(RegistryEntry<StatusEffect> type, int ticks, int amplifier) {
        return new StatusEffectInstance(type, ticks, amplifier, false, false, true);
    }

    static void sound(ServerWorld w, Vec3d at, SoundEvent sound, float volume, float pitch) {
        w.playSound(null, at.x, at.y, at.z, sound, SoundCategory.PLAYERS, volume, pitch);
    }

    static void sound(ServerWorld w, Vec3d at, RegistryEntry<SoundEvent> sound, float volume, float pitch) {
        w.playSound(null, at.x, at.y, at.z, sound, SoundCategory.PLAYERS, volume, pitch, w.random.nextLong());
    }
}
