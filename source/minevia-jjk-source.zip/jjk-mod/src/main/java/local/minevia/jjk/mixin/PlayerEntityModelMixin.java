package local.minevia.jjk.mixin;

import local.minevia.jjk.client.PlayerAnims;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Движения бойца ложатся поверх обычной анимации игрока. */
@Mixin(PlayerEntityModel.class)
abstract class PlayerEntityModelMixin {
    @Inject(method = "setAngles(Lnet/minecraft/entity/LivingEntity;FFFFF)V", at = @At("TAIL"))
    private void minevia_jjk$pose(LivingEntity entity, float limbAngle, float limbDistance, float animationProgress,
            float headYaw, float headPitch, CallbackInfo info) {
        PlayerAnims.pose((PlayerEntityModel<?>) (Object) this, entity, animationProgress);
    }
}
