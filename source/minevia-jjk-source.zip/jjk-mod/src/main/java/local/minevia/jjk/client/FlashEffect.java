package local.minevia.jjk.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** Чёрная вспышка: на треть секунды по краям экрана проходит тёмно-красная тень. Середина экрана остаётся чистой. */
final class FlashEffect {
    private static final long LENGTH_MS = 350;
    private static long startedAt;

    private FlashEffect() {
    }

    static void start() {
        startedAt = System.currentTimeMillis();
    }

    static void draw(DrawContext context, float delta) {
        long passed = System.currentTimeMillis() - startedAt;
        if (passed >= LENGTH_MS || MinecraftClient.getInstance().options.hudHidden) {
            return;
        }
        float k = 1 - passed / (float) LENGTH_MS;
        int w = context.getScaledWindowWidth();
        int h = context.getScaledWindowHeight();
        int depth = Math.max(8, Math.min(w, h) / 7);
        for (int i = 0; i < depth; i += 2) {
            float edge = 1 - i / (float) depth;
            int alpha = (int) (110 * k * edge * edge);
            if (alpha <= 0) {
                continue;
            }
            int color = alpha << 24 | 0x1A0004;
            context.fill(0, i, w, i + 2, color);
            context.fill(0, h - i - 2, w, h - i, color);
            context.fill(i, 0, i + 2, h, color);
            context.fill(w - i - 2, 0, w - i, h, color);
        }
    }
}
