package local.minevia.jjk;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.passive.WolfEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;

/**
 * Божественный пёс из Десяти теней. Ведёт себя как ручной волк: бьёт тех, кого бьёт хозяин,
 * и тех, кто бьёт хозяина. Через время уходит обратно в тень. Не сохраняется и ничего не роняет.
 */
public final class ShadowDog extends WolfEntity {
    private int lifetime = 600;

    public ShadowDog(EntityType<? extends WolfEntity> type, World world) {
        super(type, world);
    }

    public void setup(ServerPlayerEntity owner, int life, boolean strong) {
        setOwner(owner);
        setTamed(true, true);
        lifetime = life;
        getAttributeInstance(EntityAttributes.GENERIC_MAX_HEALTH).setBaseValue(strong ? 30 : 20);
        setHealth(getMaxHealth());
        getAttributeInstance(EntityAttributes.GENERIC_ATTACK_DAMAGE).setBaseValue(strong ? 7 : 5);
        getAttributeInstance(EntityAttributes.GENERIC_MOVEMENT_SPEED).setBaseValue(0.38);
    }

    /** Белый или чёрный: у пары псов номера идут подряд, поэтому они разного цвета. */
    public boolean white() {
        return (getId() & 1) == 0;
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) {
            return;
        }
        LivingEntity owner = getOwner();
        if (age > lifetime || owner == null || !owner.isAlive() || owner.getWorld() != getWorld()) {
            vanish();
        }
    }

    public void vanish() {
        if (getWorld() instanceof ServerWorld world && !isRemoved()) {
            world.spawnEntity(CursedFx.create(world, FxKind.SHADOW_POOL, getPos(), 0.9F, 16, null));
        }
        discard();
    }

    @Override
    public ActionResult interactMob(PlayerEntity player, Hand hand) {
        return ActionResult.PASS;
    }

    @Override
    public boolean isBreedingItem(ItemStack stack) {
        return false;
    }

    @Override
    public WolfEntity createChild(ServerWorld world, PassiveEntity entity) {
        return null;
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    protected int getXpToDrop() {
        return 0;
    }

    @Override
    public boolean canAttackWithOwner(LivingEntity target, LivingEntity owner) {
        if (target instanceof ShadowDog dog && dog.getOwner() == owner) {
            return false;
        }
        return super.canAttackWithOwner(target, owner);
    }
}
