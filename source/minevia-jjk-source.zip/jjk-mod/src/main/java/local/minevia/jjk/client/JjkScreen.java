package local.minevia.jjk.client;

import java.util.List;
import local.minevia.jjk.Payloads;
import local.minevia.jjk.Technique;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;

/** Меню на J: класс и опыт мага, три техники карточками. Щелчок по карточке выбирает технику. */
final class JjkScreen extends Screen {
    private static final int CARD_MAX = 136;
    private static final int CARD_H = 194;
    private static final int GAP = 10;
    private static final int PANEL = 0xE00C0E14;
    private static final int GRAY = 0xFF8A8A8A;
    private static final int BACK_W = 118;
    private static final int BACK_H = 18;

    private Payloads.Menu state;

    JjkScreen(Payloads.Menu state) {
        super(Text.literal("Герои"));
        this.state = state;
    }

    void update(Payloads.Menu menu) {
        state = menu;
    }

    /** Четыре героя должны влезть и в узкое окно: карточки сужаются. */
    private int cardW() {
        int count = Technique.PICKABLE.size();
        return Math.min(CARD_MAX, (width - 16 - (count - 1) * GAP) / count);
    }

    private int cardsLeft() {
        int count = Technique.PICKABLE.size();
        return (width - count * cardW() - (count - 1) * GAP) / 2;
    }

    private int cardsTop() {
        return Math.max(56, (height - CARD_H) / 2 + 12);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        TextRenderer text = textRenderer;
        int top = cardsTop();
        context.drawCenteredTextWithShadow(text, title, width / 2, top - 46, 0xFFFFFFFF);
        Technique current = Technique.byId(state.technique());
        if (current == null) {
            context.drawCenteredTextWithShadow(text, Text.literal("Выбери героя"), width / 2, top - 32, 0xFFB48CFF);
        } else {
            int rank = state.rank();
            String line = Technique.RANKS[rank] + " · опыт " + state.xp()
                    + (rank + 1 < Technique.RANK_XP.length ? " / " + Technique.RANK_XP[rank + 1] : "");
            context.drawCenteredTextWithShadow(text, line, width / 2, top - 32, current.color());
            int barW = 220;
            int barX = width / 2 - barW / 2;
            int barY = top - 20;
            float part = 1;
            if (rank + 1 < Technique.RANK_XP.length) {
                int from = Technique.RANK_XP[rank];
                part = (state.xp() - from) / (float) (Technique.RANK_XP[rank + 1] - from);
            }
            context.fill(barX - 1, barY - 1, barX + barW + 1, barY + 5, 0xFF2B3040);
            context.fill(barX, barY, barX + barW, barY + 4, 0xFF1A1D2A);
            context.fill(barX, barY, barX + Math.round(barW * Math.max(0, Math.min(1, part))), barY + 4, current.color());
        }

        java.util.List<Technique> all = Technique.PICKABLE;
        int left = cardsLeft();
        for (int i = 0; i < all.size(); i++) {
            Technique t = all.get(i);
            int x = left + i * (cardW() + GAP);
            boolean chosen = t == current;
            boolean hover = mouseX >= x && mouseX < x + cardW() && mouseY >= top && mouseY < top + CARD_H;
            boolean waiting = !chosen && current != null && state.waitSeconds() > 0;
            int border = chosen ? t.color() : hover && !waiting ? 0xFFDDDDDD : 0xFF3A3F50;
            context.fill(x - 1, top - 1, x + cardW() + 1, top + CARD_H + 1, border);
            context.fill(x, top, x + cardW(), top + CARD_H, PANEL);
            context.fill(x, top, x + cardW(), top + 3, t.color());
            context.drawCenteredTextWithShadow(text, t.title(), x + cardW() / 2, top + 7, t.color());
            context.getMatrices().push();
            context.getMatrices().translate(x + cardW() / 2F, top + 17, 0);
            context.getMatrices().scale(0.75F, 0.75F, 1);
            context.drawCenteredTextWithShadow(text, t.art(), 0, 0, 0xFF9AA0B0);
            context.getMatrices().pop();
            int y = top + 28;
            List<OrderedText> about = text.wrapLines(Text.literal(t.about()), cardW() - 12);
            for (OrderedText row : about) {
                context.drawTextWithShadow(text, row, x + 6, y, 0xFFC8C8C8);
                y += 10;
            }
            y += 6;
            for (int slot = 0; slot < Technique.SLOTS; slot++) {
                int color = slot == Technique.DOMAIN ? t.color() : slot == Technique.SPECIAL ? 0xFFE8E0B0 : 0xFFFFFFFF;
                y = moveLine(context, text, x, y, Technique.KEYS[slot], t.move(slot).name(), color);
            }
            // Что открывает ульта: особый приём и территория (один раз за ульту).
            String inUlt = (t.hasUltMove() ? t.move(3, true).name() + ", " : "") + t.domain();
            context.getMatrices().push();
            context.getMatrices().translate(x + 6, y + 1, 0);
            context.getMatrices().scale(0.75F, 0.75F, 1);
            List<OrderedText> ultLines = text.wrapLines(Text.literal("В ульте: " + inUlt), (int) ((cardW() - 12) / 0.75F));
            for (int row = 0; row < Math.min(2, ultLines.size()); row++) {
                context.drawTextWithShadow(text, ultLines.get(row), 0, row * 10, t.bar() == 0xFF16141C ? 0xFFB0A8C8 : t.bar());
            }
            context.getMatrices().pop();
            String footer = chosen ? "Твой герой" : waiting ? "Смена через " + (state.waitSeconds() + 59) / 60 + " мин." : "Выбрать";
            context.drawCenteredTextWithShadow(text, footer, x + cardW() / 2, top + CARD_H - 13, chosen ? t.color() : waiting ? GRAY : 0xFFFFFFFF);
        }
        String hint = "G — режим боя: 1-4 навыки, R особый, J ульта, Q рывок, F блок. Приёмы открываются с классом.";
        context.drawCenteredTextWithShadow(text, hint, width / 2, top + CARD_H + 10, GRAY);
        if (state.elements()) {
            String note = state.element().isEmpty() ? "Начало одно: техника или стихия." : "Сейчас у тебя стихия. Выбор техники её снимет.";
            context.drawCenteredTextWithShadow(text, note, width / 2, top + CARD_H + 22, state.element().isEmpty() ? GRAY : 0xFFE4B767);
            boolean hover = inBack(mouseX, mouseY);
            context.fill(6, 5, 6 + BACK_W, 5 + BACK_H, hover ? 0xFF2A2E3C : 0xFF181B26);
            context.fill(6 + BACK_W - 2, 5, 6 + BACK_W, 5 + BACK_H, 0xFFE4B767);
            context.drawCenteredTextWithShadow(text, "‹ Стихии и стили", 6 + BACK_W / 2 - 1, 10, hover ? 0xFFFFFFFF : 0xFFE8DDB8);
        }
    }

    private boolean inBack(double mouseX, double mouseY) {
        return mouseX >= 6 && mouseX < 6 + BACK_W && mouseY >= 5 && mouseY < 5 + BACK_H;
    }

    private void choose(int index) {
        if (state.element().isEmpty()) {
            ClientPlayNetworking.send(new Payloads.Pick(index));
            return;
        }
        Technique t = Technique.PICKABLE.get(index);
        client.setScreen(new ConfirmScreen(yes -> {
            client.setScreen(this);
            if (yes) {
                ClientPlayNetworking.send(new Payloads.Pick(index));
            }
        }, Text.literal("Взять технику «" + t.title() + "» вместо «").append(Text.translatable(state.element())).append("»?"),
                Text.literal("Стихия снимется, опыт её навыков сбросится. Уровень останется, вернуться к стихиям можно в любой момент.")));
    }

    private static int moveLine(DrawContext context, TextRenderer text, int x, int y, String key, String name, int color) {
        context.fill(x + 6, y - 1, x + 16, y + 9, 0xFF3A3F50);
        context.drawCenteredTextWithShadow(text, key, x + 11, y, 0xFFFFFFFF);
        context.drawTextWithShadow(text, name, x + 20, y, color);
        return y + 11;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && state.elements() && inBack(mouseX, mouseY)) {
            ElementsBridge.openSelection(client);
            return true;
        }
        if (button == 0) {
            int top = cardsTop();
            int left = cardsLeft();
            java.util.List<Technique> all = Technique.PICKABLE;
            for (int i = 0; i < all.size(); i++) {
                int x = left + i * (cardW() + GAP);
                if (mouseX >= x && mouseX < x + cardW() && mouseY >= top && mouseY < top + CARD_H) {
                    if (!all.get(i).id().equals(state.technique())) {
                        choose(i);
                    }
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
