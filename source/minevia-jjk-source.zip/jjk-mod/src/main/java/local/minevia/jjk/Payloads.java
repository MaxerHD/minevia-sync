package local.minevia.jjk;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Пакеты между клавишами, меню на J и сервером. */
public final class Payloads {
    private Payloads() {
    }

    private static <T extends CustomPayload> CustomPayload.Id<T> id(String path) {
        return new CustomPayload.Id<>(Identifier.of(MineviaJjk.MOD_ID, path));
    }

    /** Нажата клавиша приёма: номер в {@link Technique} (0..3 — навыки 1-4, 4 — особый на R, 5 — ульта на J). */
    public record Cast(int slot) implements CustomPayload {
        public static final Id<Cast> ID = id("cast");
        public static final PacketCodec<RegistryByteBuf, Cast> CODEC = PacketCodecs.VAR_INT.<RegistryByteBuf>cast().xmap(Cast::new, Cast::slot);

        @Override
        public Id<Cast> getId() {
            return ID;
        }
    }

    /** Движение игрока, которое видят все рядом: удар левой/правой, пинок, блок, рывок, приём. */
    public record Anim(int entity, int kind) implements CustomPayload {
        public static final int PUNCH_LEFT = 0;
        public static final int PUNCH_RIGHT = 1;
        public static final int KICK = 2;
        public static final int UPPERCUT = 3;
        public static final int BLOCK_ON = 4;
        public static final int BLOCK_OFF = 5;
        public static final int DASH = 6;
        public static final int CAST = 7;
        /** Пурпурный: синий в одной руке, красный в другой, руки сходятся, выстрел. */
        public static final int PURPLE = 8;
        public static final Id<Anim> ID = id("anim");
        public static final PacketCodec<RegistryByteBuf, Anim> CODEC = PacketCodec.tuple(
                PacketCodecs.VAR_INT, Anim::entity,
                PacketCodecs.VAR_INT, Anim::kind,
                Anim::new);

        @Override
        public Id<Anim> getId() {
            return ID;
        }
    }

    /** Открыть меню на J. */
    public record Open() implements CustomPayload {
        public static final Id<Open> ID = id("open");
        public static final PacketCodec<RegistryByteBuf, Open> CODEC = PacketCodec.unit(new Open());

        @Override
        public Id<Open> getId() {
            return ID;
        }
    }

    /** Выбрать технику в меню: номер в {@link Technique#values()}. */
    public record Pick(int index) implements CustomPayload {
        public static final Id<Pick> ID = id("pick");
        public static final PacketCodec<RegistryByteBuf, Pick> CODEC = PacketCodecs.VAR_INT.<RegistryByteBuf>cast().xmap(Pick::new, Pick::index);

        @Override
        public Id<Pick> getId() {
            return ID;
        }
    }

    /**
     * Панель справа внизу: техника (пустая строка — не выбрана), класс, энергия и её запас,
     * перезарядка семи приёмов в тиках и сколько тиков ещё идёт расширение территории.
     */
    public record Hud(String technique, int rank, int energy, int maxEnergy, int[] cooldowns, int domain, int combo, int ult, boolean awakened) implements CustomPayload {
        public static final Id<Hud> ID = id("hud");
        public static final PacketCodec<RegistryByteBuf, Hud> CODEC = CustomPayload.codecOf(Hud::write, Hud::read);

        private void write(RegistryByteBuf buf) {
            buf.writeString(technique);
            buf.writeVarInt(rank);
            buf.writeVarInt(energy);
            buf.writeVarInt(maxEnergy);
            for (int i = 0; i < Technique.SLOTS; i++) {
                buf.writeVarInt(cooldowns[i]);
            }
            buf.writeVarInt(domain);
            buf.writeVarInt(combo);
            buf.writeVarInt(ult);
            buf.writeBoolean(awakened);
        }

        private static Hud read(RegistryByteBuf buf) {
            String technique = buf.readString();
            int rank = buf.readVarInt();
            int energy = buf.readVarInt();
            int max = buf.readVarInt();
            int[] cooldowns = new int[Technique.SLOTS];
            for (int i = 0; i < cooldowns.length; i++) {
                cooldowns[i] = buf.readVarInt();
            }
            return new Hud(technique, rank, energy, max, cooldowns, buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readBoolean());
        }

        @Override
        public Id<Hud> getId() {
            return ID;
        }
    }

    /**
     * Состояние для меню: техника, опыт и класс, через сколько секунд можно сменить технику
     * и нужно ли открыть меню, а не только обновить.
     */
    /** element — ключ перевода стихии игрока (пусто, если нет), elements — в сборке есть мод стихий («12 начал»). */
    public record Menu(String technique, int xp, int rank, int waitSeconds, boolean open, String element, boolean elements) implements CustomPayload {
        public static final Id<Menu> ID = id("menu");
        // Полей больше шести, а PacketCodec.tuple в 1.21.1 столько не принимает: пишем по порядку сами.
        public static final PacketCodec<RegistryByteBuf, Menu> CODEC = PacketCodec.of((menu, buf) -> {
            buf.writeString(menu.technique);
            buf.writeVarInt(menu.xp);
            buf.writeVarInt(menu.rank);
            buf.writeVarInt(menu.waitSeconds);
            buf.writeBoolean(menu.open);
            buf.writeString(menu.element);
            buf.writeBoolean(menu.elements);
        }, buf -> new Menu(buf.readString(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readBoolean(), buf.readString(), buf.readBoolean()));

        @Override
        public Id<Menu> getId() {
            return ID;
        }
    }

    /** Рывок на R: куда жмёт игрок (вперёд/назад и вбок), чтобы рвануть в сторону бега. */
    public record Dash(float forward, float sideways) implements CustomPayload {
        public static final Id<Dash> ID = id("dash");
        public static final PacketCodec<RegistryByteBuf, Dash> CODEC = PacketCodec.tuple(
                PacketCodecs.FLOAT, Dash::forward,
                PacketCodecs.FLOAT, Dash::sideways,
                Dash::new);

        @Override
        public Id<Dash> getId() {
            return ID;
        }
    }

    /** Блок: зажата ПКМ с пустой рукой (true) или отпущена (false). */
    public record Block(boolean active) implements CustomPayload {
        public static final Id<Block> ID = id("block");
        public static final PacketCodec<RegistryByteBuf, Block> CODEC = PacketCodecs.BOOL.<RegistryByteBuf>cast().xmap(Block::new, Block::active);

        @Override
        public Id<Block> getId() {
            return ID;
        }
    }

    /** Чёрная вспышка у этого игрока: на миг темнеют края экрана. */
    public record Flash() implements CustomPayload {
        public static final Id<Flash> ID = id("flash");
        public static final PacketCodec<RegistryByteBuf, Flash> CODEC = PacketCodec.unit(new Flash());

        @Override
        public Id<Flash> getId() {
            return ID;
        }
    }
}
