package local.minevia.jjk;

import net.minecraft.util.math.Vec3d;

/** То, что живёт только пока игрок в игре: энергия, перезарядки, щит и расширение территории. */
public final class Sorcerer {
    public float energy = 100;
    /** Тик сервера, когда приём снова готов. */
    public final long[] readyAt = new long[Technique.SLOTS];
    public long infinityUntil;
    public long lastXpTick;
    /** Кого игрок только что ударил с чёрной вспышкой и в каком тике. */
    public int flashTarget = -1;
    public long flashTick;

    /** Серия ударов рукой: сколько ударов подряд и когда был последний. */
    public int combo;
    public long comboTick;
    /** Шкала ульты 0..100: копится в бою, тратится на расширение территории. */
    public float ult;
    public long dashReady;
    public boolean blocking;
    public long blockStart;
    /** Урон по блоку пересчитывается вручную: на это время блок не трогает удар второй раз. */
    public boolean absorbing;

    /** Ульта Итадори: до этого тика телом владеет Сукуна и у игрока его приёмы. */
    public long ultUntil;
    public long ultStart;
    /** Гробницу зла в облике Сукуны можно открыть один раз за облик. */
    public boolean ultDomainUsed;

    public Technique domainTechnique;
    public Vec3d domainCenter = Vec3d.ZERO;
    public net.minecraft.registry.RegistryKey<net.minecraft.world.World> domainWorld;
    public float domainRadius;
    public long domainUntil;
    public long domainStart;
}
