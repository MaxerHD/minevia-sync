package local.minevia.jjk.client;

import local.minevia.jjk.Technique;
import net.minecraft.client.resource.language.I18n;

/**
 * Названия героев и приёмов на языке игры: русская игра — по-русски, английская — по-английски
 * (assets/minevia_jjk/lang). Если перевода нет, берётся русское название из {@link Technique}.
 */
final class Lang {
    private Lang() {
    }

    static String get(String key, String fallback, Object... args) {
        return I18n.hasTranslation(key) ? I18n.translate(key, args) : fallback;
    }

    static String hero(Technique t) {
        return get("minevia_jjk.hero." + t.id(), t.title());
    }

    static String art(Technique t) {
        return get("minevia_jjk.art." + t.id(), t.art());
    }

    static String move(Technique t, int slot, boolean ult) {
        if (ult && slot == 3 && t.hasUltMove()) {
            return get("minevia_jjk.move." + t.id() + ".ult", t.move(slot, true).name());
        }
        if (ult && slot == Technique.DOMAIN) {
            return domain(t);
        }
        return get("minevia_jjk.move." + t.id() + "." + slot, t.move(slot).name());
    }

    static String domain(Technique t) {
        return get("minevia_jjk.domain." + t.id(), t.domain());
    }

    static String hits(int count) {
        return get("minevia_jjk.hud.hits", "Ударов: " + count, count);
    }
}
