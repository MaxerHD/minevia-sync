package local.minevia.jjk.client;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * В сборке на G, H, N и J по умолчанию сидят голосовой чат, Punchy, музыка и Cinematic. Две привязки на одной клавише
 * игра не поддерживает: срабатывает одна, какая повезёт. Один раз при первом запуске с модом снимаем чужие привязки
 * с клавиш техник, а групповой чат и тексты песен переносим на свободные клавиши. Потом игрок волен всё поменять.
 */
final class KeyConflicts {
    private static final Logger LOGGER = LoggerFactory.getLogger("minevia_jjk");
    private static final int VERSION = 1;
    private static final Map<String, String> MOVE_TO = Map.of(
            "key.voice_chat_group", "key.keyboard.apostrophe",
            "key.musicplayer.world_lyrics", "key.keyboard.period");

    private KeyConflicts() {
    }

    static void resolve(MinecraftClient client, Set<KeyBinding> ours) {
        Path mark = FabricLoader.getInstance().getConfigDir().resolve("minevia_jjk_keys.json");
        try {
            if (Files.exists(mark) && Files.readString(mark).contains("\"version\": " + VERSION)) {
                return;
            }
            int changed = 0;
            for (KeyBinding other : client.options.allKeys) {
                // С модом стихий G и J делим, а не отнимаем: нажатие уходит тому, чьё начало выбрано (ElementsBridge).
                if (ours.contains(other) || other.getTranslationKey().startsWith("key.minevia_elements.")) {
                    continue;
                }
                for (KeyBinding mine : ours) {
                    if (!other.isUnbound() && other.equals(mine)) {
                        String target = MOVE_TO.get(other.getTranslationKey());
                        InputUtil.Key to = target != null && free(client, InputUtil.fromTranslationKey(target)) ? InputUtil.fromTranslationKey(target) : InputUtil.UNKNOWN_KEY;
                        LOGGER.info("Клавиша {} нужна техникам: {} теперь на {}", mine.getBoundKeyTranslationKey(), other.getTranslationKey(), to.getTranslationKey());
                        other.setBoundKey(to);
                        changed++;
                        break;
                    }
                }
            }
            if (changed > 0) {
                KeyBinding.updateKeysByCode();
                client.options.write();
            }
            Files.writeString(mark, "{\"version\": " + VERSION + "}\n");
        } catch (IOException | RuntimeException problem) {
            LOGGER.warn("Не вышло развести клавиши техник с другими модами", problem);
        }
    }

    private static boolean free(MinecraftClient client, InputUtil.Key key) {
        for (KeyBinding binding : client.options.allKeys) {
            if (binding.getBoundKeyTranslationKey().equals(key.getTranslationKey())) {
                return false;
            }
        }
        return true;
    }
}
