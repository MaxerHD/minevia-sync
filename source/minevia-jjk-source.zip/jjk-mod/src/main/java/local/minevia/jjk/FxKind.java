package local.minevia.jjk;

/** Что за 3D-модель показывает {@link CursedFx}. Порядок важен: номер уходит клиенту. */
public enum FxKind {
    BLUE, RED, RED_BURST, PURPLE, INFINITY, VOID_DOME,
    SLASH, CLEAVE, FLAME_ARROW, FLAME_BURST, SHRINE, SHRINE_CUT,
    NUE, NUE_STRIKE, SHADOW_POOL, SHADOW_GARDEN, BLACK_FLASH, IMPACT, TONGUE,
    DIVERGENT, DASH_TRAIL, KICK_ARC, SUKUNA_AWAKEN, SHRINE_POOL,
    PROJECTION_FRAME, SPEED_RIBBONS, SONIC_BOOM, NAOYA_DOMAIN, HAND_BLUE, HAND_RED;

    private static final FxKind[] ALL = values();

    public static FxKind of(int index) {
        return index >= 0 && index < ALL.length ? ALL[index] : BLUE;
    }
}
