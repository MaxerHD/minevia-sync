package local.minevia.jjk.client;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import local.minevia.jjk.Payloads;
import local.minevia.jjk.Technique;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ConfirmScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

/**
 * «12 начал»: один экран выбора на всю сборку — 8 стихий и стилей из мода стихий и 4 героя.
 * Выбор делается один раз и навсегда; после него экран только показывает, что выбрано.
 * Мод стихий подключается через отражение (его классы и поля не меняют имён при сборке).
 */
final class OriginScreen extends Screen {
    private static final int COLUMNS = 4;
    private static final int GAP = 6;

    /** Карточка: стихия (element != null) или герой. */
    private record Card(Object element, Technique hero, String title, String about, int color) {
    }

    private final List<Card> cards = new ArrayList<>();

    OriginScreen() {
        super(Text.translatable("minevia_jjk.choice.title"));
        for (Object element : Elements.values()) {
            String key = Elements.key(element);
            cards.add(new Card(element, null, Text.translatable(key).getString(), Text.translatable(key + ".choice").getString(),
                    0xFF000000 | Elements.color(element)));
        }
        for (Technique hero : Technique.PICKABLE) {
            cards.add(new Card(null, hero, Lang.hero(hero), Lang.get("minevia_jjk.about." + hero.id(), hero.about()), hero.color()));
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private int rows() {
        return (cards.size() + COLUMNS - 1) / COLUMNS;
    }

    private int cardW() {
        return Math.min(160, (width - 20 - GAP * (COLUMNS - 1)) / COLUMNS);
    }

    private int cardH() {
        return MathHelper.clamp((height - 84 - GAP * (rows() - 1)) / rows(), 48, 96);
    }

    private int cardX(int i) {
        int left = (width - cardW() * COLUMNS - GAP * (COLUMNS - 1)) / 2;
        return left + i % COLUMNS * (cardW() + GAP);
    }

    private int cardY(int i) {
        // Перед рядом героев место под подпись.
        return 44 + i / COLUMNS * (cardH() + GAP) + (i >= Elements.values().length ? 12 : 0);
    }

    /** Что уже выбрано: стихия из мода стихий или герой. */
    private boolean chosen(Card card) {
        if (card.element() != null) {
            return card.element() == Elements.current();
        }
        return JjkHud.hasTechnique() && card.hero() == Technique.byId(JjkHud.technique());
    }

    private static boolean locked() {
        return Elements.current() != null || JjkHud.hasTechnique();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 12, 0xFFFFD27A);
        Text help = Text.translatable(locked() ? "minevia_jjk.choice.done" : "minevia_jjk.choice.help");
        context.drawCenteredTextWithShadow(textRenderer, help, width / 2, 27, locked() ? 0xFFE4B767 : 0xFFBECADA);
        boolean lock = locked();
        for (int i = 0; i < cards.size(); i++) {
            Card card = cards.get(i);
            int x = cardX(i);
            int y = cardY(i);
            int w = cardW();
            int h = cardH();
            boolean mine = chosen(card);
            boolean hover = !lock && mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
            context.fill(x - 1, y - 1, x + w + 1, y + h + 1, mine ? card.color() : hover ? 0xFF6A7890 : 0xFF263244);
            context.fill(x, y, x + w, y + h, hover ? 0xF026364A : 0xF0152132);
            context.fill(x, y, x + 2, y + h, card.color());
            if (card.element() != null) {
                Elements.icon(context, card.element(), x + 5, y + 5, 20);
            } else {
                // Знак героя: круг его цвета с первой буквой имени.
                context.fill(x + 6, y + 6, x + 24, y + 24, card.hero().bar() | 0xFF000000);
                context.fill(x + 7, y + 7, x + 23, y + 23, 0xFF10141C);
                context.drawCenteredTextWithShadow(textRenderer, card.title().substring(0, 1), x + 15, y + 11, card.color());
            }
            lines(context, card.title(), x + 30, y + 6, w - 34, 2, 1.0F, card.color());
            lines(context, card.about(), x + 5, y + 30, w - 9, h >= 70 ? 4 : 2, 0.75F, mine || !lock ? 0xFFD7DEE3 : 0xFF7E8A99);
            if (lock && !mine) {
                context.fill(x, y, x + w, y + h, 0x80000000);
            }
            if (card.hero() != null && i == Elements.values().length) {
                context.drawTextWithShadow(textRenderer, Text.translatable("minevia_jjk.choice.heroes"), x, y - 11, 0xFF9AAFC2);
            }
        }
    }

    private void lines(DrawContext context, String value, int x, int y, int span, int max, float scale, int color) {
        context.getMatrices().push();
        context.getMatrices().translate(x, y, 0);
        context.getMatrices().scale(scale, scale, 1);
        List<OrderedText> rows = textRenderer.wrapLines(Text.literal(value), (int) (span / scale));
        for (int row = 0; row < Math.min(max, rows.size()); row++) {
            context.drawTextWithShadow(textRenderer, rows.get(row), 0, row * 10, color);
        }
        context.getMatrices().pop();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && !locked()) {
            for (int i = 0; i < cards.size(); i++) {
                int x = cardX(i);
                int y = cardY(i);
                if (mouseX >= x && mouseX < x + cardW() && mouseY >= y && mouseY < y + cardH()) {
                    confirm(cards.get(i));
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void confirm(Card card) {
        client.setScreen(new ConfirmScreen(yes -> {
            if (!yes) {
                client.setScreen(this);
                return;
            }
            if (card.element() != null) {
                Elements.choose(card.element());
            } else if (ClientPlayNetworking.canSend(Payloads.Pick.ID)) {
                ClientPlayNetworking.send(new Payloads.Pick(Technique.PICKABLE.indexOf(card.hero())));
            }
            client.setScreen(null);
        }, Text.translatable("minevia_jjk.choice.confirm", card.title()), Text.translatable("minevia_jjk.choice.confirm_text")));
    }

    /** Мост к моду стихий: список стихий, значки, выбранная стихия и выбор. Без мода стихий — пусто. */
    static final class Elements {
        private static Object[] all = new Object[0];
        private static Method key;
        private static Field color;
        private static Field current;
        private static Method icon;
        private static java.lang.reflect.Constructor<?> payload;

        static {
            if (ElementsBridge.LOADED) {
                try {
                    Class<?> element = Class.forName("local.minevia.elements.Element");
                    all = element.getEnumConstants();
                    key = element.getMethod("key");
                    color = element.getField("color");
                    Class<?> client = Class.forName("local.minevia.elements.client.ElementsClient");
                    current = client.getDeclaredField("element");
                    current.setAccessible(true);
                    icon = client.getDeclaredMethod("drawElementIcon", DrawContext.class, element, int.class, int.class, int.class);
                    icon.setAccessible(true);
                    payload = Class.forName("local.minevia.elements.net.MenuPayload").getConstructor(int.class, int.class);
                } catch (ReflectiveOperationException | RuntimeException problem) {
                    all = new Object[0];
                }
            }
        }

        private Elements() {
        }

        static Object[] values() {
            return all;
        }

        static String key(Object element) {
            try {
                return (String) key.invoke(element);
            } catch (ReflectiveOperationException problem) {
                return "";
            }
        }

        static int color(Object element) {
            try {
                return color.getInt(element);
            } catch (ReflectiveOperationException problem) {
                return 0xFFFFFF;
            }
        }

        static Object current() {
            try {
                return current == null ? null : current.get(null);
            } catch (ReflectiveOperationException problem) {
                return null;
            }
        }

        static void icon(DrawContext context, Object element, int x, int y, int size) {
            try {
                icon.invoke(null, context, element, x, y, size);
            } catch (ReflectiveOperationException | RuntimeException problem) {
                context.fill(x, y, x + size, y + size, 0xFF000000 | color(element));
            }
        }

        /** Тот же пакет, что шлёт экран выбора мода стихий (MenuPayload.CHOOSE_ELEMENT = 4). */
        static void choose(Object element) {
            try {
                CustomPayload packet = (CustomPayload) payload.newInstance(4, ((Enum<?>) element).ordinal());
                if (ClientPlayNetworking.canSend(packet.getId())) {
                    ClientPlayNetworking.send(packet);
                }
            } catch (ReflectiveOperationException | RuntimeException problem) {
                // Мод стихий изменился: выбрать стихию можно его собственным экраном.
            }
        }
    }
}
