package local.minevia.jjk;

import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/**
 * Рукопашный бой в духе файтингов: серия из четырёх ударов (последний отбрасывает), рывок, блок и парирование.
 * Свой, по мотивам жанра: ничего не взято из чужих игр.
 */
final class Combat {
    /** Сколько тиков между ударами, чтобы серия не прервалась. */
    static final int COMBO_GAP = 24;
    private static final int DASH_COOLDOWN = 30;
    /** Блок, поставленный не раньше чем за столько тиков до удара, — это парирование. */
    private static final int PARRY_WINDOW = 6;

    /** Отброс от удара, который надо применить в конце тика: игра сама толкает цель уже после нашего обработчика. */
    private record Push(LivingEntity target, Vec3d velocity) {
    }

    private static final java.util.List<Push> PUSHES = new java.util.ArrayList<>();
    /** Кого мы подбросили и до какого тика он считается «в воздухе» для пинка. */
    private static final java.util.Map<Integer, Long> LAUNCHED = new java.util.HashMap<>();

    /** Для тестов: с -Dminevia.jjk.debug=true события боя пишутся в лог. */
    static final boolean DEBUG = Boolean.getBoolean("minevia.jjk.debug");
    static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger("minevia_jjk");

    private Combat() {
    }

    static void push(LivingEntity target, Vec3d velocity) {
        PUSHES.add(new Push(target, velocity));
    }

    /** В конце тика сервера: наш отброс поверх игрового. */
    static void flush(long now) {
        for (Push push : PUSHES) {
            if (push.target().isAlive()) {
                push.target().setVelocity(push.velocity());
                push.target().velocityModified = true;
            }
        }
        PUSHES.clear();
        LAUNCHED.values().removeIf(until -> until < now);
    }

    /** Отметить, что цель подброшена приёмом: пока она в воздухе, удар по ней — пинок. */
    static void launched(LivingEntity target, long now) {
        LAUNCHED.put(target.getId(), now + 40);
    }

    /** Удар рукой или оружием попал. Первые три удара держат врага рядом, четвёртый отбрасывает. */
    static void meleeHit(ServerPlayerEntity p, Sorcerer s, LivingEntity target, long now) {
        s.combo = now - s.comboTick <= COMBO_GAP && s.combo < 4 ? s.combo + 1 : 1;
        s.comboTick = now;
        ServerWorld w = p.getServerWorld();
        Vec3d look = flatLook(p);
        Vec3d at = target.getBoundingBox().getCenter().add(look.multiply(-target.getWidth() * 0.5));
        // Пинок — только по тому, кто реально высоко: подброшен нами или падает с высоты больше блока.
        boolean high = !target.isOnGround() && !target.isTouchingWater()
                && w.isSpaceEmpty(target, target.getBoundingBox().offset(0, -1.2, 0));
        boolean airborne = high || LAUNCHED.containsKey(target.getId()) && !target.isOnGround();
        if (DEBUG) {
            LOGGER.info("[jjk-test] удар {} по {}: серия {}, в воздухе {}", p.getName().getString(), target.getName().getString(), s.combo, airborne);
        }
        if (airborne) {
            // Враг в воздухе: пинок, он улетает далеко.
            s.combo = 0;
            LAUNCHED.remove(target.getId());
            push(target, new Vec3d(look.x * 1.9, 0.35, look.z * 1.9));
            stun(target, p, 20, 4);
            CursedFx fx = CursedFx.create(w, FxKind.IMPACT, at, 1.6F, 9, p).variant(1);
            fx.setYaw(p.getYaw());
            w.spawnEntity(fx);
            Moves.sound(w, at, Sounds.KICK, 1.3F, 0.95F + w.random.nextFloat() * 0.1F);
            MineviaJjk.anim(p, Payloads.Anim.KICK);
        } else if (s.combo == 4) {
            // Четвёртый удар подбрасывает: дальше телепорт, прыжок или жаба — и пинок в воздухе.
            push(target, new Vec3d(look.x * 0.25, 1.0, look.z * 0.25));
            launched(target, now);
            stun(target, p, 25, 4);
            CursedFx fx = CursedFx.create(w, FxKind.IMPACT, at, 1.5F, 9, p).variant(1);
            fx.setYaw(p.getYaw());
            w.spawnEntity(fx);
            Moves.sound(w, at, Sounds.HIT_HEAVY, 1.2F, 0.95F + w.random.nextFloat() * 0.1F);
            MineviaJjk.anim(p, Payloads.Anim.UPPERCUT);
        } else {
            MineviaJjk.anim(p, s.combo % 2 == 1 ? Payloads.Anim.PUNCH_RIGHT : Payloads.Anim.PUNCH_LEFT);
            // Свой отброс игры сбрасываем: враг остаётся под следующий удар.
            push(target, new Vec3d(look.x * 0.18, Math.min(0.05, target.getVelocity().y), look.z * 0.18));
            stun(target, p, 14, 3);
            CursedFx fx = CursedFx.create(w, FxKind.IMPACT, at, 0.8F, 6, p).variant(0);
            fx.setYaw(p.getYaw());
            w.spawnEntity(fx);
            Moves.sound(w, at, Sounds.HIT_LIGHT, 1.0F, 0.9F + 0.08F * s.combo + w.random.nextFloat() * 0.08F);
        }
    }

    static void dash(ServerPlayerEntity p, Sorcerer s, float forward, float sideways, long now) {
        if (s.dashReady > now || p.isSpectator() || p.hasVehicle()) {
            return;
        }
        s.dashReady = now + DASH_COOLDOWN;
        double yaw = Math.toRadians(p.getYaw());
        Vec3d front = new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw));
        Vec3d left = new Vec3d(Math.cos(yaw), 0, Math.sin(yaw));
        Vec3d dir = front.multiply(Math.signum(forward)).add(left.multiply(Math.signum(sideways)));
        dir = dir.lengthSquared() < 1.0E-4 ? front : dir.normalize();
        p.setVelocity(dir.x * 1.3, p.isOnGround() ? 0.12 : Math.max(0, p.getVelocity().y), dir.z * 1.3);
        p.velocityModified = true;
        p.fallDistance = 0;
        MineviaJjk.anim(p, Payloads.Anim.DASH);
        Moves.sound(p.getServerWorld(), p.getPos(), Sounds.DASH, 0.9F, 0.95F + p.getRandom().nextFloat() * 0.1F);
    }

    static void block(ServerPlayerEntity p, Sorcerer s, boolean active, long now) {
        if (active && !s.blocking) {
            s.blockStart = now;
        }
        if (active != s.blocking) {
            MineviaJjk.anim(p, active ? Payloads.Anim.BLOCK_ON : Payloads.Anim.BLOCK_OFF);
        }
        s.blocking = active;
    }

    /** Пока держишь блок, идёшь медленнее. */
    static void tick(ServerPlayerEntity p, Sorcerer s, long now) {
        if (s.blocking && now % 5 == 0) {
            p.addStatusEffect(Moves.effect(StatusEffects.SLOWNESS, 8, 1));
        }
    }

    /**
     * Удар в блок. true — игра свой урон не наносит: при парировании урона нет совсем,
     * при обычном блоке проходит четверть, её мы наносим сами.
     */
    static boolean absorb(ServerPlayerEntity p, Sorcerer s, DamageSource source, float amount, long now) {
        if (!s.blocking || s.absorbing) {
            return false;
        }
        Entity from = source.getSource() != null ? source.getSource() : source.getAttacker();
        if (from == null || from == p) {
            return false;
        }
        Vec3d to = from.getPos().subtract(p.getPos());
        to = new Vec3d(to.x, 0, to.z);
        if (to.lengthSquared() < 1.0E-4 || to.normalize().dotProduct(flatLook(p)) < 0.2) {
            return false;
        }
        ServerWorld w = p.getServerWorld();
        Vec3d at = p.getEyePos().add(to.normalize().multiply(0.7)).add(0, -0.4, 0);
        if (now - s.blockStart <= PARRY_WINDOW && source.getAttacker() instanceof LivingEntity attacker) {
            stun(attacker, p, 40, 6);
            attacker.addStatusEffect(Moves.effect(StatusEffects.WEAKNESS, 40, 2), p);
            Vec3d back = to.normalize().multiply(0.9);
            attacker.addVelocity(back.x, 0.2, back.z);
            attacker.velocityModified = true;
            CursedFx fx = CursedFx.create(w, FxKind.IMPACT, at, 1.2F, 8, p).variant(2);
            fx.setYaw(p.getYaw());
            w.spawnEntity(fx);
            Moves.sound(w, at, Sounds.PARRY, 1.2F, 1.0F);
            s.ult = Math.min(100, s.ult + 8);
            return true;
        }
        s.absorbing = true;
        try {
            p.damage(source, amount * 0.25F);
        } finally {
            s.absorbing = false;
        }
        Moves.sound(w, at, Sounds.BLOCK, 1.0F, 0.9F + w.random.nextFloat() * 0.2F);
        return true;
    }

    private static void stun(LivingEntity target, ServerPlayerEntity by, int ticks, int amplifier) {
        target.addStatusEffect(Moves.effect(StatusEffects.SLOWNESS, ticks, amplifier), by);
        if (target instanceof MobEntity mob) {
            mob.getNavigation().stop();
        }
    }

    private static Vec3d flatLook(ServerPlayerEntity p) {
        double yaw = Math.toRadians(p.getYaw());
        return new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw));
    }
}
