package local.minevia.jjk.client;

import java.util.EnumMap;
import java.util.Map;
import local.minevia.jjk.CursedFx;
import local.minevia.jjk.FxKind;
import local.minevia.jjk.MineviaJjk;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;

/** Рисует приёмы анимированными 3D-моделями из art/jjk_spells.py. Частиц игры здесь нет. */
final class FxRenderer extends EntityRenderer<CursedFx> {
    private static final Identifier WHITE = Identifier.of(MineviaJjk.MOD_ID, "textures/entity/white.png");
    private static final Map<FxKind, Look> LOOKS = new EnumMap<>(FxKind.class);
    /** Слой контура: с отсечением задних граней, поэтому от вывернутой копии остаётся только кайма. */
    private static final RenderLayer OUTLINE = RenderLayer.getEntityCutout(WHITE);

    private enum Facing {
        /** Повёрнута по направлению взгляда мага, но стоит ровно. */
        UPRIGHT,
        /** Смотрит туда, куда смотрел маг, вместе с наклоном. */
        HEADING,
        /** Смотрит туда, куда сейчас движется. */
        MOTION
    }

    /**
     * Слой модели. loop — тиков на круг анимации, 0 — проиграть один раз за всю жизнь приёма.
     * fallback — чем рисовать, пока новой модели нет в ресурсах (модели делаются отдельно, в Blender).
     */
    private record Part(String mesh, float loop, float scale, Part fallback) {
        Part(String mesh, float loop, float scale) {
            this(mesh, loop, scale, null);
        }
    }

    /**
     * grow — за сколько тиков модель вырастает до полного размера, fade — за сколько тиков до конца тает,
     * follow — висит на маге, hideOwner — не мешает магу смотреть от первого лица, roll — наклон разреза по variant.
     */
    private record Look(Facing facing, Part[] parts, int grow, int fade, float spin, boolean follow, boolean hideOwner, float lift, boolean roll) {
    }

    private static void look(FxKind kind, Facing facing, int grow, int fade, float spin, Part... parts) {
        LOOKS.put(kind, new Look(facing, parts, grow, fade, spin, false, false, 0, false));
    }

    /** Модели территорий построены в настоящих блоках, а приём растёт до радиуса: делим обратно. */
    private static final float VOID_R = 1 / 12F;
    private static final float SHRINE_R = 1 / 16F;

    static {
        // Синий без сферы: только притягивающие ленты и искажение вокруг точки.
        look(FxKind.BLUE, Facing.UPRIGHT, 4, 4, 0, new Part("blue_pull", 16, 1, new Part("infinity_shell", 20, 0.9F)));
        look(FxKind.HAND_BLUE, Facing.UPRIGHT, 3, 0, 9, new Part("blue_orb", 24, 0.24F));
        look(FxKind.HAND_RED, Facing.UPRIGHT, 3, 0, -9, new Part("red_orb", 12, 0.24F));
        look(FxKind.RED, Facing.HEADING, 2, 0, 0, new Part("red_orb", 12, 1));
        look(FxKind.RED_BURST, Facing.UPRIGHT, 0, 0, 0, new Part("red_burst", 0, 1));
        look(FxKind.PURPLE, Facing.UPRIGHT, 8, 8, 3, new Part("purple_orb", 20, 1));
        LOOKS.put(FxKind.INFINITY, new Look(Facing.UPRIGHT, new Part[] {new Part("infinity_shell", 40, 1)}, 5, 10, 0, true, true, 0, false));
        look(FxKind.VOID_DOME, Facing.UPRIGHT, 12, 15, 0, new Part("infinite_void", 80, VOID_R, new Part("void_dome", 80, 1)));
        LOOKS.put(FxKind.SLASH, new Look(Facing.HEADING, new Part[] {new Part("slash_wave", 6, 1)}, 2, 3, 0, false, false, 0, true));
        LOOKS.put(FxKind.CLEAVE, new Look(Facing.UPRIGHT, new Part[] {new Part("cleave_cuts", 0, 1)}, 0, 0, 0, false, false, 0, true));
        look(FxKind.FLAME_ARROW, Facing.HEADING, 3, 0, 0, new Part("flame_arrow", 16, 1));
        look(FxKind.FLAME_BURST, Facing.UPRIGHT, 0, 0, 0, new Part("flame_burst", 0, 1));
        look(FxKind.SHRINE, Facing.UPRIGHT, 14, 15, 0, new Part("malevolent_shrine", 40, SHRINE_R));
        LOOKS.put(FxKind.SHRINE_POOL, new Look(Facing.UPRIGHT,
                new Part[] {new Part("shrine_pool", 40, SHRINE_R, new Part("shrine_ring", 48, 1))}, 10, 15, 0, false, false, 0.04F, false));
        LOOKS.put(FxKind.SHRINE_CUT, new Look(Facing.UPRIGHT, new Part[] {new Part("cleave_cuts", 0, 1)}, 0, 0, 0, false, false, 0, true));
        look(FxKind.NUE, Facing.MOTION, 4, 4, 0, new Part("nue", 12, 1));
        look(FxKind.NUE_STRIKE, Facing.UPRIGHT, 0, 0, 0, new Part("nue_strike", 0, 1));
        LOOKS.put(FxKind.SHADOW_POOL, new Look(Facing.UPRIGHT, new Part[] {new Part("shadow_pool", 0, 1)}, 0, 0, 0, false, false, 0.03F, false));
        LOOKS.put(FxKind.SHADOW_GARDEN, new Look(Facing.UPRIGHT, new Part[] {new Part("shadow_garden", 60, 1)}, 10, 15, 0, false, false, 0.03F, false));
        look(FxKind.BLACK_FLASH, Facing.UPRIGHT, 0, 0, 0, new Part("black_flash", 0, 1));
        look(FxKind.IMPACT, Facing.UPRIGHT, 0, 0, 0, new Part("impact", 0, 1));
        look(FxKind.TONGUE, Facing.HEADING, 0, 2, 0, new Part("tongue", 0, 1));
        look(FxKind.DIVERGENT, Facing.HEADING, 0, 4, 0, new Part("divergent_fist", 0, 1, new Part("impact_2", 0, 0.9F)));
        look(FxKind.DASH_TRAIL, Facing.UPRIGHT, 0, 5, 0, new Part("dash_trail", 0, 1));
        look(FxKind.KICK_ARC, Facing.UPRIGHT, 0, 3, 0, new Part("kick_arc", 0, 1, new Part("slash_wave", 0, 0.8F)));
        look(FxKind.SUKUNA_AWAKEN, Facing.UPRIGHT, 0, 0, 0, new Part("sukuna_awaken", 0, 1, new Part("flame_burst", 0, 1.2F)));
        look(FxKind.PROJECTION_FRAME, Facing.UPRIGHT, 2, 4, 0, new Part("projection_frame", 0, 1, new Part("infinity_shell", 40, 0.7F)));
        look(FxKind.SPEED_RIBBONS, Facing.UPRIGHT, 0, 4, 0, new Part("speed_ribbons", 0, 1));
        look(FxKind.SONIC_BOOM, Facing.HEADING, 0, 4, 0, new Part("sonic_boom", 0, 1, new Part("red_burst", 0, 0.8F)));
        look(FxKind.NAOYA_DOMAIN, Facing.UPRIGHT, 12, 15, 0, new Part("naoya_domain", 80, VOID_R, new Part("void_dome", 80, 1)));
    }

    private static final float SKILL_SCALE = 0.8F;
    private static final java.util.Set<FxKind> FULL_SIZE = java.util.EnumSet.of(FxKind.VOID_DOME, FxKind.SHRINE, FxKind.SHRINE_POOL,
            FxKind.SHADOW_GARDEN, FxKind.NAOYA_DOMAIN, FxKind.INFINITY, FxKind.TONGUE, FxKind.PROJECTION_FRAME);

    /** У этих приёмов модель выбирается по variant: impact_0, impact_1 и так далее. */
    private static final java.util.Set<FxKind> BY_VARIANT = java.util.EnumSet.of(FxKind.IMPACT);
    /** Эти модели тянутся вперёд на variant блоков: язык жабы от рта до цели. */
    private static final java.util.Set<FxKind> STRETCH = java.util.EnumSet.of(FxKind.TONGUE);

    FxRenderer(EntityRendererFactory.Context context) {
        super(context);
    }

    @Override
    public boolean shouldRender(CursedFx fx, Frustum frustum, double x, double y, double z) {
        Look look = LOOKS.get(fx.kind());
        if (look == null) {
            return false;
        }
        if (look.follow()) {
            return true;
        }
        float reach = 0;
        for (Part wanted : look.parts()) {
            Part part = present(wanted, fx);
            if (part == null) {
                continue;
            }
            FxMesh mesh = FxMesh.get(BY_VARIANT.contains(fx.kind()) ? part.mesh() + "_" + fx.variant() : part.mesh());
            if (mesh != null) {
                reach = Math.max(reach, mesh.extent() * part.scale() * (STRETCH.contains(fx.kind()) ? Math.max(1, fx.variant()) : 1));
            }
        }
        double r = reach * fx.size() * 1.2 + 1;
        // Мелкий приём вдали — пара пикселей: не рисуем дальше, чем 40 его размеров (но не ближе 32 блоков).
        double far = Math.max(32, r * 40);
        double dx = fx.getX() - x;
        double dy = fx.getY() - y;
        double dz = fx.getZ() - z;
        if (dx * dx + dy * dy + dz * dz > far * far) {
            return false;
        }
        return frustum.isVisible(new Box(fx.getX() - r, fx.getY() - r, fx.getZ() - r, fx.getX() + r, fx.getY() + r, fx.getZ() + r));
    }

    @Override
    public void render(CursedFx fx, float yaw, float delta, MatrixStack matrices, VertexConsumerProvider consumers, int light) {
        if (ShaderCompat.shadowPass()) {
            return;
        }
        Look look = LOOKS.get(fx.kind());
        if (look == null) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        Entity owner = fx.ownerEntity();
        if (look.hideOwner() && owner == client.player && !client.gameRenderer.getCamera().isThirdPerson()) {
            return;
        }
        float age = fx.age + delta;
        float life = Math.max(1, fx.life());
        float grown = look.grow() > 0 ? MathHelper.clamp(age / look.grow(), 0, 1) : 1;
        grown = 1 - (1 - grown) * (1 - grown);
        float alpha = look.fade() > 0 ? MathHelper.clamp((life - age) / look.fade(), 0, 1) : 1;
        // Приёмы чуть меньше, чем раньше; территории и щит — в полный размер.
        float scale = fx.size() * Math.max(0.05F, grown) * (FULL_SIZE.contains(fx.kind()) ? 1 : SKILL_SCALE);

        matrices.push();
        if (look.follow() && owner != null) {
            Vec3d self = fx.getLerpedPos(delta);
            Vec3d at = owner.getLerpedPos(delta);
            matrices.translate(at.x - self.x, at.y - self.y + owner.getHeight() * 0.5, at.z - self.z);
            scale *= Math.max(owner.getHeight(), owner.getWidth() * 1.4F) * 0.62F;
        }
        matrices.translate(0, look.lift(), 0);
        float turn = fx.getYaw();
        float tilt = fx.getPitch();
        if (look.facing() == Facing.MOTION) {
            Vec3d move = fx.getPos().subtract(fx.prevX, fx.prevY, fx.prevZ);
            if (move.lengthSquared() > 1.0E-4) {
                turn = (float) Math.toDegrees(Math.atan2(-move.x, move.z));
                tilt = (float) -Math.toDegrees(Math.atan2(move.y, move.horizontalLength()));
            }
        }
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-turn));
        if (look.facing() != Facing.UPRIGHT) {
            matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(tilt));
        }
        if (look.roll()) {
            matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((fx.variant() - 1) * 35));
        }
        if (look.spin() != 0) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(age * look.spin()));
        }
        RenderLayer layer = ShaderCompat.glow();
        boolean byVariant = BY_VARIANT.contains(fx.kind());
        float stretch = STRETCH.contains(fx.kind()) ? Math.max(1, fx.variant()) : 1;
        for (Part wanted : look.parts()) {
            Part part = present(wanted, fx);
            FxMesh mesh = part == null ? null : FxMesh.get(byVariant ? part.mesh() + "_" + fx.variant() : part.mesh());
            if (mesh == null) {
                continue;
            }
            matrices.push();
            float s = scale * part.scale();
            matrices.scale(s, s, s * stretch);
            boolean loop = part.loop() > 0;
            float phase = loop ? age / part.loop() * mesh.frames() : age / life * (mesh.frames() - 1);
            String name = byVariant ? part.mesh() + "_" + fx.variant() : part.mesh();
            FxMesh line = alpha > 0.5F ? FxMesh.get(name + "_line") : null;
            if (line != null) {
                // Контур в аниме-стиле: вывернутая раздутая копия, у неё видна только кайма вокруг силуэта.
                line.draw(matrices.peek(), consumers.getBuffer(OUTLINE), phase, loop, 0xFFFFFF, 1,
                        LightmapTextureManager.MAX_LIGHT_COORDINATE, FxMesh.Surface.PLAIN);
            }
            mesh.draw(matrices.peek(), consumers.getBuffer(layer), phase, loop, 0xFFFFFF, alpha,
                    LightmapTextureManager.MAX_LIGHT_COORDINATE, FxMesh.Surface.PLAIN);
            matrices.pop();
        }
        matrices.pop();
    }

    /** Новая модель, если она уже есть в ресурсах, иначе запасная. */
    private static Part present(Part part, CursedFx fx) {
        while (part != null) {
            String name = BY_VARIANT.contains(fx.kind()) ? part.mesh() + "_" + fx.variant() : part.mesh();
            if (FxMesh.get(name) != null) {
                return part;
            }
            part = part.fallback();
        }
        return null;
    }

    @Override
    public Identifier getTexture(CursedFx fx) {
        return WHITE;
    }
}
