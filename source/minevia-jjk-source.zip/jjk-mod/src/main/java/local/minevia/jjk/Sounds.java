package local.minevia.jjk;

import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Свои звуки мода: сделаны локально (art/jjk_sounds), варианты каждого звука перечислены в sounds.json. */
public final class Sounds {
    public static final SoundEvent HIT_LIGHT = register("hit_light");
    public static final SoundEvent HIT_HEAVY = register("hit_heavy");
    public static final SoundEvent DASH = register("dash");
    public static final SoundEvent BLOCK = register("block");
    public static final SoundEvent PARRY = register("parry");
    public static final SoundEvent BLACK_FLASH = register("black_flash");
    public static final SoundEvent BLUE = register("blue");
    public static final SoundEvent RED_SHOT = register("red_shot");
    public static final SoundEvent RED_BOOM = register("red_boom");
    public static final SoundEvent PURPLE = register("purple");
    public static final SoundEvent INFINITY = register("infinity");
    public static final SoundEvent SLASH = register("slash");
    public static final SoundEvent CLEAVE = register("cleave");
    public static final SoundEvent FLAME_SHOT = register("flame_shot");
    public static final SoundEvent FLAME_BOOM = register("flame_boom");
    public static final SoundEvent DOGS = register("dogs");
    public static final SoundEvent NUE = register("nue");
    public static final SoundEvent THUNDER = register("thunder");
    public static final SoundEvent SHADOW_STEP = register("shadow_step");
    public static final SoundEvent DOMAIN = register("domain");
    public static final SoundEvent TELEPORT = register("teleport");
    public static final SoundEvent TOAD = register("toad");
    public static final SoundEvent KICK = register("kick");

    private Sounds() {
    }

    private static SoundEvent register(String name) {
        Identifier id = Identifier.of(MineviaJjk.MOD_ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    /** Загружает класс, а с ним и регистрацию звуков, в нужный момент запуска. */
    static void init() {
    }
}
