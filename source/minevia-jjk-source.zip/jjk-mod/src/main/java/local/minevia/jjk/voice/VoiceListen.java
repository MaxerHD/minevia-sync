package local.minevia.jjk.voice;

import com.sun.jna.Native;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.function.BiConsumer;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;
import org.vosk.Recognizer;

/**
 * Голосом: «Расширение территории», «Domain expansion» или «Рёики тэнкай» в микрофон голосового чата.
 * Распознаёт Vosk с маленькой русской моделью прямо на компьютере, без интернета. Слушаем только тех, у кого идёт
 * ульта и территория ещё не открывалась, — в остальное время звук даже не разбирается.
 * Вся работа с распознавателем — в одном своём потоке: его объекты не любят, когда их трогают из разных потоков.
 */
public final class VoiceListen {
    private static final Logger LOGGER = LoggerFactory.getLogger("minevia_jjk");
    private static final String MODEL = "vosk-model-small-ru-0.22";
    /**
     * Модель русская, поэтому английскую и японскую фразу она слышит русскими словами: «дом мейн экспансия»,
     * «рио ики тен кай». Подобрано на записях разных голосов (D:\Rudnik\voice), см. {@link #matches}.
     */
    private static final String GRAMMAR = "[\"расширение территории\", \"дом мейн экспансия\", \"домен экспансия\", "
            + "\"рио ики тен кай\", \"реки тен кай\", \"[unk]\"]";
    /** Голосовой чат не шлёт тишину: замолчал на столько миллисекунд — фраза закончена. */
    private static final long PAUSE_MS = 400;

    private static final ScheduledExecutorService WORKER = Executors.newSingleThreadScheduledExecutor(task -> {
        Thread thread = new Thread(task, "minevia-voice");
        thread.setDaemon(true);
        return thread;
    });
    private static final Set<UUID> LISTENING = ConcurrentHashMap.newKeySet();
    private static final Map<UUID, Recognizer> RECOGNIZERS = new ConcurrentHashMap<>();
    private static final Map<UUID, Long> LAST_SOUND = new ConcurrentHashMap<>();
    private static volatile boolean enabled;
    private static Model model;
    private static boolean broken;
    private static BiConsumer<UUID, String> heard = (id, text) -> { };

    private VoiceListen() {
    }

    /** Голосовой чат подключился: можно слушать. */
    static void enable() {
        enabled = true;
        WORKER.scheduleWithFixedDelay(VoiceListen::endPauses, 200, 100, TimeUnit.MILLISECONDS);
    }

    public static boolean enabled() {
        return enabled;
    }

    /** Кому сообщить услышанное: id игрока и текст, если это одна из фраз. */
    public static void onPhrase(BiConsumer<UUID, String> callback) {
        heard = callback;
    }

    /** Сервер раз в полсекунды говорит, кого слушать. */
    public static void listen(UUID id, boolean on) {
        if (on) {
            if (LISTENING.add(id)) {
                WORKER.execute(VoiceListen::loadModel);
            }
        } else if (LISTENING.remove(id)) {
            WORKER.execute(() -> close(id));
        }
    }

    public static boolean listening(UUID id) {
        return enabled && LISTENING.contains(id);
    }

    /** Звук 48 кГц моно из голосового чата. decode вызывается уже в потоке распознавания. */
    static void feed(UUID id, java.util.function.Supplier<short[]> decode) {
        WORKER.execute(() -> {
            if (!LISTENING.contains(id)) {
                return;
            }
            short[] pcm = decode.get();
            if (pcm != null && pcm.length > 0) {
                accept(id, downsample(pcm));
            }
        });
    }

    /** Проверка без микрофона: WAV 16 кГц моно 16 бит (команда /jjk voice). Ответ — что услышано. */
    public static void test(UUID id, Path wav, BiConsumer<String, Boolean> answer) {
        WORKER.execute(() -> {
            try {
                byte[] all = Files.readAllBytes(wav);
                short[] pcm = new short[(all.length - 44) / 2];
                ByteBuffer.wrap(all, 44, all.length - 44).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(pcm);
                loadModel();
                if (model == null) {
                    answer.accept("модель не загрузилась", false);
                    return;
                }
                try (Recognizer rec = new Recognizer(model, 16000, toNative(GRAMMAR))) {
                    for (int off = 0; off < pcm.length; off += 3200) {
                        int n = Math.min(3200, pcm.length - off);
                        short[] chunk = new short[n];
                        System.arraycopy(pcm, off, chunk, 0, n);
                        rec.acceptWaveForm(chunk, n);
                    }
                    String text = text(rec.getFinalResult());
                    boolean match = matches(text);
                    answer.accept(text, match);
                    if (match) {
                        heard.accept(id, text);
                    }
                }
            } catch (IOException | RuntimeException problem) {
                answer.accept("ошибка: " + problem.getMessage(), false);
            }
        });
    }

    private static void accept(UUID id, short[] pcm16k) {
        if (model == null) {
            return;
        }
        Recognizer rec = RECOGNIZERS.computeIfAbsent(id, key -> {
            try {
                return new Recognizer(model, 16000, toNative(GRAMMAR));
            } catch (RuntimeException problem) {
                LOGGER.warn("Распознаватель голоса не создался", problem);
                return null;
            }
        });
        if (rec == null) {
            return;
        }
        LAST_SOUND.put(id, System.currentTimeMillis());
        if (rec.acceptWaveForm(pcm16k, pcm16k.length)) {
            report(id, rec.getResult());
        }
    }

    /** Игрок замолчал: дослушиваем фразу до конца. */
    private static void endPauses() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, Long> entry : LAST_SOUND.entrySet()) {
            if (now - entry.getValue() > PAUSE_MS) {
                LAST_SOUND.remove(entry.getKey());
                Recognizer rec = RECOGNIZERS.get(entry.getKey());
                if (rec != null) {
                    report(entry.getKey(), rec.getFinalResult());
                    rec.reset();
                }
            }
        }
    }

    private static void report(UUID id, String json) {
        String text = text(json);
        if (matches(text)) {
            LOGGER.info("[jjk-voice] услышал «{}»", text);
            heard.accept(id, text);
        }
    }

    /**
     * Фраза целиком и короткая. Русская — слова подряд; английская — «мейн экспансия» или «домен экспансия» подряд;
     * японская — «тен кай» в конце короткой фразы. Так обычная болтовня с этими словами вразнобой не срабатывает.
     */
    static boolean matches(String text) {
        String t = " " + text.trim().replaceAll("\\s+", " ") + " ";
        int words = t.trim().isEmpty() ? 0 : t.trim().split(" ").length;
        if (words == 0 || words > 5) {
            return false;
        }
        return t.contains(" расширение территории ")
                || t.contains(" мейн экспансия ") || t.contains(" домен экспансия ")
                || t.endsWith(" тен кай ") && words <= 4;
    }

    private static short[] downsample(short[] pcm48k) {
        short[] out = new short[pcm48k.length / 3];
        for (int i = 0; i < out.length; i++) {
            out[i] = (short) ((pcm48k[i * 3] + pcm48k[i * 3 + 1] + pcm48k[i * 3 + 2]) / 3);
        }
        return out;
    }

    private static void close(UUID id) {
        LAST_SOUND.remove(id);
        Recognizer rec = RECOGNIZERS.remove(id);
        if (rec != null) {
            rec.close();
        }
    }

    /** Модель лежит в jar архивом; при первом использовании распаковывается в config/minevia_jjk/voice. */
    private static void loadModel() {
        if (model != null || broken) {
            return;
        }
        try {
            LibVosk.setLogLevel(LogLevel.WARNINGS);
            Path dir = FabricLoader.getInstance().getConfigDir().resolve("minevia_jjk").resolve("voice");
            Path root = dir.resolve(MODEL);
            Path done = dir.resolve(MODEL + ".ready");
            if (!Files.exists(done)) {
                unpack(dir);
                Files.writeString(done, "ok");
            }
            long start = System.currentTimeMillis();
            model = new Model(root.toAbsolutePath().toString());
            LOGGER.info("[jjk-voice] модель речи загружена за {} мс", System.currentTimeMillis() - start);
        } catch (IOException | RuntimeException | Error problem) {
            broken = true;
            LOGGER.warn("Голосовые фразы отключены: распознаватель не запустился", problem);
        }
    }

    private static void unpack(Path dir) throws IOException {
        try (InputStream raw = VoiceListen.class.getResourceAsStream("/minevia_jjk_voice/" + MODEL + ".zip")) {
            if (raw == null) {
                throw new IOException("в моде нет модели речи");
            }
            try (ZipInputStream zip = new ZipInputStream(raw)) {
                ZipEntry entry;
                while ((entry = zip.getNextEntry()) != null) {
                    Path to = dir.resolve(entry.getName()).normalize();
                    if (!to.startsWith(dir)) {
                        continue;
                    }
                    if (entry.isDirectory()) {
                        Files.createDirectories(to);
                    } else {
                        Files.createDirectories(to.getParent());
                        Files.copy(zip, to, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                    }
                }
            }
        }
    }

    /**
     * Строки в Vosk уходят через JNA в кодировке Windows по умолчанию (у русской системы cp1251), а модель ждёт UTF-8.
     * Поэтому кириллицу заранее перекладываем так, чтобы после перекодировки получились нужные байты UTF-8.
     */
    private static Charset nativeCharset() {
        try {
            return Charset.forName(Native.getDefaultStringEncoding());
        } catch (RuntimeException problem) {
            return StandardCharsets.UTF_8;
        }
    }

    private static String toNative(String value) {
        Charset charset = nativeCharset();
        return charset.equals(StandardCharsets.UTF_8) ? value : new String(value.getBytes(StandardCharsets.UTF_8), charset);
    }

    private static String fromNative(String value) {
        Charset charset = nativeCharset();
        return charset.equals(StandardCharsets.UTF_8) ? value : new String(value.getBytes(charset), StandardCharsets.UTF_8);
    }

    private static String text(String json) {
        String value = fromNative(json);
        int i = value.indexOf("\"text\"");
        if (i < 0) {
            return "";
        }
        int a = value.indexOf('"', value.indexOf(':', i) + 1);
        int b = value.indexOf('"', a + 1);
        return a < 0 || b < 0 ? "" : value.substring(a + 1, b).trim();
    }
}
