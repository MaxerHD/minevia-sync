package local.minevia.jjk;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Видимая часть приёма: 3D-модель, которую рисует клиент. На сервере у неё есть поведение — полёт,
 * попадание, притяжение. В мир не сохраняется: после перезахода никаких остатков приёмов.
 */
public final class CursedFx extends Entity {
    /** Что делает приём каждый тик на сервере. */
    public interface Behavior {
        void tick(CursedFx fx);
    }

    private static final TrackedData<Byte> KIND = DataTracker.registerData(CursedFx.class, TrackedDataHandlerRegistry.BYTE);
    private static final TrackedData<Float> SIZE = DataTracker.registerData(CursedFx.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Integer> OWNER = DataTracker.registerData(CursedFx.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> LIFE = DataTracker.registerData(CursedFx.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Byte> VARIANT = DataTracker.registerData(CursedFx.class, TrackedDataHandlerRegistry.BYTE);

    private ServerPlayerEntity caster;
    private Behavior behavior;
    /** Кого приём уже задел: сквозные приёмы бьют каждого один раз. */
    public final Set<Integer> hit = new HashSet<>();
    public Vec3d from = Vec3d.ZERO;
    public Vec3d to = Vec3d.ZERO;

    public CursedFx(EntityType<? extends CursedFx> type, World world) {
        super(type, world);
        noClip = true;
        setNoGravity(true);
    }

    public static CursedFx create(World world, FxKind kind, Vec3d pos, float size, int life, ServerPlayerEntity caster) {
        CursedFx fx = new CursedFx(MineviaJjk.FX, world);
        fx.dataTracker.set(KIND, (byte) kind.ordinal());
        fx.dataTracker.set(SIZE, size);
        fx.dataTracker.set(LIFE, life);
        fx.caster = caster;
        fx.dataTracker.set(OWNER, caster == null ? -1 : caster.getId());
        fx.refreshPositionAndAngles(pos.x, pos.y, pos.z, caster == null ? 0 : caster.getYaw(), caster == null ? 0 : caster.getPitch());
        return fx;
    }

    public CursedFx behavior(Behavior value) {
        behavior = value;
        return this;
    }

    public CursedFx variant(int value) {
        dataTracker.set(VARIANT, (byte) value);
        return this;
    }

    public CursedFx velocity(Vec3d value) {
        setVelocity(value);
        return this;
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        builder.add(KIND, (byte) 0);
        builder.add(SIZE, 1.0F);
        builder.add(OWNER, -1);
        builder.add(LIFE, 20);
        builder.add(VARIANT, (byte) 0);
    }

    public FxKind kind() {
        return FxKind.of(dataTracker.get(KIND));
    }

    public float size() {
        return dataTracker.get(SIZE);
    }

    public void setSize(float value) {
        dataTracker.set(SIZE, value);
    }

    public int life() {
        return dataTracker.get(LIFE);
    }

    public int variant() {
        return dataTracker.get(VARIANT);
    }

    public ServerPlayerEntity caster() {
        return caster;
    }

    /** Хозяин приёма на клиенте: за ним следуют щит Бесконечности и прочие модели «на теле». */
    public Entity ownerEntity() {
        int id = dataTracker.get(OWNER);
        return id < 0 ? null : getWorld().getEntityById(id);
    }

    public DamageSource damage() {
        return Moves.source(this, caster);
    }

    public boolean hurt(LivingEntity target, float amount) {
        return target.damage(damage(), amount);
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient()) {
            return;
        }
        if (age > life() || caster != null && caster.isRemoved() && behavior != null) {
            discard();
            return;
        }
        Vec3d motion = getVelocity();
        if (motion.lengthSquared() > 0) {
            setPosition(getPos().add(motion));
        }
        if (behavior != null) {
            behavior.tick(this);
        }
    }

    @Override
    public boolean shouldSave() {
        return false;
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        return false;
    }

    @Override
    public boolean shouldRender(double distance) {
        double reach = 96 + size() * 8;
        return distance < reach * reach;
    }

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
    }
}
