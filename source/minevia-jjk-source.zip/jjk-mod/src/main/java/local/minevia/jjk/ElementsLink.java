package local.minevia.jjk;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.world.PersistentState;

/**
 * Режим «12 начал»: у игрока одно начало — стихия или стиль из мода стихий, либо проклятая техника.
 * Выбрал технику — стихия снимается, выбрал стихию — снимается техника (опыт техники при этом остаётся).
 * Мод стихий подключается без прямой зависимости: без него техники работают как раньше.
 * Через отражение вызываются только классы самих модов Minevia, их имена при сборке не меняются.
 */
final class ElementsLink {
    static final boolean LOADED = FabricLoader.getInstance().isModLoaded("minevia_elements");

    private static Method get;
    private static Method find;
    private static Method sync;
    private static Method key;
    private static Method forget;
    private static Field element;
    private static Field path;
    private static Field skills;
    private static boolean ready;

    static {
        if (LOADED) {
            try {
                Class<?> state = Class.forName("local.minevia.elements.ElementState");
                Class<?> data = Class.forName("local.minevia.elements.ElementState$Data");
                get = state.getMethod("get", MinecraftServer.class);
                find = state.getMethod("find", UUID.class);
                sync = Class.forName("local.minevia.elements.MineviaElements").getMethod("sync", ServerPlayerEntity.class);
                key = Class.forName("local.minevia.elements.Element").getMethod("key");
                forget = Class.forName("local.minevia.elements.Abilities").getMethod("forget", UUID.class);
                element = data.getField("element");
                path = data.getField("path");
                skills = data.getField("skills");
                ready = true;
            } catch (ReflectiveOperationException | RuntimeException problem) {
                Combat.LOGGER.warn("Мод стихий найден, но связать его с техниками не вышло: выбор будет раздельным", problem);
            }
        }
    }

    private ElementsLink() {
    }

    static boolean active() {
        return ready;
    }

    /** Ключ перевода стихии или стиля игрока; пустая строка, если не выбраны. */
    static String elementKey(ServerPlayerEntity p) {
        if (!ready) {
            return "";
        }
        try {
            Object data = find.invoke(get.invoke(null, p.getServer()), p.getUuid());
            Object chosen = data == null ? null : element.get(data);
            return chosen == null ? "" : (String) key.invoke(chosen);
        } catch (ReflectiveOperationException | RuntimeException problem) {
            return "";
        }
    }

    /** Снимает стихию так же, как её смена в самом моде: путь и опыт навыков сбрасываются, уровень остаётся. */
    static boolean clearElement(ServerPlayerEntity p) {
        if (!ready) {
            return false;
        }
        try {
            Object state = get.invoke(null, p.getServer());
            Object data = find.invoke(state, p.getUuid());
            if (data == null || element.get(data) == null) {
                return false;
            }
            element.set(data, null);
            path.setInt(data, 0);
            Arrays.fill((int[]) skills.get(data), 0);
            ((PersistentState) state).markDirty();
            forget.invoke(null, p.getUuid());
            sync.invoke(null, p);
            return true;
        } catch (ReflectiveOperationException | RuntimeException problem) {
            Combat.LOGGER.warn("Не вышло снять стихию у {}", p.getName().getString(), problem);
            return false;
        }
    }
}
