package local.minevia.jjk.client;

import java.util.ArrayList;
import java.util.List;
import local.minevia.jjk.Payloads;
import local.minevia.jjk.mixin.KeyBindingAccessor;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;

/**
 * «12 начал»: в одной сборке с модом стихий. G и J у обоих модов одни и те же, а игра отдаёт нажатие только одной
 * привязке. Поэтому нажатие получает тот мод, чьё начало выбрано: есть техника — техники, иначе стихии.
 * На экран выбора стихии добавляется переход к техникам, в меню техник — обратно к стихиям.
 */
final class ElementsBridge {
    static final boolean LOADED = FabricLoader.getInstance().isModLoaded("minevia_elements");
    private static final String SELECTION = "local.minevia.elements.client.SelectionScreen";
    private static final String KEY_PREFIX = "key.minevia_elements.";
    private static final int BUTTON_W = 128;
    private static final int BUTTON_H = 18;

    /** Экран выбора стихии, открытый из меню техник: его не закрываем, даже если техника есть. */
    private static Screen opened;

    private ElementsBridge() {
    }

    static void init() {
        if (!LOADED) {
            return;
        }
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> {
            if (!isSelection(screen)) {
                return;
            }
            // Экран стихий сам закрашивает всё поверх кнопок, поэтому переход рисуем после него.
            ScreenEvents.afterRender(screen).register((s, context, mouseX, mouseY, delta) -> drawLink(s, context, mouseX, mouseY));
            ScreenMouseEvents.allowMouseClick(screen).register((s, mouseX, mouseY, button) -> {
                if (button != 0 || !inLink(s, mouseX, mouseY)) {
                    return true;
                }
                if (ClientPlayNetworking.canSend(Payloads.Open.ID)) {
                    ClientPlayNetworking.send(new Payloads.Open());
                }
                return false;
            });
        });
    }

    static boolean isSelection(Screen screen) {
        return screen != null && screen.getClass().getName().equals(SELECTION);
    }

    /** Открыть выбор стихии из меню техник. */
    static void openSelection(MinecraftClient client) {
        try {
            Screen screen = (Screen) Class.forName(SELECTION).getConstructor().newInstance();
            opened = screen;
            client.setScreen(screen);
        } catch (ReflectiveOperationException | RuntimeException problem) {
            client.inGameHud.setOverlayMessage(net.minecraft.text.Text.literal("Выбор стихий: J без техники"), false);
        }
    }

    /** Мод стихий сам открывает свой выбор, когда стихии нет. У мага с техникой этот экран лишний. */
    static void closeExtraSelection(MinecraftClient client) {
        if (!LOADED) {
            return;
        }
        Screen screen = client.currentScreen;
        if (screen != opened) {
            opened = null;
        }
        if (isSelection(screen) && screen != opened && JjkHud.hasTechnique()) {
            client.setScreen(null);
        }
    }

    /**
     * В начале тика, раньше обоих модов: собираем нажатия всех привязок на клавишах техник, которые делят с модом
     * стихий, и отдаём их одной. Удержание берём с самой клавиши: игра помечает нажатой только одну привязку.
     */
    static void route(MinecraftClient client, KeyBinding... ours) {
        if (!LOADED || client.player == null || client.currentScreen != null) {
            return;
        }
        boolean technique = JjkHud.hasTechnique();
        for (KeyBinding mine : ours) {
            InputUtil.Key key = KeyBindingHelper.getBoundKeyOf(mine);
            if (key.equals(InputUtil.UNKNOWN_KEY)) {
                continue;
            }
            List<KeyBinding> theirs = new ArrayList<>();
            for (KeyBinding other : client.options.allKeys) {
                if (other != mine && other.getTranslationKey().startsWith(KEY_PREFIX) && KeyBindingHelper.getBoundKeyOf(other).equals(key)) {
                    theirs.add(other);
                }
            }
            if (theirs.isEmpty()) {
                continue;
            }
            int presses = times(mine);
            boolean held = mine.isPressed();
            for (KeyBinding other : theirs) {
                presses += times(other);
                held |= other.isPressed();
            }
            if (key.getCategory() == InputUtil.Type.KEYSYM) {
                held = InputUtil.isKeyPressed(client.getWindow().getHandle(), key.getCode());
            }
            give(mine, technique, presses, held);
            for (KeyBinding other : theirs) {
                give(other, !technique, presses, held);
            }
        }
    }

    private static int times(KeyBinding binding) {
        return ((KeyBindingAccessor) binding).minevia$getTimesPressed();
    }

    private static void give(KeyBinding binding, boolean owner, int presses, boolean held) {
        ((KeyBindingAccessor) binding).minevia$setTimesPressed(owner ? presses : 0);
        binding.setPressed(owner && held);
    }

    private static int linkX(Screen screen) {
        return screen.width - BUTTON_W - 6;
    }

    private static boolean inLink(Screen screen, double mouseX, double mouseY) {
        int x = linkX(screen);
        return mouseX >= x && mouseX < x + BUTTON_W && mouseY >= 5 && mouseY < 5 + BUTTON_H;
    }

    /** Кнопка в цветах карточек экрана стихий, с фиолетовой полосой проклятой энергии. */
    private static void drawLink(Screen screen, DrawContext context, int mouseX, int mouseY) {
        int x = linkX(screen);
        int y = 5;
        boolean hover = inLink(screen, mouseX, mouseY);
        context.fill(x, y, x + BUTTON_W, y + BUTTON_H, hover ? 0xFF26364A : 0xFF152132);
        context.fill(x, y, x + 2, y + BUTTON_H, 0xFFB48CFF);
        var text = MinecraftClient.getInstance().textRenderer;
        context.drawCenteredTextWithShadow(text, "Проклятые техники ›", x + BUTTON_W / 2 + 1, y + 5, hover ? 0xFFFFFFFF : 0xFFD9C8FF);
    }
}
